// Alma Chaab service worker — PWA install + offline shell for /admin + Web Push (new orders)
const CACHE = "alma-shell-v3";
const SHELL = ["/admin", "/icon-192.png", "/icon-512.png", "/manifest.webmanifest"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  // Never cache API or admin data — always live
  if (url.pathname.startsWith("/api/") || e.request.method !== "GET") return;
  if (url.pathname === "/admin" || url.pathname.startsWith("/icons")) {
    e.respondWith(
      fetch(e.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
          return res;
        })
        .catch(() => caches.match(e.request))
    );
  }
});

/* ---------------- Web Push: new order / reservation alerts ---------------- */

self.addEventListener("push", (e) => {
  let data = {};
  try {
    data = e.data ? e.data.json() : {};
  } catch {
    data = { title: "Alma Chaab", body: e.data ? e.data.text() : "" };
  }
  const options = {
    body: data.body || "",
    tag: data.tag || "alma-order",
    renotify: true, // re-alert even if a previous notification with same tag is on screen
    // Owner order alerts stay on screen until tapped; marketing/loyalty
    // pushes (no orderId) behave like normal notifications.
    requireInteraction: Boolean(data.orderId),
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    vibrate: data.orderId ? [300, 120, 300, 120, 300] : [120],
    data: { url: data.url || (data.orderId ? "/admin" : "/"), orderId: data.orderId || "" },
    actions:
      data.orderId
        ? [
            { action: "accept", title: "✓ Priimti" },
            { action: "open", title: "Atidaryti" },
          ]
        : [],
  };
  e.waitUntil(self.registration.showNotification(data.title || "Alma Chaab", options));
});

self.addEventListener("notificationclick", (e) => {
  const n = e.notification;
  n.close();
  const base = (n.data && n.data.url) || "/admin";
  const orderId = (n.data && n.data.orderId) || "";

  if (e.action === "accept" && orderId) {
    // Try to accept the order right away (works when the owner browser session
    // cookie is still valid); otherwise just open the order in admin.
    e.waitUntil(
      (async () => {
        try {
          const res = await fetch(`/api/admin/orders/${orderId}`, {
            method: "PATCH",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: "confirmed" }),
          });
          if (res.ok) {
            await self.registration.showNotification("Užsakymas priimtas ✓", {
              body: "Klientui išsiųstas patvirtinimas.",
              icon: "/icon-192.png",
              tag: "alma-accepted",
            });
            return;
          }
        } catch (err) {
          /* fall through to opening admin */
        }
        await openOrFocus(`${base}?order=${encodeURIComponent(orderId)}`);
      })()
    );
  } else {
    e.waitUntil(openOrFocus(orderId ? `${base}?order=${encodeURIComponent(orderId)}` : base));
  }
});

async function openOrFocus(path) {
  const full = new URL(path, self.location.origin).href;
  const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
  for (const c of all) {
    if (c.url.startsWith(self.location.origin)) {
      await c.focus();
      if ("navigate" in c) await c.navigate(full).catch(() => {});
      return c;
    }
  }
  return self.clients.openWindow(full);
}
