# v1.5 — phone layout pass

## Header (phones and tablets, up to 900px wide)
- One clean row: "✦ Alma Chaab" on the left, a round **+** button on the right.
- **+** opens a panel with every option: Meniu ir rezervacija, Wolt (opens Wolt directly), Apie mus,
  Atsiliepimai, Degustacijos, Šventės ir renginiai, Galerija, Kontaktai, Straipsniai, Mano užsakymai,
  plus a call button and Facebook. The + turns into ×. Closes with ×, Escape or a tap outside.
- Desktop header is unchanged.

## First screen (phones)
- "Meniu ir rezervacija" and "Wolt" sit side by side right under the headline, visible without scrolling.
- The hero Wolt button now opens the Wolt restaurant page directly (it used to jump down to the Wolt section).

## Meniu ir rezervacija
- Every "Meniu ir rezervacija" press (header panel, hero, bottom bar) lands on the **Jūsų stalas** card,
  not on the intro text. Desktop too: the card no longer stops under the header.
- The ~100px gap between the intro text and the Jūsų stalas card is down to 14px (phones and tablets).
- Root cause of the "lands under the header" problem: the booking area used `overflow: hidden`, which made
  it its own scroll box. It's now `overflow: clip` (same cropping, no scroll box). This also fixes the
  checkout's own jump to step 2 (Kontaktai).
- Every section reached from the + panel clears the fixed header.

## Dish cards (phones)
- The + button sits on the price row, on the right. Cards went from ~240px to ~138px tall.
- The category tag (e.g. "Pagrindinis") is hidden on phones, since it repeats the category heading.
- Sold-out dishes still show the "Išparduota" label.

## Other
- The Staliukas / Šventė / Degustacija scene cards loaded their background photos from imageproxy.wolt.com
  in the CSS. They now use the local copies (`/api/files/menu-d1.jpg`, `menu-d5.jpg`, `menu-d16.jpg`).
  Don't delete those three files from the media library.

## Files
- new: `src/app/site-mobile.css` (all phone/tablet styles, loaded last on the home page)
- changed: `src/components/site/sections.tsx` (Header, Hero), `src/components/site/AlmaSite.tsx`
  (scrollToBooking), `src/app/page.tsx` (imports the new CSS), `src/app/site*.css` (Wolt image URLs only)

---

# v1.6 — phone header + desktop-style first screen

- **Phone header:** "Alma Chaab" · phone number · Facebook · **+**, all in one row. Phone and Facebook
  moved out of the + panel into the header. On very narrow phones (≤ 374px) the number becomes a call icon
  so the row never overflows. The ✦ before the logo is hidden on phones to make room.
- **First screen on phones now looks like desktop:** the restaurant photo fills the whole first screen
  and the text sits on top of it, behind a cream veil (stronger on the left, lighter on the right) so the building shows through.
  Same order and buttons as desktop: wide gold "Peržiūrėti meniu + rezervuoti", Wolt below it.
  Both stay visible above the bottom action bar on 360 / 390 / 430px phones.
- Desktop and tablet are unchanged.
- files: `src/components/site/sections.tsx` (header quick buttons), `src/app/site-mobile.css` (header + hero)

---

# v1.7 — less scrolling at the bottom of the page (phones)

- **Wolt → Kontaktai → SEO text:** section spacing cut from 90px + 90px to about 20–28px.
  This stretch is ~900px shorter (2420px → 1526px).
- **Kontaktai card:** one compact row per item (label left, value right): Adresas, Telefonas, Facebook,
  Staliuko rezervacija. The section went from 706px to 309px tall.
- **SEO text + DUK:** smaller heading, tighter paragraphs and FAQ rows. All text is unchanged (it matters for Google).
- **Footer:** quick links in two columns; call button full width with email/address under it.
  884px → 583px. Bottom padding still leaves room for the action bar.
- Desktop and tablet unchanged. Only file: `src/app/site-mobile.css` (sections 5 and 6).

---

# v1.8 — directions button

- **"Maršrutas · Google Maps"** button next to Wolt on the first screen (phone and desktop). Opens Google Maps
  directions to "Alma Chaab, Didžioji g. 25, Kėdainiai"; on phones that opens the Maps app ready to navigate.
  Built from the name + address in admin settings, so it follows any address change automatically.
- **Kontaktai → Adresas** is now a tappable link to the same directions ("· maršrutas ↗").
- files: `src/components/site/sections.tsx`, `src/components/site/icons.tsx` (MapPinIcon), `src/app/site-mobile.css` (section 7)

---

# v1.9 — compact reviews block (phones)

- **Atsiliepimai:** the score card is now one horizontal strip (big 4.4 on the left, stars + count on the right,
  Google Maps link below). Tighter heading, quote and note. Block height 702px → 451px.
- Gap between the reviews block and "Meniu ir rezervacija" ~60px → 32px; less empty space above it under the photo strip.
- Desktop unchanged. Only file: `src/app/site-mobile.css` (section 8).
