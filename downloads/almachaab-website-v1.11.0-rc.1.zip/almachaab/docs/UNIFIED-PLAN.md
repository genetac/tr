# AlmaChaab: unified scope and release plan

Source of truth: the two supplied pasted texts and v1.9.3 archive. Irina's answers override Google attributes. The implementation specification supplies exact approved Lithuanian wording. Public deployment is excluded. The client email is a proposal and status update, not evidence that features passed validation.

## Commercial agreement to communicate

| Item | Unified treatment |
|---|---|
| Website | €300 already paid; no second final-payment request. Finish the agreed website and existing admin, WebApp and short training within that scope. |
| Content and existing delivery links | Included. Use real listing URLs; no invented Bolt link. |
| Loyalty/CRM | Optional €50 one-time introductory configuration of a bounded pilot using existing modules. Keep disabled until rules, rewards, identification and marketing consent are agreed. This is a proposed goodwill price, not a claim about market minimums. No monthly CRM fee is promised. |
| Hosting, email and other providers | Costs separate; obtain agreement before purchasing or enabling billable services. No provider plan or price is assumed. |
| Wolt Drive | Feasibility assessment only until eligibility, API access, courier costs and implementation scope are known. A normal Wolt link is not a courier integration. |
| Support | 60 days of minor fixes to agreed existing functionality after handover. New features excluded. |
| Ongoing care | Optional €19/month, up to 30 minutes of small content edits plus basic technical check. No ranking or incident-response guarantee. |
| App stores | Separate future project and provider fees. Existing PWA does not imply App Store/Play approval. |

Keep the email short; technical implementation and verification belong in these project documents. Do not tell Irina that everything is already complete or that Cloudflare is the only secure option.

## Delivery sequence and acceptance

1. **Baseline and preservation.** Import without overwriting existing work. Back up SQLite. Frozen dependencies, verified Prisma engines, type check, lint, production build and functional startup. The imported app is Next.js 16 + SQLite + local files + SSE; extend it rather than replacing it.
2. **Confirmed facts and shared sources.** Use the exact visitor, services, staff, hours and billiards wording in IMPLEMENTATION-REQUEST.md. Remove fireplace/Wi-Fi/free-parking claims. Centralize repeated facts, links and staff roles. Sunday kitchen wording must respect the 20:00 venue closing time. Verify page text, FAQ and structured data agree.
3. **Menu classification.** Independent vegetarian, vegan and halal controls, initially unspecified, optional notes, accessible text and filters. Validate nonnegative prices and server-side writes. Saving/reloading must preserve classifications and update the public menu without a deployment.
4. **Content management.** Extend the existing authenticated sidebar and editors. Add structured visitor/services editing, individually editable billiards prices/cutoff, dated draft events, shared navigation with parent/order/visibility, page visibility and image/CTA editing. Add draft/preview/publish states where appropriate, validation and deletion/unsaved-change protection. Never use localStorage as the content database.
5. **Editorial and media review.** Existing articles need Irina's review; keep review status distinct from publication. Missing event years/times are drafts, Happy Hour and unlimited-food offers unpublished. Preserve sample assets in the package but do not present them as authentic restaurant photography. Upload/replacement, alt text, captions and ordering must work. No permanent changing-team feature.
6. **Verification.** Build/type/lint; request affected public routes; exercise login and unauthorized write/upload rejection, actual save/reload/restart persistence, dietary filters, navigation on both screen sizes, valid/invalid image upload and draft leakage checks. Verify Lithuanian text, keyboard access and labels. Record passed/failed/skipped outcomes distinctly. Do not send marketing messages or charge real payments while testing.
7. **Deployment preparation.** Versioned complete ZIP, changelog, Lithuanian admin guide, migration/backup/restore instructions, documented secrets by name only, tested standalone startup, persistent DB/upload paths, HTTPS/proxy guidance and rollback procedure. Only call the package ready after required gates pass.
8. **External launch gates.** User-selected compatible hosting and credentials; actual domain/DNS access; mail delivery, real devices/push, payment providers if enabled; approved articles and supplied photos where used. Public deployment requires a separate instruction. Search Console/Analytics need account access; analytics only after consent checks.

## Hosting decision

Recommended architecture: one long-running Node process with durable SQLite and uploads, a supervised restart policy, backups and an HTTPS reverse proxy. A small VPS or managed Node host with a persistent volume can fit; size from measured build/runtime use and provider limits. Getspace's PHP-only shared plan cannot host this unchanged app. Cloudflare DNS/proxy can sit in front of a compatible host; it is not the application's Node host and is not the only security option. Vercel requires a port to supported durable database/object storage and review of SSE/function limits and commercial plan terms. Do not promise a free always-on service with durable storage or quote unverified current tariffs.

## Truly pending business inputs

- Actual Bolt Food restaurant listing URL (unless verified from project material).
- Event years, start times, descriptions and booking details; October 16, November 6/13/30 remain draft notes.
- Irina's review of articles and confirmed dish classifications.
- Real photographs/approval to use supplied images; existing samples do not count as received assets.
- Optional parking price/changing table/hearing equipment verification: omit claims meanwhile.
- Loyalty decision and rules; no enrolment or promotional sends in this release.
- Hosting choice, domain/DNS access and mail/provider credentials through secure settings at deployment time.

## Status

Detailed execution and verification status is maintained in RELEASE-STATUS.md. A checklist item is complete only when implemented and its acceptance checks pass. Business facts can be confirmed while implementation remains pending.
