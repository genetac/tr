# Acceptance with Irina

Use private staging and Irina's own account before choosing a public launch date.

- Find an existing dish by name. Add a private dietary note, public description and independent classifications; turn display off/on, save, preview and publish. Confirm hidden/unreviewed data stays private.
- Correct one shared contact/hour/visitor fact and staff biography. Check the corresponding public page/shared block after publication.
- Change homepage text and its colour, replace a photograph by clicking it, move and hide a section. Check desktop and saved mobile/tablet previews.
- Edit About and privacy content; create an article as a document and a new page with blocks. Review text/photographs, publish only approved records and add the page to navigation.
- Recover an earlier content revision into a draft. Confirm the public version remains unchanged until publishing.
- Create a staff account, verify its role, revoke access and try a private help request with an attachment.
- Supply real restaurant/menu photographs and appropriate alternative text, actual delivery/listing URLs, article approvals, kitchen-confirmed dietary classifications and complete event years/times. Do not classify from dish names alone.

Some screens share the content document. A publication applies the saved draft for that document, including edits made in its other screens. Menu dishes and menu layout have separate publication actions. Security credentials and operational stock/order state are immediate.

After those tasks, validate the selected production host: individual owner password, fresh keys, HTTPS/proxy, real mail, off-host backups/restoration, external destinations, analytics/consent and push on real supported phones. Payment/social providers are optional scope decisions. Loyalty and promotional email remain off until rules and the full consent/unsubscribe workflow are accepted and verified.

This checklist is an acceptance aid, not evidence that external tests already passed. See RELEASE-STATUS.md for executed local checks.
