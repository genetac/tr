# AlmaChaab — visual CMS completion plan

Status: implementation advanced in v1.11.0-rc.1. This remains the acceptance specification; see RELEASE-STATUS.md for verified capabilities, limits and external launch gates.

## Intended result

Irina can manage routine restaurant content without a developer: select a page, see it in the website's design, click text or a photograph, make changes, preview mobile/desktop, and publish. Business facts, menus, events, articles, navigation and theme have clear dedicated screens. A change to a shared fact updates its public appearances and corresponding metadata. Incomplete information can be stored privately without appearing on the website.

Keep the existing Next.js/SQLite application and extend its CMS. A WordPress migration would require a separate decision and migration project. Reuse existing authentication, media upload/re-encoding, theme settings, content drafts, @dnd-kit and the installed rich-text editor package where they fit. Do not add a second content database or competing publishing system.

## Navigation in Lithuanian

| Sidebar | Contents |
|---|---|
| Skydelis | Drafts, items awaiting review, pending assets, operational notices |
| Puslapiai | Home, About, visitor information, services, privacy and new standalone pages |
| Straipsniai | Document editor, authors, review, drafts, publication, revisions |
| Meniu | Categories, dishes, prices, photos, availability, dietary information |
| Renginiai | Dates, times, photos, booking links, draft/public status |
| Mediateka | Uploads, replacement, captions, alternative text, usage references |
| Išvaizda | Brand colours, fonts, buttons and global design styles |
| Navigacija | Desktop/mobile links, nesting, ordering and visibility |
| Užsakymai ir rezervacijos | Existing queues and kitchen access |
| Klientai ir lojalumas | Existing optional pilot; remain disabled until rules/consent are agreed |
| Pagalba | Internal issue/request inbox; no automatic external message sending |
| Nustatymai | Shared business facts, hours, staff, delivery/contact links, users and integrations |

Avoid one very long form containing every subsystem. Public content editing and technical/secret settings must have distinct permissions and navigation.

## 1. Shared content and publishing foundation

Implement this before building the visual canvas.

- Inventory every hard-coded public string, image, link, role and metadata occurrence. Preserve existing content and functioning URLs during migration.
- Store pages as validated ordered blocks with stable IDs, visibility, content and constrained style settings. Add a proper standalone-page record/route; current extra homepage sections are not equivalent to new pages.
- Centralize staff names/roles/bios/photos, business identity, contacts, kitchen/venue hours, delivery links, accessibility and billiards data. Public text, shared blocks, FAQ and structured data read these sources.
- Extend draft/published separation to pages, articles, menu changes and theme/content settings. A saved edit must not change a published item until published. Keep security credentials and operational order controls outside this public-content workflow.
- Add persistent revisions: editor, timestamp and change summary; restore an older version as a draft. Session undo/redo is separate from server revision history.
- Add autosaved drafts, explicit saving/saved/error states, unsaved-change protection and conflict detection for every editable entity. Preserve the live version when validation or publishing fails.
- Publishing updates related public data consistently. Revisions/audit records must never retain plaintext passwords, API keys or payment details.

Acceptance: edit shared business/staff information and About/privacy page text, save a draft, reload and preview; public text and metadata remain unchanged until publication. Publish, verify every relevant occurrence, restore the previous revision as a draft, and verify no accidental public rollback occurs.

## 2. Visual page editing

Editing screen: WordPress-style sidebar; a large canvas rendered with the same page blocks, fonts, spacing and background as the website; an inspector for the selected block. Protected admin editing only—no editing controls for anonymous visitors.

- Click text to edit its content; select bold/italic, links, headings, alignment and text colour using a compact toolbar.
- Click a photograph to open the existing upload/media picker; replace it, adjust available crop/focal-point controls, caption and alt text.
- Add, duplicate, remove, hide or reorder blocks. Support drag-and-drop and keyboard-accessible move-up/down controls.
- Support text, heading, photo, photo/text, gallery, buttons, FAQ, visitor facts, staff, event list and menu blocks. Menu/contact/hour blocks reference shared data instead of duplicating it.
- Allow safe column/spacing presets and section backgrounds. Restrict layout and typography to responsive controls; validate colour contrast and allow returning to the site's defaults.
- Provide desktop/tablet/mobile preview, undo/redo, autosave, draft preview and explicit publication.
- Confirmation for deletion; preserve navigation/page independence. Changing a page slug needs a redirect, not a broken old URL.
- Start with the existing site's blocks rather than attempting an unrestricted Elementor clone. Irina gets the requested visual actions while mobile layouts remain controlled.

Acceptance: Irina can change a paragraph's colour, swap two sections, click/replace a photograph, hide a section, undo a change and publish from the canvas. Reload/restart preserves state and desktop/mobile public views match the preview. Keyboard users can perform equivalent selection/reordering.

## 3. Document-style articles and new pages

Replace the current small paragraph/image forms with a spacious visual document editor inside the site's design. Reuse the installed rich-text package only after verifying format compatibility with existing articles.

- Title, author and document canvas; toolbar for paragraphs/headings, bold/italic, lists, links, quotes and images.
- Write or paste ordinary text, insert pictures inline and see the article in its final typography/background. A DOCX-like editing experience does not imply .docx file import/export.
- Keep URL, excerpt, cover, SEO and publication controls in an inspector rather than interrupting writing.
- Add autosave, revision restore, preview and an explicit review/publish action. Existing unreviewed articles stay drafts.
- Migrate existing paragraph/heading/quote/image/list content without losing text or media. Sanitize and validate rich-text output; do not execute user-authored MDX/HTML.
- Allow a similar workflow to create standalone pages and optionally add them to navigation.

Acceptance: create a new article/page, paste Lithuanian text, format a list, insert an image, save/reopen, preview and publish; inspect existing migrated articles for content loss and verify anonymous visitors cannot access drafts.

## 4. Irina's factual review and dietary controls

Give each item a clear factual status independently of its implementation/publication state:

- Patvirtinta — fact supported by Irina.
- Reikia patikslinti — missing or uncertain details; retain an internal note.
- Laukiama medžiagos — photograph/listing or other asset missing.
- Juodraštis / Paskelbta — whether the content is public.

Dish editing must distinguish classification from display. Keep vegetarian, vegan and halal independent; do not infer one from another. Existing unspecified fields remain unspecified, not negative dietary claims.

For each dish, provide confirmed classifications plus display switches, editable public dietary description, separate internal review notes and a public-notes visibility switch. Add global label/filter visibility settings. A hidden label must also be excluded from public filters and public structured data. A draft confirmation or internal note must not leak through APIs or page props.

Irina can review dishes one by one, enter supported information, hide it while checking, and publish when ready. No allergen-free or certification claims arise automatically. Add an allergen information area only with explicit source/verification and clear wording; never infer allergies from a recipe name.

Apply the same private-note/review controls to incomplete event dates, articles, photographs and delivery links. Preserve the four music notes without inventing years/times. Do not enable loyalty or send promotional messages as part of factual review.

Acceptance: classify a dish privately, verify no public label/filter/note appears, publish selected labels/notes, hide them again without deleting the confirmed internal record, and verify consistency after reload/restart.

## 5. Accounts, help and operational controls

- Owner: users, publishing, integrations and operational settings.
- Editor: permitted content/media/drafts; publication permission can be granted separately.
- Kitchen: permitted order/reservation workflow only; no CMS, customer exports, payment keys or user administration.
- Enforce permissions on the server for every read/write/upload endpoint, not merely by hiding menu entries. Add session revocation and audit entries.
- Internal help inbox: subject, description, optional controlled attachment, status and replies visible to authorized staff. No email/Slack notifications unless separately instructed/configured.
- Keep loyalty/CRM visually separate. Add a clear pilot checklist for rules, rewards, customer identification and consent. Do not describe existing CRM email behavior as consent-complete without implementing and testing opt-in/withdrawal handling.

Acceptance: test allowed and forbidden operations for each role, including direct API calls; verify no cross-role data leakage, secret exposure or marketing sends.

## 6. Deployment preparation and checks

### Work that can be prepared in code/admin

- Initial-owner password setup, secure credential-entry screens and key-presence diagnostics without exposing values.
- Draft-based content review, media management, integration status, email-test controls with explicit recipient/action, backup status, and consent-aware analytics settings.
- Reproducible production build/startup, persistent DB/upload paths, controlled migrations, backup/restore and rollback instructions.
- Targeted security/accessibility tests and fixes: authorization, uploads, rich-text sanitization, draft privacy, session handling, keyboard access, labels, focus, contrast and responsive layouts.

### External requirements still necessary

- Select compatible persistent Node hosting; agree actual provider costs and provision the account.
- Supply domain/DNS/proxy access and choose where secrets/keys are securely managed. Avoid exposing host-level infrastructure administration through the restaurant CMS.
- Test HTTPS/proxy trust, real mail delivery, off-host backups and restoration on the selected host.
- Test push notifications on real supported phones, including background/closed-tab behavior.
- Connect/test payment/social providers only for the agreed launch scope and with real credentials.
- Obtain Irina's factual approvals, actual photos, actual Bolt Food destination and event details. The CMS can collect these; it cannot invent or independently approve them.
- Verify listing destinations and analytics/consent behavior in the actual deployment. Automated local checks are not an independent security or accessibility certification.

## Completion order

1. Shared page/business/staff schema, migration, universal content drafts/revisions and server permission boundaries.
2. Dedicated Lithuanian navigation and document editor for articles/standalone pages.
3. Visual block canvas with click-to-edit text/photos, ordering, styles and responsive previews.
4. Dietary/review visibility controls, media workflow, help inbox and staff roles.
5. Regression, security/accessibility checks, restart/restore tests, updated guides and versioned package.
6. Selected-host staging validation and Irina's acceptance tasks, then separately authorized public deployment.

Each phase must include its persistence, draft-privacy and authorization checks. Do not defer all verification until the end. Only mark features implemented after those checks pass; this plan adds no completion claims to v1.10.0-rc.1.

## Final acceptance with Irina

Using her own account, Irina can: edit hours/contact information once; change staff details and About text; replace a photo by clicking it; recolour text; reorder/hide a section; create an article and standalone page; classify and selectively display a dish's dietary information; review/publish an event; edit navigation; restore a content revision; and access help. Changes persist after restart, unpublished information remains private and the mobile site remains usable. Hosting, live integrations, backup restoration and actual-device checks must also pass before the website is called deployment-ready.
