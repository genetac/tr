# Release status — v1.11.0-rc.1

**Locally validated release candidate for private staging and owner acceptance; not publicly deployed.** The two supplied texts are unified in UNIFIED-PLAN.md. LAISKAS-IRINAI.md is the updated proposed client email. Earlier status documents and release notes describe historical versions; this document describes the current candidate.

## Implemented

- Per-existing-dish dietary block with name search, visibility switch, kitchen review, independent vegetarian/vegan/halal labels, independently shown optional description and private review note. Switching off preserves saved values. Global label, note and filter controls are separate. All 37 source dishes remain unclassified pending kitchen confirmation.
- Shared draft/publish system for homepage/content, standalone pages, articles, individual menu dishes, category layout, theme, contacts/hours and dietary display settings. Autosave, optimistic conflict detection, persistent revisions (50 snapshots), restoring a previous/published version as a draft, and session undo/redo. Credentials/integrations and operational stock/order changes remain immediate.
- Homepage visual selection of bound text/photos, text colour/alignment, photo upload/library replacement, section order/visibility; dedicated standalone-page blocks with duplication, ordering, visibility, styles and shared blocks. Mobile/tablet preview frames render the saved draft in actual viewport widths. Desktop editing shows changes immediately.
- About/privacy content migrated to editable documents; new standalone routes, metadata, published-page sitemap entries and old-address redirects. Articles use a document-style editor with formatting, lists, links/images, or visual blocks. Imported articles remain private review drafts.
- Shared people profiles, roles, bios/photos and visitor/business blocks, with related structured business data. Dedicated Lithuanian pages, articles, events, navigation, media, appearance and business screens.
- Owner-managed staff accounts, editor publication permission, kitchen permissions and session revocation. Private internal help threads/replies/attachments; no automatic external messaging.
- Additive dietary migration and repeatable page/content migration, safe WebP uploads and release-copy secret removal. Loyalty remains disabled. Legacy promotional-email sends are explicitly blocked until a complete consent/unsubscribe workflow is implemented and accepted.

## Executed checks

| Check | Result |
|---|---|
| Production build and TypeScript | Passed with build errors enforced |
| ESLint | No errors; one pre-existing warning in scripts/security-verify.mjs |
| API assertions | 136 passed on isolated QA data |
| Browser scenarios | 19 passed in Chromium, desktop and mobile |
| Responsive preview | Authenticated same-origin frame; actual 390 px document viewport verified |
| Browser JavaScript exceptions | None in tested owner workflows |
| Backup restoration/restart | Restored DB/uploads retained published text/colour, dietary data, drafts/revisions, media, private attachments and staff accounts |
| Migration repeatability | Passed; subsequent edits preserved; imported duplicate block IDs repaired without changing text/order |
| Working content DB | Integrity ok; 8 categories, 37 dishes, 10 draft articles; no QA orders/users/staff/help or dietary classifications |

The API checks cover anonymous and role authorization, credential filtering, per-dish/global dietary display, draft privacy, invalid prices/URLs, revision conflicts/history/restore, public formatting and script safety, slug redirects, sitemap, hidden built-in pages, shared people data, theme drafts, private help/media, staff revocation, cross-origin writes and new-category/dish publication. Browser checks exercise login, visual text/colour/photo edits, section order, named-dish dietary controls, Lithuanian document writing/reopening, block duplication, responsive preview, public filtering, mobile overflow and kitchen navigation. Prior v1.10 checks also exercised reservations/order tracking; no real payment, marketing or mail delivery occurred.

QA evidence and credentials are outside the repository in `/workspace/.almachaab-qa-v2` and excluded from the release ZIP. These are focused local checks, not an independent security or accessibility audit.

## Practical boundaries

- This is a custom CMS with navigation familiar to a WordPress user; WordPress itself is not installed. Bound homepage text/photos and page blocks are editable. System interface labels, arbitrary application behavior and complete freeform redesign still require code.
- Several editing screens share the content document; publishing it publishes that document's saved changes across those screens. Dishes and category layout have separate publication actions. Revisions are document snapshots, not database-wide undo of orders, uploads or credentials.
- Document mode combines visible prose into one document; use visual mode to preserve detailed block styles/order. Hidden blocks remain hidden. Shared blocks stay linked to their source; independently authored prose must be reviewed separately when facts change.
- Media captions/alternative metadata can be managed, but independently placed image blocks have their own alternative text. There is no full media-usage dependency report.
- Owner acceptance is still required, including review of privacy wording against the actual enabled services. Not every aspiration in the longer proposal is an implemented launch feature.

## External launch requirements

1. Select/provision persistent Node hosting, agree cost, and supply domain/DNS/proxy access.
2. Set an individual owner password and fresh production keys before public exposure.
3. Configure/test real mail, HTTPS/proxy behavior, off-host backups/restoration and push notifications on supported physical phones.
4. Configure/test payment and social providers only if included in launch scope; live credentials were not exercised.
5. Obtain Irina's article review, actual photographs, kitchen-confirmed dietary classifications, actual Bolt Food/listing URLs and complete event years/times. Incomplete events and sample gallery remain private/hidden.
6. Verify external destinations and consent/analytics in the selected deployment. Loyalty/marketing require an accepted scope and complete consent/unsubscribe work before activation.

See IRINA-ACCEPTANCE.md for the owner walkthrough and DEPLOYMENT-CANDIDATE.md for installation/backup instructions. No public deployment or paid service purchase was performed.
