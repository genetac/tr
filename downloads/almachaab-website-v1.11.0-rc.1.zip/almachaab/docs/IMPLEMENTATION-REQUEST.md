# AlmaChaab — complete implementation plan

**Starting package:** `almachaab-website-v1.9.3.zip`

**Goal:** Finish the website using Irina’s answers and provide a familiar, WordPress-style `/admin` where the client can maintain content, menus, prices, events, photos and navigation herself.

**Authorization:** Implementation is approved. Public deployment is not included.

**Current status:** The website package has not been inspected because this session’s execution environment is unavailable. This document defines the agreed work; it does not claim that changes have already been made.

## 1. Implementation principles

- Use **Irina’s answers as the authoritative source** when they conflict with Google Business Profile attributes.
- Write all new public content and admin labels in natural Lithuanian.
- Preserve the existing design where it works and extend its visual language consistently.
- Inspect the existing architecture before choosing storage, authentication or other dependencies.
- Build on existing working functionality instead of introducing a second competing system.
- Make recurring information editable from one place and update every public occurrence from that source.
- Do not publish unsupported claims or invent missing information.
- Omit Wi-Fi information entirely.
- Keep unresolved offers and events unpublished until their details are entered.
- Complete implementation, verification and packaging before returning the updated version.

## 2. First step: inspect the actual project

Before editing:

1. Extract the ZIP and read any project instructions.
2. Identify the framework, build commands, routes, hosting assumptions and dependencies.
3. Inspect the current `/admin`, authentication, storage and media handling.
4. Inventory existing pages, menu data, articles, events, navigation and structured business data.
5. Find outdated information, duplicate sources and placeholder content.
6. Establish whether the project currently builds and runs.

The implementation should fit the project’s actual architecture. Any hosting limitation that prevents persistent editing must be identified explicitly.

## 3. Public website structure

Use these as sections or existing-page additions where appropriate. Avoid unnecessary duplicate pages.

| Area | Purpose and content |
|---|---|
| **Pagrindinis** | Clear introduction, menu and reservation actions, selected practical highlights |
| **Meniu** | Dishes, prices, categories, photographs and dietary labels |
| **Prieš atvykstant** | Accessibility, children, parking, pets, payments and facilities |
| **Rezervacijos / Šventės** | Reservations, upstairs room, smaller groups and individual arrangements |
| **Paslaugos** | Catering, takeaway, delivery and billiards |
| **Renginiai** | Dated live-music events and confirmed activities |
| **Apie mus** | Restaurant story, Irina, Elie and women-founded business |
| **Galerija** | Real restaurant and food photographs |
| **Straipsniai** | Articles with reviewable authorship |
| **Kontaktai** | Opening hours, kitchen information, verified contact details, directions and service links |

A short FAQ can appear within “Prieš atvykstant” or another suitable existing page.

Homepage highlights should link to the relevant details. Candidate highlights are family facilities, seasonal outdoor seating, dogs welcome and private celebrations. Do not advertise free parking without confirmation.

## 4. Confirmed content and corrections

### Accessibility

Publish careful, specific wording:

> **Pagrindinis įėjimas pritaikytas patekti su vežimėliu. Pirmame aukšte yra staliukų, prie kurių patogu sėdėti su vežimėliu.**

> **Tualetas turi platesnes duris, tačiau jame nėra atraminio turėklo.**

> **Antrame aukšte esančioje salėje telpa iki 30 žmonių. Į ją patenkama tik laiptais.**

> **Specialiai pažymėtos automobilių stovėjimo vietos žmonėms su negalia nėra.**

Do not describe the whole venue or toilet as fully accessible. Do not describe either staircase as wheelchair accessible or promise that it is suitable for a particular visitor.

Google’s statements about hearing-assistance equipment should not override the owner’s current information. Omit those details unless verified.

### Families and children

Publish:

> **Laukiame šeimų su vaikais. Turime dvi vaikiškas maitinimo kėdutes, vaikišką meniu ir vaikų kampelį.**

The changing-table attribute comes from Google rather than Irina’s answers. Keep it out of definitive public copy until verified; it does not need to block the other updates.

### Brunch and kitchen hours

Publish:

> **Vėlyvieji pusryčiai grupėms ruošiami tik iš anksto susitarus.**

> **Virtuvė užsakymus įprastai priima iki 21 val. Dėl galimybės užsisakyti vėliau teiraukitės komandos.**

Kitchen information must remain separate from venue opening hours. Where a day’s closing time is earlier, the site must not imply that orders are accepted after closing.

### Food and dietary information

Until individual dishes are classified, publish:

> **Dėl vegetariškų, veganiškų ir halal patiekalų teiraukitės mūsų komandos prieš atvykdami arba restorane.**

Do not label the entire restaurant halal or imply certification.

### Drinks and service

Publish that beer, wine, cocktails and spirits are available.

Use:

> **Įprastai aptarnaujame prie staliukų.**

Remove an unsupported claim that counter service is routinely available.

### Fireplace

Remove the fireplace claim from public text, highlights, FAQs and any structured data or image captions that incorrectly suggest one exists.

### Happy Hour and unlimited-food offers

There is no confirmed active Happy Hour offer. Keep this unpublished.

Do not publish an “all you can eat” offer based on the ambiguous Google attribute. Future promotions can be created through admin.

### Live music

Use individual event records with dates and details.

Irina supplied:

- October 16 — Lithuanian music.
- November 6.
- November 13.
- November 30.

The year, times and remaining details are not established. Preserve these as draft information rather than creating upcoming public events. Do not assume they are recurring annually.

### Sports

Publish:

> **Svarbių rungtynių metu galimos sporto transliacijos. Dėl konkrečių rungtynių teiraukitės mūsų komandos.**

Do not imply that every match is screened.

### Outdoor seating

Publish:

> **Šiltuoju metų laiku svečių laukiame ir kiemelyje.**

Do not invent fixed opening months.

### Private room

Publish:

> **Antrame aukšte esančioje salėje telpa iki 30 žmonių. Ją galima rezervuoti ir mažesnei kompanijai. Sąlygos derinamos individualiai.**

Show the stairs-only access information near this description. Do not invent minimum spending, deposits or hire charges.

### Catering

Publish:

> **Dėl išvažiuojamojo maitinimo galimybių, meniu ir užsakymo sąlygų susisiekite su mumis – viską deriname individualiai.**

Use the existing verified contact method.

### Takeaway and delivery

Retain takeaway information where supported by the existing project and supplied business information.

Publish:

> **Maistą galite užsisakyti per „Wolt“ ir „Bolt Food“. Dėl didesnio užsakymo pristatymo galima susitarti individualiai.**

Use actual restaurant listing URLs. Do not invent delivery areas, fees, minimum orders or guaranteed no-contact delivery.

### Reservations

Publish:

> **Staliuką galima rezervuoti, tačiau laukiame ir atvykstant be rezervacijos.**

Do not promise immediate seating.

### Parking

Publish:

> **Turime privačią automobilių stovėjimo aikštelę su ribotu vietų skaičiumi. Netoliese yra ir kitų automobilių stovėjimo aikštelių. Specialiai pažymėtos vietos žmonėms su negalia nėra.**

Irina did not explicitly confirm the parking price. Do not describe private or nearby parking as free.

### Payments

Publish:

> **Priimame grynuosius, „Visa“, „Mastercard“ ir bekontakčius mokėjimus telefonu, įskaitant „Apple Pay“ bei „Google Pay“.**

Omit American Express because acceptance is unknown. A long list of unsupported card brands is unnecessary.

### Dogs

Publish:

> **Šunys laukiami restorano viduje ir kiemelyje.**

Do not add unconfirmed restrictions.

### Toilets

Publish where relevant:

> **Tualetai bendri visiems lankytojams.**

### Wi-Fi

Do not display whether Wi-Fi exists, is paid or is free.

Remove conflicting Wi-Fi claims from existing public content if present.

### Billiards

Publish:

> **Veikia du biliardo stalai. Moksleiviams ir studentams – 5 €/val., suaugusiesiems – 10 €/val. Žaisti galima iki 20 val.**

Make prices, descriptions and the playing cutoff editable independently.

### Opening hours

| Day | Hours |
|---|---|
| Pirmadienis | Nedirbame |
| Antradienis | 12:00–22:00 |
| Trečiadienis | 12:00–22:00 |
| Ketvirtadienis | 12:00–22:00 |
| Penktadienis | 12:00–22:00 |
| Šeštadienis | 11:00–22:00 |
| Sekmadienis | 11:00–20:00 |

Support exceptional closures and holiday hours if the existing architecture allows this cleanly.

## 5. Vegetarian, vegan and halal dish controls

Each dish must support independent dietary fields:

| Field | Public presentation |
|---|---|
| **Vegetariškas** | Small green leaf with **V**, accompanied by “Vegetariškas” |
| **Veganiškas** | Distinct label reading “Veganiškas” |
| **Halal** | Label reading “Halal”, with optional explanatory text |

Requirements:

- Irina can change each field through `/admin`.
- Existing dishes start unlabelled unless their classification is supported.
- Unselected means **not specified**, not “definitely unsuitable.”
- Selecting vegetarian must not automatically select vegan or halal.
- Dietary classification must not create allergen-free claims.
- Icons must remain understandable without colour and have accessible text.
- Use a lightweight SVG or the project’s existing icon system.
- Add dietary filters if they fit the existing menu layout.
- Include optional dietary notes for clarification.

No certification-style badge should appear without supporting information.

## 6. WordPress-style `/admin`

Provide a familiar sidebar, clear editing screens and consistent save behaviour. This means a similar management experience; migration to WordPress is not required.

| Admin section | Editable information |
|---|---|
| **Skydelis** | Useful shortcuts, drafts and content needing attention |
| **Puslapiai** | Headings, text, section visibility, images and calls to action |
| **Meniu** | Categories, dishes, prices, descriptions, images, availability and dietary labels |
| **Renginiai** | Dates, times, descriptions, photos, booking links and publication status |
| **Paslaugos ir erdvės** | Private room, catering, delivery, outdoor seating and billiards |
| **Informacija lankytojams** | Accessibility, children, parking, pets, payments and facilities |
| **Straipsniai** | Drafts, author details, preview and publication |
| **Galerija** | Uploading, replacement, ordering, captions and alternative text |
| **Navigacija** | Link labels, order, destinations, parent items and visibility |
| **Nustatymai** | Opening hours, kitchen information, contacts, social links and delivery URLs |

Admin behaviour:

- Lithuanian labels and straightforward instructions.
- Persistent server-side saving appropriate to the hosting environment.
- Authenticated access and server-side authorization for edits and uploads.
- No reliance on browser local storage as the primary content database.
- Clear unsaved-change, saving, success and error states.
- Draft, preview and publish controls where appropriate.
- Confirmation before deleting content.
- Validation for prices, dates, links and required fields.
- Safe text rendering and appropriate upload restrictions.
- Mobile-usable navigation and forms.
- Existing content preserved during migration.

Use the existing editor where suitable. A full drag-and-drop page builder is unnecessary unless the project already has one.

## 7. Central content and navigation

Create or consolidate a single source for recurring facts such as:

- Opening and kitchen hours.
- Contact information and address.
- Reservations and delivery links.
- Billiards prices and cutoff time.
- Accessibility and parking information.
- Staff names and titles.

Editing one of these should update every relevant page and any corresponding structured data.

Navigation controls should manage both desktop and mobile menus. Removing a navigation item must not silently delete its page.

## 8. People, ownership and article approval

Use these approved descriptions:

- **Irina Eid, „AlmaChaab“ vadovė**
- **Elie, virtuvės šefas**
- **Moters įkurtas ir valdomas verslas**

Replace unsupported descriptions such as:

- “Irina Eid, savininkė.”
- “Elie, vyriausiasis virtuvės šefas.”

Articles attributed to Irina must be reviewable before publication. Do not imply she has already approved their wording.

Prefer photographs of Irina and Elie. Avoid building permanent website content around changing team members.

## 9. Gallery and photographs

Build the upload and replacement workflow now.

When actual photographs become available:

- Replace sample images.
- Optimize dimensions and file size.
- Add accurate Lithuanian alternative text.
- Keep galleries responsive.
- Avoid invented captions.
- Preserve useful image quality.

Photos not yet supplied must remain recorded as pending assets. Do not mark them received or present sample photographs as authentic restaurant photographs.

## 10. Loyalty programme

Record this as **an interested future pilot**, rather than a confirmed public service.

Before launching it, define:

- How customers earn points or stamps.
- Rewards and redemption rules.
- Customer identification.
- Staff administration.
- Consent and preferences for promotional reminders.

Do not add working loyalty claims, enrol customers or send promotional messages as part of the current content update. A hidden planning entry is sufficient unless an existing implementation can be completed against explicit rules.

## 11. Treatment of answered and unresolved questions

Mark the questionnaire as answered using Irina’s responses.

Keep implementation status separate from factual status:

| Status | Meaning |
|---|---|
| **Patvirtinta** | Supported by Irina’s answer and ready for publication |
| **Derinama individualiai** | Publish the agreed contact-based wording |
| **Juodraštis** | An event or offer lacks publication details |
| **Laukiama medžiagos** | Photographs or other assets have not been supplied |
| **Įgyvendinta** | The corresponding website change has actually been completed and verified |

Unknown American Express acceptance, event years and missing photographs do not need to block the confirmed website updates.

## 12. Search and structured information

After inspecting the existing implementation:

- Keep page titles and descriptions accurate.
- Use natural Lithuanian wording.
- Maintain consistent business identity and contact details.
- Update existing restaurant structured data to match visible content.
- Remove outdated fireplace, Wi-Fi or other conflicting claims.
- Publish event structured data only for complete, public events.
- Preserve functioning URLs and add redirects if a route must change.
- Check image descriptions, internal links and page headings.

Do not create repetitive pages or promise search-ranking gains.

## 13. Verification

Run checks appropriate to the project and changes:

1. Build and available lint/type checks.
2. Start the site and inspect the affected routes.
3. Verify admin authentication and rejection of unauthorized edits.
4. Save content, reload and confirm persistence.
5. Confirm changes appear in all relevant public locations.
6. Test dish labels, visibility and any dietary filters.
7. Test navigation editing on desktop and mobile.
8. Check photo uploads, replacement and validation.
9. Confirm draft events and articles stay unpublished.
10. Check Lithuanian characters, keyboard access, labels and contrast.
11. Verify contact, reservation and delivery links.
12. Check that restaurant hours and kitchen wording do not contradict each other.
13. Confirm outdated claims have been removed.

Report any checks that cannot be completed in the available environment.

## 14. Final deliverables

Return:

- The updated complete website ZIP with a new version identifier.
- A concise change log.
- Lithuanian instructions for common `/admin` tasks.
- Required setup or migration instructions, without exposing credentials.
- Verification results and any remaining limitations.
- A short list of genuinely pending assets or details.

**Completion means the client can save and publish supported content through `/admin`, those edits persist and appear correctly on the website, and the finished package builds and passes the relevant checks.** Public deployment remains a separate action.