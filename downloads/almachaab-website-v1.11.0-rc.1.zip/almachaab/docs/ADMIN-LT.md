# „Alma Chaab“ valdymas — v1.11

## Prisijungimas

Atidarykite `/admin`. Savininkė jungiasi administratoriaus slaptažodžiu, darbuotojai – asmeniniu vartotojo vardu ir slaptažodžiu. Prieš viešą paleidimą būtinas individualus savininkės slaptažodis. Darbuotojų prieigas savininkė kuria, keičia ir išjungia skiltyje **Darbuotojai**. Redaktoriui skelbimo teisė suteikiama atskirai; virtuvės darbuotojai valdo užsakymus ir savo pagalbos užklausas.

## Bendras išsaugojimas

Puslapių, straipsnių, meniu, turinio, spalvų, kontaktų ir darbo laiko pakeitimai pirmiausia saugomi kaip juodraščiai. **Paskelbti** pakeičia viešą versiją. Juodraščio peržiūrai reikia prisijungti. Automatinio saugojimo būsena rodoma įrankių juostoje; prieš išeidami palaukite išsaugojimo patvirtinimo. Klaidos ar konflikto pranešimo neignoruokite.

**Istorija** leidžia ankstesnę versiją atkurti kaip juodraštį. Vieša versija pasikeis tik paskelbus. Atšaukimas ir pakartojimas galioja dabartinei redagavimo sesijai. Saugoma iki 50 ankstesnių dokumento versijų. Slaptažodžiai, techninės integracijos ir operacinės užsakymų/atsargų būsenos keičiamos atskirai ir iš karto.

Kelios skiltys, pavyzdžiui, vaizdinis redaktorius, renginiai, navigacija ir bendri žmonių aprašymai, naudoja vieną turinio dokumentą. Skelbdami peržiūrėkite visus to dokumento juodraščio pakeitimus. Vienu metu neredaguokite jo keliuose languose.

## Meniu ir mitybos informacija

1. Atidarykite **Meniu** ir paieškoje įrašykite esamo patiekalo pavadinimą.
2. Ties konkrečiu patiekalu spauskite **Mitybos informacija**. Tai to paties meniu patiekalo įrašas, atskiro produktų sąrašo nereikia.
3. Įjunkite **Rodyti mitybos informaciją prie šio patiekalo**, kai informaciją norite rodyti lankytojams.
4. Patvirtinę virtuvėje pažymėkite peržiūros lauką ir reikiamus nepriklausomus pasirinkimus: vegetariškas, veganiškas, halal. Nepažymėta reiškia „nenurodyta“.
5. Prireikus įrašykite **Viešą mitybos aprašymą** ir atskirai įjunkite jo rodymą. Vidinė pastaba matoma tik valdyme.
6. Išsaugokite juodraštį, patikrinkite peržiūrą ir paskelbkite. Išjungus rodymą, tekstas ir pasirinkimai lieka išsaugoti kitam kartui. Nepatikrinta informacija viešai nerodoma.

Bendri rodymo nustatymai leidžia atskirai slėpti visas žymas, aprašymus arba lankytojų filtrą. Žymos nepakeičia patvirtinto alergenų sąrašo ar sertifikavimo. Pateiktame pakete patiekalai sąmoningai nesuklasifikuoti – sprendimą priima restoranas.

Bendrą patiekalo kainą, aprašymą ir nuotrauką keiskite per **Keisti**. Kategorijų pavadinimai ir tvarka turi atskirą bendrą skelbimo juostą; patiekalų pakeitimai skelbiami kiekvienam patiekalui.

## Vaizdinis redaktorius ir puslapiai

**Vaizdinis redaktorius** atidaro pagrindinį puslapį svetainės dizaine. Spustelėkite pažymėtą tekstą, keiskite jį inspektoriuje, spalvą ar lygiavimą. Spustelėjus nuotrauką atidaromas keitimo / įkėlimo langas. Skyrius galima slėpti ir perkelti rodyklėmis arba tempiant. Pasikartojančių tekstų eilę galima keisti inspektoriuje. Ne kiekvienas sisteminis mygtuko užrašas yra atskirai redaguojamas.

Kompiuterio peržiūra keičiasi iš karto. **Telefonas** ir **Planšetė** rodo išsaugotą juodraštį tikro dydžio rėmelyje; po pakeitimo palaukite automatinio išsaugojimo.

**Puslapiai** leidžia redaguoti „Apie mus“, privatumo tekstą arba sukurti naują savarankišką puslapį. Blokus galima pridėti, dubliuoti, slėpti, perkelti, keisti tekstą, foną, spalvą ir nuotraukas. Nuorodą į naują puslapį pridėkite **Navigacijoje**. Pakeitus paskelbto puslapio adresą, senasis nukreipia į naują.

## Straipsniai

**Straipsniai → Naujas straipsnis** atidaro dokumento tipo rašymą: antraštes, paryškinimą, sąrašus, nuorodas ir paveikslėlius. Galima persijungti į vaizdinius blokus. Prieš keisdami rašymo režimą išsaugokite; sudėtingam blokų išdėstymui naudokite vaizdinius blokus. Dešimt importuotų straipsnių palikti juodraščiais Irinos peržiūrai. Paskelbtas straipsnis nesikeičia vien išsaugojus naują juodraštį.

## Bendri faktai, navigacija, renginiai ir nuotraukos

**Bendra informacija**: kontaktai, darbo laikas, bendri lankytojų faktai, žmonių vardai, pareigos, biografijos ir nuotraukos. Bendri žmonių ir verslo blokai puslapiuose naudoja tuos pačius laukus. Individualiai parašytą seną pasakojimą ar straipsnio tekstą reikia peržiūrėti atskirai.

**Renginiai**: įrašykite patvirtintą datą su metais, laiką Lietuvoje ir aprašymą. Nepilni renginiai neviešinami. **Navigacija**: pavadinimas, tikras adresas, du lygiai, tvarka ir matomumas. **Mediateka**: saugios WebP nuotraukos, antraštė ir alternatyvus tekstas. Puslapio nuotraukos alternatyvų tekstą tikrinkite ir pačiame bloke.

**Pagalba** – vidinės užklausos su atsakymais ir privačiomis nuotraukomis. Tai nėra automatinis laiškas išoriniam programuotojui. Darbuotojas mato savo užklausas, savininkė – visas.

## Prieš paleidimą

Lojalumas lieka išjungtas; reklaminių el. laiškų siuntimas užblokuotas, kol nebus įdiegtas ir patikrintas visas sutikimų bei atsisakymo procesas. Hostingas, HTTPS, tikras paštas, atsarginės kopijos ir telefonų pranešimai tikrinami pasirinktoje aplinkoje. Patvirtinkite nuotraukas, straipsnius, dietines žymas, renginius ir tikrą „Bolt Food“ nuorodą. Privatumo tekstą peržiūrėkite pagal realiai įjungtas paslaugas.
