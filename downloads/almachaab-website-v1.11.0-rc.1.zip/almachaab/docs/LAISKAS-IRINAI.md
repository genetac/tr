Tema: „Alma Chaab“ svetainė – užbaigimas ir paleidimas

Laba diena, Irina,

ačiū už atsakymus! Pagal juos patikslinau svetainės informaciją ir paruošiau valdymą per /admin: tekstus ir nuotraukas galima keisti vaizdinėje peržiūroje, straipsnius rašyti kaip dokumentą, o pakeitimus pirmiausia išsaugoti juodraščiu ir tik tada paskelbti. Taip pat galima valdyti meniu, kainas, renginius bei darbuotojų prieigas. Šie darbai, esama WebApp ir trumpas apmokymas įeina į jau apmokėtą 300 € kainą.

Prieš paleidimą patikrinsiu rezervacijas, užsakymus, administravimą, laiškus ir pranešimus. Straipsniai palikti Jūsų peržiūrai. Prie kiekvieno esamo meniu patiekalo galima įjungti ar išjungti mitybos informaciją, patvirtinti žymas ir prireikus įrašyti aprašymą. Prašysiu virtuvėje patvirtinti vegetariškus, veganiškus ir halal pasirinkimus; nepatvirtinta informacija lankytojams nerodoma. Renginiams dar reikės tikslių metų ir laiko, o pristatymui – tikros „Bolt Food“ nuorodos. Kai turėsite, atsiųskite aktualias restorano ir patiekalų nuotraukas; jas galėsime papildyti ir vėliau.

„Getspace“ patvirtino, kad dabartinis hostingas šiai svetainei netinka. Parinksiu tinkamą serverį ir jo kainą suderinsime prieš užsakant. „Cloudflare“ gali būti papildoma DNS ir apsaugos priemonė. Jokių mokamų paslaugų be Jūsų sutikimo neįjungsiu.

Pasirinktinai siūlau bazinės lojalumo programos nustatymą ir bandymą už 50 € vieną kartą. Pirmiausia sutartume, kaip kaupiami taškai arba antspaudai ir koks atlygis taikomas. Programa ir reklaminiai priminimai nebus įjungti, kol nesuderintos taisyklės bei reikalingi sutikimai. Ar norėtumėte šį variantą išbandyti?

Esamas „Wolt“ ir patvirtintos „Bolt Food“ nuorodas įtrauksiu be papildomo darbo mokesčio. Didesnių užsakymų pristatymui paliksime individualų susitarimą; „Wolt Drive“ galimybes galėsime įvertinti atskirai.

Paleidimo datą suderinsime pasirinkę hostingą ir užbaigę bandymus. Po perdavimo 60 dienų padėsiu dėl smulkių esamų funkcijų pataisymų. Vėliau, jei norėsite, bazinė priežiūra – 19 € per mėnesį, įskaitant iki 30 min. smulkių turinio darbų ir pagrindinę techninę patikrą. Hostingas, domenas ir išorinės paslaugos į šią kainą neįeina. Programėlių parduotuvių publikavimas būtų atskiras projektas.

Gražios dienos!
Manvydas
