# Deployment candidate (not a public deployment)

Use this document with UNIFIED-PLAN.md and RELEASE-STATUS.md. The original DEPLOY.md contains historical commands and assumptions; prefer the explicit environment loading and initial-password sequence below. Cloudflare is optional architecture, not a substitute for a Node host.

## Hosting requirements

Long-running Node 24 (validated) or a compatible supported Node release, a durable filesystem, the SQLite file and uploads retained across updates/restarts, HTTPS, a process supervisor and consistent backups. Build resource needs can exceed runtime needs. Do not assume a 1 GB shared hosting plan can build or run this package. Getspace's stated PHP-only shared plan is incompatible. Vercel/Cloudflare Workers require an architectural port; do not deploy this SQLite/filesystem package unchanged to ephemeral functions.

## Prepare installation

1. Extract the complete package into an application directory. Keep `.env.local` private, excluded from Git and backups shared with others.
2. Install Bun 1.3.4 and Python 3 plus Node 24. Use `scripts/install-dependencies.sh`. It keeps the lockfile unchanged, rewrites only the registry hostname in a temporary copy, and preserves versions/integrity verification. Allow `registry.npmjs.org` and `binaries.prisma.sh` for installation.
3. Copy the provided database and uploads to persistent paths, for example `/srv/almachaab-data/custom.db` and `/srv/almachaab-data/uploads`. Do not replace an existing site's database with a release copy. Back up existing data first.
4. Create `.env.local` with `DATABASE_URL=file:/srv/almachaab-data/custom.db`, `UPLOAD_DIR=/srv/almachaab-data/uploads`, `NEXTAUTH_URL=https://YOUR-DOMAIN`, `NEXT_PUBLIC_SITE_URL=https://YOUR-DOMAIN` and separate generated `APP_SECRET_KEY` / `NEXTAUTH_SECRET`. Generate each key from 32 cryptographically random bytes; retain the encryption key securely. No real keys ship in the ZIP. Do not enable `CRON_SECRET` or CRM sends during initial launch.
5. For an existing v1.9.3 DB, run `python3 scripts/migrate-dietary.py /srv/almachaab-data/custom.db`. Then `node --env-file=.env.local node_modules/prisma/build/index.js generate`. Run the two content migration scripts once, reviewing the fact that old articles become drafts and sample gallery photos are hidden:

```sh
node --env-file=.env.local --import tsx scripts/apply-owner-content.ts
node --env-file=.env.local --import tsx scripts/initialize-managed-content.ts
node --env-file=.env.local --import tsx scripts/initialize-visual-cms.ts
```

The supplied candidate database already has these changes. They are idempotent and preserve subsequent content edits. Never run reset/seed or `db:push --accept-data-loss` on production data.

6. Before accepting public traffic, set an individual admin password locally with `python3 scripts/set-admin-password.py /srv/almachaab-data/custom.db`. It reads the password securely from the terminal and revokes old sessions. Never retain the factory password on a public deployment.

## Build and start

```sh
node --env-file=.env.local node_modules/typescript/bin/tsc --noEmit
node_modules/.bin/eslint .
node_modules/.bin/next build
cp -a .next/static .next/standalone/.next/
cp -a public .next/standalone/
HOSTNAME=127.0.0.1 PORT=3000 NODE_ENV=production node --env-file=.env.local .next/standalone/server.js
```

Run from the application directory. Configure the process supervisor with that working directory, explicit environment-file loading, restart-on-failure and least filesystem access needed for the database/uploads. Live processes do not survive a snapshot or deployment. Keep the Node port on loopback. Adapt the proxy configuration to the chosen provider; the included historical Caddyfile assumes a Cloudflare proxy/firewall trust model and must not be used blindly when hosting directly.

Local readiness: `/api/site` must contain the 8 categories/37 imported dishes, `/` and `/admin` must respond, private APIs must reject anonymous edits, and a controlled edit/upload must survive reload and a process restart. Publish content only after reviewing drafts. Never send a live test payment or marketing campaign as a generic health check.

## Backups, updates and rollback

Use SQLite's backup API or the supplied backup utility for consistent snapshots; do not copy a live database file blindly while writes are active. Back up both DB and uploads, and retain the encryption key separately. Test restoration on a private copy. For schema changes, stop writes and retain the pre-migration snapshot. To roll back: stop the app, restore the corresponding code, DB snapshot and upload set together, then restart and re-run readiness checks. Retain the newer state for investigation rather than discarding customer data.

## External release gates

Confirm hosting cost/terms, domain/DNS/proxy access, real mail delivery and mobile push behavior. Configure payments/social providers only when requested and credentials are supplied securely. Confirm actual delivery listing URLs. Obtain article review and real photographs before claiming those assets are final. Consent/analytics and any loyalty/CRM launch require separate checks. Publication of the website requires the user's explicit instruction; this package performs none.
