# Alma Chaab v1.9.1 — security fixes (from audit R1)

No visual changes: the v1.9 design is untouched. All fixes are server-side, plus small client changes so payment buttons pass the tracking credentials.

## Must do on the server (DEPLOY.md §0)
- `.env`: **three different** random values: `APP_SECRET_KEY`, `NEXTAUTH_SECRET`, and `CRON_SECRET` (only if you use the cron). Also `NEXTAUTH_URL=https://almachaab.lt`.
  Without `APP_SECRET_KEY` the production app refuses to work (HTTP 500), on purpose.
- systemd: `Environment=HOSTNAME=127.0.0.1`. Use the new Caddyfile (Caddy 2.7+), and ideally firewall 80/443 to Cloudflare IPs.
- Admin password: still the factory default. Change it before DNS goes live (owner's task, SEC-003). New rule: min. 12 characters.

## Fixed
| ID | Fix |
|---|---|
| SEC-001 | Vault has no built-in key in production; an undecryptable or empty admin secret is replaced by a fresh random one; HMAC signing refuses short keys |
| SEC-002 | No hard-coded NextAuth fallback (derived per install, or `NEXTAUTH_SECRET`); the social bridge accepts only tokens minted after a real OAuth sign-in; `/api/auth/*` NextAuth endpoint returns 404 while no provider is enabled |
| SEC-004 | All customer values in emails are HTML-escaped centrally (`htmlSafeOrder`) |
| SEC-005 | Customer login: 5 fails per account, 10 per IP, 300 globally per 15 min; register 5 per IP per hour; same timing for unknown emails |
| SEC-006 | Caddy trusts `Cf-Connecting-Ip` only from Cloudflare and overwrites it; phone-last-4 tracking also capped at 20 fails per order per hour across all IPs |
| SEC-007 | SMTP password never sent to the browser (masked; saving the mask keeps it) |
| SEC-008 | VAPID private key encrypted at rest; release DB ships without keys (generated on the server) |
| SEC-009 | Cron needs its own `CRON_SECRET`, header only, constant-time compare |
| SEC-010 | Pay-later and payment-verify routes need the tracking token, phone last 4 or the signed-in owner |
| SEC-011 | Admin tokens carry a session version: logout and password change revoke all devices. 7-day lifetime. Header/`?token=` fallback is development-only |
| SEC-012 | CSP, X-Frame-Options DENY, nosniff and Referrer-Policy (app); HSTS and Permissions-Policy (Caddy) |
| SEC-013 | Customer cookie SameSite=Lax |
| SEC-014 | Admin password: min. 12 characters, can't reuse the default or trivial values |
| SEC-015 | Order field length caps; max 100 cart lines |
| SEC-016 | All absolute links and redirects come from `NEXTAUTH_URL`, never request headers |
| SEC-017 | About-section HTML goes through an allow-list sanitiser; theme CSS values are sanitised |

`scripts/prepare-release-db.mts` (run by `package-release.sh` on the staged copy) clears the admin secret, VAPID keys and provider secrets from the shipped DB.
