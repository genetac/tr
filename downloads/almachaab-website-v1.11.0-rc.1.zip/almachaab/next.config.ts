import type { NextConfig } from "next";

// SEC-012: Content-Security-Policy + anti-framing headers for every route.
// Third parties are limited to what the site actually loads: Cloudflare
// Turnstile, PayPal SDK, Telegram login widget (each only when enabled) and
// Cloudflare's optional analytics beacon. 'unsafe-inline' scripts are needed
// for Next.js inline bootstrap without nonces; 'unsafe-eval' only in dev (HMR).
// In DEV the anti-framing part is relaxed (frame-ancestors *, no XFO) because
// the sandbox preview renders the app inside an iframe; see securityHeaders.
const isDev = process.env.NODE_ENV !== "production";
const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""} https://challenges.cloudflare.com https://www.paypal.com https://telegram.org https://static.cloudflareinsights.com`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  `connect-src 'self'${isDev ? " ws: wss:" : ""} https://challenges.cloudflare.com https://www.paypal.com https://www.sandbox.paypal.com https://cloudflareinsights.com`,
  "frame-src 'self' https://challenges.cloudflare.com https://www.paypal.com https://www.sandbox.paypal.com https://oauth.telegram.org",
  "worker-src 'self'",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self' https://accounts.google.com https://www.facebook.com",
  // DEV: the sandbox preview (preview-*.space-z.ai) displays this app inside
  // an iframe, so anti-framing must be relaxed while developing — otherwise
  // the preview pane shows "refused to connect". PRODUCTION keeps SEC-012
  // anti-clickjacking fully strict.
  isDev ? "frame-ancestors *" : "frame-ancestors 'none'",
].join("; ");

const securityHeaders = [
  { key: "Content-Security-Policy", value: csp },
  // X-Frame-Options takes a single value and cannot whitelist the preview
  // origin, so it is omitted in dev (CSP frame-ancestors governs modern
  // browsers). Production keeps the strict SEC-012 header.
  ...(isDev ? [] : [{ key: "X-Frame-Options", value: "DENY" }]),
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
];

const nextConfig: NextConfig = {
  output: "standalone",
  // Pin the tracing root to this project so `.next/standalone/server.js`
  // is always at the expected path, even if a parent directory contains
  // another lockfile (which would otherwise nest the standalone output).
  outputFileTracingRoot: process.cwd(),
  // Type errors must not ship (review fix #9): the release script also runs
  // `tsc --noEmit` before packaging.
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      { source: "/admin/preview", headers: securityHeaders.map(h=>h.key==='Content-Security-Policy'?{...h,value:h.value.replace(/frame-ancestors [^;]+/,"frame-ancestors 'self'")}:h.key==='X-Frame-Options'?{...h,value:'SAMEORIGIN'}:h).concat([{key:'Cache-Control',value:'private, no-store'}]) },
    ];
  },
};

export default nextConfig;
