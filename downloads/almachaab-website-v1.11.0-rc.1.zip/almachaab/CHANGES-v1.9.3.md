# Alma Chaab v1.9.3 — pre-launch fixes (content, trust, code health)

Design unchanged (v1.9 look). Builds on v1.9.2.

## Fixed
| # | Change |
|---|---|
| 1 | **Admin image upload restored.** `src/app/api/admin/upload/route.ts` was missing in v1.9.2 (POST returned 404, so every image picker in admin failed). Cause: `.gitignore` line `upload/` also matched `src/app/api/admin/upload/`. The line is now `/upload/` (root folder only). |
| 2 | **`/virtuove` removed completely.** The redirect is gone; the URL now returns 404. `/virtuve` is the only kitchen route. |
| 3 | **Billiards offer is switchable and can expire.** Admin → Turinys → "Šventės ir renginiai" now has *Rodyti biliardo pasiūlymą* (on/off), *Galioja iki* (the block hides itself after that date) and the reservation-form line. The September text was replaced with neutral wording. |
| 4 | **Company details.** UAB „Chaab“, įmonės kodas 307075624 now appear in the footer, on /privatumas and /apie-mus, and in JSON-LD (`legalName` + `identifier`). Both can be edited in Admin → Nustatymai → Svetainė. |
| 5 | **Google Business Profile.** `site.mapsUrl` = https://share.google/yxkPJvWAh18FvUBOt (reviews link + JSON-LD `sameAs`). Directions still use the address. |
| 6 | **New /apie-mus page.** Irina and Elie Eid, the meaning of the name, how the bakery idea became a restaurant, the rooms, the team and owner photos, the "Apie mus rašė" press card (Kėdainių mugė, 2025-07-16) and company details. AboutPage JSON-LD. Added to the footer and sitemap. |
| 7 | **Press article.** New short article `/straipsniai/kedainiu-muge-apie-alma-chaab`: our own summary of the Kėdainių mugė piece with a link to the original. Irina's photo is also added to "Alma Chaab: Libano skoniai Kėdainių senamiestyje". |
| 8 | **Article author.** Byline "Irina Eid, Alma Chaab savininkė" under every article, linked to /apie-mus, plus a `Person` author in JSON-LD. Editable in Admin → Turinys → Straipsnių autorius (an empty name falls back to the restaurant). |
| 9 | **Restaurant JSON-LD:** `founder` (Irina Eid, Elie Eid) and `subjectOf` (Kėdainių mugė article). |
| 10 | **Homepage SEO text rewritten** to read naturally: no bolded keyword phrases, real facts and real menu dishes only. |
| 11 | **404 page.** Title "Puslapis nerastas (404) \| Alma Chaab", Lithuanian text, links to menu, articles, about and contacts, `noindex`. |
| 12 | **Image alt texts.** Menu category cards, cart lines and upsell images use dish names. |
| 13 | **Contact card on /privatumas was unreadable** (cream text on cream; CSS specificity). Fixed; it is now dark like the design intended. Same card used on /apie-mus. |
| 14 | **Theme CSS:** a missing theme value no longer emits `inherit` (side effect of SEC-017); missing values are simply skipped. |
| 15 | **Lint: 30 errors → 0** (React compiler rules). Content editor lists are now render helpers (fixes a real focus loss while typing). Prop→state sync follows the React pattern. Browser values use `useSyncExternalStore`. Fetch-on-mount goes through one `useLoadEffect` hook. Unused generated `carousel`, `sidebar` and `use-mobile` removed. 4 non-blocking warnings remain (full-page navigations kept on purpose). |
| 16 | Release cleanup: `scripts/daemonize.py` and `scripts/iframe-embed-test.html` removed; CHANGES-v1.5.md v1.6–v1.9 notes restored. |

## Corrections to the v1.9.2 notes
- v1.9.2 also **dropped the admin upload route** (see #1) and **changed the database**: the order counter moved 1053 → 1056 from test orders (harmless; the first real order will be AC-1056).

## To confirm with the owner
- Billiards price **5 € / val.** is still shown (it came from the September offer). Change or hide it in Admin → Turinys if it no longer applies.
- Articles are now signed by Irina Eid: she should read them once, or change the author in Admin → Turinys.

## Deploy
Same as v1.9.1 (DEPLOY.md §0). The admin password change is still the owner's task before DNS goes live.
