/**
 * Import the rewritten Alma Chaab articles into the database.
 *
 *   npx tsx scripts/seo/import-articles.ts --dry-run   # show what would change
 *   npx tsx scripts/seo/import-articles.ts             # apply
 *
 * - Backs up every existing article to db/backup-articles-<timestamp>.json first.
 * - Matches by slug. An entry with "replaces" renames that old (unpublished) row
 *   to the new slug instead of creating a duplicate.
 * - Keeps an existing publishedAt; new/never-published rows get "now".
 * - Never deletes anything.
 */
import fs from "node:fs";
import path from "node:path";
import { db } from "../../src/lib/db";

type Item = {
  slug: string;
  replaces?: string;
  title: string;
  excerpt: string;
  keywords: string;
  coverImage: string;
  published: boolean;
  body: unknown[];
};

const DRY = process.argv.includes("--dry-run");
const file = path.resolve(process.cwd(), "scripts/seo/articles.json");

async function main() {
  const items: Item[] = JSON.parse(fs.readFileSync(file, "utf8"));
  const existing = await db.article.findMany();

  if (!DRY) {
    const backup = path.resolve(process.cwd(), `db/backup-articles-${Date.now()}.json`);
    fs.writeFileSync(backup, JSON.stringify(existing, null, 2));
    console.log("backup →", backup);
  }

  for (const it of items) {
    const bySlug = existing.find((a) => a.slug === it.slug);
    const byOld = it.replaces ? existing.find((a) => a.slug === it.replaces) : undefined;
    const row = bySlug ?? byOld;
    const data = {
      slug: it.slug,
      title: it.title,
      excerpt: it.excerpt,
      keywords: it.keywords,
      coverImage: it.coverImage || "",
      bodyJson: JSON.stringify(it.body),
      published: it.published,
      publishedAt: row?.publishedAt ?? (it.published ? new Date() : null),
    };
    const action = row ? (row.slug !== it.slug ? `rename ${row.slug} →` : "update") : "create";
    console.log(`${DRY ? "[dry] " : ""}${action} ${it.slug}`);
    if (DRY) continue;
    if (row) await db.article.update({ where: { id: row.id }, data });
    else await db.article.create({ data });
  }

  const unknown = existing.filter(
    (a) => !items.some((it) => it.slug === a.slug || it.replaces === a.slug),
  );
  if (unknown.length) console.log("left untouched (not in import file):", unknown.map((a) => a.slug).join(", "));
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
