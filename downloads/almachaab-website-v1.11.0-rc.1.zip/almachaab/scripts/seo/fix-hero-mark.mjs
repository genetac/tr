/**
 * SEO plan Phase 4.5 — hero.mark copy: puts the main keyword
 * ("Libaniškas restoranas · Kėdainių senamiestis") right above the H1
 * without touching the design. Idempotent: only writes when different.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const NEW_MARK = "Libaniškas restoranas · Kėdainių senamiestis";

async function main() {
  const row = await db.setting.findUnique({ where: { key: "content" } });
  if (!row) {
    console.log("no content setting row — nothing to do (defaults render H1 only)");
    return;
  }
  const content = JSON.parse(row.value);
  const before = content?.hero?.mark;
  if (before === NEW_MARK) {
    console.log("hero.mark already up to date:", before);
    return;
  }
  content.hero = { ...(content.hero || {}), mark: NEW_MARK };
  await db.setting.update({ where: { key: "content" }, data: { value: JSON.stringify(content) } });
  console.log(`hero.mark: ${JSON.stringify(before)} → ${JSON.stringify(NEW_MARK)}`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
