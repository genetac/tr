/**
 * Copy menu photos that are hot-linked from other sites (e.g. imageproxy.wolt.com)
 * into our own upload folder + Media library, and point MenuItem.image at them.
 *
 *   npx tsx scripts/seo/localize-menu-images.ts --dry-run
 *   npx tsx scripts/seo/localize-menu-images.ts
 *
 * Needs outbound internet to the image host. Safe to re-run: only http(s) URLs are touched.
 * Ask the restaurant to confirm they own these photos (they were supplied to Wolt by them).
 */
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";
import sharp from "sharp";
import { db } from "../../src/lib/db";
import { UPLOAD_DIR } from "../../src/lib/uploads";

const DRY = process.argv.includes("--dry-run");

function slug(s: string) {
  const map: Record<string, string> = { ą: "a", č: "c", ę: "e", ė: "e", į: "i", š: "s", ų: "u", ū: "u", ž: "z" };
  return s.toLowerCase().replace(/[ąčęėįšųūž]/g, (m) => map[m]).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "menu";
}

async function main() {
  const items = await db.menuItem.findMany({ where: { image: { startsWith: "http" } } });
  console.log(`${items.length} menu items use external images`);
  if (!DRY) await mkdir(UPLOAD_DIR, { recursive: true });
  let ok = 0;
  for (const it of items) {
    if (DRY) { console.log("[dry]", it.name, "←", it.image); continue; }
    try {
      const res = await fetch(it.image, { signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const webp = await sharp(Buffer.from(await res.arrayBuffer()))
        .rotate()
        .resize({ width: 1200, height: 1200, fit: "inside", withoutEnlargement: true })
        .webp({ quality: 80 })
        .toBuffer();
      const filename = `menu-${slug(it.name)}-${randomBytes(3).toString("hex")}.webp`;
      await writeFile(path.join(UPLOAD_DIR, filename), webp);
      await db.media.create({ data: { filename, mime: "image/webp", size: webp.length, title: it.name } });
      await db.menuItem.update({ where: { id: it.id }, data: { image: `/api/files/${filename}` } });
      ok++;
      console.log("✓", it.name);
    } catch (e) {
      console.log("✗", it.name, "-", (e as Error).message, "(left unchanged)");
    }
  }
  if (!DRY) console.log(`done: ${ok}/${items.length} localized`);
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
