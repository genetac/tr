/**
 * SEO handoff verification — Phase 1 (home/meta/schema/icons) + Phase 2 (articles)
 * Run with dev or prod server on :3000.  Exits 1 on any failure.
 */
const BASE = process.env.BASE_URL || "http://localhost:3000";
let pass = 0, fail = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${extra}`); }
};

const get = async (p) => {
  const r = await fetch(BASE + p);
  return { r, body: r.ok ? await r.text() : "" };
};

const SLUGS = [
  "kur-pavalgyti-kedainiuose-libano-skoniai-senamiestyje",
  "libano-skoniai-kedainiu-senamiestyje",
  "libanietiskas-restoranas-kedainiuose-kas-tai-reiskia-jusu-leksteje",
  "ka-paragauti-alma-chaab-pirma-karta",
  "pietus-kedainiuose-greita-sveika-ir-skoninga-pietu-pertrauka",
  "romantiska-vakariene-kedainiuose-vakaras-senamiestyje",
  "banketai-ir-sventes-kedainiuose-nuo-gimtadienio-iki-vestuviu",
  "maistas-issinesimui-kedainiuose-uzsisakykite-internetu-per-minutes",
  "renginiai-degustacijos-ir-biliardas",
];

async function main() {
  console.log("— Phase 1: home —");
  {
    const { r, body } = await get("/");
    ok("GET / → 200", r.status === 200);
    ok("title = new 56-char one", body.includes("<title>Alma Chaab — libaniškas restoranas Kėdainių senamiestyje"));
    ok("no aggregateRating", !body.includes("aggregateRating"));
    const sections = (body.match(/"@type":"MenuSection"/g) || []).length;
    ok("MenuSection × 8", sections === 8, `got ${sections}`);
    ok("Menu JSON-LD present", body.includes('"@type":"Menu"'));
    ok("no default-password hint anywhere", !body.includes("alma2026"));
    ok("footer has no /admin link", !body.includes('href="/admin"'));
    ok("hero mark updated", body.includes("Libaniškas restoranas · Kėdainių senamiestis"));
    ok("geo corrected", body.includes("55.28718") && body.includes("23.97782"));
  }

  console.log("— Icons —");
  for (const f of ["favicon.ico", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png"]) {
    const { r } = await get("/" + f);
    ok(`${f} → 200`, r.status === 200);
  }

  console.log("— Phase 2: articles —");
  for (const slug of SLUGS) {
    const { r, body } = await get(`/straipsniai/${slug}`);
    if (r.status !== 200) { ok(`${slug} → 200`, false, `(got ${r.status})`); continue; }
    const h1 = (body.match(/<h1[ >]/g) || []).length;
    ok(`${slug.slice(0, 44)}… 200`, true);
    ok("  one <h1>", h1 === 1, `got ${h1}`);
    ok("  BlogPosting JSON-LD", body.includes('"@type":"BlogPosting"'));
    ok("  FAQPage JSON-LD", body.includes('"@type":"FAQPage"'));
    ok("  related block (Skaitykite toliau)", body.includes("Skaitykite toliau"));
    ok("  no raw ** markers", !body.includes("**"));
    ok("  no raw ]( links", !body.includes("]("));
    ok("  FAQ question text visible", body.includes("Dažni klausimai"));
  }

  console.log("— Sitemap —");
  {
    const { r, body } = await get("/sitemap.xml");
    ok("GET /sitemap.xml → 200", r.status === 200);
    for (const s of SLUGS) ok(`  sitemap has ${s.slice(0, 40)}…`, body.includes(s));
    ok("  sitemap has /privatumas", body.includes("/privatumas"));
    // lastModified should be a real date, not "now" — just check format present
    ok("  lastmod entries", (body.match(/<lastmod>/g) || []).length >= 12);
  }

  console.log("— Upload route guards —");
  {
    const r1 = await fetch(`${BASE}/api/admin/upload`, { method: "POST" });
    ok("upload POST logged-out → 401", r1.status === 401);
    const r2 = await fetch(`${BASE}/api/admin/media`, { method: "POST", body: JSON.stringify({ to: "x@y.lt" }) });
    ok("media POST removed → 401/404/405", [401, 404, 405].includes(r2.status));
    const r3 = await fetch(`${BASE}/api/admin/email-test`, { method: "POST", body: JSON.stringify({ to: "x@y.lt" }) });
    ok("email-test route exists (401 logged-out)", r3.status === 401);
  }

  console.log(`\nRESULT: ${pass} pass, ${fail} fail`);
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
