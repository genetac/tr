/**
 * E2E: admin image upload (new /api/admin/upload route from the SEO handoff).
 * 1. login → session cookie
 * 2. POST a real generated JPG (multipart "files")
 * 3. expect { files:[{url}] }, file on disk in UPLOAD_DIR, Media row in DB
 * 4. GET the returned /api/files/<name> → 200 image/webp
 * 5. reject a fake image (text disguised as .jpg) → 400
 * 6. logged-out POST → 401
 * Cleans up the created Media row + file afterwards.
 */
import sharp from "sharp";
import { readFile, unlink } from "fs/promises";
import path from "path";

const BASE = process.env.BASE_URL || "http://localhost:3000";
const ADMIN_PW = process.env.ADMIN_PW || "alma2026";
let pass = 0, fail = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${extra}`); }
};

async function main() {
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient();
  const origAdminRow = await db.setting.findUnique({ where: { key: "admin" } });
  const TEST_PW = "SeoUpload-2026!";

  // 6. logged-out first
  const anon = await fetch(`${BASE}/api/admin/upload`, { method: "POST" });
  ok("logged-out POST → 401", anon.status === 401, `(got ${anon.status})`);

  // 1. login (+ forced password change when the factory default is in use)
  const lr = await fetch(`${BASE}/api/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: BASE },
    body: JSON.stringify({ password: ADMIN_PW }),
  });
  const loginJson = await lr.json().catch(() => ({}));
  let cookie = (lr.headers.getSetCookie?.() || []).map((c) => c.split(";")[0]).join("; ");
  ok("admin login", lr.status === 200 && cookie.length > 0, `(got ${lr.status})`);
  if (loginJson.mustChangePassword) {
    const cp = await fetch(`${BASE}/api/admin/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Cookie: cookie, Origin: BASE },
      body: JSON.stringify({ key: "password", current: ADMIN_PW, next: TEST_PW }),
    });
    const rl = await fetch(`${BASE}/api/admin/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Origin: BASE },
      body: JSON.stringify({ password: TEST_PW }),
    });
    cookie = (rl.headers.getSetCookie?.() || []).map((c) => c.split(";")[0]).join("; ");
    ok("must-change flow → clean session", rl.status === 200 && cookie.length > 0, `(got ${rl.status})`);
  }

  // 2. real JPG via sharp (2000×1200 → must come back ≤1920 webp)
  const jpg = await sharp({ create: { width: 2000, height: 1200, channels: 3, background: { r: 180, g: 123, b: 45 } } })
    .jpeg({ quality: 90 }).toBuffer();
  const fd = new FormData();
  fd.append("files", new Blob([jpg], { type: "image/jpeg" }), "seo-test-upload.jpg");

  const up = await fetch(`${BASE}/api/admin/upload`, {
    method: "POST",
    headers: { Cookie: cookie, Origin: BASE },
    body: fd,
  });
  const upText = await up.text();
  ok("upload POST → 200", up.status === 200, `(got ${up.status}) ${upText.slice(0, 200)}`);
  let data = {};
  try { data = JSON.parse(upText); } catch { /* leave {} */ }
  const file = data?.files?.[0];
  ok("response has files[0].url", !!file?.url, JSON.stringify(data).slice(0, 120));
  if (file?.url) {
    ok("url is /api/files/*.webp", /^\/api\/files\/[a-z0-9-]+\.webp$/.test(file.url), file.url);

    // 3. file on disk + Media row
    const name = file.url.split("/").pop();
    const disk = path.join(process.cwd(), "uploads", name);
    const buf = await readFile(disk).catch(() => null);
    ok("file exists in UPLOAD_DIR", !!buf);
    if (buf) {
      const meta = await sharp(buf).metadata();
      ok("re-encoded to webp", meta.format === "webp", meta.format);
      ok("resized to ≤1920", Math.max(meta.width, meta.height) <= 1920, `${meta.width}×${meta.height}`);
      ok("smaller than original", buf.length < jpg.length, `${buf.length} vs ${jpg.length}`);
    }

    // 4. served back
    const serv = await fetch(BASE + file.url);
    ok("GET /api/files/<name> → 200", serv.status === 200);
    ok("content-type image/webp", (serv.headers.get("content-type") || "").includes("webp"));

    // 5. Media row registered
    const mres = await fetch(`${BASE}/api/admin/media`, { headers: { Cookie: cookie } });
    const mdata = await mres.json().catch(() => ({}));
    ok("appears in media library", (mdata.media || []).some((m) => m.url === file.url));

    // cleanup
    await db.media.deleteMany({ where: { filename: name } });
    await unlink(disk).catch(() => {});
    console.log("  (cleaned up test upload)");
  }

  // 5b. fake image rejected
  const fd2 = new FormData();
  fd2.append("files", new Blob([Buffer.from("this is not an image at all")], { type: "image/jpeg" }), "fake.jpg");
  const bad = await fetch(`${BASE}/api/admin/upload`, {
    method: "POST", headers: { Cookie: cookie, Origin: BASE }, body: fd2,
  });
  ok("fake image → 400", bad.status === 400, `(got ${bad.status})`);

  // restore admin settings row (password back to pre-test state)
  if (origAdminRow) {
    await db.setting.update({ where: { key: "admin" }, data: { value: origAdminRow.value } });
    console.log("  (admin settings row restored)");
  }
  await db.$disconnect();

  console.log(`\nRESULT: ${pass} pass, ${fail} fail`);
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
