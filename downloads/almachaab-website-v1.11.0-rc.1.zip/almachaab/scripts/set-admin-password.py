#!/usr/bin/env python3
"""Set the initial admin password locally before exposing a new deployment."""
import getpass, hashlib, json, secrets, sqlite3, sys
from pathlib import Path
path=Path(sys.argv[1] if len(sys.argv)>1 else 'db/custom.db')
if not path.is_file(): raise SystemExit('Database file not found.')
password=getpass.getpass('Naujas administratoriaus slaptažodis (bent 12 simbolių): ')
if len(password)<12 or len(password)>200 or len(set(password))<5: raise SystemExit('Pasirinkite ilgesnį, sunkiau atspėjamą slaptažodį.')
if password!=getpass.getpass('Pakartokite slaptažodį: '): raise SystemExit('Slaptažodžiai nesutampa.')
salt=secrets.token_hex(16)
encoded='scrypt:'+salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1,dklen=64).hex()
with sqlite3.connect(path) as db:
    row=db.execute("SELECT value FROM Setting WHERE key='admin'").fetchone()
    if not row: raise SystemExit('Admin settings not found.')
    admin=json.loads(row[0]);admin.update(passwordHash=encoded,secret='',sessionVersion=admin.get('sessionVersion',0)+1)
    db.execute("UPDATE Setting SET value=? WHERE key='admin'",(json.dumps(admin),))
print('Slaptažodis nustatytas. Paleiskite arba iš naujo paleiskite serverį; ankstesnės sesijos nebegalios.')
