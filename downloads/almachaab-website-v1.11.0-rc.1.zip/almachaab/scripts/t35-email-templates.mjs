/**
 * Task 35 e2e — editable email templates (admin panel) over a REAL SMTP round-trip.
 *
 * 1. Starts a minimal SMTP capture server on 127.0.0.1:2525 (AUTH LOGIN + DATA).
 * 2. Enables the real email settings (admin API) pointing at that server.
 * 3. POST /api/admin/email-preview:
 *    - unauthenticated -> 401, bad key -> 400
 *    - default order.paid render over sample data (subject, blocks, payment, track)
 *    - unsaved draft merge (custom subject/body rendered, defaults kept for rest)
 *    - send:true test-send arrives at the capture server
 * 4. Saves a CUSTOM order.paid template (placeholders + toggles off) via settings PUT,
 *    creates a real pickup order, PATCH paid+confirmed -> receipt uses the custom text,
 *    items/track blocks hidden, payment block kept.
 * 5. Non-overridden event ("ready") still renders the built-in default.
 * 6. Reset (templates: {}) -> preview falls back to defaults again.
 * 7. Restores original email settings (DB), deletes the test order.
 */
import net from "node:net";
import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000";
const ADMIN_PW = process.env.ADMIN_PW || "alma2026";
const TEST_PW = "alma2026-e2e"; // forced-change target password
const db = new PrismaClient();
let fail = 0;
const ok = (cond, label) => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}`);
  if (!cond) fail++;
};

// ---------- tiny SMTP capture server (explicit state machine) ----------
const captured = []; // { from, to, data }

const server = net.createServer((sock) => {
  let stage = "greet"; // greet | user | pass | ready | from | rcpt | data | quit
  let buf = "";
  let from = "";
  let to = "";
  smtpReply(["220 capture.local ESMTP t35"]);
  sock.on("data", (chunk) => {
    buf += chunk.toString("utf8");
    while (true) {
      if (stage === "data") {
        const end = buf.indexOf("\r\n.\r\n");
        if (end < 0) return;
        const data = buf.slice(0, end).replace(/^\.\./gm, "."); // undo dot-stuffing
        captured.push({ from, to, data });
        buf = buf.slice(end + 5);
        stage = "ready";
        smtpReply(["250 OK: queued as t35"]);
        continue;
      }
      const nl = buf.indexOf("\r\n");
      if (nl < 0) return;
      const line = buf.slice(0, nl);
      buf = buf.slice(nl + 2);
      const up = line.toUpperCase();
      if (up.startsWith("EHLO") || up.startsWith("HELO")) {
        sock.write("250-capture.local\r\n250-SIZE 5242880\r\n250-AUTH PLAIN LOGIN\r\n250 OK\r\n");
      } else if (up.startsWith("AUTH LOGIN")) {
        stage = "user";
        smtpReply(["334 VXNlcm5hbWU6"]);
      } else if (stage === "user") {
        stage = "pass";
        smtpReply(["334 UGFzc3dvcmQ6"]);
      } else if (stage === "pass") {
        stage = "ready";
        smtpReply(["235 2.7.0 Accepted"]);
      } else if (up.startsWith("MAIL FROM:")) {
        from = line.slice(10).trim();
        stage = "from";
        smtpReply(["250 OK"]);
      } else if (up.startsWith("RCPT TO:")) {
        to = line.slice(8).trim();
        stage = "rcpt";
        smtpReply(["250 OK"]);
      } else if (up === "DATA") {
        stage = "data";
        smtpReply(["354 End data with <CR><LF>.<CR><LF>"]);
      } else if (up.startsWith("QUIT")) {
        smtpReply(["221 Bye"]);
        sock.end();
      } else {
        smtpReply(["250 OK"]);
      }
    }
  });
  function smtpReply(lines) {
    for (const l of lines) sock.write(l + "\r\n");
  }
  sock.on("error", () => {});
});

// ---------- helpers ----------
async function api(path, opts = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text.slice(0, 200) };
  }
  return { status: res.status, json, setCookie: res.headers.get("set-cookie") };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(n, timeoutMs = 9000) {
  const t0 = Date.now();
  while (captured.length < n) {
    if (Date.now() - t0 > timeoutMs) return false;
    await sleep(150);
  }
  return true;
}
/** Raw Subject header INCLUDING folded continuation lines ("\r\n " + content). */
function rawSubject(data) {
  const m = data.match(/^Subject: [^\r\n]*(?:\r\n[ \t][^\r\n]*)*/m);
  return m ? m[0].slice("Subject: ".length) : "";
}
function subjects() {
  return captured.map((c) => decodeSubj(rawSubject(c.data)) || "(no subject)");
}
/** Decode folded RFC2047 =?UTF-8?Q?..?= / =?UTF-8?B?..?= subject words. */
function decodeSubj(raw) {
  const unfolded = raw.replace(/\r?\n[ \t]+/g, "").replace(/\?=\s+=\?/g, "?==?");
  return unfolded
    .replace(/=\?UTF-8\?([QB])\?([^?]*)\?=/gi, (_, enc, payload) => {
      try {
        if (enc.toUpperCase() === "B") return Buffer.from(payload, "base64").toString("utf8");
        const bytes = [];
        for (let i = 0; i < payload.length; i++) {
          const ch = payload[i];
          if (ch === "_") bytes.push(0x20);
          else if (ch === "=" && /^[0-9A-F]{2}$/i.test(payload.slice(i + 1, i + 3))) {
            bytes.push(parseInt(payload.slice(i + 1, i + 3), 16));
            i += 2;
          } else bytes.push(payload.charCodeAt(i) & 0xff);
        }
        return Buffer.from(bytes).toString("utf8");
      } catch {
        return "?";
      }
    });
}
/** Decode an email body per its Content-Transfer-Encoding (qp / base64 / 7bit). */
function decodeBody(data) {
  const sep = data.indexOf("\r\n\r\n");
  if (sep < 0) return data;
  const headers = data.slice(0, sep);
  let body = data.slice(sep + 4);
  const cte = (headers.match(/Content-Transfer-Encoding:\s*(\S+)/i) || [])[1]?.toLowerCase() || "7bit";
  try {
    if (cte === "base64") return Buffer.from(body.replace(/\s+/g, ""), "base64").toString("utf8");
    if (cte === "quoted-printable") {
      body = body.replace(/=\r\n/g, "");
      const bytes = [];
      for (let i = 0; i < body.length; i++) {
        if (body[i] === "=" && /^[0-9A-F]{2}$/i.test(body.slice(i + 1, i + 3))) {
          bytes.push(parseInt(body.slice(i + 1, i + 3), 16));
          i += 2;
        } else bytes.push(body.charCodeAt(i) & 0xff);
      }
      return Buffer.from(bytes).toString("utf8");
    }
  } catch {}
  return body;
}
const fmtEur = (v) => v.toFixed(2).replace(".", ",") + " €";

// ---------- run ----------
let adminCookie = "";
let orderId = null;
let origEmailRow = null;
let origAdminRow = null;

server.listen(2525, "127.0.0.1");
await sleep(300);

try {
  // 0. Snapshot email + admin settings rows (restored via DB at the end).
  origEmailRow = await db.setting.findUnique({ where: { key: "email" } });
  origAdminRow = await db.setting.findUnique({ where: { key: "admin" } });

  // 1. Admin login (+ forced password change when the factory default is in use).
  const login = await api("/api/admin/login", {
    method: "POST",
    body: JSON.stringify({ password: ADMIN_PW }),
  });
  adminCookie = (login.setCookie || "").split(";")[0];
  ok(login.json.ok === true && !!adminCookie, "admin login");
  if (login.json.mustChangePassword) {
    const changePw = await api("/api/admin/settings", {
      method: "PUT",
      headers: { cookie: adminCookie },
      body: JSON.stringify({ key: "password", current: ADMIN_PW, next: TEST_PW }),
    });
    ok(changePw.json.ok === true, "forced password change accepted (must-change flow)");
    const relogin = await api("/api/admin/login", {
      method: "POST",
      body: JSON.stringify({ password: TEST_PW }),
    });
    adminCookie = (relogin.setCookie || "").split(";")[0];
    ok(relogin.json.ok === true && relogin.json.mustChangePassword === false, "relogin with new password — no mustChange flag");
  }

  // 2. Point the REAL email settings at the capture server.
  await api("/api/admin/settings", {
    method: "PUT",
    headers: { cookie: adminCookie },
    body: JSON.stringify({
      key: "email",
      value: {
        enabled: true,
        host: "127.0.0.1",
        port: 2525,
        secure: false,
        user: "system@almachaab.lt",
        pass: "capture-pass",
        from: "system@almachaab.lt",
        fromName: "Alma Chaab",
        notifyEmail: "info@almachaab.lt",
      },
    }),
  });

  // 3. Preview API — auth + validation.
  const unauth = await api("/api/admin/email-preview", {
    method: "POST",
    body: JSON.stringify({ key: "order.paid" }),
  });
  ok(unauth.status === 401, `preview without session -> 401 (got ${unauth.status})`);

  const badKey = await api("/api/admin/email-preview", {
    method: "POST",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ key: "hacker.payload" }),
  });
  ok(badKey.status === 400, `preview with bad key -> 400 (got ${badKey.status})`);

  // 4. Preview API — default order.paid over sample data.
  const def = await api("/api/admin/email-preview", {
    method: "POST",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ key: "order.paid" }),
  });
  ok(def.status === 200 && def.json.ok === true, "preview default order.paid renders");
  ok(
    def.json.subject === "Kvitas – užsakymas #AC-1042 apmokėtas (12,20 €)",
    `default subject with sample data: "${def.json.subject}"`
  );
  const defHtml = def.json.html || "";
  ok(defHtml.includes("Šiandien 17:30") && defHtml.includes("AC-1042") && defHtml.includes("12,20 €"), "preview shows base info block");
  ok(defHtml.includes("Obuolių pyragas") && defHtml.includes("Kava"), "preview shows items table");
  ok(defHtml.includes("Banko kortelė (Stripe)") && defHtml.includes("pi_3PxYzDemo123456"), "preview shows payment block (method + ref)");
  ok(defHtml.includes("/mano?nr=AC-1042"), "preview shows tracking link");

  // 5. Preview API — unsaved draft merges over saved defaults.
  const draft = await api("/api/admin/email-preview", {
    method: "POST",
    headers: { cookie: adminCookie },
    body: JSON.stringify({
      key: "order.paid",
      template: { subject: "TEST {{vardas}} {{suma}}", body: "Zodis {{ref}}." },
    }),
  });
  ok(draft.status === 200, "preview with draft renders");
  ok(draft.json.subject === "TEST Eglė Petraitienė 12,20 €", `draft placeholders substituted: "${draft.json.subject}"`);
  ok((draft.json.html || "").includes("Zodis pi_3PxYzDemo123456."), "draft body placeholder substituted");
  ok((draft.json.html || "").includes("Banko kortelė (Stripe)"), "draft keeps default payment block");

  // 6. Test-send through the preview API (uses real settings -> capture server).
  const sent = await api("/api/admin/email-preview", {
    method: "POST",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ key: "order.paid", send: true, to: "preview@test.lt" }),
  });
  ok(sent.json.sent && sent.json.sent.ok === true, "preview test-send accepted");
  ok(await waitFor(1), "test-send arrived over SMTP");
  ok(/To: preview@test\.lt/i.test(captured[0]?.data || ""), "test-send addressed to the entered mailbox");

  // 7. Save a CUSTOM order.paid template (real settings PUT, like the panel does).
  const customTpl = {
    subject: "Mano kvitas {{numeris}} — {{suma}}",
    title: "Apmokėta!",
    body: "Dėkojame, {{vardas}}! Operacija {{ref}}.\nAntra eilutė.",
    showDetails: true,
    showItems: false,
    showPayment: true,
    showTrack: false,
  };
  const item = await db.menuItem.findFirst({ where: { active: true } });
  await api("/api/admin/settings", {
    method: "PUT",
    headers: { cookie: adminCookie },
    body: JSON.stringify({
      key: "email",
      value: {
        enabled: true,
        host: "127.0.0.1",
        port: 2525,
        secure: false,
        user: "system@almachaab.lt",
        pass: "capture-pass",
        from: "system@almachaab.lt",
        fromName: "Alma Chaab",
        notifyEmail: "info@almachaab.lt",
        templates: { "order.paid": customTpl },
      },
    }),
  });

  // 8. Real order -> custom receipt over SMTP.
  const hh = new Date(Date.now() + 2 * 3600e3).toTimeString().slice(0, 5);
  const created = await api("/api/orders", {
    method: "POST",
    body: JSON.stringify({
      type: "pickup",
      customerName: "T35 Testas",
      phone: "+37060000000",
      email: "customer@test.lt",
      items: [{ id: item.id, qty: 1 }],
      pickupTime: hh,
      note: "t35 e2e",
    }),
  });
  ok(created.json.ok === true, `order created: #${created.json.number} (${created.json.total} €)`);
  const row = await db.order.findUnique({ where: { number: created.json.number } });
  orderId = row.id;
  ok(await waitFor(3), "received + restaurant copy sent (2 new emails)");

  const paid = await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ paid: true, status: "confirmed" }),
  });
  ok(paid.json.ok === true && paid.json.order.paymentStatus === "paid", "admin mark paid (venue)");
  ok(await waitFor(4), "custom receipt sent");

  const wantSubject = `Mano kvitas ${created.json.number} — ${fmtEur(created.json.total)}`;
  const receipt = captured.find((c) => decodeSubj(rawSubject(c.data)).includes("Mano kvitas"));
  ok(!!receipt, `custom receipt subject: "${subjects().find((s) => s.includes("Mano kvitas")) || "—"}"`);
  ok(subjects().some((s) => s === wantSubject), `subject matches custom template with placeholders (${wantSubject})`);
  if (receipt) {
    const body = decodeBody(receipt.data);
    ok(body.includes("Dėkojame, T35 Testas! Operacija admin-"), "custom body + {{vardas}} + {{ref}} substituted");
    ok(body.includes("Antra eilutė"), "multi-line body -> separate paragraphs");
    ok(!body.includes(item.name), "items table hidden (showItems: false)");
    ok(!body.includes("/mano?nr="), "tracking link hidden (showTrack: false)");
    ok(body.includes("Mokėjimo būdas") && body.includes("Apmokėta suma"), "payment block kept (showPayment: true)");
    ok(/To: customer@test\.lt/i.test(receipt.data), "receipt addressed to customer email");
  }

  // 9. Non-overridden event still uses the built-in default.
  await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ status: "ready" }),
  });
  ok(await waitFor(5), "ready email sent");
  ok(
    (subjects()[4] || "").includes("paruoštas") && (subjects()[4] || "").startsWith("Užsakymas #"),
    `non-overridden template falls back to default: "${subjects()[4] || "—"}"`
  );

  // 10. Idempotency — repeat paid must not re-send.
  await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ paid: true }),
  });
  await sleep(1200);
  ok(captured.length === 5, `repeat paid is a no-op (still ${captured.length} emails)`);

  // 11. Reset (templates: {}) -> preview back to defaults.
  await api("/api/admin/settings", {
    method: "PUT",
    headers: { cookie: adminCookie },
    body: JSON.stringify({
      key: "email",
      value: {
        enabled: true,
        host: "127.0.0.1",
        port: 2525,
        secure: false,
        user: "system@almachaab.lt",
        pass: "capture-pass",
        from: "system@almachaab.lt",
        fromName: "Alma Chaab",
        notifyEmail: "info@almachaab.lt",
        templates: {},
      },
    }),
  });
  const afterReset = await api("/api/admin/email-preview", {
    method: "POST",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ key: "order.paid" }),
  });
  ok(
    afterReset.json.subject === "Kvitas – užsakymas #AC-1042 apmokėtas (12,20 €)",
    "after reset, default template is back"
  );
} catch (e) {
  fail++;
  console.error("ERROR:", e);
} finally {
  // 12. Cleanup: restore original email + admin settings rows, delete the test order.
  try {
    if (origAdminRow) {
      await db.setting.update({ where: { key: "admin" }, data: { value: origAdminRow.value } });
      console.log("admin settings restored (password/scheme as before)");
    }
    if (origEmailRow) {
      await db.setting.update({ where: { key: "email" }, data: { value: origEmailRow.value } });
      console.log("email settings restored from snapshot");
    } else {
      await db.setting.delete({ where: { key: "email" } }).catch(() => {});
      console.log("email settings row removed (did not exist before)");
    }
    if (orderId && adminCookie) {
      await fetch(`${BASE}/api/admin/orders/${orderId}`, {
        method: "DELETE",
        headers: { cookie: adminCookie },
      });
    }
  } catch {}
  server.close();
  await db.$disconnect();

  console.log("\nEmails captured:");
  for (const s of subjects()) console.log("  •", s);
  console.log(fail === 0 ? "\nALL CHECKS PASSED ✓" : `\n${fail} CHECK(S) FAILED ✗`);
  process.exit(fail === 0 ? 0 : 1);
}
