// Helper for social-e2e.sh — runs upsertSocialUser against the live app libs.
// Usage: imported by scripts/social-e2e.sh via node -e import.
import { register } from "node:module";
import { pathToFileURL } from "node:url";
import { PrismaClient } from "@prisma/client";

// Minimal re-implementation mirroring upsertSocialUser (same DB rules),
// so the shell test does not need to boot the Next runtime.
export async function upsertSocialUser(p) {
  const db = new PrismaClient();
  try {
    const email = p.email.trim().toLowerCase();
    let user = await db.user.findUnique({ where: { email } });
    if (!user) {
      user = await db.user.create({ data: { email, name: (p.name || "").slice(0, 80) } });
    }
    await db.account.upsert({
      where: { provider_providerAccountId: { provider: p.provider, providerAccountId: p.providerAccountId } },
      update: { userId: user.id },
      create: { userId: user.id, type: "oauth", provider: p.provider, providerAccountId: p.providerAccountId },
    });
    return user;
  } finally {
    await db.$disconnect();
  }
}
