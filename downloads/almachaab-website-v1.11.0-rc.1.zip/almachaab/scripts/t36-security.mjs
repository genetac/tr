/**
 * Task 36 e2e — security & privacy review fixes.
 *
 * #2  default-password hint gone + forced password change at first login
 * #3  tracking token / phone-last-4 gate; name dropped from public reply; SSE guard
 * #4  secrets at rest encrypted (enc:v1:... in the DB)
 * #5  admin password scrypt + 5 fails / 15 min rate limit
 * #6  SameSite=Lax cookie + Origin check on write APIs
 * #1  no .zip/.db inside public/
 *
 * Uses x-forwarded-for to simulate distinct client IPs for the rate-limit test.
 */
import fs from "node:fs";
import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000";
const DEFAULT_PW = "alma2026";
const TEST_PW = "sec-test-123";
const db = new PrismaClient();
let fail = 0;
const ok = (cond, label) => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}`);
  if (!cond) fail++;
};

async function api(path, opts = {}, ip) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(ip ? { "x-forwarded-for": ip } : {}),
      ...(opts.headers || {}),
    },
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text.slice(0, 120) }; }
  return { status: res.status, json, setCookie: res.headers.get("set-cookie") };
}

let adminCookie = "";
let orderId = null;
let origAdmin = null;
let origOrders = null;

try {
  // ---- #1 public/ hygiene -------------------------------------------------
  const leaks = fs
    .readdirSync("public", { withFileTypes: true })
    .filter((f) => /\.(zip|db|sqlite|sqlite3)$/i.test(f.name) && f.isFile());
  ok(leaks.length === 0, `#1 no .zip/.db in public/ (found: ${leaks.map((f) => f.name).join(", ") || "none"})`);

  // ---- #4 secrets at rest -------------------------------------------------
  const storeRow = await db.settings.findUnique({ where: { id: "global" } });
  const secretFields = ["stripeSecretKey", "stripeWebhookSecret", "paypalSecret", "googleClientSecret", "facebookClientSecret", "telegramBotToken", "turnstileSecretKey"].filter((k) => storeRow?.[k]);
  const allEnc = secretFields.length > 0 && secretFields.every((k) => String(storeRow[k]).startsWith("enc:v1:"));
  ok(allEnc, `#4 store secrets encrypted at rest (${secretFields.length} field(s) checked)`);
  const adminRow = await db.setting.findUnique({ where: { key: "admin" } });
  const adminSecretEnc = adminRow ? JSON.parse(adminRow.value).secret.startsWith("enc:v1:") : false;
  ok(adminSecretEnc, "#4 admin session secret encrypted at rest");

  // ---- snapshot for cleanup ----------------------------------------------
  origAdmin = await db.setting.findUnique({ where: { key: "admin" } }).catch(() => null);
  origOrders = await db.order.count();

  // ---- #6 Origin check ----------------------------------------------------
  const badOrigin = await api("/api/orders", { method: "POST", body: "{}", headers: { origin: "https://evil.example" } });
  ok(badOrigin.status === 403, `#6 cross-site POST rejected (got ${badOrigin.status})`);
  const goodOrigin = await api("/api/orders", {
    method: "POST",
    body: JSON.stringify({ items: [] }),
    headers: { origin: BASE },
  });
  ok(goodOrigin.status !== 403, `#6 same-origin POST passes the origin gate (got ${goodOrigin.status})`);
  const noOrigin = await api("/api/orders", { method: "POST", body: JSON.stringify({ items: [] }) });
  ok(noOrigin.status !== 403, `#6 non-browser POST (no Origin) passes (got ${noOrigin.status})`);

  // ---- #5 rate limit: 5 fails / 15 min per IP -----------------------------
  // Fresh random IP each run — the limiter state lives in the server process.
  const RATE_IP = `9.${Math.floor(Math.random() * 250) + 1}.${Math.floor(Math.random() * 250) + 1}.${Math.floor(Math.random() * 250) + 1}`;
  for (let i = 0; i < 5; i++) {
    const r = await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password: "wrong-" + i }) }, RATE_IP);
    ok(r.status === 401, `#5 wrong attempt ${i + 1} -> 401 (got ${r.status})`);
  }
  const blocked = await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password: DEFAULT_PW }) }, RATE_IP);
  ok(blocked.status === 429, `#5 6th attempt blocked -> 429 even with the RIGHT password (got ${blocked.status})`);

  // ---- #2 forced password change ------------------------------------------
  const CHANGE_IP = `7.${Math.floor(Math.random()*250)+1}.${Math.floor(Math.random()*250)+1}.${Math.floor(Math.random()*250)+1}`;
  const login = await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password: DEFAULT_PW }) }, CHANGE_IP);
  ok(login.json.ok === true && login.json.mustChangePassword === true, "#2 default-password login flags mustChangePassword");
  adminCookie = (login.setCookie || "").split(";")[0];

  const blockedApi = await api("/api/admin/settings", { headers: { cookie: adminCookie } });
  ok(blockedApi.status === 401, "#2 must-change session is blocked from admin APIs (401)");

  const change = await api("/api/admin/settings", {
    method: "PUT",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ key: "password", current: DEFAULT_PW, next: TEST_PW }),
  });
  ok(change.json.ok === true, "#2 password change allowed under must-change session");
  const adminAfter = await db.setting.findUnique({ where: { key: "admin" } });
  ok(JSON.parse(adminAfter.value).passwordHash.startsWith("scrypt:"), "#5 new password stored as salted scrypt");

  const relogin = await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password: TEST_PW }) }, CHANGE_IP);
  adminCookie = (relogin.setCookie || "").split(";")[0];
  ok(relogin.json.mustChangePassword === false, "#2 relogin after change: no mustChange flag");
  const sc = relogin.setCookie || "";
  ok(/samesite=lax/i.test(sc), "#6 admin cookie is SameSite=Lax");
  ok(!/samesite=none/i.test(sc), "#6 admin cookie is NOT SameSite=None");
  const apiWorks = await api("/api/admin/settings", { headers: { cookie: adminCookie } });
  ok(apiWorks.status === 200, "#2 full admin access after password change");

  // ---- #3 tracking gate ----------------------------------------------------
  const item = await db.menuItem.findFirst({ where: { active: true } });
  const created = await api("/api/orders", {
    method: "POST",
    body: JSON.stringify({
      type: "pickup",
      customerName: "T36 Testas",
      phone: "+37060000001",
      email: "t36@test.lt",
      items: [{ id: item.id, qty: 1 }],
      pickupTime: new Date(Date.now() + 2 * 3600e3).toTimeString().slice(0, 5),
    }),
  });
  ok(created.json.ok === true, `order created: #${created.json.number}`);
  const row = await db.order.findUnique({ where: { number: created.json.number } });
  orderId = row.id;
  ok(!!row.trackToken && row.trackToken.length >= 16, "#3 new order gets a random trackToken");

  const bare = await api(`/api/track/${created.json.number}`);
  ok(bare.status === 403, `#3 bare order number -> 403 (got ${bare.status})`);
  const bare2 = await api(`/api/track/${created.json.number.replace("AC-", "")}`);
  ok(bare2.status === 403, `#3 bare digits form -> 403 (got ${bare2.status})`);
  const withToken = await api(`/api/track/${created.json.number}?t=${row.trackToken}`);
  ok(withToken.status === 200, "#3 with token -> 200");
  ok(withToken.json.customerName === undefined, "#3 customer name NOT in public reply");
  const withP4 = await api(`/api/track/${created.json.number}?p4=0001`);
  ok(withP4.status === 200, "#3 with last-4 phone digits -> 200");
  const badP4 = await api(`/api/track/${created.json.number}?p4=9999`);
  ok(badP4.status === 403, "#3 wrong last-4 -> 403");

  const sseBad = await api(`/api/track/${created.json.number}/stream`);
  ok(sseBad.status === 403, "#3 SSE without auth -> 403");
  const sseAbort = new AbortController();
  const sseGood = await fetch(`${BASE}/api/track/${created.json.number}/stream?t=${row.trackToken}`, { signal: sseAbort.signal });
  sseAbort.abort();
  ok(sseGood.status === 200, "#3 SSE with token -> 200 stream");
} catch (e) {
  fail++;
  console.error("ERROR:", e);
} finally {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  try {
    if (origAdmin) {
      let restored = false;
      for (let i = 0; i < 4 && !restored; i++) {
        try {
          await db.setting.update({ where: { key: "admin" }, data: { value: origAdmin.value } });
          const check = await db.setting.findUnique({ where: { key: "admin" } });
          restored = check.value === origAdmin.value;
          if (!restored) throw new Error("readback mismatch");
        } catch (err) {
          console.log(`cleanup: admin restore retry ${i + 1} (${err.message})`);
          await sleep(600);
        }
      }
      console.log(`cleanup: admin settings restored: ${restored ? "verified" : "FAILED"}`);
      if (!restored) fail++;
    }
    if (orderId) {
      const del = await db.order.deleteMany({ where: { number: (await db.order.findUnique({ where: { id: orderId }, select: { number: true } }))?.number } }).catch(() => null);
      console.log("cleanup: test order deleted:", del ? del.count : "FAILED");
    }
  } catch (e) {
    console.error("cleanup error:", e);
    fail++;
  }
  await db.$disconnect();
  console.log(fail === 0 ? "\nALL CHECKS PASSED ✓" : `\n${fail} CHECK(S) FAILED ✗`);
  process.exit(fail === 0 ? 0 : 1);
}
