import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
const rows = await db.order.findMany({ orderBy: { id: 'desc' }, take: 6, select: { number: true, type: true, status: true, paymentStatus: true, createdAt: true } });
console.table(rows);
await db.$disconnect();
