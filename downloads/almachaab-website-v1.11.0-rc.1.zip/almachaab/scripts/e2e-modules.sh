#!/bin/bash
# E2E verification for the 5 production modules (Alma Chaab)
set -uo pipefail
BASE="http://localhost:3000"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✔ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✘ $1"; }
check(){ if [ "$1" = "$2" ]; then ok "$3"; else bad "$3 (expected $1, got $2)"; fi }

echo "== 1. Settings singleton: admin store config =="
LOGIN=$(curl -s -X POST $BASE/api/admin/login -H 'Content-Type: application/json' -d '{"password":"alma2026"}')
TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))")
[ -n "$TOKEN" ] && ok "admin login" || bad "admin login"
AUTH="x-admin-token: $TOKEN"

PUT=$(curl -s -X PUT $BASE/api/admin/settings -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"key":"store","value":{"stripePublicKey":"pk_test_5123","stripeSecretKey":"sk_test_51secret","paypalClientId":"AeTEST","paypalSecret":"EF-TEST-SECRET","taxRate":9,"payFee":1}}')
echo "$PUT" | python3 -c "import sys,json;d=json.load(sys.stdin);print('  store after PUT:',d['store'])" 2>/dev/null
echo "$PUT" | python3 -c "
import sys,json
d=json.load(sys.stdin)
s=d.get('store',{})
assert s.get('stripeSecretKey','').startswith('••••'), 'secret not masked'
assert s.get('taxRate')==9, 'taxRate not saved'
assert s.get('stripePublicKey')=='pk_test_5123'
" && ok "PUT store: saved + secrets masked" || bad "PUT store"

CFG=$(curl -s $BASE/api/payments/config)
echo "$CFG" | python3 -c "
import sys,json
d=json.load(sys.stdin)
assert d['stripeEnabled'] is True
assert d['paypalEnabled'] is True
assert d['taxRate']==9
assert 'secret' not in json.dumps(d)
" && ok "payments/config: dynamic keys visible, no secrets" || bad "payments/config"

echo "== 2. SSE stream (kitchen) =="
(streamout=$(timeout 6 curl -s -N "$BASE/api/orders/stream?token=$TOKEN" 2>/dev/null &) ; sleep 2
ORDER=$(curl -s -X POST $BASE/api/orders -H 'Content-Type: application/json' -d '{"type":"pickup","customerName":"E2E Testas","phone":"+37060000001","items":[],"pickupTime":"12:30","note":"e2e"}')
sleep 2
if timeout 3 cat /dev/null; then :; fi
STREAM_CHECK=$(timeout 4 curl -s -N "$BASE/api/orders/stream?token=$TOKEN" 2>/dev/null | head -c 400)
echo "$STREAM_CHECK" | head -2
) 
SSE_FIRST=$(timeout 4 curl -s -N "$BASE/api/orders/stream?token=$TOKEN" 2>/dev/null | head -c 200)
echo "$SSE_FIRST" | grep -q "event: ready" && ok "SSE ready event" || bad "SSE ready event"
SSE_NOAUTH=$(curl -s -o /dev/null -w "%{http_code}" $BASE/api/orders/stream)
check "401" "$SSE_NOAUTH" "SSE without token → 401"

echo "== 3. Inventory 86-ing =="
ITEM=$(curl -s $BASE/api/site | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['categories'][0]['items'][0]['id'])")
curl -s -X PATCH $BASE/api/admin/menu -H "$AUTH" -H 'Content-Type: application/json' -d "{\"action\":\"updateItem\",\"id\":\"$ITEM\",\"inStock\":false}" > /dev/null
curl -s $BASE/api/site | python3 -c "
import sys,json
d=json.load(sys.stdin)
item=d['categories'][0]['items'][0]
assert item['inStock'] is False, 'inStock not exposed/public'
" && ok "86'd item exposed as inStock:false publicly" || bad "public inStock"
SO=$(curl -s -X POST $BASE/api/orders -H 'Content-Type: application/json' -d "{\"type\":\"pickup\",\"customerName\":\"E2E\",\"phone\":\"+37060000002\",\"items\":[{\"id\":\"$ITEM\",\"qty\":2}],\"pickupTime\":\"13:00\"}")
echo "$SO" | grep -q "išparduoti" && ok "server rejects sold-out item (409 + names)" || { echo "$SO"; bad "sold-out rejection"; }
curl -s -X PATCH $BASE/api/admin/menu -H "$AUTH" -H 'Content-Type: application/json' -d "{\"action\":\"updateItem\",\"id\":\"$ITEM\",\"inStock\":true,\"stockCount\":null}" > /dev/null
ok "item restored to stock"

echo "== 4. Stripe checkout: graceful without webhook secret, uses DB key =="
ST=$(curl -s -X POST $BASE/api/checkout/stripe -H 'Content-Type: application/json' -d '{"customerName":"E2E","phone":"+37060000003","items":[],"pickupTime":"13:30"}')
# items empty → "Krepšelis tuščias" OR stripe init error; both are graceful JSON errors
echo "$ST" | python3 -c "import sys,json;d=json.load(sys.stdin);assert 'error' in d and d['error'];print('  →', d['error'])" && ok "stripe checkout graceful error" || bad "stripe checkout"
# clean up test keys → back to disabled (null = explicitly clear secrets)
curl -s -X PUT $BASE/api/admin/settings -H "$AUTH" -H 'Content-Type: application/json' -d '{"key":"store","value":{"stripePublicKey":"","stripeSecretKey":null,"paypalClientId":"","paypalSecret":null,"taxRate":0}}' > /dev/null
CFG2=$(curl -s $BASE/api/payments/config)
echo "$CFG2" | python3 -c "import sys,json;d=json.load(sys.stdin);assert d['stripeEnabled'] is False and d['taxRate']==0" && ok "keys cleared + tax reset" || bad "keys clear"

echo "== 5. Customer accounts + history + reorder data =="
EMAIL="e2e$(date +%s)@test.lt"
REG=$(curl -s -c /tmp/alma-user.jar -X POST $BASE/api/auth/register -H 'Content-Type: application/json' -d "{\"email\":\"$EMAIL\",\"password\":\"slaptazodis1\",\"name\":\"E2E Vartotojas\",\"phone\":\"+37060000004\"}")
echo "$REG" | grep -q '"ok":true' && ok "register + auto-login" || { echo "$REG"; bad "register"; }
ME=$(curl -s -b /tmp/alma-user.jar $BASE/api/auth/me)
echo "$ME" | grep -q "$EMAIL" && ok "session cookie → /api/auth/me" || bad "me"
# place an order while logged in (order attaches to user)
ITEM2=$(curl -s $BASE/api/site | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['categories'][0]['items'][0]['id'])")
curl -s -b /tmp/alma-user.jar -X POST $BASE/api/orders -H 'Content-Type: application/json' -d "{\"type\":\"pickup\",\"customerName\":\"E2E Vartotojas\",\"phone\":\"+37060000004\",\"items\":[{\"id\":\"$ITEM2\",\"qty\":1}],\"pickupTime\":\"14:00\"}" > /dev/null
HIST=$(curl -s -b /tmp/alma-user.jar $BASE/api/me/orders)
echo "$HIST" | python3 -c "
import sys,json
d=json.load(sys.stdin)
assert len(d['orders'])>=1, 'no history'
o=d['orders'][0]
assert o['items'] and o['items'][0].get('id'), 'items missing ids for reorder'
" && ok "order attached to account + history with item ids" || { echo "$HIST" | head -c 300; bad "history"; }
HIST_NOAUTH=$(curl -s -o /dev/null -w "%{http_code}" $BASE/api/me/orders)
check "401" "$HIST_NOAUTH" "history requires auth"

echo "== 6. Store closed toggle =="
curl -s -X PUT $BASE/api/admin/settings -H "$AUTH" -H 'Content-Type: application/json' -d '{"key":"store","value":{"isOpen":false}}' > /dev/null
CL=$(curl -s -o /dev/null -w "%{http_code}" -X POST $BASE/api/orders -H 'Content-Type: application/json' -d '{"type":"pickup","customerName":"E2E","phone":"+37060000005","items":[],"pickupTime":"15:00"}')
check "503" "$CL" "closed store → orders rejected 503"
curl -s -X PUT $BASE/api/admin/settings -H "$AUTH" -H 'Content-Type: application/json' -d '{"key":"store","value":{"isOpen":true}}' > /dev/null
ok "store re-opened"

echo
echo "RESULT: $PASS passed, $FAIL failed"
[ $FAIL -eq 0 ]
