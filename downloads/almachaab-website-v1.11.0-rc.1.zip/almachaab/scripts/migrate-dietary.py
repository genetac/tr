#!/usr/bin/env python3
"""Add independent dietary fields without resetting data; keep a consistent backup."""
import sqlite3, sys
from pathlib import Path
path = Path(sys.argv[1] if len(sys.argv) > 1 else 'db/custom.db')
if not path.is_file():
    raise SystemExit('Existing database required; refusing to create an empty database.')
with sqlite3.connect(path) as db:
    columns = {c[1] for c in db.execute('PRAGMA table_info(MenuItem)')}
    additions = {'vegetarian': 'BOOLEAN NOT NULL DEFAULT false', 'vegan': 'BOOLEAN NOT NULL DEFAULT false', 'halal': 'BOOLEAN NOT NULL DEFAULT false', 'dietaryNotes': "TEXT NOT NULL DEFAULT ''", 'dietaryVisible': 'BOOLEAN NOT NULL DEFAULT false', 'dietaryNotesVisible': 'BOOLEAN NOT NULL DEFAULT false', 'dietaryReviewed': 'BOOLEAN NOT NULL DEFAULT false', 'dietaryInternalNote': "TEXT NOT NULL DEFAULT ''"}
    missing = {k:v for k,v in additions.items() if k not in columns}
    if missing:
        backup = path.with_name(path.name + '.bak-dietary-v2')
        if backup.exists():
            raise SystemExit('Backup exists but migration incomplete; inspect before continuing.')
        with sqlite3.connect(backup) as target:
            db.backup(target)
        with db:
            for name, definition in missing.items():
                db.execute(f'ALTER TABLE MenuItem ADD COLUMN {name} {definition}')
    print('Dietary schema ready; existing content preserved.')
