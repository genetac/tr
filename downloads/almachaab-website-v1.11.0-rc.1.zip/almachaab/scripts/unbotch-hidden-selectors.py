#!/usr/bin/env python3
"""Real repair: my first pass injected '[h' before each already-correct
'[hidden]' selector, producing 'X[h[hidden]'. Remove the injected '[h'.
Literals are built by concatenation so no channel can mangle them."""
import re

FILES = [
    "/home/z/my-project/src/app/site.css",
    "/home/z/my-project/src/app/site-scoped.css",
]

LB, RB = "[", "]"
BOTCHED = LB + "h" + LB + "hidden" + RB   # X[h[hidden]
GOOD = LB + "hidden" + RB                  # X[hidden]

for path in FILES:
    s = open(path, encoding="utf-8").read()
    n = s.count(BOTCHED)
    s = s.replace(BOTCHED, GOOD)
    open(path, "w", encoding="utf-8").write(s)
    print(f"{path.split('/')[-1]}: repaired {n}")

# Ground-truth re-dump (tokens, not raw brackets)
def tok(x: str) -> str:
    return x.replace(LB, "LB").replace(RB, "RB")

for path in FILES:
    s = open(path, encoding="utf-8").read()
    n = 0
    ok = True
    for m in re.finditer(r"hidden" + re.escape(RB), s):
        n += 1
        i = m.start()
        before = s[max(0, i - 4) : i]
        if not before.endswith(LB) or before[:-1].endswith(LB) or "h" in before[:-1]:
            ok = False
            print(f"  BAD in {path.split('/')[-1]}: ...{tok(s[max(0, i-10):i])} hidden...")
    print(f"{path.split('/')[-1]}: occurrences={n} all-clean={ok}")
print("DONE")
