#!/usr/bin/env python3
"""Scope prototype CSS under .alma-root so it never leaks into /admin."""
import re

SRC = "/home/z/my-project/src/app/site.css"
OUT = "/home/z/my-project/src/app/site-scoped.css"

css = open(SRC, encoding="utf-8").read()
# strip comments (they confuse the flat parser)
css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)

def prefix_selector(sel: str) -> str:
    sel = sel.strip()
    if not sel:
        return sel
    # keyframes percentages
    if re.fullmatch(r"(from|to|\d+%|\d+\s*%)", sel):
        return sel
    if sel.startswith(":root"):
        return sel.replace(":root", ".alma-root", 1)
    if sel in ("html", "body"):
        return ".alma-root"
    if sel.startswith("body"):
        return ".alma-root" + sel[4:]
    if sel.startswith("html"):
        return ".alma-root" + sel[4:]
    if sel == "*":
        return ".alma-root *"
    return ".alma-root " + sel

def prefix_rules(block: str) -> str:
    """Prefix all rules in a flat block (may contain nested at-rule blocks)."""
    out = []
    i = 0
    n = len(block)
    while i < n:
        # find next '{'
        brace = block.find("{", i)
        if brace == -1:
            out.append(block[i:])
            break
        header = block[i:brace]
        if "@keyframes" in header or "@-webkit-keyframes" in header:
            # copy whole keyframes block verbatim
            depth = 0
            j = brace
            while j < n:
                if block[j] == "{":
                    depth += 1
                elif block[j] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            out.append(header + block[brace:j+1])
            i = j + 1
            continue
        if header.strip().startswith("@media") or header.strip().startswith("@supports"):
            # recurse into inner block
            depth = 0
            j = brace
            while j < n:
                if block[j] == "{":
                    depth += 1
                elif block[j] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            inner = block[brace+1:j]
            out.append(header + "{" + prefix_rules(inner) + "}")
            i = j + 1
            continue
        # normal rule: find matching close brace (rules are flat here)
        depth = 0
        j = brace
        while j < n:
            if block[j] == "{":
                depth += 1
            elif block[j] == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        body = block[brace:j+1]
        selectors = [s for s in header.split(",")]
        prefixed = ",".join(prefix_selector(s) for s in selectors)
        out.append(prefixed + body)
        i = j + 1
    return "".join(out)

result = prefix_rules(css)
open(OUT, "w", encoding="utf-8").write(result)
print("scoped css:", len(result), "chars")

# sanity checks
assert ".alma-root .header" in result or ".alma-root  .header" in result or ".alma-root.header" in result
assert ":root" not in result
assert not re.search(r"(?m)^\s*body\s*\{", result)
print("checks passed")
