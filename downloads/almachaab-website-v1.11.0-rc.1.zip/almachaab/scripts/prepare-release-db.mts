/**
 * Security fixes SEC-001 / SEC-002 / SEC-008 — scrub install-specific secrets
 * from db/custom.db before it is zipped and handed over.
 *
 *  - admin.secret → "" : the server generates a fresh random HMAC secret on
 *    first boot (src/lib/settings.ts). The shipped value was encrypted with a
 *    key that is public in old source, so it must never be reused.
 *  - admin.sessionVersion → 0
 *  - Setting "vapid" deleted : a fresh push key pair is generated on the server
 *    (and stored encrypted) the first time push is used.
 *  - leftover social secrets / placeholder client IDs cleared (they were
 *    encrypted with a developer key and are useless on the server anyway).
 *
 * The admin password hash is intentionally NOT touched (owner's own task).
 *
 *   cp db/custom.db db/custom.db.bak-$(date +%s) && npx tsx scripts/prepare-release-db.mts
 * Idempotent — safe to run again. package-release.sh runs it on the staged copy.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const adminRow = await db.setting.findUnique({ where: { key: "admin" } });
  if (adminRow) {
    const admin = JSON.parse(adminRow.value) as Record<string, unknown>;
    admin.secret = "";
    admin.sessionVersion = 0;
    await db.setting.update({ where: { key: "admin" }, data: { value: JSON.stringify(admin) } });
  }
  await db.setting.deleteMany({ where: { OR:[{key:"vapid"},{key:{startsWith:"staff:"}},{key:{startsWith:"help:"}}] } });
  const emailRow = await db.setting.findUnique({ where: { key: 'email' } });
  if (emailRow) {
    const email=JSON.parse(emailRow.value);email.pass='';email.enabled=false;
    await db.setting.update({where:{key:'email'},data:{value:JSON.stringify(email)}});
  }
  const ratingRow = await db.setting.findUnique({ where: { key: 'rating' } });
  if (ratingRow) {
    const rating=JSON.parse(ratingRow.value);rating.placesApiKey='';
    await db.setting.update({where:{key:'rating'},data:{value:JSON.stringify(rating)}});
  }
  await db.settings.updateMany({
    data: {
      googleEnabled: false,
      facebookEnabled: false,
      telegramEnabled: false,
      turnstileEnabled: false,
      googleClientSecret: "",
      facebookClientSecret: "",
      telegramBotToken: "",
      googleClientId: "",
      facebookClientId: "",
      stripeSecretKey: "",
      stripeWebhookSecret: "",
      paypalSecret: "",
      turnstileSecretKey: "",
    },
  });
  console.log("release DB scrubbed: admin.secret cleared, VAPID keys removed, provider secrets cleared");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
