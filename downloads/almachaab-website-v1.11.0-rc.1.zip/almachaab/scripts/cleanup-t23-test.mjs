import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

// Task 23 E2E cleanup: remove ONLY orders created by this test run
// (customer "E2E Svecias" / phone +37061111111). The owner's own orders
// (AC-1042/1043/1046/1050 etc.) are never touched.
const testOrders = await db.order.findMany({
  where: { OR: [{ customerName: "E2E Svecias" }, { phone: "+37061111111" }] },
  select: { id: true, number: true, status: true, paymentStatus: true, paymentMethod: true },
});
console.log("E2E orders found:", JSON.stringify(testOrders));
for (const o of testOrders) {
  await db.order.delete({ where: { id: o.id } });
  console.log("deleted", o.number);
}

// Reset the order counter so the next real order continues after the
// owner's latest kept order (AC-1050).
const kept = await db.order.findMany({ orderBy: { createdAt: "desc" }, take: 1, select: { number: true } });
const lastNum = kept[0] ? parseInt(kept[0].number.replace(/\D/g, ""), 10) : 1042;
const store = await db.setting.findUnique({ where: { key: "orders" } });
const cfg = JSON.parse(store?.value || "{}");
cfg.nextNumber = lastNum + 1;
await db.setting.update({ where: { key: "orders" }, data: { value: JSON.stringify(cfg) } });
console.log("order counter reset → next:", cfg.nextNumber);

console.log(
  "users:", await db.user.count(),
  "accounts:", await db.account.count(),
  "orders left:", JSON.stringify((await db.order.findMany({ select: { number: true, status: true } })).map((o) => `${o.number}:${o.status}`))
);
await db.$disconnect();
