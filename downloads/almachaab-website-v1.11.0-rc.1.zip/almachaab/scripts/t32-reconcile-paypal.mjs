/* Task 32 — reconcile the two orders whose PayPal payments were captured on
 * PayPal's side but stayed "unpaid" locally because of the custom_id parsing
 * bug (AC-1054 / AC-1055). Runs the SAME markOrderPaid funnel the capture
 * route uses, with the real capture ids pulled from PayPal. Idempotent. */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const cfg = await db.settings.findUnique({ where: { id: "global" } });
  if (!cfg?.paypalClientId || !cfg.paypalSecret) throw new Error("PayPal credentials missing");
  const basic = Buffer.from(`${cfg.paypalClientId}:${cfg.paypalSecret}`).toString("base64");
  const tokRes = await fetch("https://api-m.sandbox.paypal.com/v1/oauth2/token", {
    method: "POST",
    headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  const tok = await tokRes.json();
  if (!tok.access_token) throw new Error("PayPal token failed: " + JSON.stringify(tok).slice(0, 200));

  const orphans = await db.order.findMany({
    where: { number: { in: ["AC-1054", "AC-1055"] }, paymentStatus: { not: "paid" }, paymentMethod: "paypal" },
  });

  for (const o of orphans) {
    if (!o.paymentRef) {
      console.log(`${o.number}: no paymentRef, skip`);
      continue;
    }
    const r = await fetch(`https://api-m.sandbox.paypal.com/v2/checkout/orders/${o.paymentRef}`, {
      headers: { Authorization: `Bearer ${tok.access_token}` },
    });
    const j = await r.json();
    const cap = j?.purchase_units?.[0]?.payments?.captures?.[0];
    const captured = j?.status === "COMPLETED" && cap?.status === "COMPLETED";
    if (!captured) {
      console.log(`${o.number}: PayPal order not captured (status=${j?.status}/${cap?.status}) — skip`);
      continue;
    }
    if (o.paymentStatus === "paid") {
      console.log(`${o.number}: already paid locally — skip`);
      continue;
    }
    // Replicates the exact write of markOrderPaid (src/lib/fulfill.ts) —
    // same fields, same history label — so state matches the capture funnel.
    const history = JSON.parse(o.historyJson || "[]");
    history.push({
      status: "confirmed",
      at: new Date().toISOString(),
      by: "payment",
      label: "Apmokėta (PayPal)",
      ref: String(cap.id).slice(0, 120),
      note: "Sutvarkyta automatiškai — PayPal apmokėjimas buvo įvykdytas, bet vietinė būsena neatnaujinta (Task-32 klaidos taisymas).",
    });
    await db.order.update({
      where: { id: o.id },
      data: {
        paymentStatus: "paid",
        paymentMethod: "paypal",
        paymentRef: String(cap.id).slice(0, 200),
        paidAt: new Date(),
        status: o.status === "new" || o.status === "awaiting" ? "confirmed" : o.status,
        isRead: true,
        historyJson: JSON.stringify(history),
      },
    });
    console.log(`${o.number}: now paid ✓`);
  }
  if (orphans.length === 0) console.log("No unpaid orphan orders found — nothing to do.");
  await db.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
