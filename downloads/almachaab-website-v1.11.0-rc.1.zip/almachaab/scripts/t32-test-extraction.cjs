/* eslint-disable @typescript-eslint/no-require-imports */
/* Task 32 — regression test for the PayPal capture order-mapping fix.
 * Simulates the EXACT failure the owner hit: PayPal's capture response that
 * omits custom_id at unit level → old code returned "" →
 * "PayPal grąžino be mūsų užsakymo nuorodos." New code must fall back. */
const path = require("path");
process.env.NODE_ENV = "test";

(async () => {
  // Import the real TS module via the compiled Next build? — use ts strip via
  // a tiny transform: read the file, strip types with the TypeScript compiler
  // already present in node_modules.
  const ts = require("typescript");
  const fs = require("fs");
  const src = fs.readFileSync("src/lib/payments.ts", "utf8");
  const js = ts.transpileModule(src, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: 2020 } }).outputText;
  const mod = { exports: {} };
  const path = require("path");
  const libDir = path.resolve("src/lib");
  // local-module stubs: payments.ts's runtime deps are only used inside
  // functions we don't call here — extractInternalOrderId is pure.
  const stubs = {
    "./settings": { getStoreSettings: async () => ({}), StoreSettings: {} },
    "./db": { db: {} },
    stripe: require("stripe"),
  };
  new Function("require", "module", "exports", js)(
    (id) => (id in stubs ? stubs[id] : require(id)),
    mod,
    mod.exports
  );
  const { extractInternalOrderId } = mod.exports;

  const ourId = "cmv6tdgpw0007q33hldwa9si3";
  const cases = [
    ["unit-level custom_id (normal)", { purchase_units: [{ custom_id: ourId, payments: { captures: [{ status: "COMPLETED" }] } }] }, "", ourId],
    ["capture-level only", { purchase_units: [{ payments: { captures: [{ status: "COMPLETED", custom_id: ourId }] } }] }, "", ourId],
    ["custom_id MISSING entirely (the bug)", { purchase_units: [{ payments: { captures: [{ status: "COMPLETED" }] } }] }, "", ""],
    ["missing + DB fallback", { purchase_units: [{ payments: { captures: [{ status: "COMPLETED" }] } }] }, ourId, ourId],
    ["whitespace-only custom_id", { purchase_units: [{ custom_id: "  ", payments: { captures: [{}] } }] }, ourId, ourId],
    ["empty response + fallback", {}, ourId, ourId],
  ];
  let fail = 0;
  for (const [name, json, fb, expected] of cases) {
    const got = extractInternalOrderId(json, fb);
    const ok = got === expected;
    if (!ok) fail++;
    console.log(`${ok ? "PASS" : "FAIL"} — ${name}: got "${got}" expected "${expected}"`);
  }
  if (fail) { console.log(`${fail} FAILURES`); process.exit(1); }
  console.log("All extraction cases pass ✓");
})().catch((e) => { console.error(e); process.exit(1); });
