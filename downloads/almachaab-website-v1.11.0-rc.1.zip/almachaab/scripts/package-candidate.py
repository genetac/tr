#!/usr/bin/env python3
"""Package a verified source candidate without runtime keys, backups or customer data."""
from pathlib import Path
import hashlib, json, os, shutil, sqlite3, subprocess, tempfile, zipfile
root=Path(__file__).resolve().parents[1]
version=json.loads((root/'package.json').read_text())['version']
build=root/'.next/BUILD_ID'
if not build.is_file(): raise SystemExit('A successful production build is required.')
inputs=[*list((root/'src').rglob('*')),*list((root/'prisma').rglob('*')),root/'package.json',root/'next.config.ts']
if any(p.is_file() and p.stat().st_mtime>build.stat().st_mtime for p in inputs): raise SystemExit('Source changed after build; rebuild before packaging.')
for p in (root/'public').rglob('*'):
    if p.is_file() and (p.suffix.lower() in {'.zip','.db','.sqlite','.sqlite3','.pem'} or p.name.startswith('.env')): raise SystemExit('Sensitive artifact found in public/.')
with sqlite3.connect(root/'db/custom.db') as source:
    for table in ['User','Order','Account','PushSubscription','LoyaltyProfile','LoyaltyTransaction','RewardRedemption']:
        if source.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]: raise SystemExit('Customer data exists; prepare a separate sanitized release DB first.')
    with tempfile.TemporaryDirectory(prefix='almachaab-release-') as temporary:
        stage=Path(temporary)/'almachaab';stage.mkdir()
        for folder in ['src','public','prisma','uploads','scripts','docs']:
            shutil.copytree(root/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__','*.log','*.pyc','*.bak-*','.support'))
        for name in ['.gitignore','.env.example','Caddyfile','DEPLOY.md','bun.lock','components.json','eslint.config.mjs','next.config.ts','package.json','postcss.config.mjs','tailwind.config.ts','tsconfig.json']:
            shutil.copyfile(root/name,stage/name)
        shutil.copyfile(root/'docs/README-CANDIDATE.md',stage/'README.md')
        shutil.copyfile(root/'README.imported.md',stage/'README.imported.md')
        for p in root.glob('CHANGES-*.md'): shutil.copyfile(p,stage/p.name)
        (stage/'db').mkdir()
        with sqlite3.connect(stage/'db/custom.db') as target: source.backup(target)
        process_env=os.environ.copy();process_env['DATABASE_URL']='file:'+str(stage/'db/custom.db')
        subprocess.run(['node',str(root/'node_modules/tsx/dist/cli.mjs'),str(root/'scripts/prepare-release-db.mts')],cwd=root,env=process_env,check=True)
        with sqlite3.connect(stage/'db/custom.db') as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            admin=json.loads(db.execute("SELECT value FROM Setting WHERE key='admin'").fetchone()[0]);assert not admin.get('secret')
            email=json.loads(db.execute("SELECT value FROM Setting WHERE key='email'").fetchone()[0]);assert not email.get('pass') and not email.get('enabled')
        output=root.parent/'releases';output.mkdir(exist_ok=True)
        archive=output/f'almachaab-website-v{version}.zip'
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for p in sorted(stage.rglob('*')):
                if p.is_file(): z.write(p,p.relative_to(stage.parent))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert not any(Path(n).name.startswith('.env') and Path(n).name!='.env.example' for n in z.namelist())
        digest=hashlib.sha256(archive.read_bytes()).hexdigest()
        archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n')
        print(f'Created {archive} ({archive.stat().st_size} bytes); integrity and secret exclusions verified.')
