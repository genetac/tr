#!/usr/bin/env python3
"""Line-based extraction from prototype (fast, no regex backtracking)."""
import json, os

SRC = "/home/z/my-project/upload/Alma-Chaab-PC-Mobile.html"
OUT_CSS = "/home/z/my-project/src/app/site.css"
OUT_DATA = "/home/z/my-project/scripts/seed-data.json"

lines = open(SRC, encoding="utf-8").readlines()
print("total lines:", len(lines))

# --- 1. CSS: from first <style> to last </style> before <body ---
css_start = css_end = None
for i, l in enumerate(lines):
    if "<style" in l and css_start is None:
        css_start = i
    if "</style>" in l:
        css_end = i  # keep last one before body
    if "<body" in l:
        break
print("css lines:", css_start, "->", css_end)
css = "".join(lines[css_start:css_end+1])
# strip the style tags themselves
import re
css = re.sub(r"</?style[^>]*>", "", css)
os.makedirs(os.path.dirname(OUT_CSS), exist_ok=True)
open(OUT_CSS, "w", encoding="utf-8").write(css)
print(f"CSS written: {len(css)} chars")

# --- 2. MENU JSON: single line search ---
menu = None
for i, l in enumerate(lines):
    if l.startswith("const MENU=") or "const MENU=[" in l:
        s = l[l.index("["):]
        # menu may span multiple lines; accumulate until balanced
        buf = s
        j = i
        while j < len(lines) - 1:
            try:
                # try parse from first [ to matching ]; quick check with decoder
                dec = json.JSONDecoder()
                obj, end = dec.raw_decode(buf)
                menu = obj
                break
            except Exception:
                j += 1
                buf += lines[j]
        if menu: 
            print(f"menu parsed from line {i}, spans {j-i+1} lines")
            break
if menu:
    print(f"Menu categories: {len(menu)}")
    for c in menu:
        print(f"  - {c['id']}: {c['name']} ({len(c['items'])} items)")

# --- 3. Sections by known line ranges (1-indexed from earlier grep) ---
def sl(a, b):
    return "".join(lines[a-1:b])

data_sections = {
    "proof": sl(1419, 1429),
    "about": sl(1430, 1451),
    "social": sl(1459, 1474),
    "hub": sl(1475, 1488),
    "contacts": sl(1810, 1823),
    "footer": sl(1824, 1836),
}

# hero section: find from line 1397 until next <section
hero = []
for i in range(1397, 1419):
    hero.append(lines[i])
data_sections["hero"] = "".join(hero)

# wolt section
wolt = []
for i in range(1730, 1744):
    wolt.append(lines[i])
data_sections["wolt"] = "".join(wolt)

# ribbon
ribbon = []
for i in range(1452, 1459):
    ribbon.append(lines[i])
data_sections["ribbon"] = "".join(ribbon)

# find all external image URLs (non-base64)
import re as _re
def re_finditer_urls(l):
    return [m.group(0) for m in _re.finditer(r'https://imageproxy\.wolt\.com/assets/[a-z0-9]+', l)]

urls = set()
for l in lines:
    for m in re_finditer_urls(l):
        urls.add(m)
print("external image urls:", len(urls))

urls = set()
for l in lines:
    urls.update(re_finditer_urls(l))
print("unique wolt asset urls:", len(urls))

data = {"menu": menu, "sections": data_sections, "wolt_urls": sorted(urls)}
with open(OUT_DATA, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=1)
print(f"Seed data -> {OUT_DATA} ({os.path.getsize(OUT_DATA)} bytes)")
