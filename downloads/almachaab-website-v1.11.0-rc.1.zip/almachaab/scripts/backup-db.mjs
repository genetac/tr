/**
 * Review fix #16 — daily off-server database backup.
 * Creates a consistent snapshot with SQLite VACUUM INTO, keeps the last N
 * copies locally, and optionally mirrors to a remote host via rsync/scp.
 *
 * Cron (3:00 at night):  0 3 * * *  node /path/to/alma/scripts/backup-db.mjs
 * Remote mirror: set BACKUP_RSYNC_TARGET in the environment, e.g.
 *   BACKUP_RSYNC_TARGET="backup@nas:/volume1/backups/almachaab"
 */
import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { PrismaClient } from "@prisma/client";

const DB_URL = (fs.readFileSync(new URL("../.env", import.meta.url), "utf8").match(/^DATABASE_URL="?([^"\n]+)"?/m) || [])[1] || "";
const dbFile = DB_URL.replace(/^file:/, "").startsWith("/")
  ? DB_URL.replace(/^file:/, "")
  : path.resolve(new URL("..", import.meta.url).pathname, DB_URL.replace(/^file:/, "./"));

const KEEP = Number(process.env.BACKUP_KEEP || 14);
const OUT_DIR = process.env.BACKUP_DIR || "/home/z/my-project/backups";
const RSYNC_TARGET = process.env.BACKUP_RSYNC_TARGET || "";

fs.mkdirSync(OUT_DIR, { recursive: true });
const stamp = new Date().toISOString().slice(0, 10);
const dest = path.join(OUT_DIR, `almachaab-${stamp}.db`);

const db = new PrismaClient();

try {
  // Consistent snapshot even while the server is running.
  await db.$executeRawUnsafe(`VACUUM INTO '${dest}'`);
  const size = fs.statSync(dest).size;
  console.log(`backup ok: ${dest} (${Math.round(size / 1024)} KB)`);

  // Rotate old local copies (keep the newest KEEP files).
  const old = fs
    .readdirSync(OUT_DIR)
    .filter((f) => f.startsWith("almachaab-") && f.endsWith(".db"))
    .sort()
    .reverse()
    .slice(KEEP);
  for (const f of old) {
    fs.unlinkSync(path.join(OUT_DIR, f));
    console.log(`rotated: ${f}`);
  }

  // Optional off-server copy.
  if (RSYNC_TARGET) {
    execFile("rsync", ["-az", dest, RSYNC_TARGET], (err) => {
      if (err) console.error("rsync failed:", err.message);
      else console.log(`mirrored to ${RSYNC_TARGET}`);
    });
  } else {
    console.log("BACKUP_RSYNC_TARGET not set — local copy only (set it to mirror off-server).");
  }
} catch (e) {
  console.error("backup FAILED:", e.message);
  process.exit(1);
} finally {
  await db.$disconnect();
}
