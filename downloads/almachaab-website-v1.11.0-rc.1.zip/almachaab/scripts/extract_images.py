#!/usr/bin/env python3
"""Extract base64-embedded images from prototype into public/seed/."""
import base64, os, re, json

SRC = "/home/z/my-project/upload/Alma-Chaab-PC-Mobile.html"
OUT = "/home/z/my-project/public/seed"
os.makedirs(OUT, exist_ok=True)

html = open(SRC, encoding="utf-8").read()

# find all data:image URIs with context: preceding id/class
results = []
for m in re.finditer(r'data:image/(webp|jpeg|jpg|png);base64,([A-Za-z0-9+/=]{500,})', html):
    ext = m.group(1).replace("jpg", "jpeg")
    b64 = m.group(2)
    start = max(0, m.start() - 300)
    ctx = html[start:m.start()]
    results.append({"ext": ext, "len": len(b64), "ctx": ctx[-160:].replace("\n", " ")})

print(f"Found {len(results)} base64 images")
for i, r in enumerate(results):
    print(f"{i}: {r['ext']} {r['len']//1024}KB ctx: ...{r['ctx']}")

# save them
manifest = []
for i, m in enumerate(re.finditer(r'data:image/(webp|jpeg|jpg|png);base64,([A-Za-z0-9+/=]{500,})', html)):
    ext = m.group(1).replace("jpg", "jpeg")
    data = base64.b64decode(m.group(2))
    name = f"proto-{i}.{ext}"
    with open(os.path.join(OUT, name), "wb") as f:
        f.write(data)
    manifest.append({"file": name, "size": len(data), "context_hint": html[max(0, m.start()-200):m.start()][-120:].replace("\n"," ")})

json.dump(manifest, open(os.path.join(OUT, "manifest.json"), "w"), ensure_ascii=False, indent=1)
print("saved", len(manifest), "images to", OUT)
