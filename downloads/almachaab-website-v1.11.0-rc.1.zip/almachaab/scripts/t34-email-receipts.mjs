/**
 * Task 34 e2e — order email receipts through a REAL SMTP round-trip.
 *
 * 1. Starts a minimal SMTP capture server on 127.0.0.1:2525 (AUTH LOGIN + DATA).
 * 2. Enables the real email settings (admin API) pointing at that server.
 * 3. POST /api/orders            -> expect "received" email + restaurant copy.
 * 4. PATCH admin paid+confirmed  -> expect ONE receipt ("Kvitas"), no duplicate.
 * 5. PATCH admin status ready    -> expect "paruoštas" email.
 * 6. Verifies receipt content (method, ref, sum) + history logging + idempotency.
 * 7. Restores original email settings, deletes the test order.
 */
import net from "node:net";
import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000";
const ADMIN_PW = process.env.ADMIN_PW || "alma2026";
const TEST_PW = "alma2026-e2e"; // forced-change target password
const db = new PrismaClient();
let fail = 0;
const ok = (cond, label) => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}`);
  if (!cond) fail++;
};

// ---------- tiny SMTP capture server (explicit state machine) ----------
const captured = []; // { from, to, data }

const server = net.createServer((sock) => {
  let stage = "greet"; // greet | user | pass | ready | from | rcpt | data | quit
  let buf = "";
  let from = "";
  let to = "";
  smtpReply(["220 capture.local ESMTP t34"]);
  sock.on("data", (chunk) => {
    buf += chunk.toString("utf8");
    while (true) {
      if (stage === "data") {
        const end = buf.indexOf("\r\n.\r\n");
        if (end < 0) return;
        const data = buf.slice(0, end).replace(/^\.\./gm, "."); // undo dot-stuffing
        captured.push({ from, to, data });
        buf = buf.slice(end + 5);
        stage = "ready";
        smtpReply(["250 OK: queued as t34"]);
        continue;
      }
      const nl = buf.indexOf("\r\n");
      if (nl < 0) return;
      const line = buf.slice(0, nl);
      buf = buf.slice(nl + 2);
      const up = line.toUpperCase();
      if (up.startsWith("EHLO") || up.startsWith("HELO")) {
        sock.write("250-capture.local\r\n250-SIZE 5242880\r\n250-AUTH PLAIN LOGIN\r\n250 OK\r\n");
      } else if (up.startsWith("AUTH LOGIN")) {
        stage = "user";
        smtpReply(["334 VXNlcm5hbWU6"]);
      } else if (stage === "user") {
        stage = "pass";
        smtpReply(["334 UGFzc3dvcmQ6"]);
      } else if (stage === "pass") {
        stage = "ready";
        smtpReply(["235 2.7.0 Accepted"]);
      } else if (up.startsWith("MAIL FROM:")) {
        from = line.slice(10).trim();
        stage = "from";
        smtpReply(["250 OK"]);
      } else if (up.startsWith("RCPT TO:")) {
        to = line.slice(8).trim();
        stage = "rcpt";
        smtpReply(["250 OK"]);
      } else if (up === "DATA") {
        stage = "data";
        smtpReply(["354 End data with <CR><LF>.<CR><LF>"]);
      } else if (up.startsWith("QUIT")) {
        smtpReply(["221 Bye"]);
        sock.end();
      } else {
        smtpReply(["250 OK"]);
      }
    }
  });
  function smtpReply(lines) {
    for (const l of lines) sock.write(l + "\r\n");
  }
  sock.on("error", () => {});
});

// ---------- helpers ----------
async function api(path, opts = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text.slice(0, 200) };
  }
  return { status: res.status, json, setCookie: res.headers.get("set-cookie") };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(n, timeoutMs = 9000) {
  const t0 = Date.now();
  while (captured.length < n) {
    if (Date.now() - t0 > timeoutMs) return false;
    await sleep(150);
  }
  return true;
}
function subjects() {
  return captured.map((c) => decodeSubj((c.data.match(/^Subject: (.*)$/m) || [])[1] || "(no subject)"));
}
/** Decode folded RFC2047 =?UTF-8?Q?..?= / =?UTF-8?B?..?= subject words. */
function decodeSubj(raw) {
  // Unfold continuation lines: "=?..?=\r\n =?..?=" -> "=?..?==?..?="
  const unfolded = raw.replace(/\r?\n[ \t]+/g, "").replace(/\?=\s+=\?/g, "?==?");
  return unfolded
    .replace(/=\?UTF-8\?([QB])\?([^?]*)\?=/gi, (_, enc, payload) => {
      try {
        if (enc.toUpperCase() === "B") return Buffer.from(payload, "base64").toString("utf8");
        // Q-encoding: _ = space, =XX = byte; decode bytes then read as UTF-8
        const bytes = [];
        for (let i = 0; i < payload.length; i++) {
          const ch = payload[i];
          if (ch === "_") bytes.push(0x20);
          else if (ch === "=" && /^[0-9A-F]{2}$/i.test(payload.slice(i + 1, i + 3))) {
            bytes.push(parseInt(payload.slice(i + 1, i + 3), 16));
            i += 2;
          } else bytes.push(payload.charCodeAt(i) & 0xff);
        }
        return Buffer.from(bytes).toString("utf8");
      } catch {
        return "?";
      }
    });
}
/** Decode an email body per its Content-Transfer-Encoding (qp / base64 / 7bit). */
function decodeBody(data) {
  const sep = data.indexOf("\r\n\r\n");
  if (sep < 0) return data;
  const headers = data.slice(0, sep);
  let body = data.slice(sep + 4);
  const cte = (headers.match(/Content-Transfer-Encoding:\s*(\S+)/i) || [])[1]?.toLowerCase() || "7bit";
  try {
    if (cte === "base64") return Buffer.from(body.replace(/\s+/g, ""), "base64").toString("utf8");
    if (cte === "quoted-printable") {
      body = body.replace(/=\r\n/g, ""); // soft line breaks
      const bytes = [];
      for (let i = 0; i < body.length; i++) {
        if (body[i] === "=" && /^[0-9A-F]{2}$/i.test(body.slice(i + 1, i + 3))) {
          bytes.push(parseInt(body.slice(i + 1, i + 3), 16));
          i += 2;
        } else bytes.push(body.charCodeAt(i) & 0xff);
      }
      return Buffer.from(bytes).toString("utf8");
    }
  } catch {}
  return body;
}

// ---------- run ----------
let adminCookie = "";
let orderId = null;
let origEmail = null;
let origAdmin = null;

server.listen(2525, "127.0.0.1");
await sleep(300);

try {
  // 0. Snapshot email + admin settings.
  const before = await db.setting.findUnique({ where: { key: "email" } });
  origEmail = before ? JSON.parse(before.value) : { enabled: false };
  origAdmin = await db.setting.findUnique({ where: { key: "admin" } });
  const item = await db.menuItem.findFirst({ where: { active: true } });
  ok(!!item, `menu item available: ${item?.name || "—"}`);

  // 1. Admin login. With the factory default password the session is
  // must-change: set a test password, re-login, restore at cleanup.
  const login = await api("/api/admin/login", {
    method: "POST",
    body: JSON.stringify({ password: ADMIN_PW }),
  });
  adminCookie = (login.setCookie || "").split(";")[0];
  ok(login.json.ok === true && !!adminCookie, "admin login");
  if (login.json.mustChangePassword) {
    const changePw = await api("/api/admin/settings", {
      method: "PUT",
      headers: { cookie: adminCookie },
      body: JSON.stringify({ key: "password", current: ADMIN_PW, next: TEST_PW }),
    });
    ok(changePw.json.ok === true, "forced password change accepted (must-change flow)");
    const relogin = await api("/api/admin/login", {
      method: "POST",
      body: JSON.stringify({ password: TEST_PW }),
    });
    adminCookie = (relogin.setCookie || "").split(";")[0];
    ok(relogin.json.ok === true && relogin.json.mustChangePassword === false, "relogin with new password — no mustChange flag");
  }

  // 2. Point the REAL email settings at the capture server.
  await api("/api/admin/settings", {
    method: "PUT",
    headers: { cookie: adminCookie },
    body: JSON.stringify({
      key: "email",
      value: {
        enabled: true,
        host: "127.0.0.1",
        port: 2525,
        secure: false,
        user: "system@almachaab.lt",
        pass: "capture-pass",
        from: "system@almachaab.lt",
        fromName: "Alma Chaab",
        notifyEmail: "info@almachaab.lt",
      },
    }),
  });

  // 3. Create a pickup order with email.
  const hh = new Date(Date.now() + 2 * 3600e3).toTimeString().slice(0, 5);
  const created = await api("/api/orders", {
    method: "POST",
    body: JSON.stringify({
      type: "pickup",
      customerName: "T34 Testas",
      phone: "+37060000000",
      email: "customer@test.lt",
      items: [{ id: item.id, qty: 2 }],
      pickupTime: hh,
      note: "t34 e2e",
    }),
  });
  ok(created.json.ok === true, `order created: #${created.json.number} (${created.json.total} €)`);
  const row = await db.order.findUnique({ where: { number: created.json.number } });
  orderId = row.id;

  ok(await waitFor(2), "2 emails after order (customer received + restaurant copy)");
  ok(subjects().some((s) => s.includes("gautas")), `received email: "${subjects()[0] ?? "—"}"`);

  // 4. Admin: mark paid + confirmed in ONE request — must yield exactly ONE receipt.
  const paid = await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ paid: true, status: "confirmed" }),
  });
  ok(paid.json.ok === true && paid.json.order.paymentStatus === "paid", "admin mark paid (venue)");
  ok(await waitFor(3), "1 new email after paid+confirmed");
  ok(subjects().length === 3, `email count = 3, no duplicate (got ${subjects().length})`);

  const receipt = captured.find((c) => decodeSubj((c.data.match(/^Subject: (.*)$/m) || [])[1] || "").includes("Kvitas"));
  ok(!!receipt, `receipt sent: "${subjects().find((s) => s.includes("Kvitas")) || "—"}"`);
  if (receipt) {
    const body = decodeBody(receipt.data);
    ok(/Mokėjimo būdas/.test(body) && /Apmokėta vietoje/.test(body), "receipt shows payment method (venue)");
    ok(/Mokėjimo operacijos nr\./.test(body) && /admin-/.test(body), "receipt shows transaction ref");
    ok(/Apmokėta suma/.test(body), "receipt shows paid total");
    ok(body.includes(created.json.number), "receipt shows order number");
    ok(/To: customer@test\.lt/i.test(receipt.data), "receipt addressed to customer email");
    ok(/From: .*system@almachaab\.lt/i.test(receipt.data), "receipt from business mailbox");
  }
  const afterPaid = await db.order.findUnique({ where: { id: orderId } });
  const hist = JSON.parse(afterPaid.historyJson || "[]");
  ok(hist.some((h) => h.emailSent && h.emailSent.ok === true), "receipt result logged in order history");

  // 5. Normal status email still works (ready).
  await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ status: "ready" }),
  });
  ok(await waitFor(4), "ready email still sent");
  ok((subjects()[3] || "").includes("paruoštas"), `"${subjects()[3] || "—"}"`);

  // 6. Idempotency — repeat paid PATCH must NOT re-send the receipt.
  await api(`/api/admin/orders/${orderId}`, {
    method: "PATCH",
    headers: { cookie: adminCookie },
    body: JSON.stringify({ paid: true }),
  });
  await sleep(1500);
  ok(captured.length === 4, `repeat paid is a no-op (still ${captured.length} emails)`);
} catch (e) {
  fail++;
  console.error("ERROR:", e);
} finally {
  // 7. Cleanup: restore email + admin settings, delete the test order.
  try {
    if (origAdmin) {
      await db.setting.update({ where: { key: "admin" }, data: { value: origAdmin.value } });
      console.log("admin settings restored (password/scheme as before)");
    }
    if (origEmail) {
      await api("/api/admin/settings", {
        method: "PUT",
        headers: { cookie: adminCookie },
        body: JSON.stringify({ key: "email", value: origEmail }),
      });
      console.log("email settings restored:", origEmail.enabled ? "(was enabled)" : "(disabled, as before)");
    }
    if (orderId && adminCookie) {
      await fetch(`${BASE}/api/admin/orders/${orderId}`, {
        method: "DELETE",
        headers: { cookie: adminCookie },
      });
    }
  } catch {}
  server.close();
  await db.$disconnect();

  console.log("\nEmails captured:");
  for (const s of subjects()) console.log("  •", s);
  console.log(fail === 0 ? "\nALL CHECKS PASSED ✓" : `\n${fail} CHECK(S) FAILED ✗`);
  process.exit(fail === 0 ? 0 : 1);
}
