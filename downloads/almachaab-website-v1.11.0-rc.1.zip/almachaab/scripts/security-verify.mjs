/**
 * Security-verify for audit R1 (v1.9.1) — HTTP-level checks against the dev server.
 * Covers SEC-002, 005, 006(p4 part), 007, 009, 010, 011, 012, 013, 014, 015, 016(bridge).
 * SEC-001(prod vault), 004(escapeHtml), 008(vapid), 017(sanitiser) are unit checks
 * in security-verify-prod.mts.
 * Requires the SHIPPED (factory) DB state: admin password alma2026, no extra orders.
 * Cleans up every row it creates and restores the admin/email setting rows.
 */
const BASE = process.env.BASE_URL || "http://localhost:3000";
const STRONG_PW = "Sec-Verify!2026-almachaab";
let pass = 0, fail = 0, done = 0;
const results = [];
const ok = (sec, name, cond, extra = "") => {
  done++;
  results.push({ sec, name, pass: !!cond, extra });
  if (cond) { pass++; console.log(`  ✓ [${sec}] ${name}`); }
  else { fail++; console.log(`  ✗ [${sec}] ${name} ${extra}`); }
};

const jreq = async (path, opts = {}) => {
  const r = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", Origin: BASE, ...(opts.headers || {}) },
  });
  const txt = await r.text();
  let j = null;
  try { j = JSON.parse(txt); } catch { /* non-json */ }
  return { r, j, txt };
};

async function main() {
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient();
  const adminSnap = await db.setting.findUnique({ where: { key: "admin" } });
  const emailSnap = await db.setting.findUnique({ where: { key: "email" } });
  const vapidSnap = await db.setting.findUnique({ where: { key: "vapid" } });
  const { createHmac } = await import("crypto");
  const restoreSettings = async () => {
    for (const [key, snap] of [["admin", adminSnap], ["email", emailSnap], ["vapid", vapidSnap]]) {
      if (snap) await db.setting.upsert({ where: { key }, create: { key, value: snap.value }, update: { value: snap.value } });
      else await db.setting.deleteMany({ where: { key } });
    }
  };

  try {
    // ============ SEC-012: security headers ============
    console.log("\nSEC-012 · security headers");
    const home = await fetch(`${BASE}/`);
    const h = home.headers;
    const csp = h.get("content-security-policy") || "";
    ok("SEC-012", "CSP present", csp.length > 40, csp.slice(0, 60));
    ok("SEC-012", "frame-ancestors none / XFO DENY", csp.includes("frame-ancestors 'none'") && h.get("x-frame-options") === "DENY", h.get("x-frame-options"));
    ok("SEC-012", "nosniff", h.get("x-content-type-options") === "nosniff");
    ok("SEC-012", "Referrer-Policy", !!h.get("referrer-policy"));
    const adm = await fetch(`${BASE}/admin`);
    ok("SEC-012", "headers also on /admin", (adm.headers.get("content-security-policy") || "").length > 40);

    // ============ SEC-001: forged empty-key admin tokens ============
    console.log("\nSEC-001 · forged admin tokens (HMAC key = \"\")");
    const forge = (payload) => createHmac("sha256", "").update(payload).digest("base64url");
    const oldTok = `admin.${Date.now()}.${forge(`admin.${Date.now()}`)}`;       // pre-v1.9 format
    const newTok = `admin.${Date.now()}.7.${forge(`admin.${Date.now()}.7`)}`;   // v1.9 format
    for (const [label, tok] of [["old-format", oldTok], ["new-format", newTok]]) {
      const ov = await jreq("/api/admin/overview", { headers: { Cookie: `alma_admin=${tok}` } });
      ok("SEC-001", `forged ${label} → overview 401`, ov.r.status === 401, `(got ${ov.r.status})`);
      const st = await jreq("/api/admin/settings", { headers: { Cookie: `alma_admin=${tok}` } });
      ok("SEC-001", `forged ${label} → settings 401`, st.r.status === 401, `(got ${st.r.status})`);
    }
    const sess = await jreq("/api/admin/session", { headers: { Cookie: `alma_admin=${newTok}` } });
    ok("SEC-001", "session reports unauthenticated", sess.j && sess.j.authenticated === false, JSON.stringify(sess.j));

    // ============ SEC-002: forged social tokens + NextAuth off ============
    console.log("\nSEC-002 · social bridge / NextAuth fallback");
    const b64u = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
    const OLD_SECRET = "alma-chaab-fallback-secret";
    const jwt = (claims) => [b64u({ alg: "HS256", typ: "JWT" }), b64u(claims), createHmac("sha256", OLD_SECRET).update(`${b64u({ alg: "HS256", typ: "JWT" })}.${b64u(claims)}`).digest("base64url")].join(".");
    const br1 = await fetch(`${BASE}/api/auth/social/bridge?token=${encodeURIComponent(jwt({ email: "victim@example.com" }))}`, { redirect: "manual" });
    const br1c = (br1.headers.getSetCookie() || []).find((c) => c.startsWith("alma_user="));
    ok("SEC-002", "bare-email JWT with old constant → no session", br1c === undefined && /social=error/.test(br1.headers.get("location") || ""), `(loc ${br1.headers.get("location")})`);
    const br2 = await fetch(`${BASE}/api/auth/social/bridge?token=${encodeURIComponent(jwt({ uid: "fake-uid", sub: "x" }))}`, { redirect: "manual" });
    const br2c = (br2.headers.getSetCookie() || []).find((c) => c.startsWith("alma_user="));
    ok("SEC-002", "uid-only JWT (not bridge-marked) → no session", br2c === undefined, "");
    const prov = await jreq("/api/auth/providers");
    ok("SEC-002", "NextAuth endpoints 404 while no provider enabled", prov.r.status === 404, `(got ${prov.r.status})`);

    // ============ SEC-016: bridge redirect uses canonical host ============
    console.log("\nSEC-016 · base URL from NEXTAUTH_URL, not Host");
    const br3 = await fetch(`${BASE}/api/auth/social/bridge?token=x`, { redirect: "manual", headers: { Host: "evil.example" } });
    ok("SEC-016", "Host: evil.example → redirect stays canonical", !/evil\.example/.test(br3.headers.get("location") || ""), br3.headers.get("location"));

    // ============ SEC-009: cron guard ============
    console.log("\nSEC-009 · cron guard");
    const cq = await jreq("/api/cron/winback?secret=whatever-long-secret-123456", { method: "POST" });
    ok("SEC-009", "?secret= in URL → 401 (no CRON_SECRET set)", cq.r.status === 401, `(got ${cq.r.status})`);
    const ch = await jreq("/api/cron/winback", { method: "POST", headers: { "x-cron-secret": "whatever-long-secret-123456" } });
    ok("SEC-009", "header without CRON_SECRET env → 401", ch.r.status === 401, `(got ${ch.r.status})`);

    // ============ SEC-010: payment routes need tracking auth ============
    console.log("\nSEC-010 · order access on payment routes");
    const dish = await db.menuItem.findFirst({ where: { active: true, inStock: true, price: { gt: 0 } } });
    ok("SEC-010", "menu item available for cart", !!dish, "");
    const cartItem = dish ? [{ id: dish.id, qty: 1 }] : [];
    const o1 = await jreq("/api/orders", { method: "POST", body: JSON.stringify({ type: "pickup", customerName: "SEC-VERIFY 010", phone: "+37060000101", pickupTime: "12:30", items: cartItem }) });
    ok("SEC-010", "test order created (with total > 0)", o1.r.status === 200 && o1.j?.number, JSON.stringify(o1.j).slice(0, 140));
    const NR = o1.j?.number, TK = o1.j?.trackToken;
    const v0 = await fetch(`${BASE}/api/checkout/stripe/verify?number=${NR}`);
    ok("SEC-010", "verify without token → 403", v0.status === 403, `(got ${v0.status})`);
    const v1 = await fetch(`${BASE}/api/checkout/stripe/verify?number=${NR}&t=${encodeURIComponent(TK)}`);
    ok("SEC-010", "verify with token → not 403/429", v1.status !== 403 && v1.status !== 429, `(got ${v1.status})`);
    const se = await jreq("/api/checkout/stripe/existing", { method: "POST", body: JSON.stringify({ number: NR }) });
    ok("SEC-010", "stripe/existing without auth → 403", se.r.status === 403, `(got ${se.r.status} ${JSON.stringify(se.j)})`);
    const pe = await jreq("/api/checkout/paypal/existing", { method: "POST", body: JSON.stringify({ number: NR }) });
    ok("SEC-010", "paypal/existing without auth → 403", pe.r.status === 403, `(got ${pe.r.status} ${JSON.stringify(pe.j)})`);

    // ============ SEC-006: p4 per-order global cap (rotating IPs) ============
    console.log("\nSEC-006 · p4 cap across rotating IPs (per order)");
    const codes = [];
    for (let i = 0; i < 21; i++) {
      const ip = `198.51.100.${10 + Math.floor(i / 5)}`; // 5 IPs × up to 5 tries each
      const r = await fetch(`${BASE}/api/track/${NR}?p4=999${i % 10}`, { headers: { "cf-connecting-ip": ip } });
      codes.push(r.status);
    }
    ok("SEC-006", "first 20 guesses all 403 (no early global block)", codes.slice(0, 20).every((c) => c === 403), codes.join(","));
    ok("SEC-006", "21st guess → 429 (20 fails per order per hour)", codes[20] === 429, codes.join(","));
    const tokStill = await fetch(`${BASE}/api/track/${NR}?t=${encodeURIComponent(TK)}`);
    ok("SEC-006", "token auth never limited", tokStill.status === 200, `(got ${tokStill.status})`);

    // ============ SEC-015: order field caps (reservation: all fields) ============
    console.log("\nSEC-015 · order field length caps");
    const o2 = await jreq("/api/orders", { method: "POST", body: JSON.stringify({
      type: "reservation", pickupTime: "12:30",
      customerName: "X".repeat(500),
      phone: "+370" + "6".repeat(500),                       // digits stay ≥ 8 after truncation
      email: "y".repeat(99) + "@" + "z".repeat(15) + "." + "c".repeat(10), // 126 chars; cut at 120 keeps a valid address
      experiences: "E".repeat(500),
      note: "N".repeat(2000),
      resDate: "2026-12-01", resTime: "18:00", guests: 2,
      items: [],
    }) });
    ok("SEC-015", "oversized order accepted (truncated, not rejected)", o2.r.status === 200 && !!o2.j?.number, `(got ${o2.r.status} ${JSON.stringify(o2.j).slice(0, 120)})`);
    const o2row = o2.j?.number ? await db.order.findFirst({ where: { number: o2.j.number } }) : null;
    ok("SEC-015", "name capped at 80", o2row?.customerName?.length === 80, `(${o2row?.customerName?.length})`);
    ok("SEC-015", "phone capped at 30", o2row?.phone?.length === 30, `(${o2row?.phone?.length})`);
    ok("SEC-015", "email capped at 120", o2row?.email?.length === 120, `(${o2row?.email?.length})`);
    ok("SEC-015", "experiences capped at 300", (o2row?.experiences || "").length === 300, `(${o2row?.experiences?.length})`);
    ok("SEC-015", "note capped at 1000", (o2row?.note || "").length === 1000, `(${o2row?.note?.length})`);

    // ============ Admin flow: SEC-011/014/007 ============
    console.log("\nSEC-014/011/007 · admin password & settings");
    const lg = await jreq("/api/admin/login", { method: "POST", body: JSON.stringify({ password: "alma2026" }) });
    ok("SEC-003/014", "factory login works (must-change issued)", lg.r.status === 200 && lg.j?.mustChangePassword === true, JSON.stringify(lg.j));
    if (lg.r.status !== 200) throw new Error("factory login failed — DB not in shipped state; reset db/custom.db from the release zip and re-run");
    const adminCookie = (lg.r.headers.getSetCookie() || [])[0]?.split(";")[0] || "";
    const maxAge = (lg.r.headers.getSetCookie() || [])[0]?.match(/Max-Age=(\d+)/)?.[1];
    ok("SEC-011", "admin cookie Max-Age = 7 days", maxAge === "604800", `(${maxAge})`);
    const auth = { Cookie: adminCookie };

    const w1 = await jreq("/api/admin/settings", { method: "PUT", headers: auth, body: JSON.stringify({ key: "password", current: "alma2026", next: "short" }) });
    ok("SEC-014", "short password rejected", w1.r.status === 400, `(got ${w1.r.status})`);
    const w2 = await jreq("/api/admin/settings", { method: "PUT", headers: auth, body: JSON.stringify({ key: "password", current: "alma2026", next: "alma2026" }) });
    ok("SEC-014", "factory default rejected as new password", w2.r.status === 400, `(got ${w2.r.status})`);

    // SEC-011: password change revokes the pre-change token…
    const chg = await jreq("/api/admin/settings", { method: "PUT", headers: auth, body: JSON.stringify({ key: "password", current: "alma2026", next: STRONG_PW }) });
    ok("SEC-014", "strong password accepted", chg.r.status === 200, `(got ${chg.r.status}) ${chg.txt.slice(0, 80)}`);
    const oldSess = await jreq("/api/admin/session", { headers: auth });
    ok("SEC-011", "pre-change cookie revoked after password change", oldSess.r.status === 401 || oldSess.j?.authenticated === false, `(got ${oldSess.r.status} ${JSON.stringify(oldSess.j)})`);
    const lg2 = await jreq("/api/admin/login", { method: "POST", body: JSON.stringify({ password: STRONG_PW }) });
    ok("SEC-011", "login with new password → normal session", lg2.r.status === 200 && lg2.j?.mustChangePassword === false, JSON.stringify(lg2.j));
    const auth2 = { Cookie: (lg2.r.headers.getSetCookie() || [])[0]?.split(";")[0] || "" };

    // …SEC-007 needs the full (non-must-change) session → test after the change
    const emVal = { ...((emailSnap ? JSON.parse(emailSnap.value) : {})), enabled: false, pass: "smtp-secret-verify-123" };
    const emSet = await jreq("/api/admin/settings", { method: "PUT", headers: auth2, body: JSON.stringify({ key: "email", value: emVal }) });
    ok("SEC-007", "email settings saved", emSet.r.status === 200, `(got ${emSet.r.status}) ${emSet.txt.slice(0, 80)}`);
    const g1 = await jreq("/api/admin/settings", { headers: auth2 });
    ok("SEC-007", "GET masks email.pass", g1.j?.settings?.email?.pass === "••••••••", JSON.stringify(g1.j?.settings?.email?.pass));
    const emRow1 = await db.setting.findUnique({ where: { key: "email" } });
    ok("SEC-007", "stored pass is vault-encrypted (enc:v1)", (emRow1?.value || "").includes("enc:v1:"), String(emRow1?.value || "").slice(0, 50));
    await jreq("/api/admin/settings", { method: "PUT", headers: auth2, body: JSON.stringify({ key: "email", value: { ...emVal, pass: "••••••••" } }) });
    const emRow2 = await db.setting.findUnique({ where: { key: "email" } });
    // NOTE: re-saving re-encrypts with a fresh IV, so compare DECRYPTED plaintexts.
    const { decryptSecret } = await import("../src/lib/vault");
    const p1 = decryptSecret(JSON.parse(emRow1?.value || "{}").pass || "");
    const p2 = decryptSecret(JSON.parse(emRow2?.value || "{}").pass || "");
    ok("SEC-007", "saving the mask keeps the stored password", p1 === "smtp-secret-verify-123" && p1 === p2, `(${p1 === p2 ? "same" : "CHANGED"})`);

    // …logout revocation last (kills the session)
    const lo = await jreq("/api/admin/session", { method: "POST", headers: auth2, body: JSON.stringify({ action: "logout" }) });
    ok("SEC-011", "logout revokes all devices", lo.r.status === 200, "");
    const deadSess = await jreq("/api/admin/session", { headers: auth2 });
    ok("SEC-011", "post-logout cookie dead", deadSess.r.status === 401 || deadSess.j?.authenticated === false, `(got ${deadSess.r.status})`);

    // ============ SEC-005 + SEC-013: customer register/login ============
    console.log("\nSEC-005/013 · customer register & login limiters");
    const mkEmail = (i) => `sec-verify-${i}@example.com`;
    const regCodes = [];
    for (let i = 1; i <= 6; i++) {
      const r = await jreq("/api/auth/register", { method: "POST", body: JSON.stringify({ email: mkEmail(i), password: "Customer-Pass-1", name: "SEC Verify" }) });
      regCodes.push(r.r.status);
      if (i === 1) {
        const sc = (r.r.headers.getSetCookie() || []).find((c) => c.startsWith("alma_user="));
        ok("SEC-013", "alma_user cookie SameSite=Lax", !!sc && /SameSite=Lax/i.test(sc), (sc || "").split(";").map((s) => s.trim()).join(" | ").slice(0, 120));
      }
    }
    ok("SEC-005", "register: 5 ok then 429 (5/IP/hour)", regCodes.slice(0, 5).every((c) => c === 200 || c === 409) && regCodes[5] === 429, regCodes.join(","));
    const seq = [];
    for (let i = 0; i < 6; i++) { // account cap: 5 fails then block
      const r = await jreq("/api/auth/login", { method: "POST", body: JSON.stringify({ email: mkEmail(1), password: "wrong" }) });
      seq.push(r.r.status);
    }
    ok("SEC-005", "login acct1: 5×401 then 429 (5/account/15min)", seq.slice(0, 5).every((c) => c === 401) && seq[5] === 429, seq.join(","));
    for (let i = 0; i < 5; i++) { // account 2: 5 more IP failures (still under account cap)
      await jreq("/api/auth/login", { method: "POST", body: JSON.stringify({ email: mkEmail(2), password: "wrong" }) });
    }
    const ipTest = await jreq("/api/auth/login", { method: "POST", body: JSON.stringify({ email: mkEmail(3), password: "wrong" }) });
    ok("SEC-005", "acct3 first fail → 429 (10/IP/15min across accounts)", ipTest.r.status === 429, `(got ${ipTest.r.status})`);

  } finally {
    console.log("\ncleanup");
    try {
      const delOrders = await db.order.deleteMany({ where: { customerName: { startsWith: "SEC-VERIFY" } } });
      const delUsers = await db.user.deleteMany({ where: { email: { contains: "sec-verify-" } } });
      await restoreSettings();
      console.log(`  deleted ${delOrders.count} test orders, ${delUsers.count} test users; admin/email/vapid settings restored to shipped state`);
    } catch (e) {
      console.error("  cleanup error:", e.message);
    }
    await db.$disconnect();
  }

  console.log(`\n════════ security-verify (HTTP) ════════`);
  console.log(`   ${pass}/${done} checks passed, ${fail} failed`);
  const bySec = {};
  for (const r of results) { bySec[r.sec] = bySec[r.sec] || { p: 0, f: 0 }; r.pass ? bySec[r.sec].p++ : bySec[r.sec].f++; }
  for (const [sec, s] of Object.entries(bySec)) console.log(`   ${sec}: ${s.f === 0 ? "PASS" : "FAIL"} (${s.p}✓/${s.f}✗)`);
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => { console.error("suite error:", e); process.exit(1); });
