import {PrismaClient} from '@prisma/client';import pages from './standalone-pages-v1.json';import {PEOPLE_DEFAULTS} from '../src/lib/business-content';
const db=new PrismaClient();
async function main(){await db.$transaction(async tx=>{
 const marker='visual-cms-v1';if(await tx.setting.findUnique({where:{key:marker}})){console.log('Visual CMS migration already applied; current edits preserved.');return;}
 const row=await tx.setting.findUnique({where:{key:'content'}});const content=JSON.parse(row?.value||'{}');content.people??=PEOPLE_DEFAULTS;
 const value=JSON.stringify(content);await tx.setting.upsert({where:{key:'content'},update:{value},create:{key:'content',value}});
 for(const page of pages){const data={...page,visible:true,coverImage:'',author:''};const value=JSON.stringify({revision:1,draft:data,published:data,pending:false,actor:'migration',updatedAt:new Date().toISOString()});await tx.setting.create({data:{key:`cms:page:${page.slug}`,value}});}
 await tx.setting.create({data:{key:marker,value:'true'}});
 });
 const about=await db.setting.findUnique({where:{key:'cms:page:apie-mus'}});
 if(about){const record=JSON.parse(about.value);if(record.actor==='migration'&&record.revision===1&&!record.draft.blocks.some((b:any)=>b.id==='press-destination')){const button=pages.find(p=>p.slug==='apie-mus')!.blocks.find(b=>b.id==='press-destination');if(button){record.draft.blocks.push(button);record.published.blocks.push(button);record.revision=2;await db.setting.update({where:{key:about.key},data:{value:JSON.stringify(record)}});}}}
 // Repair duplicate identifiers in imported documents without changing their text or order.
 for(const row of await db.setting.findMany({where:{key:{startsWith:'cms:page:'}}})){
  const record=JSON.parse(row.value);let changed=false;
  for(const version of ['draft','published']){const seen=new Set<string>();for(const [index,block]of(record[version]?.blocks||[]).entries()){if(seen.has(block.id)){block.id=`${block.id}-${index}`;changed=true;}seen.add(block.id);}}
  if(changed){record.revision++;await db.setting.update({where:{key:row.key},data:{value:JSON.stringify(record)}});}
 }
 console.log('Visual CMS standalone pages and shared staff content prepared.');}

main().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>db.$disconnect());
