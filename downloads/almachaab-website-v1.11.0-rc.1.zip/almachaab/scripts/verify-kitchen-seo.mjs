// E2E verification: kitchen board flow + SEO outputs. Run with dev server up.
const BASE = "http://localhost:3000";

async function j(method, path, body, token) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { "x-admin-token": token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}

function assert(name, cond, extra = "") {
  console.log(`${cond ? "PASS" : "FAIL"} — ${name}${extra ? " · " + extra : ""}`);
  if (!cond) process.exitCode = 1;
}

// 1. login
const login = await j("POST", "/api/admin/login", { password: "alma2026" });
const token = login.json.token;
assert("login", !!token);

// 2. kitchen initially empty
const k0 = await j("GET", "/api/admin/kitchen", null, token);
assert("kitchen endpoint", k0.status === 200 && Array.isArray(k0.json.incoming) && Array.isArray(k0.json.active));

// 3. customer places pickup order
const ord = await j("POST", "/api/orders", { type: "pickup", customerName: "Skydelis Testas", phone: "+37060000001", items: [], pickupTime: "19:30" });
assert("order created", ord.json.ok === true, ord.json.number);
const number = ord.json.number;

// 4. order appears in kitchen incoming
const k1 = await j("GET", "/api/admin/kitchen", null, token);
const inc = k1.json.incoming.find((o) => o.number === number);
assert("order in incoming", !!inc, `total incoming: ${k1.json.incoming.length}`);

// 5. accept with prep time 25 min
const acc = await j("PATCH", `/api/admin/orders/${inc.id}`, { status: "confirmed", prepMinutes: 25, isRead: true }, token);
assert("accept + prepMinutes", acc.json.ok && acc.json.order.status === "confirmed" && acc.json.order.prepMinutes === 25);

// 6. track shows readyAt
const tr = await j("GET", `/api/track/${number}`);
assert("track readyAt", !!tr.json.readyAt && tr.json.prepMinutes === 25, `readyAt: ${tr.json.readyAt}`);

// 7. walk statuses
const p1 = await j("PATCH", `/api/admin/orders/${inc.id}`, { status: "preparing" }, token);
assert("preparing", p1.json.order.status === "preparing");
const p2 = await j("PATCH", `/api/admin/orders/${inc.id}`, { status: "ready" }, token);
assert("ready", p2.json.order.status === "ready");
const k2 = await j("GET", "/api/admin/kitchen", null, token);
assert("kitchen active shows ready", k2.json.active.some((o) => o.number === number && o.status === "ready"));

// 8. unauth guards
const un = await fetch(BASE + "/api/admin/kitchen");
assert("kitchen auth guard", un.status === 401);

// 9. pages render ("/sekti" is a redirect to /mano — fetch follows it)
const pages = ["/", "/straipsniai", "/mano", "/sekti", "/robots.txt", "/sitemap.xml", "/manifest.webmanifest"];
for (const p of pages) {
  const res = await fetch(BASE + p);
  assert(`GET ${p}`, res.status === 200, `status ${res.status}`);
}

// 10. SEO content checks
const home = await (await fetch(BASE + "/")).text();
assert("JSON-LD Restaurant", home.includes('"@type":"Restaurant"') || home.includes('"@type": "Restaurant"'));
assert("JSON-LD FAQPage", home.includes("FAQPage"));
assert("SEO keyword copy", home.includes("kur pavalgyti Kėdainiuose") || home.includes("Kur pavalgyti Kėdainiuose"));
const robots = await (await fetch(BASE + "/robots.txt")).text();
assert("AI bots in robots", robots.includes("GPTBot") && robots.includes("PerplexityBot") && robots.includes("ClaudeBot"));
const sitemap = await (await fetch(BASE + "/sitemap.xml")).text();
assert("articles in sitemap", sitemap.includes("geriausi-restoranai-kedainiuose") && sitemap.includes("straipsniai/"));
const arts = await (await fetch(BASE + "/straipsniai")).text();
assert("straipsniai page lists articles", arts.includes("/straipsniai/"));

console.log("E2E done.");
