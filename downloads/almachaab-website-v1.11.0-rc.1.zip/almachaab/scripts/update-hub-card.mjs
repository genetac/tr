// Polishes the "straipsniai" hub card text. Safe to re-run.
process.env.DATABASE_URL = process.env.DATABASE_URL || "file:/home/z/my-project/db/custom.db";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const row = await db.setting.findUnique({ where: { key: "content" } });
const content = row ? JSON.parse(row.value) : {};
content.hub = content.hub || {};
content.hub.cards = Array.isArray(content.hub.cards) ? content.hub.cards : [];

const card = content.hub.cards.find((c) => c.id === "straipsniai");
if (card) {
  card.icon = "📰";
  card.title = "Straipsniai ir istorijos";
  card.sub = "Naujienos, patiekalų istorijos ir žvilgsnis į virtuvę";
} else {
  content.hub.cards.push({
    id: "straipsniai",
    icon: "📰",
    title: "Straipsniai ir istorijos",
    sub: "Naujienos, patiekalų istorijos ir žvilgsnis į virtuvę",
  });
}

await db.setting.upsert({
  where: { key: "content" },
  update: { value: JSON.stringify(content) },
  create: { key: "content", value: JSON.stringify(content) },
});
console.log("hub card updated:", JSON.stringify(content.hub.cards.find((c) => c.id === "straipsniai")));
await db.$disconnect();
