/**
 * v1.4 Section C — turn off everything that isn't configured yet.
 *
 * The owner will re-enable these as paid add-ons later; until then the
 * placeholder IDs/keys must never reach the customer UI:
 *  - social sign-in (Google / Facebook / Telegram) → disabled
 *  - Stripe + PayPal gateway keys → cleared (checkout falls back to
 *    "pay at the restaurant" only)
 *  - Turnstile → disabled (the 1x0000… test key always passes anyway)
 *  - loyalty program → disabled (/mano and checkout hide it)
 *  - email (SMTP) stays disabled until configured on the server
 *  - admin session secret regenerated + stored ENCRYPTED (vault) — old
 *    ciphertext from a previous APP_SECRET_KEY would not decrypt after E2
 *
 * Run with tsx so the real vault code is used (no encryption drift):
 *   cp db/custom.db db/custom.db.bak-$(date +%s) && npx tsx scripts/disable-unconfigured.mts
 * Idempotent — safe to run again.
 */
import { randomBytes } from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { encryptSecret } from "../src/lib/vault";

const db = new PrismaClient();

async function main() {
  // 1. Settings singleton — social flags, gateway keys, Turnstile.
  const store = await db.settings.findUnique({ where: { id: "global" } });
  if (store) {
    await db.settings.update({
      where: { id: "global" },
      data: {
        googleEnabled: false,
        facebookEnabled: false,
        telegramEnabled: false,
        stripePublicKey: "",
        stripeSecretKey: "",
        stripeWebhookSecret: "",
        paypalClientId: "",
        paypalSecret: "",
        turnstileEnabled: false,
        turnstileSiteKey: "",
        turnstileSecretKey: "",
      },
    });
    console.log("✓ Settings singleton: social/gateway/turnstile disabled + keys cleared");
  } else {
    console.log("! Settings singleton row not found — skipped");
  }

  // 2. Loyalty program off (Setting row, key "loyalty").
  const loyalty = await db.setting.findUnique({ where: { key: "loyalty" } });
  const loyaltyCfg = loyalty ? JSON.parse(loyalty.value) : {};
  if (loyaltyCfg.enabled !== false) {
    loyaltyCfg.enabled = false;
    if (loyalty) await db.setting.update({ where: { key: "loyalty" }, data: { value: JSON.stringify(loyaltyCfg) } });
    else await db.setting.create({ data: { key: "loyalty", value: JSON.stringify(loyaltyCfg) } });
    console.log("✓ Loyalty program disabled");
  } else {
    console.log("· loyalty already disabled");
  }

  // 3. Email stays off until SMTP is configured on the server.
  const email = await db.setting.findUnique({ where: { key: "email" } });
  if (email) {
    const cfg = JSON.parse(email.value);
    cfg.enabled = false;
    // Old-key ciphertext for the mailbox password would not decrypt after the
    // E2 key removal — clear it; the owner re-enters it when enabling SMTP.
    if (cfg.pass) {
      cfg.pass = "";
      await db.setting.update({ where: { key: "email" }, data: { value: JSON.stringify(cfg) } });
      console.log("✓ Email kept disabled + SMTP password cleared (re-enter when configuring)");
    } else {
      console.log("· email already off with no stored password");
    }
  }

  // 4. Regenerate the admin session secret — old value may be ciphertext from
  //    the previous APP_SECRET_KEY. Stored encrypted via the real vault.
  const admin = await db.setting.findUnique({ where: { key: "admin" } });
  if (admin) {
    const cfg = JSON.parse(admin.value);
    cfg.secret = encryptSecret(randomBytes(32).toString("hex"));
    await db.setting.update({ where: { key: "admin" }, data: { value: JSON.stringify(cfg) } });
    console.log("✓ Admin session secret regenerated (encrypted at rest, sessions re-login)");
  }

  console.log("\nDONE — unconfigured features are off.");
}

main()
  .then(() => process.exit(0))
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
