// Adds the "Straipsniai" hub card to site content + seeds 3 example articles
// (1 published welcome story, 2 drafts). Safe to re-run.
process.env.DATABASE_URL = process.env.DATABASE_URL || "file:/home/z/my-project/db/custom.db";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

// ---------- 1) Hub card ----------
const contentRow = await db.setting.findUnique({ where: { key: "content" } });
const content = contentRow ? JSON.parse(contentRow.value) : {};
content.hub = content.hub || {};
content.hub.cards = Array.isArray(content.hub.cards) ? content.hub.cards : [];

if (!content.hub.cards.some((c) => c.id === "straipsniai")) {
  content.hub.cards.push({
    id: "straipsniai",
    icon: "📰",
    title: "Straipsniai ir istorijos",
    sub: "Naujienos, patiekalų istorijos ir žvilgsnis į mūsų virtuvę",
  });
  await db.setting.upsert({
    where: { key: "content" },
    update: { value: JSON.stringify(content) },
    create: { key: "content", value: JSON.stringify(content) },
  });
  console.log("hub card 'straipsniai' added");
} else {
  console.log("hub card already present");
}

// ---------- 2) Articles ----------
const A1 = {
  slug: "libano-skoniai-kedainiu-senamiestyje",
  title: "Libano skoniai Kėdainių senamiestyje: mūsų istorija",
  excerpt:
    "Kodėl mes atidarėme libanietiškos virtuvės restoraną Kėdainiuose ir ką norime duoti miestui — istorija apie Alma Chaab nuo pirmos idėjos iki pirmo lankytojo.",
  keywords: "libanietiškas maistas Kėdainiuose, libanietiška virtuvė, restoranas Kėdainiuose, kur pavalgyti Kėdainiuose, Alma Chaab",
  published: true,
  body: [
    { t: "p", text: "Alma Chaab — šeimos restoranas Kėdainių senamiestyje, Didžiojoje gatvėje. Vardas arabų kalboje reiškia „pasaulio obuolį“, ir būtent to norime: kad kiekvienas apsilankęs paragautų pasaulio, neatvykęs nė mylios nuo miesto centro." },
    { t: "h", text: "Kodėl Libanas?" },
    { t: "p", text: "Libanietiška virtuvė gimsta prie stalo: dalijamasi užkandžiais — hummusu, baba ganoush, šviežiomis salotomis, — kalbame, juokiamės ir neglamoname. Tokią patirtį ieškojome ir Kėdainiuose, todėl nusprendėme ją atsinešti patiems. Meniu sudėliojome taip, kad būtų lengva ragauti kartu: kelios dalijimosi lėkštės, sotus pagrindinis patiekalas ir desertas arbatai." },
    { t: "q", text: "Geras vakaras pas mus matuojamas ne patiekalų skaičiumi, o tuo, kiek kartų vėluojate namo, nes nenorite skubėti." },
    { t: "h", text: "Ką rasite pas mus" },
    { t: "p", text: "Rugpjūčio–rugsėjo vakarais čia kvepia grilis, savaitgaliais sutinkame šeimas su vaikais, o biiliardo stalelis laukia tuos, kurie vakarienę nori pratęsti žaidimu. Iš anksto pasirinktus patiekalus galime paruošti iki jūsų atvykimo — tai ypač patogu šeimos šventėms ar susitikimams su draugais." },
    { t: "p", text: "Jeigu ieškote, kur pavalgyti Kėdainiuose kitaip — ne greitai, ne triukšmingai, o prie pilno stalo — mes jums duris atvėrėme. Apsilankykite, parsineškite pasakojimą apie Libaną namo." },
  ],
};

const A2 = {
  slug: "hummus-baba-ganoush-kaip-ragauti",
  title: "Hummus, baba ganoush ir kiti užkandžiai: kaip jais dalijamasi",
  excerpt:
    "Libanietiško stalo pradžia — dalijimosi užkandžiai. Paaiškiname, kas tai, kaip juos ragauti ir kodėl jie tapo mūsų svečių mėgstamiausia dalimi.",
  keywords: "hummus, baba ganoush, artimųjų rytų patiekalai, užkandžiai, libanietiškas maistas Kėdainiuose",
  published: false,
  body: [
    { t: "p", text: "Libano virtuvėje vakarienė dažnai prasideda ne pagrindiniu patiekalu, o visa eile smulkių lėkščių vidury stalo. Jos vadinamos meze — ir tai ne tik užkandžiai, o visas bendravimo būdas." },
    { t: "h", text: "Hummus — daugiau nei padažas" },
    { t: "p", text: "Klasikinis hummus gaminamas iš virtų avinžirnių, tahini (sezamų pastos), citrinos sulčių ir alyvuogių aliejaus. Jis švelnus, kreminis ir puikiai dera su šilta duona. Mūsų svečiai dažnai sako, kad prieš tai „tik žinoję“ hummuso pavadinimą — o paragavę supranta, kodėl Viduriniuose Rytuose jis yra kasdienio stalo dalis." },
    { t: "h", text: "Baba ganoush — rūkytų baklažanų švelnumas" },
    { t: "p", text: "Baba ganoush gaminamas iš ant žarijų kepintų baklažanų, todėl turi lengvą rūkytą atspalvį. Su hummusu jie sudaro puikų porą: vienas švelnus ir riešutinis, kitas sodrus ir žaismingas." },
    { t: "p", text: "Patarimas: užsisakykite kelis dalijimosi užkandžius vietoj vieno didelio — taip paragausite daugiau skonių ir vakarienė taps maža kelione po Libaną." },
  ],
};

const A3 = {
  slug: "renginiai-degustacijos-ir-biliardas",
  title: "Vakarai su istorija: degustacijos, renginiai ir biiliardas pas mus",
  excerpt:
    "Alma Chaab — ne tik vakarienė. Pasakojame apie degustacijų vakarus, privačias šventes ir biiliardo stalelį, dėl kurio verta atvykti anksčiau.",
  keywords: "renginiai Kėdainiuose, degustacijos, biiliardas, vakarienė Kėdainiuose, privatus renginys",
  published: false,
  body: [
    { t: "p", text: "Restoranas gyvena ne tik pietų ir vakarienių ritmu. Visa savaitė pas mus turi savo skonį: darbo dienos ramesnės, o savaitgaliais senamiestis prisipildo kalbų ir kvapų." },
    { t: "h", text: "Degustacijų vakarai" },
    { t: "p", text: "Periodiškai rengiame degustacijas, kuriose supažindiname su keliais Libano regionų skoniais vienu vakaru. Tai puiki proga pirmą kartą ateiti pas mus — šefas papasakoja kiekvieno patiekalo istoriją, o jūs tiesiog ragaujate ir klausiate." },
    { t: "h", text: "Privačios šventės ir biiliardas" },
    { t: "p", text: "Švenčiate gimtadienį ar kompanijos vakarą? Iš anksto suderinkite meniu — paruošime patiekalus iki jūsų atvykimo, kad šventė prasidėtų be laukimo. Po vakarienės galite pereiti prie biiliardo stalelio: sena gera tradicija, kuri vakarą pratęsia natūraliai." },
    { t: "q", text: "Geriausi vakarai pas mus baigiasi ne sąskaita, o žadėjimu sugrįžti." },
  ],
};

for (const a of [A1, A2, A3]) {
  const existing = await db.article.findUnique({ where: { slug: a.slug } });
  if (existing) {
    console.log("skip (exists):", a.slug);
    continue;
  }
  await db.article.create({
    data: {
      slug: a.slug,
      title: a.title,
      excerpt: a.excerpt,
      keywords: a.keywords,
      bodyJson: JSON.stringify(a.body),
      published: a.published,
      publishedAt: a.published ? new Date() : null,
    },
  });
  console.log("created:", a.slug, a.published ? "(published)" : "(draft)");
}

console.log("done");
await db.$disconnect();
