#!/usr/bin/env python3
"""Re-extract only style block contents (not the head content between them)."""
import re

SRC = "/home/z/my-project/upload/Alma-Chaab-PC-Mobile.html"
OUT = "/home/z/my-project/src/app/site.css"

lines = open(SRC, encoding="utf-8").readlines()

blocks = []
inside = False
cur = []
for l in lines:
    if not inside and "<style" in l:
        inside = True
        # content may start on same line after <style...>
        after = l.split(">", 1)[1] if ">" in l else ""
        cur = [after] if after.strip() else []
        if "</style>" in l:
            before = l.split("</style>")[0]
            after2 = after.split("</style>")[0] if "</style>" in after else ""
            cur = [after2] if after2.strip() else []
            inside = False
            blocks.append("".join(cur))
            cur = []
        continue
    if inside:
        if "</style>" in l:
            cur.append(l.split("</style>")[0])
            blocks.append("".join(cur))
            cur = []
            inside = False
        else:
            cur.append(l)

print(f"{len(blocks)} style blocks, sizes: {[len(b) for b in blocks]}")
css = "\n\n".join(blocks)
open(OUT, "w", encoding="utf-8").write(css)
print(f"CSS written: {len(css)} chars")
# sanity: no HTML tags
assert "<meta" not in css, "HTML leaked into CSS!"
assert "<!--" not in css, "HTML comment leaked!"
print("clean")
