import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const orders = await db.order.findMany({
  where: { OR: [{ number: "AC-1044" }, { number: "AC-1045" }] },
  select: { id: true, number: true },
});
for (const o of orders) {
  await db.order.delete({ where: { id: o.id } });
  console.log("deleted order", o.number);
}

const user = await db.user.findUnique({ where: { email: "e2e-pay@test.lt" } });
if (user) {
  await db.user.delete({ where: { id: user.id } });
  console.log("deleted user e2e-pay@test.lt (cascade accounts/loyalty)");
}

const [oc, uc, ac] = await Promise.all([db.order.count(), db.user.count(), db.account.count()]);
console.log(`remaining — orders:${oc} users:${uc} accounts:${ac}`);
await db.$disconnect();
