/**
 * v1.4 acceptance checks — A2 (p4 limiter), B (login limiter bypass), CSRF.
 * Creates one test order, runs the gauntlet, cleans up after itself.
 */
const BASE = process.env.BASE_URL || "http://localhost:3000";
let pass = 0, fail = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${extra}`); }
};

async function main() {
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient();
  const origAdminRow = await db.setting.findUnique({ where: { key: "admin" } });
  const TEST_PW = "V14-Accept-2026!";

  // ---------- Create a test order ----------
  const or = await fetch(`${BASE}/api/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: BASE },
    body: JSON.stringify({
      type: "pickup", customerName: "V14 Test", phone: "+37060000001",
      pickupTime: "12:30", items: [],
    }),
  });
  const oj = await or.json();
  ok("A1 test order created", or.status === 200 && oj.number, JSON.stringify(oj).slice(0, 140));
  ok("A1 /api/orders returns trackToken (crypto)", typeof oj.trackToken === "string" && oj.trackToken.length >= 20 && !/[._]/.test(oj.trackToken), oj.trackToken);
  const nr = oj.number;

  // A1: no token → 403; with token → 200
  const noAuth = await fetch(`${BASE}/api/track/${nr}`);
  ok("A1 track without auth → 403", noAuth.status === 403, `(got ${noAuth.status})`);
  const withToken = await fetch(`${BASE}/api/track/${nr}?t=${encodeURIComponent(oj.trackToken)}`);
  ok("A1 track with token → 200", withToken.status === 200, `(got ${withToken.status})`);

  // ---------- A2: 6 wrong p4 guesses → 5×403 then 429 ----------
  const codes = [];
  for (let i = 0; i < 6; i++) {
    const r = await fetch(`${BASE}/api/track/${nr}?p4=999${i}`);
    codes.push(r.status);
    if (r.status === 429) {
      const j = await r.json().catch(() => ({}));
      ok("A2 429 message (LT)", /Per daug bandymų/.test(j.error || ""), j.error);
    }
  }
  ok("A2 sequence 5×403 then 429", codes.slice(0, 5).every((c) => c === 403) && codes[5] === 429, codes.join(","));
  // Correct token still works while p4 is limited
  const tokenWhileLimited = await fetch(`${BASE}/api/track/${nr}?t=${encodeURIComponent(oj.trackToken)}`);
  ok("A2 token auth never limited", tokenWhileLimited.status === 200, `(got ${tokenWhileLimited.status})`);
  // Different order number is NOT limited (per-order cap)
  const or2 = await fetch(`${BASE}/api/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: BASE },
    body: JSON.stringify({ type: "pickup", customerName: "V14 Test 2", phone: "+37060000002", pickupTime: "12:30", items: [] }),
  });
  const oj2 = await or2.json();
  const otherOrder = await fetch(`${BASE}/api/track/${oj2.number}?p4=0000`);
  ok("A2 per-order cap (other order unaffected)", otherOrder.status === 403, `(got ${otherOrder.status})`);

  // ---------- B: login limiter bypass via X-Forwarded-For ----------
  // 6 wrong passwords, each with a DIFFERENT X-Forwarded-For but the SAME
  // cf-connecting-ip → per-IP counter must key on cf-connecting-ip → 429.
  const loginCodes = [];
  for (let i = 0; i < 6; i++) {
    const r = await fetch(`${BASE}/api/admin/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Origin: BASE,
        "cf-connecting-ip": "198.51.100.77",
        "x-forwarded-for": `10.0.${i}.1, 10.9.9.9`,
      },
      body: JSON.stringify({ password: "definitely-wrong-" + i }),
    });
    loginCodes.push(r.status);
  }
  ok("B XFF rotation defeated → 5×401 then 429", loginCodes.slice(0, 5).every((c) => c === 401) && loginCodes[5] === 429, loginCodes.join(","));

  // ---------- CSRF: foreign Origin → 403 ----------
  const csrf = await fetch(`${BASE}/api/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: "https://evil.example" },
    body: JSON.stringify({ type: "pickup", customerName: "Evil", phone: "+37060000003", pickupTime: "12:30", items: [] }),
  });
  ok("CSRF foreign Origin → 403", csrf.status === 403, `(got ${csrf.status})`);

  // ---------- Cleanup ----------
  const orders = await db.order.findMany({ where: { number: { in: [oj.number, oj2.number] } }, select: { id: true, number: true } });
  for (const o of orders) await db.order.delete({ where: { id: o.id } });
  console.log(`  (cleaned up ${orders.length} test orders)`);
  if (origAdminRow) {
    await db.setting.update({ where: { key: "admin" }, data: { value: origAdminRow.value } });
    console.log("  (admin settings restored)");
  }
  await db.$disconnect();

  console.log(`\nRESULT: ${pass} pass, ${fail} fail`);
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
