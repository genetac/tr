#!/usr/bin/env python3
"""Ground-truth dump: every 'hidden]' occurrence with its 8 preceding chars,
brackets spelled out as LB/RB tokens so no display layer can distort them."""
import re

FILES = [
    "/home/z/my-project/src/app/site.css",
    "/home/z/my-project/src/app/site-scoped.css",
]

def tok(s: str) -> str:
    return s.replace("[", "LB").replace("]", "RB")

for path in FILES:
    s = open(path, encoding="utf-8").read()
    print("FILE:", path.split("/")[-1])
    n = 0
    for m in re.finditer(r"hidden\]", s):
        n += 1
        i = m.start()
        before = s[max(0, i - 8) : i]
        after = s[m.end() : m.end() + 6]
        print(f"  #{n}: ...{tok(before)} | hidden] | {tok(after)}...")
    print(f"  TOTAL={n}")
