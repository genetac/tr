/** One-time, non-destructive content migration. Run with node --env-file=.env.local --import tsx. */
import { PrismaClient } from '@prisma/client';
import { VISITOR_DEFAULTS } from '../src/lib/visitor';
const db = new PrismaClient();
async function main() {
try {
  await db.$transaction(async tx => {
    const key = 'owner-content-v1';
    if (await tx.setting.findUnique({ where: { key } })) {
      console.log('Owner content migration already applied; existing edits preserved.');
      return;
    }
    const row = await tx.setting.findUnique({ where: { key: 'content' } });
    const c = row ? JSON.parse(row.value) : {};
    c.visitor = { ...VISITOR_DEFAULTS, ...(c.visitor || {}) };
    c.articles = { ...c.articles, authorName: 'Irina Eid', authorRole: '„AlmaChaab“ vadovė' };
    c.events = { ...c.events, billiards: { ...c.events?.billiards, studentPrice: 5, adultPrice: 10, cutoff: '20:00', text: 'Veikia du biliardo stalai.', price: '5 € / 10 €', priceNote: 'Moksleiviams ir studentams / suaugusiesiems', bookingNote: '', meta: [] } };
    c.wolt = { ...c.wolt, title: 'Maistas išsinešimui ir pristatymas', text: VISITOR_DEFAULTS.delivery };
    // Sample photographs remain in the archive, but are not presented as authentic assets.
    const removeSamples = (v: any): any => {
      if (typeof v === 'string' && v.startsWith('/seed/')) return '/logo.svg';
      if (Array.isArray(v)) return v.map(removeSamples);
      if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k,x]) => [k,removeSamples(x)]));
      return v;
    };
    const content = removeSamples(c);
    content.gallery = { ...content.gallery, images: [], pending: true };
    content.ribbon = [];
    // Preserve articles for review; do not attribute unreviewed published text to Irina.
    await tx.article.updateMany({ data: { published: false, publishedAt: null } });
    await tx.setting.upsert({ where: { key: 'content' }, update: { value: JSON.stringify(content) }, create: { key: 'content', value: JSON.stringify(content) } });
    await tx.setting.create({ data: { key, value: JSON.stringify({ applied: true, articlesRequireReview: true, photosPending: true }) } });
    console.log('Confirmed owner content applied; articles retained as drafts, sample gallery hidden.');
  });
} finally { await db.$disconnect(); }

}
main().catch(e => { console.error(e); process.exitCode = 1; });
