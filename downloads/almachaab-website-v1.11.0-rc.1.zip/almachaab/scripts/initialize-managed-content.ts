import { PrismaClient } from '@prisma/client';
import { DEFAULT_NAVIGATION } from '../src/lib/content-management';
const db=new PrismaClient();
async function main() {
  await db.$transaction(async tx => {
    if (await tx.setting.findUnique({ where:{ key:'managed-content-v1' } })) return;
    const row=await tx.setting.findUnique({ where:{ key:'content' } });
    const content=JSON.parse(row?.value || '{}');
    content.navigation ??= DEFAULT_NAVIGATION;
    content.pages ??= [];
    content.liveEvents ??= ['10-16','11-06','11-13','11-30'].map(day => ({ id:`music-${day}`,title:day==='10-16' ? 'Lietuviškos muzikos vakaras' : 'Gyvos muzikos vakaras',date:'',time:'',description:'',image:'',bookingUrl:'',published:false,draftNote:`Irina nurodė ${day}. Metai, laikas ir kitos detalės nepatvirtinti.` }));
    await tx.setting.update({ where:{ key:'content' },data:{ value:JSON.stringify(content) } });
    await tx.setting.create({ data:{ key:'managed-content-v1',value:'true' } });
  });
}
main().catch(e => { console.error(e);process.exitCode=1; }).finally(() => db.$disconnect());
