/**
 * One-off migration: store the official business contact details.
 *  - Phone display format -> "+370 666 13 055" (tel: stays +37066613055)
 *  - Official Facebook page -> https://www.facebook.com/restoranas.almachaab
 * Idempotent — safe to re-run. Run: bun scripts/update-contact.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const OFFICIAL = {
  phone: "+37066613055",
  phoneDisplay: "+370 666 13 055",
  facebookUrl: "https://www.facebook.com/restoranas.almachaab",
};

async function main() {
  // 1) Patch the "site" settings key (merge — keeps any admin-edited fields)
  const site = await db.setting.findUnique({ where: { key: "site" } });
  if (site) {
    const v = JSON.parse(site.value);
    v.phone = OFFICIAL.phone;
    v.phoneDisplay = OFFICIAL.phoneDisplay;
    v.facebookUrl = OFFICIAL.facebookUrl;
    await db.setting.update({ where: { key: "site" }, data: { value: JSON.stringify(v) } });
    console.log("site settings updated:", v);
  } else {
    console.warn('No "site" settings row found — run scripts/seed.ts first.');
    process.exitCode = 1;
  }

  // 2) Patch any content blocks that hardcode the old display format (billiards promo)
  const content = await db.setting.findUnique({ where: { key: "content" } });
  if (content) {
    const v = JSON.parse(content.value);
    let touched = false;
    const walk = (obj) => {
      if (!obj || typeof obj !== "object") return;
      for (const [k, val] of Object.entries(obj)) {
        if (typeof val === "string" && val.includes("+370 666 13055")) {
          obj[k] = val.replaceAll("+370 666 13055", "+370 666 13 055");
          touched = true;
        } else if (val && typeof val === "object") {
          walk(val);
        }
      }
    };
    walk(v);
    if (touched) {
      await db.setting.update({ where: { key: "content" }, data: { value: JSON.stringify(v) } });
      console.log("content strings updated to official phone format");
    } else {
      console.log("content: no old-format phone strings found");
    }
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
