import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
const u = await db.user.findUnique({ where: { email: 'e2e-ts@test.lt' } });
if (u) { await db.user.delete({ where: { id: u.id } }); console.log('test user deleted:', u.id); }
else console.log('no test user found');
console.log('users:', await db.user.count(), 'accounts:', await db.account.count());
await db.$disconnect();
