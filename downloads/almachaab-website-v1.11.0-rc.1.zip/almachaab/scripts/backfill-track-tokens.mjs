/**
 * A3 backfill — give every order that has an empty trackToken a fresh
 * crypto-random token (run once after deploying the new newTrackToken()).
 * Idempotent: re-running finds nothing to do.
 *
 *   cp db/custom.db db/custom.db.bak-$(date +%s)   # first!
 *   node scripts/backfill-track-tokens.mjs
 */
import { randomBytes } from "node:crypto";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const missing = await db.order.findMany({
    where: { trackToken: "" },
    select: { id: true, number: true },
  });
  console.log(`orders without a trackToken: ${missing.length}`);
  for (const o of missing) {
    const token = randomBytes(16).toString("base64url");
    await db.order.update({ where: { id: o.id }, data: { trackToken: token } });
    console.log(`  ✓ ${o.number} → ${token.slice(0, 6)}…`);
  }
  console.log("done");
}

main()
  .then(() => process.exit(0))
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
