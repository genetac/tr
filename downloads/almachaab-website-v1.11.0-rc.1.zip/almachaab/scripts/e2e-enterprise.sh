#!/bin/bash
# Enterprise suite E2E — locations, loyalty award/redeem, recommendations, CRM, auth guards
set -uo pipefail
BASE="http://localhost:3000"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✗ $1  →  $2"; }
check() { # name, expected, actual
  if [ "$2" = "$3" ]; then ok "$1"; else bad "$1" "expected=$2 got=$3"; fi
}

echo "== 1. Admin auth =="
TOKEN=$(curl -s -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -d '{"password":"alma2026"}' | python3 -c 'import sys,json;print(json.load(sys.stdin).get("token",""))')
[ -n "$TOKEN" ] && ok "admin login token" || bad "admin login token" "empty"
AH="x-admin-token: $TOKEN"

echo "== 2. Locations =="
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/admin/locations")
check "locations unauthorized=401" 401 "$code"
LOCS=$(curl -s "$BASE/api/admin/locations" -H "$AH")
DEF=$(echo "$LOCS" | python3 -c 'import sys,json;l=[x for x in json.load(sys.stdin)["locations"] if x["isDefault"]];print(l[0]["name"] if l else "NONE")')
check "default location seeded" "Alma Chaab — Kėdainiai" "$DEF"
NEW=$(curl -s -X POST "$BASE/api/admin/locations" -H "$AH" -H 'Content-Type: application/json' -d '{"name":"Test Filialas Vilnius","address":"Test g. 1","taxRate":21,"deliveryFee":2.5}')
NEWID=$(echo "$NEW" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("location",{}).get("id",""))')
[ -n "$NEWID" ] && ok "create location" || bad "create location" "$NEW"
UPD=$(curl -s -X PUT "$BASE/api/admin/locations" -H "$AH" -H 'Content-Type: application/json' -d "{\"id\":\"$NEWID\",\"name\":\"Test Filialas Kaunas\",\"isActive\":false}")
UPNAME=$(echo "$UPD" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("location",{}).get("name",""))')
check "update location" "Test Filialas Kaunas" "$UPNAME"
code=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE "$BASE/api/admin/locations?id=$NEWID" -H "$AH")
check "delete location" 200 "$code"

echo "== 3. Loyalty admin =="
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/admin/loyalty")
check "loyalty unauthorized=401" 401 "$code"
LOY=$(curl -s "$BASE/api/admin/loyalty" -H "$AH")
NR=$(echo "$LOY" | python3 -c 'import sys,json;print(len(json.load(sys.stdin)["rewards"]))')
check "rewards seeded (>=4)" "True" "$([ "$NR" -ge 4 ] && echo True || echo False)"
CFG=$(echo "$LOY" | python3 -c 'import sys,json;c=json.load(sys.stdin)["config"];print(c["enabled"],c["pointsPerEuro"],c["stampGoal"])')
check "loyalty config" "True 1 8" "$CFG"
RW=$(curl -s -X POST "$BASE/api/admin/loyalty" -H "$AH" -H 'Content-Type: application/json' -d '{"action":"saveReward","name":"Test prizas E2E","pointsCost":25,"description":"tmp","active":true}')
RWID=$(echo "$RW" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("reward",{}).get("id",""))')
[ -n "$RWID" ] && ok "saveReward create" || bad "saveReward create" "$RW"
code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/admin/loyalty" -H "$AH" -H 'Content-Type: application/json' -d "{\"action\":\"deleteReward\",\"id\":\"$RWID\"}")
check "deleteReward" 200 "$code"

echo "== 4. Recommendations =="
FIRST=$(curl -s "$BASE/api/site" | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d["categories"][0]["items"][0]["id"])')
REC=$(curl -s "$BASE/api/recommendations?ids=$FIRST&limit=3")
NREC=$(echo "$REC" | python3 -c 'import sys,json;print(len(json.load(sys.stdin)["recommendations"]))')
check "recommendations non-empty" "True" "$([ "$NREC" -ge 1 ] && echo True || echo False)"
EMPTY=$(curl -s "$BASE/api/recommendations?ids=")
check "recommendations empty-safe" '{"recommendations":[]}' "$EMPTY"

echo "== 5. Customer loyalty lifecycle =="
EMAIL="e2e-loyalty-$(date +%s)@test.lt"
REG=$(curl -s -c /tmp/e2e-cj.txt -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' -d "{\"email\":\"$EMAIL\",\"password\":\"password123\",\"name\":\"E2E Testas\"}")
USERID=$(echo "$REG" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("user",{}).get("id",""))')
[ -n "$USERID" ] && ok "register test user" || bad "register test user" "$REG"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/me/loyalty")
check "me/loyalty unauthorized=401" 401 "$code"
LOY0=$(curl -s -b /tmp/e2e-cj.txt "$BASE/api/me/loyalty")
check "fresh profile zero points" "0" "$(echo "$LOY0" | python3 -c 'import sys,json;print((json.load(sys.stdin)["profile"] or {"points":0})["points"])')"
ITEM2=$(curl -s "$BASE/api/site" | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d["categories"][0]["items"][1]["id"])')
ORD=$(curl -s -b /tmp/e2e-cj.txt -X POST "$BASE/api/orders" -H 'Content-Type: application/json' -d "{\"type\":\"pickup\",\"customerName\":\"E2E Testas\",\"phone\":\"+37060000001\",\"items\":[{\"id\":\"$FIRST\",\"qty\":2},{\"id\":\"$ITEM2\",\"qty\":1}],\"pickupTime\":\"18:00\"}")
ONUM=$(echo "$ORD" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("number",""))')
OTOTAL=$(echo "$ORD" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("total",0))')
[ -n "$ONUM" ] && ok "order created ($ONUM, total $OTOTAL)" || bad "order created" "$ORD"
OID=$(curl -s "$BASE/api/admin/orders?q=$ONUM" -H "$AH" | python3 -c 'import sys,json;o=json.load(sys.stdin)["orders"];print(o[0]["id"] if o else "")')
[ -n "$OID" ] && ok "admin finds order" || bad "admin finds order" "empty"
LOC=$(curl -s "$BASE/api/admin/orders?q=$ONUM" -H "$AH" | python3 -c 'import sys,json;o=json.load(sys.stdin)["orders"][0];print(o.get("locationName",""))')
check "order has location" "Alma Chaab — Kėdainiai" "$LOC"
# complete the order (pay on pickup) → loyalty award
curl -s -X PATCH "$BASE/api/admin/orders/$OID" -H "$AH" -H 'Content-Type: application/json' -d '{"status":"completed"}' > /dev/null
sleep 1
LOY1=$(curl -s -b /tmp/e2e-cj.txt "$BASE/api/me/loyalty")
PTS=$(echo "$LOY1" | python3 -c 'import sys,json;print(json.load(sys.stdin)["profile"]["points"])')
STAMPS=$(echo "$LOY1" | python3 -c 'import sys,json;print(json.load(sys.stdin)["profile"]["stamps"])')
check "points awarded (=floor total)" "$(python3 -c "import math;print(math.floor($OTOTAL))")" "$PTS"
check "stamp awarded (1 of 8)" "1" "$STAMPS"
# idempotency: re-complete must not double-award
curl -s -X PATCH "$BASE/api/admin/orders/$OID" -H "$AH" -H 'Content-Type: application/json' -d '{"status":"completed"}' > /dev/null
sleep 1
PTS2=$(curl -s -b /tmp/e2e-cj.txt "$BASE/api/me/loyalty" | python3 -c 'import sys,json;print(json.load(sys.stdin)["profile"]["points"])')
check "idempotent award (no double)" "$PTS" "$PTS2"
# redeem the 30-point drink? total may be < 30; redeem cheapest affordable or expect error
RID=$(echo "$LOY1" | python3 -c 'import sys,json;d=json.load(sys.stdin);rs=[r for r in d["rewards"] if r["affordable"]];print(rs[0]["id"] if rs else "")')
if [ -n "$RID" ]; then
  RED=$(curl -s -b /tmp/e2e-cj.txt -X POST "$BASE/api/me/redeem" -H 'Content-Type: application/json' -d "{\"rewardId\":\"$RID\"}")
  CODE=$(echo "$RED" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("redemption",{}).get("code",""))')
  [ -n "$CODE" ] && ok "redeem → voucher $CODE" || bad "redeem" "$RED"
  VCHK=$(curl -s -X POST "$BASE/api/admin/loyalty" -H "$AH" -H 'Content-Type: application/json' -d "{\"action\":\"useVoucher\",\"code\":\"$CODE\"}")
  check "admin marks voucher used" "used" "$(echo "$VCHK" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("redemption",{}).get("status",""))')"
else
  ok "no affordable reward (total <$ min cost) — redeem skipped"
fi

echo "== 6. CRM win-back =="
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/admin/crm/winback")
check "winback unauthorized=401" 401 "$code"
WB=$(curl -s "$BASE/api/admin/crm/winback?days=14" -H "$AH")
CNT=$(echo "$WB" | python3 -c 'import sys,json;print(json.load(sys.stdin)["count"])')
FRESH=$(echo "$WB" | python3 -c 'import sys,json;d=json.load(sys.stdin);print("False" if any(c["email"]=="'"$EMAIL"'" for c in d["customers"]) else "True")')
check "fresh orderer excluded from dormant" "True" "$FRESH"
echo "  · dormant count: $CNT"
code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/cron/winback")
check "cron no secret=401" 401 "$code"
SECRET=$(python3 -c "import json;print(json.load(open('/dev/stdin'))['admin']['secret'] if False else '')" 2>/dev/null)
# read admin secret from settings via admin API
SECRET=$(curl -s "$BASE/api/admin/settings" -H "$AH" | python3 -c 'import sys,json;s=json.load(sys.stdin)["settings"];print(s.get("admin",{}).get("secret",""))')
if [ -n "$SECRET" ]; then
  CRON=$(curl -s -X POST "$BASE/api/cron/winback?secret=$SECRET")
  check "cron with secret ok" "True" "$(echo "$CRON" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("ok",""))')"
else
  ok "cron secret check skipped (admin secret hidden)"
fi

echo "== 7. Customer push config =="
PK=$(curl -s -b /tmp/e2e-cj.txt "$BASE/api/me/push" | python3 -c 'import sys,json;print("yes" if json.load(sys.stdin).get("publicKey") else "no")')
check "customer push VAPID key exposed" "yes" "$PK"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/me/push")
check "me/push unauthorized=401" 401 "$code"

echo "== 8. Cleanup =="
curl -s -X DELETE "$BASE/api/admin/orders/$OID" -H "$AH" > /dev/null
# delete test user + loyalty rows via prisma (no user delete API by design)
node -e '
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
(async () => {
  const u = await db.user.findUnique({ where: { email: "'"$EMAIL"'" } });
  if (u) { await db.user.delete({ where: { id: u.id } }); console.log("  ✓ test user deleted"); }
  await db.$disconnect();
})();
'
# reset order counter
node -e '
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
(async () => {
  const s = await db.setting.findUnique({ where: { key: "orders" } });
  if (s) {
    const v = JSON.parse(s.value);
    v.nextNumber = Math.min(v.nextNumber, 1042);
    await db.setting.update({ where: { key: "orders" }, data: { value: JSON.stringify(v) } });
    console.log("  ✓ counter reset to", v.prefix + "-" + v.nextNumber);
  }
  await db.$disconnect();
})();
'
echo ""
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" = "0" ]