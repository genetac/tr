#!/usr/bin/env python3
"""Generate Alma Chaab PWA icons (gold 'AC' monogram on cream)."""
from PIL import Image, ImageDraw, ImageFont
import glob

GOLD = (180, 123, 45)
GOLD2 = (208, 161, 95)
CREAM = (248, 242, 233)
INK = (36, 26, 19)

def make_icon(size, path, maskable=False):
    img = Image.new("RGB", (size, size), CREAM)
    d = ImageDraw.Draw(img)
    # subtle radial-ish circles
    pad = int(size * 0.08) if maskable else int(size * 0.06)
    # gold ring
    d.ellipse([pad, pad, size - pad, size - pad], outline=GOLD, width=max(2, size // 32))
    # inner text AC
    fs = int(size * 0.38)
    font = None
    for cand in glob.glob("/usr/share/fonts/truetype/dejavu/DejaVuSerif*.ttf") + glob.glob("/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf"):
        font = ImageFont.truetype(cand, fs)
        break
    if font is None:
        font = ImageFont.load_default()
    text = "AC"
    bbox = d.textbbox((0, 0), text, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    d.text(((size - w) / 2 - bbox[0], (size - h) / 2 - bbox[1]), text, font=font, fill=INK)
    # small diamond accents
    for cx, cy in [(size*0.5, size*0.2), (size*0.5, size*0.8)]:
        r = size * 0.02
        d.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)], fill=GOLD2)
    img.save(path, "PNG")
    print("saved", path, size)

make_icon(192, "/home/z/my-project/public/icon-192.png")
make_icon(512, "/home/z/my-project/public/icon-512.png")
make_icon(512, "/home/z/my-project/public/icon-maskable-512.png", maskable=True)
make_icon(180, "/home/z/my-project/public/apple-touch-icon.png")
