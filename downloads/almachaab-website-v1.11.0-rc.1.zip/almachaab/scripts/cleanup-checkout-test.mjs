import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const testOrders = await db.order.findMany({ where: { OR: [{ customerName: { in: ["E2E Testas", "M Testas"] } }, { phone: { in: ["+37066613055", "+37066613056"] } }] }, select: { id: true, number: true, customerName: true, status: true, paymentStatus: true, paymentMethod: true } });
console.log("Test orders found:", JSON.stringify(testOrders));
for (const o of testOrders) {
  await db.order.delete({ where: { id: o.id } });
}
// also any orphaned 'awaiting' orders created by PayPal failure attempts today with test-ish names
const orphans = await db.order.findMany({ where: { status: "awaiting" }, select: { id: true, number: true, customerName: true } });
console.log("Remaining awaiting:", JSON.stringify(orphans));
const counter = await db.setting.findUnique({ where: { key: "store" } });
console.log("Done. users:", await db.user.count(), "accounts:", await db.account.count());
await db.$disconnect();
