import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const adminCookie = process.argv[2];

// 1. Delete test orders via Prisma directly
const orders = await db.order.findMany({ where: { number: { in: ["AC-1042", "AC-1043"] } } });
for (const o of orders) {
  await db.order.delete({ where: { id: o.id } });
  console.log("deleted order", o.number);
}

// 2. Delete test user (cascades loyalty profile, transactions, redemptions, push subs)
const u = await db.user.findUnique({ where: { email: "e2e-loyalty@test.lt" } });
if (u) {
  await db.user.delete({ where: { id: u.id } });
  console.log("deleted user e2e-loyalty@test.lt (cascade: loyalty, voucher, subs)");
} else {
  console.log("test user not found");
}

// 3. Reset order counter back to 1042
const s = await db.setting.findUnique({ where: { key: "orders" } });
if (s) {
  const v = JSON.parse(s.value);
  v.nextNumber = 1042;
  await db.setting.update({ where: { key: "orders" }, data: { value: JSON.stringify(v) } });
  console.log("counter reset to AC-1042");
}

// 4. Verify clean state
const remOrders = await db.order.count();
const remUsers = await db.user.count();
const remProfiles = await db.loyaltyProfile.count();
const remRedemptions = await db.rewardRedemption.count();
const activeItems = await db.menuItem.count({ where: { inStock: false } });
console.log({ remOrders, remUsers, remProfiles, remRedemptions, soldOutItems: activeItems });

await db.$disconnect();
