/**
 * Seed the Alma Chaab database with content extracted from the prototype.
 * Run: bun scripts/seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { createHash, randomBytes } from "crypto";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const db = new PrismaClient();

function sha256(s: string) {
  return createHash("sha256").update(s).digest("hex");
}

// Portable path — works regardless of the working directory the seed is run from.
const here = dirname(fileURLToPath(import.meta.url));
const seedMenu = JSON.parse(readFileSync(join(here, "seed-data.json"), "utf-8")).menu;

const SETTINGS: Record<string, unknown> = {
  site: {
    name: "Alma Chaab",
    tagline: "Kėdainių senamiestis",
    phone: "+37066613055",
    phoneDisplay: "+370 666 13 055",
    email: "info@almachaab.lt",
    address: "Didžioji g. 25, Kėdainiai",
    woltUrl: "https://wolt.com/lt/ltu/kedainiai/restaurant/alma-chaab",
    mapsUrl:
      "https://www.google.com/maps/search/?api=1&query=Alma+Chaab+Did%C5%BEioji+g.+25+K%C4%97dainiai",
    facebookUrl: "https://www.facebook.com/restoranas.almachaab",
  },
  hours: {
    mon: null,
    tue: [12, 22],
    wed: [12, 22],
    thu: [12, 22],
    fri: [12, 22],
    sat: [11, 22],
    sun: [11, 20],
  },
  theme: {
    gold: "#b47b2d",
    gold2: "#d0a15f",
    cream: "#f8f2e9",
    cream2: "#fffaf2",
    paper: "#fffdf8",
    ink: "#241a13",
    muted: "#74665b",
    line: "#ded0bd",
    dark: "#35241a",
    radius: 24,
    fontHead: 'Georgia,"Times New Roman",serif',
    fontBody: 'Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
  },
  rating: {
    mode: "manual", // manual | hidden | auto
    score: 4.4,
    count: 161,
    placesApiKey: "",
    note: "161 Google atsiliepimas · dabartinis viešas įvertinimas",
  },
  email: {
    enabled: false,
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    user: "",
    pass: "",
    from: "",
    fromName: "Alma Chaab",
    notifyEmail: "",
  },
  orders: { prefix: "AC", nextNumber: 1042 },
  pickup: { enabled: true, leadMinutes: 30, slotMinutes: 30, maxDaysAhead: 7 },
  admin: { passwordHash: sha256("alma2026"), secret: randomBytes(24).toString("hex") },
};

const CONTENT = {
  hero: {
    mark: "Alma Chaab · Kėdainių senamiestis",
    titleLines: ["Libano šiluma.", "Skonis, kuris", "lieka atmintyje."],
    lead: "Artimųjų Rytų ir libanietiškos virtuvės skoniai Kėdainių senamiestyje — vakarienei, šeimos susitikimui ar stalui su iš anksto pasirinktais patiekalais.",
    mainCta: "Peržiūrėti meniu + rezervuoti",
    woltCta: "užsakyti pristatymą",
    serviceNote:
      "Pasirinkite patiekalus dar prieš atvykdami — jie keliaus kartu su jūsų staliuko rezervacija.",
    image: "/seed/proto-0.webp",
    chipsAddress: "⌖ Didžioji g. 25, Kėdainiai",
  },
  proof: {
    items: [
      { title: "Libanietiška · Viduržemio", sub: "Artimųjų Rytų virtuvės kryptis" },
      { title: "Šeimos restoranas", sub: "Kėdainių senamiestyje nuo 2025 m." },
      { title: "Meniu + stalas", sub: "Patiekalų pasirinkimas kartu su rezervacija" },
    ],
  },
  about: {
    title: "Langas į Libaną pačioje Kėdainių senamiesčio širdyje.",
    paragraphs: [
      "<strong>Alma Chaab</strong> – šeimos restoranas Didžiojoje g. 25, Kėdainiuose, kuriame Artimųjų Rytų ir libanietiškos virtuvės tradicijos pateikiamos šiuolaikiškai ir jaukiai. Čia rasite Tawook, Kafta, humusą, Fattoush, baklavą, žuvies ir mėsos patiekalus bei pasirinkimų šeimai.",
      "Ieškantiems <strong>kur pavalgyti Kėdainiuose</strong> ar norintiems atrasti <strong>libanietišką maistą Kėdainiuose</strong>, Alma Chaab siūlo kitokią patirtį – prieskonių, svetingumo ir dalijimosi prie bendro stalo kultūrą.",
      "Restoranas tinka pietums, vakarienei, šeimos susitikimams, degustacijoms ir privačioms progoms. Svetainėje galite ne tik rezervuoti stalelį, bet ir iš anksto pažymėti patiekalus ar užsisakyti atsiėmimui.",
    ],
    cta: "Atrasti meniu ir rezervuoti →",
    image: "/seed/proto-7.webp",
    caption1: "Didžioji g. 25",
    caption2: "Kėdainių senamiestis",
    stats: [
      { n: "37", label: "meniu pozicijos" },
      { n: "8", label: "meniu kategorijos" },
      { n: "1", label: "aiškus kelias iki stalo" },
    ],
  },
  ribbon: [
    { src: "/seed/proto-1.jpeg", caption: "Kėdainių senamiestyje" },
    { src: "/seed/proto-2.jpeg", caption: "Alma Chaab atmosfera" },
    { src: "/seed/proto-3.jpeg", caption: "Skoniai dalijimuisi" },
  ],
  social: {
    eyebrow: "Svečiai apie Alma Chaab",
    title: "Pasitikėjimas prieš paspaudžiant „rezervuoti“.",
    quote:
      "Viešuose atsiliepimuose svečiai mini jaukią aplinką, Levanto skonius, malonų aptarnavimą ir ramų apsilankymą.",
    note: "Viešų Google ir Tripadvisor atsiliepimų temų santrauka · duomenys gali keistis.",
    mapsLink: "Peržiūrėti Google Maps →",
    scoreNote:
      "viešas Google atsiliepimas. Socialinis įrodymas rodomas šalia rezervacijos kelio, o ne paslėptas puslapio apačioje.",
  },
  hub: {
    eyebrow: "Atraskite daugiau",
    title: "Visa kita — tik kai norite",
    sub: "Šios skiltys pagal nutylėjimą yra suskleistos. Pasirinkite vieną ir ji atsivers pilnu pločiu.",
    cards: [
      { id: "skoniai", icon: "✦", title: "Mūsų skoniai", sub: "Populiariausi patiekalai" },
      { id: "degustacijos", icon: "❧", title: "Degustacijos", sub: "Teminiai skonių vakarai ir patirtys" },
      { id: "renginiai", icon: "♟", title: "Šventės ir renginiai", sub: "Šeimos ir įmonių progoms" },
      { id: "galerija", icon: "◫", title: "Galerija", sub: "Alma Chaab atmosfera" },
      { id: "straipsniai", icon: "⌁", title: "Straipsniai", sub: "SEO ir istorijos" },
    ],
  },
  skoniai: {
    eyebrow: "Mūsų skoniai",
    title: "Atraskite mėgstamus patiekalus",
    link: "Peržiūrėti visą meniu →",
    features: [
      { img: "/seed/proto-4.jpeg", title: "Humusas", text: "Kreminis, aromatingas ir puikiai tinkantis dalintis.", price: "nuo €5.80" },
      { img: "/seed/proto-5.jpeg", title: "Kafta ir grilis", text: "Sodrūs Artimųjų Rytų prieskoniai ir sotūs pagrindiniai patiekalai.", price: "nuo €15.30" },
      { img: "/seed/proto-6.jpeg", title: "Užkandžiai dalintis", text: "Spalvingas pasirinkimas ilgesniam vakarui prie bendro stalo.", price: "nuo €5.80" },
    ],
  },
  degustacijos: {
    eyebrow: "Alma Chaab istorija",
    title: "Šeimos virtuvė, sukurta būti kartu",
    intro:
      "Kėdainių senamiesčio namuose susitinka Libano ir Artimųjų Rytų įkvėpti receptai, dalinimosi kultūra ir jaukus vakaras. Svetainėje akcentuojame ne tik maistą, bet ir patirtį — degustacijas, šeimos šventes bei susitikimus.",
    stats: [
      { n: "37", label: "meniu pozicijos" },
      { n: "8", label: "kategorijos" },
      { n: "2", label: "švenčių erdvės" },
    ],
    image: "/seed/proto-7.webp",
  },
  events: {
    eyebrow: "Šventės ir renginiai",
    title: "Vieta progoms, kurios lieka atmintyje",
    intro:
      "Privačios vakarienės, šeimos šventės, įmonių vakarai, degustacijos ar biliardo vakaras — Alma Chaab galima rinktis ne tik vakarienei, bet ir laikui kartu.",
    billiards: {
      kicker: "Rugsėjo pasiūlymas",
      title: "Visą rugsėjį biliardas – tik 5 € / val.",
      text: "Mokslo metų pradžią kviečiame švęsti ne tik prie stalo. Rinkitės iš dviejų skirtingų biliardo stalų ir surenkite draugišką turnyrą šeimai, klasei ar draugų kompanijai.",
      options: [
        { icon: "🎱", name: "POOL", sub: "Klasikinis biliardo stalas" },
        { icon: "🎱", name: "Rusiškas / Piramidė", sub: "Kitokiam žaidimo vakarui" },
      ],
      meta: ["⏰ Žaisti galima iki 20:00", "👥 Galima rezervuoti abu stalus", "📍 Didžioji g. 25, Kėdainiai"],
      priceSmall: "1 valanda",
      price: "5 €",
      priceNote: "visą rugsėjį",
      cta: "Rezervuoti biliardą →",
      phone: "☎ +370 666 13 055",
    },
  },
  gallery: {
    eyebrow: "Galerija",
    title: "Alma Chaab atmosfera",
    images: [
      { src: "/seed/proto-1.jpeg", caption: "Kėdainių senamiestyje" },
      { src: "/seed/proto-10.jpeg", caption: "Dalintis prie stalo" },
      { src: "/seed/proto-11.jpeg", caption: "Ryškūs skoniai" },
      { src: "/seed/proto-12.webp", caption: "Vakaro pradžia" },
    ],
  },
  menuIntro: {
    eyebrow: "Meniu ir rezervacija",
    title: "Vienoje vietoje — meniu, išankstinis pasirinkimas ir staliukas.",
    sub: "Pasirinkite, kaip norite mėgautis Alma Chaab: rezervuokite stalelį su iš anksto pasirinktais patiekalais arba užsisakykite atsiėmimui restorane.",
  },
  flow: {
    reserveTitle: "Staliuko rezervacija",
    reserveSub: "Iš anksto pasirinkite patiekalus ir atvykite prie paruošto stalo. Rezervuoti galima ir be pasirinkimo.",
    pickupTitle: "Atsiėmimui restorane",
    pickupSub: "Užsisakykite iš anksto ir atsiimkite be laukimo — be staliuko rezervacijos.",
  },
  wolt: {
    badge: "W · pristatymas atskirai",
    eyebrow: "Kai norisi Alma Chaab namuose",
    title: "Pristatymas lieka paprastas – per Wolt.",
    text: "Svetainės krepšelis skirtas staliuko rezervacijai, išankstiniam pasirinkimui ir atsiėmimui restorane. Pristatymui paliekame vieną aiškų kelią – oficialų Alma Chaab Wolt puslapį.",
  },
  contacts: {
    eyebrow: "Kontaktai",
    title: "Susisiekite su Alma Chaab",
    reservationLink: "Atidaryti meniu ir rezervaciją →",
  },
  footer: {
    about: "Artimųjų Rytų ir libanietiškos virtuvės skoniai Kėdainių senamiestyje.",
    copyright: "Alma Chaab · Kėdainių senamiestis",
  },
  reservation: {
    help: "Patvirtinkite kontaktus. Jei pasirinkote patiekalus, jų santrauka bus rodoma žemiau.",
    successTitle: "Rezervacijos užklausa gauta",
    successSub: "Per trumpą laiką susisieksime patvirtinti rezervacijos.",
  },
  pickup: {
    help: "Užpildykite kontaktus ir pasirinkite atsiėmimo laiką.",
    successTitle: "Užsakymas gautas. Laukiama patvirtinimo.",
    successSub: "Perspėsime, kai užsakymas bus patvirtintas ir paruoštas.",
  },
};

async function main() {
  console.log("Seeding settings...");
  for (const [key, value] of Object.entries(SETTINGS)) {
    await db.setting.upsert({
      where: { key },
      update: { value: JSON.stringify(value) },
      create: { key, value: JSON.stringify(value) },
    });
  }
  await db.setting.upsert({
    where: { key: "content" },
    update: {},
    create: { key: "content", value: JSON.stringify(CONTENT) },
  });

  const existing = await db.category.count();
  if (existing === 0) {
    console.log("Seeding menu:", seedMenu.length, "categories");
    for (let ci = 0; ci < seedMenu.length; ci++) {
      const cat = seedMenu[ci];
      const dbCat = await db.category.create({
        data: { id: cat.id, name: cat.name, sortOrder: ci },
      });
      for (let ii = 0; ii < cat.items.length; ii++) {
        const it = cat.items[ii];
        await db.menuItem.create({
          data: {
            id: it.id,
            categoryId: dbCat.id,
            name: it.name,
            price: it.price,
            image: it.image || "",
            description: "",
            sortOrder: ii,
          },
        });
      }
    }
  } else {
    console.log("Menu already seeded,", existing, "categories");
  }
  console.log("Seed done.");
}

main().finally(() => db.$disconnect());
