// Seeds 6 SEO articles covering the Kėdainiai restaurant keyword clusters.
// Usage: bun scripts/seed-keyword-articles.mjs
import { PrismaClient } from "@prisma/client";

const p = new PrismaClient();

function slugify(s) {
  const map = { ą: "a", č: "c", ę: "e", ė: "e", į: "i", š: "s", ų: "u", ū: "u", ž: "z" };
  return s.toLowerCase().replace(/[ąčęėįšųūž]/g, (m) => map[m]).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

const articles = [
  {
    title: "Kur pavalgyti Kėdainiuose? Libano skoniai senamiestyje",
    excerpt:
      "Ieškote, kur pavalgyti Kėdainiuose? Alma Chaab — libaniškos virtuvės restoranas Didžiojoje g. 25: meze užkandžiai, grilio patiekalai, naminiai desertai ir rami senamiesčio atmosfera.",
    keywords:
      "kur pavalgyti Kėdainiuose, restoranai Kėdainiuose, kur valgyti Kėdainiuose, restoranas Kėdainių senamiestyje, pietūs Kėdainiuose",
    body: [
      { t: "p", text: "Kėdainiai gali pasigirti vienu geriausiai išsilaikiusių senamiesčių Lietuvoje, o jo širdyje, Didžiojoje gatvėje, veikia libaniškos virtuvės restoranas Alma Chaab. Jei klausiate savęs, kur pavalgyti Kėdainiuose — ar tai būtų pietūs per pietų pertrauką, vakarienė su šeima ar susitikimas su draugais — čia rasite atsakymą, kuris skiriasi nuo įprastų pasirinkimų." },
      { t: "h", text: "Kuo libaniška virtuvė skiriasi?" },
      { t: "p", text: "Libano virtuvė grindžiama dalijimusi: stalelį užima keli meze užkandžiai — kreminis humusas, rūkytas baba ganoush, žolelių turintys tabbouleh ir falafelis — o tada seka grilio patiekalai: vištienos šiš taviukas, jautienos kofta kebabai su česnakinį skonį primenančiu toum padažu. Visi patiekalai ruošiami iš šviežių produktų, o prieskoniai — kmynai, koriandras, sumachas — suteikia gilumo be aštrumo." },
      { t: "p", text: "Vegetarams ir veganams tai vienas patogiausių pasirinkimų Kėdainiuose: dauguma meze užkandžių yra augalinės kilmės, o virtuvė lengvai pritaiko patiekalus pagal poreikius." },
      { t: "h", text: "Kur mus rasti?" },
      { t: "p", text: "Alma Chaab — Didžioji g. 25, Kėdainių senamiestis. Stalelį galite rezervuoti internetu per mūsų svetainę, o maistą išsinešimui užsisakyti keliais paspaudimais. Laukiame jūsų!" },
    ],
  },
  {
    title: "Pietūs Kėdainiuose: greita, sveika ir skoninga pietų pertrauka",
    excerpt:
      "Dienos pietūs Kėdainiuose be skubos: libaniškos lėkštės su humusu, griliu ir salotomis. Papasakojame, kodėl Pietų Vidurio Rytų virtuvė puikiai tinka pietų pertraukai.",
    keywords:
      "pietūs Kėdainiuose, dienos pietūs Kėdainiuose, pietų pertrauka Kėdainiuose, kur pavalgyti pietus Kėdainiuose",
    body: [
      { t: "p", text: "Pietų pertrauka Kėdainiuose nebūtinai turi reikšti greitą maistą iš vokelio. Alma Chaab siūlo subalansuotas libaniškas lėkštes: humusas su alyvuogių aliejumi, mėsingas ar vegetariškas grilio pasirinkimas, šviežios salotos ir šiltos trapnos duonos gabalėlis. Tai maistas, po kurio nevena skubėti grįžti prie darbo — jis suteikia energijos antrai dienos pusei." },
      { t: "h", text: "Kodėl meze staliukas — puikus pietų pasirinkimas" },
      { t: "p", text: "Meze principas leidžia paragauti kelių skirtingų skonių vieno vizito metu. Porai ar kolegų būriui užtenka 3–4 užkandžių ir vieno grilio patiekalo pasidalyti. Pietūs tampa mažu renginiu, o ne formalybe." },
      { t: "h", text: "Rezervuokite iš anksto" },
      { t: "p", text: "Pietų valandomis (12–14 val.) staleliai užpildomi greitai. Rezervuokite internetu — užtruksite ne ilgiau minutės, o stalelis jūsų lauks." },
    ],
  },
  {
    title: "Romantiška vakarienė Kėdainiuose: vakaras senamiestyje",
    excerpt:
      "Planuojate romantišką vakarienę Kėdainiuose? Užkandžiai dviem, žvakutės, Libano vynai ir naminiai desertai — Alma Chaab senamiestyje kuria vakarą, kuris primena pertvarą nuo kasdienybės.",
    keywords:
      "romantiška vakarienė Kėdainiuose, vakarienė Kėdainiuose, kur paminėti pasimatymą Kėdainiuose, vakarienė dviem Kėdainiai",
    body: [
      { t: "p", text: "Romantiškai vakarienei Kėdainiuose reikia trijų dalykų: jaukios aplinkos, maisto, kurį norisi ragauti lėtai, ir laiko. Alma Chaab senamiesčio kvartale siūlo viską: švelnią vakarinę šviesą, meze lėkštes dviem, grilio patiekalus ir naminius desertus su arbatomis." },
      { t: "h", text: "Ką rinktis vakarienei dviem" },
      { t: "p", text: "Rekomenduojame pradėti nuo meze rinkinio (hummusas, baba ganoush, tabbouleh), tęsti grilio lėkšte dviem ir užbaigti naminiu desertu. Libano arbata su apelsinų žiedų vandeniu — gražus taškas vakaro pabaigoje." },
      { t: "h", text: "Rezervacija — vienas paspaudimas" },
      { t: "p", text: "Vakarinėms valandoms (18–21 val.) stalelius rekomenduojame rezervuoti iš anksto, ypač penktadieniais ir šeštadieniais. Internetinė rezervacija užtrunka minutę." },
    ],
  },
  {
    title: "Banketai ir šventės Kėdainiuose: nuo gimtadienio iki vestuvių",
    excerpt:
      "Rengiate banketą Kėdainiuose? Alma Chaab tinka iki 80 svečių: gimtadieniai, jubiliejai, vestuvių banketai ir verslo pietūs su iš anksto suderintu libanišku meniu.",
    keywords:
      "banketas Kėdainiuose, šventės Kėdainiuose, kur švęsti gimtadienį Kėdainiuose, vestuvių banketas Kėdainiai, verslo pietūs Kėdainiuose",
    body: [
      { t: "p", text: "Šventės organizavimas prasideda nuo vietos ir meniu. Alma Chaab salė tinka iki 80 svečių banketams: gimtadieniams, jubiliejams, krikštynomoms, vestuvių pobūviams ir verslo pietūs. Libaniška virtuvė puikiai tinka šventėms, nes dalijimosi stalas natūraliai suartina žmones." },
      { t: "h", text: "Kaip vyksta banketo organizavimas" },
      { t: "p", text: "Pirmiausia susitinkame dėl datos ir svečių skaičiaus, tada sudarome meniu: galime pasiūlyti visą meze stalą, grilio lėkštes, desertus ir gėrimus. Visi patiekalai derinami iš anksto — šventės dieną jūs rūpinatės tik svečiais." },
      { t: "h", text: "Verslo pietūs ir susitikimai" },
      { t: "p", text: "Verslo renginiams siūlome greitesnį formatą: suderintą meniu su keliais pasirinkimais ir aptarnavimu pagal jūsų laiko planą. Susisiekite telefonu +370 666 13055 — padėsime susiplanuoti." },
    ],
  },
  {
    title: "Maistas išsinešimui Kėdainiuose: užsisakykite internetu per minutes",
    excerpt:
      "Alma Chaab maistas išsinešimui Kėdainiuose: užsisakykite internetu, pasirinkite atsiėmimo laiką ir sekite paruošimą realiu laiku. Humusas, grilio patiekalai ir desertai — namuose per 20–30 minučių.",
    keywords:
      "maistas išsinešimui Kėdainiuose, išsinešti maistą Kėdainiai, užsisakyti maisto Kėdainiuose, maistas namams Kėdainiai",
    body: [
      { t: "p", text: "Kartą norisi gerai pavalgyti, bet nenorima niekur eiti. Alma Chaab maistas išsinešimui veikia taip: pasirinkite patiekalus svetainėje, nurodykite atsiėmimo laiką ir atvykstate — užsakymas jau paruoštas. O jei norite žinoti tiksliai kada ateiti — užsakymo būseną galite sekti realiu laiku puslapyje „Sekti užsakymą“." },
      { t: "h", text: "Kas geriausiai tinka išsinešimui" },
      { t: "p", text: "Meze užkandžiai (hummusas, baba ganoush) keliauja puikiai, grilio patiekalai išlieka sultingi, o šiltos duonos rekomenduojame atsiimti paskutinę minutę. Deserto siūlome naminius variantus — jie atlaiko kelionę namo be nuostolių." },
      { t: "h", text: "Atsiėmimo laikas pagal darbo valandas" },
      { t: "p", text: "Užsakymus priimame visomis darbo valandomis. Pasirinkite laiką, kuris jums patogus — virtuvė paruoš iki jo, o jūs sutaupysite laiko." },
    ],
  },
  {
    title: "Libanietiškas restoranas Kėdainiuose: kas tai reiškia jūsų lėkštėje",
    excerpt:
      "Kuo libanietiškas restoranas skiriasi nuo kitų? Alma Chaab pasakoja apie Libano virtuvės tradicijas: meze, grilį, prieskonius ir tai, kodėl šis skonis stiprėja kiekvieną kartą grįžtant.",
    keywords:
      "libanietiškas restoranas Kėdainiuose, Libano virtuvė Kėdainiai, artimųjų rytų virtuvė Kėdainiuose, humusas Kėdainiai, geriausi restoranai Kėdainiuose",
    body: [
      { t: "p", text: "Libanietiškas restoranas Kėdainiuose — dar prieš kelerius metus tai skambėtų kaip neįgyvendinama svajonė. Šiandien Alma Chaab Didžiojoje g. 25 atveria Libano virtuvės pasaulį: nuo kreminio humuso iki žarijose keptų grilio patiekalų." },
      { t: "h", text: "Meze — dalijimosi kultūra" },
      { t: "p", text: "Libano virtuvės širdis — meze: daugybė mažų lėkščių, kuriomis dalijamasi. Humusas su alyvuogių aliejumi, rūkytas baklažanų baba ganoush, žalias tabbouleh, traškus falafelis. Kiekviena lėkštė — naujas skonis, o stalas nuolat juda." },
      { t: "h", text: "Prieskoniai be aštrumo" },
      { t: "p", text: "Daugelis bijo, kad Artimųjų Rytų virtuvė — per aštri. Libano virtuvė kitokia: kmynai, koriandras, cinamonas ir sumachas suteikia gilumo, o ne deginimo. Todėl tai puikus pasirinkimas ir šeimoms su vaikais." },
      { t: "h", text: "Ateikite paragauti" },
      { t: "p", text: "Esame Didžiojoje g. 25, Kėdainių senamiestyje. Rezervuokite stalelį arba užsisakykite išsinešimui — ir leiskite Libano skoniams kalbėti patiems." },
    ],
  },
];

for (const a of articles) {
  const slug = slugify(a.title);
  const existing = await p.article.findUnique({ where: { slug } });
  if (existing) {
    console.log("skip (exists):", slug);
    continue;
  }
  await p.article.create({
    data: {
      slug,
      title: a.title,
      excerpt: a.excerpt,
      keywords: a.keywords,
      coverImage: "/seed/proto-7.webp",
      bodyJson: JSON.stringify(a.body),
      published: true,
      publishedAt: new Date(),
    },
  });
  console.log("created:", slug);
}

await p.$disconnect();
console.log("done");
