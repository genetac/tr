// Inspect admin + settings rows in the SQLite DB via Prisma
process.env.DATABASE_URL = process.env.DATABASE_URL || "file:/home/z/my-project/db/custom.db";
import { createHash } from "crypto";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const hash = (pw) => createHash("sha256").update("alma:" + pw).digest("hex");

const rows = await db.setting.findMany();
console.log("=== Setting rows ===");
for (const r of rows) {
  const v = r.value.length > 300 ? r.value.slice(0, 300) + "..." : r.value;
  console.log(`[${r.key}] ${v}`);
}

const adminRow = rows.find((r) => r.key === "admin");
if (adminRow) {
  const parsed = JSON.parse(adminRow.value);
  console.log("\n=== Admin check ===");
  console.log("stored hash:", parsed.passwordHash);
  console.log("hash('alma2026'):", hash("alma2026"));
  console.log("MATCH alma2026:", parsed.passwordHash === hash("alma2026"));
  console.log("secret:", parsed.secret);
} else {
  console.log("\n!!! NO 'admin' row in Setting table — no password can ever match");
}

const orderCount = await db.order.count();
const mediaCount = await db.media.count();
console.log("\norders:", orderCount, "media:", mediaCount);
await db.$disconnect();
