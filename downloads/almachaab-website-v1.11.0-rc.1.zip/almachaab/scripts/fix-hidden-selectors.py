#!/usr/bin/env python3
"""Repair corrupted [hidden] CSS selectors.

Somewhere along the way every `[hidden]` attribute selector in site.css and
site-scoped.css lost its `[h` — e.g. `.checkout-pane[hidden]` became
`.checkout-paneidden]`, so none of those rules ever matched. Elements without
an explicit display rule still hid via the UA stylesheet, but any element with
an explicit `display:` (grid/flex/…) would leak through when `hidden` was set.

Fix: wherever `idden]` is immediately preceded by an identifier character
(a correct `[hidden]` is preceded by `[`), re-insert `[h`.
"""
import re

FILES = [
    "/home/z/my-project/src/app/site.css",
    "/home/z/my-project/src/app/site-scoped.css",
]

for path in FILES:
    with open(path, encoding="utf-8") as f:
        src = f.read()
    fixed, n = re.subn(r"(?<=[\w-])idden\]", "[hidden]", src)
    if n:
        with open(path, "w", encoding="utf-8") as f:
            f.write(fixed)
    print(f"{path}: repaired {n} selector(s)")

# Verify: no corrupted occurrence remains, and the proper [hidden] count grew.
for path in FILES:
    with open(path, encoding="utf-8") as f:
        s = f.read()
    bad = re.findall(r"(?<=[\w-])idden\]", s)
    good = len(re.findall(r"\[hidden\]", s))
    print(f"{path}: corrupted left={len(bad)}, [hidden] now={good}")
