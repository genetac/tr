#!/usr/bin/env python3
"""Generate the 1200x630 OG cover image (public/images/og-cover.jpg)
from the hero photo + brand text overlay."""
from PIL import Image, ImageDraw, ImageFont
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "public", "seed", "proto-0.webp")
OUT_DIR = os.path.join(ROOT, "public", "images")
OUT = os.path.join(OUT_DIR, "og-cover.jpg")

W, H = 1200, 630
GOLD = (201, 162, 39)
CREAM = (240, 230, 210)
MUTED = (203, 185, 148)

os.makedirs(OUT_DIR, exist_ok=True)

# --- cover-crop the hero photo ---
img = Image.open(SRC).convert("RGB")
sw, sh = img.size
scale = max(W / sw, H / sh)
img = img.resize((round(sw * scale), round(sh * scale)), Image.LANCZOS)
left = (img.width - W) // 2
top = (img.height - H) // 2
img = img.crop((left, top, left + W, top + H))

# slight global tint so text pops
tint = Image.new("L", (W, H), 42)
img = Image.composite(Image.new("RGB", (W, H), (10, 8, 6)), img, tint)

# --- bottom gradient overlay ---
grad = Image.new("L", (1, H), 0)
for y in range(H):
    t = max(0.0, (y - H * 0.38) / (H * 0.62))  # starts at 38% height
    grad.putpixel((0, y), int(235 * (t ** 1.25)))
grad = grad.resize((W, H))
img = Image.composite(Image.new("RGB", (W, H), (12, 9, 6)), img, grad)

draw = ImageDraw.Draw(img)

F_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
F_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
f_title = ImageFont.truetype(F_BOLD, 96)
f_sub = ImageFont.truetype(F_REG, 34)
f_url = ImageFont.truetype(F_BOLD, 26)

x = 72
# gold accent bar
draw.rectangle([x, H - 268, x + 84, H - 260], fill=GOLD)
# title
draw.text((x, H - 236), "ALMA CHAAB", font=f_title, fill=(255, 252, 245))
# subtitle
draw.text((x, H - 122), "Libano virtuvės restoranas · Kėdainių senamiestis", font=f_sub, fill=CREAM)
# url
draw.text((x, H - 66), "almachaab.lt", font=f_url, fill=MUTED)

img.save(OUT, "JPEG", quality=86, optimize=True, progressive=True)
size_kb = os.path.getsize(OUT) / 1024
print(f"saved {OUT} ({size_kb:.0f} KB, {W}x{H})")
