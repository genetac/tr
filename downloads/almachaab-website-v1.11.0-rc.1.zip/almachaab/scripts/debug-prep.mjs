// Debug prepMinutes PATCH with retries (sandbox server can be mid-compile)
const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitUp() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + "/");
      if (r.ok) return true;
    } catch {}
    await sleep(1000);
  }
  return false;
}

async function j(method, path, body, token) {
  for (let a = 0; a < 3; a++) {
    try {
      const res = await fetch(BASE + path, {
        method,
        headers: { "Content-Type": "application/json", ...(token ? { "x-admin-token": token } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      return { status: res.status, json: await res.json().catch(() => ({})) };
    } catch {
      await sleep(1500);
    }
  }
  return { status: 0, json: {} };
}

if (!(await waitUp())) {
  console.log("server never came up");
  process.exit(1);
}

const login = await j("POST", "/api/admin/login", { password: "alma2026" });
const token = login.json.token;
console.log("login:", token ? "ok" : "FAIL " + JSON.stringify(login));

const ord = await j("POST", "/api/orders", { type: "pickup", customerName: "Debug Testas", phone: "+37060000002", items: [], pickupTime: "20:00" });
console.log("order:", JSON.stringify(ord.json));
const number = ord.json.number;

const list = await j("GET", "/api/admin/orders?status=new", null, token);
const row = (list.json.orders || []).find((o) => o.number === number);
console.log("found id:", row?.id);

const acc = await j("PATCH", `/api/admin/orders/${row.id}`, { status: "confirmed", prepMinutes: 25 }, token);
const o = acc.json.order || {};
console.log("PATCH →", JSON.stringify({ ok: acc.json.ok, status: o.status, prepMinutes: o.prepMinutes, prepSetAt: !!o.prepSetAt, err: acc.json.error }));

const tr = await j("GET", `/api/track/${number}`);
console.log("track →", JSON.stringify({ prepMinutes: tr.json.prepMinutes, readyAt: tr.json.readyAt, status: tr.json.status }));

// cleanup both debug orders
const all = await j("GET", "/api/admin/orders?status=all", null, token);
for (const row of all.json.orders || []) {
  if (row.customerName === "Debug Testas" || row.customerName === "Skydelis Testas") {
    await j("DELETE", `/api/admin/orders/${row.id}`, null, token);
  }
}
console.log("cleanup done");
