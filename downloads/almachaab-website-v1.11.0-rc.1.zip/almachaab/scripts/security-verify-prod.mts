/**
 * Security-verify (unit + prod-mode) for audit R1 (v1.9.1).
 * Covers SEC-001 (vault fails closed in production), SEC-004 (escapeHtml),
 * SEC-008 (VAPID encrypted at rest), SEC-017 (sanitiser).
 * Run: bunx tsx scripts/security-verify-prod.mts   (cwd = project root)
 */
let pass = 0, fail = 0;
const ok = (sec, name, cond, extra = "") => {
  if (cond) { pass++; console.log(`  ✓ [${sec}] ${name}`); }
  else { fail++; console.log(`  ✗ [${sec}] ${name} ${extra}`); }
};

async function main() {
  // ---------- SEC-004: escapeHtml / htmlSafeOrder ----------
  console.log("\nSEC-004 · email HTML escaping");
  const mail = await import("../src/lib/mail");
  ok("SEC-004", "escapeHtml exists", typeof mail.escapeHtml === "function");
  const esc = mail.escapeHtml(`<b>"&'"</b><script>alert(1)</script>`);
  ok("SEC-004", "< > & \" ' escaped", esc === "&lt;b&gt;&quot;&amp;&#39;&quot;&lt;/b&gt;&lt;script&gt;alert(1)&lt;/script&gt;", esc);
  const src = await import("fs").then((f) => f.readFileSync("src/lib/mail.ts", "utf8"));
  ok("SEC-004", "htmlSafeOrder escapes all customer fields", /\["number", "customerName", "phone", "email", "note", "experiences"/.test(src), "");
  ok("SEC-004", "both email builders use htmlSafeOrder", (src.match(/htmlSafeOrder\(/g) || []).length >= 3, "(definition + 2 call sites)");

  // ---------- SEC-017: sanitiser ----------
  console.log("\nSEC-017 · About-HTML sanitiser + theme cssValue");
  const { sanitizeInlineHtml, cssValue } = await import("../src/lib/sanitize");
  const dirty = `Sveiki <img src=x onerror="alert(1)"> <script>alert(2)</script><a href="javascript:alert(3)">x</a><a href="https://almachaab.lt" target="_blank">ok</a><b>bold</b> <i>i</i><br/>`;
  const clean = sanitizeInlineHtml(dirty);
  ok("SEC-017", "img stripped", !clean.includes("<img"));
  ok("SEC-017", "script stripped", !clean.includes("<script"));
  ok("SEC-017", "onerror gone", !clean.includes("onerror"));
  ok("SEC-017", "javascript: href gone", !/javascript:/i.test(clean));
  ok("SEC-017", "allowed tags + safe link kept", clean.includes("<b>bold</b>") && clean.includes('href="https://almachaab.lt"'), clean);
  ok("SEC-017", "cssValue rejects injection", !cssValue("red; background:url(javascript:alert(1)); position:fixed", "#fff").includes(";"), cssValue("red; background:url(x); position:fixed", "#fff"));
  ok("SEC-017", "cssValue accepts a colour", cssValue("#a0522d", "#fff") === "#a0522d");

  // ---------- SEC-008: VAPID encrypted at rest ----------
  console.log("\nSEC-008 · VAPID key encrypted at rest");
  const { setSetting, getSettings } = await import("../src/lib/settings");
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient();
  const vapidSnap = await db.setting.findUnique({ where: { key: "vapid" } });
  try {
    await setSetting("vapid", { publicKey: "test-pub", privateKey: "vapid-private-verify-123" } as any);
    const row = await db.setting.findUnique({ where: { key: "vapid" } });
    ok("SEC-008", "privateKey stored as enc:v1 ciphertext", (row?.value || "").includes("enc:v1:") && !String(row?.value).includes("vapid-private-verify-123"), String(row?.value).slice(0, 60));
    // Reader is push.ts ensureVapid() which decrypts — verify the same round-trip here.
    const { decryptSecret } = await import("/home/z/my-project/src/lib/vault");
    const raw = JSON.parse((await db.setting.findUnique({ where: { key: "vapid" } }))?.value || "{}");
    ok("SEC-008", "decrypts back to the plaintext on read (as push.ts does)", decryptSecret(raw.privateKey) === "vapid-private-verify-123");
  } finally {
    if (vapidSnap) await db.setting.upsert({ where: { key: "vapid" }, create: { key: "vapid", value: vapidSnap.value }, update: { value: vapidSnap.value } });
    else await db.setting.deleteMany({ where: { key: "vapid" } });
    await db.$disconnect();
  }

  // ---------- SEC-001: production vault fails closed ----------
  console.log("\nSEC-001 · production vault refuses to work without APP_SECRET_KEY");
  // Run a child process with NODE_ENV=production and no APP_SECRET_KEY.
  const { execSync } = await import("child_process");
  const probe = `import { encryptSecret, decryptSecret, VaultKeyMissingError } from "/home/z/my-project/src/lib/vault";
let threw = 0;
try { encryptSecret("x"); } catch (e) { threw += (e instanceof VaultKeyMissingError ? 1 : 0); }
try { decryptSecret("enc:v1:a:b:c"); } catch (e) { threw += (e instanceof VaultKeyMissingError ? 1 : 0); }
console.log("THREW:" + threw);`;
  const { writeFileSync, mkdtempSync } = await import("fs");
  const { tmpdir } = await import("os");
  const { join } = await import("path");
  const dir = mkdtempSync(join(tmpdir(), "secv-"));
  const probePath = join(dir, "probe.mts");
  writeFileSync(probePath, probe);
  let out = "";
  try {
    out = execSync(`cd /home/z/my-project && NODE_ENV=production bunx tsx ${probePath}`, {
      env: { ...process.env, NODE_ENV: "production", APP_SECRET_KEY: "" },
    }).toString();
  } catch (e: any) { out = e.stdout?.toString() || e.message; }
  ok("SEC-001", "encrypt+decrypt throw VaultKeyMissingError in production", out.includes("THREW:2"), out.slice(-120));

  // ---------- SEC-001: short/empty HMAC signing keys rejected ----------
  console.log("\nSEC-001 · sign() refuses short keys");
  const authSrc = await import("fs").then((f) => f.readFileSync("src/lib/auth.ts", "utf8"));
  ok("SEC-001", "auth.ts guards secret length < 32", /length < 32/.test(authSrc), "");
  const naSrc = await import("fs").then((f) => f.readFileSync("src/lib/nextauth-options.ts", "utf8"));
  ok("SEC-002", "no hard-coded NextAuth fallback secret in source", !naSrc.includes("alma-chaab-fallback-secret"), "");

  console.log(`\n════════ security-verify (unit/prod) ════════`);
  console.log(`   ${pass}/${pass + fail} checks passed, ${fail} failed`);
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => { console.error("suite error:", e); process.exit(1); });
