/**
 * Review fix #8 — stop hot-linking imageproxy.wolt.com.
 * Downloads every menu-item photo into the local uploads/ library, points
 * MenuItem.image at /api/files/<name> and registers it in the Media table.
 * Idempotent: items already served locally are skipped.
 */
import fs from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const UPLOAD_DIR = "/home/z/my-project/uploads";
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MIME = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/avif": ".avif" };

let ok = 0;
let failed = 0;

try {
  const items = await db.menuItem.findMany();
  for (const item of items) {
    const url = item.image || "";
    if (!url) continue;
    if (!/https?:\/\//.test(url)) { ok++; continue; } // already local
    if (!url.includes("imageproxy.wolt.com")) { console.log(`  ? external but not wolt: ${item.name}`); }
    try {
      const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (compatible; AlmaChaabSite/1.0)" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const mime = (res.headers.get("content-type") || "image/jpeg").split(";")[0].trim();
      const ext = MIME[mime] || ".jpg";
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 1024) throw new Error("suspiciously small file");
      const filename = `menu-${item.id}${ext}`;
      fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
      await db.menuItem.update({ where: { id: item.id }, data: { image: `/api/files/${filename}` } });
      await db.media.upsert({
        where: { filename },
        update: { size: buf.length, mime },
        create: { filename, mime, size: buf.length, title: item.name },
      });
      ok++;
      console.log(`  ✓ ${item.name} → ${filename} (${Math.round(buf.length / 1024)} KB)`);
    } catch (e) {
      failed++;
      console.log(`  ✗ ${item.name}: ${e.message}`);
    }
  }
  console.log(`\nDONE — imported: ${ok}, failed: ${failed}`);
  if (failed > 0) process.exitCode = 2;
} catch (e) {
  console.error("FAILED:", e);
  process.exit(1);
} finally {
  await db.$disconnect();
}
