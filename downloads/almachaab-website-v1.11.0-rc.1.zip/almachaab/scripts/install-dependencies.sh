#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
stage_dir=$(mktemp -d /tmp/almachaab-deps.XXXXXX)
trap 'rm -rf -- "$stage_dir"' EXIT
cd "$project_dir"
cp package.json "$stage_dir/package.json"
python3 - "$stage_dir" <<'PY'
from pathlib import Path
import sys
(Path(sys.argv[1])/'bun.lock').write_text(Path('bun.lock').read_text().replace('https://registry.npmjs.com/','https://registry.npmjs.org/'))
PY
"${BUN_BIN:-bun}" install --cwd "$stage_dir" --frozen-lockfile
mkdir -p node_modules
cp -a "$stage_dir/node_modules/." node_modules/
