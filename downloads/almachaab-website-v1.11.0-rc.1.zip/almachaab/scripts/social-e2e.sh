#!/bin/bash
# Social sign-in E2E: config, admin masking, NextAuth providers, Telegram HMAC, account linking
set -uo pipefail
B=http://localhost:3000
ADMIN="alma_admin=admin.1791735834510.a9f2e67e89b3173bbefb238a0c85457fe0a85f41cf7d0a9672b80fec91c18992"
PASS=0; FAIL=0
chk() { # chk <label> <expected> <actual>
  if [ "$2" == "$3" ]; then PASS=$((PASS+1)); echo "✓ $1";
  else FAIL=$((FAIL+1)); echo "✗ $1 — expected [$2] got [$3]"; fi
}
contains() { if echo "$3" | grep -q "$2"; then PASS=$((PASS+1)); echo "✓ $1"; else FAIL=$((FAIL+1)); echo "✗ $1 — missing [$2] in: $(echo "$3" | head -c 200)"; fi; }

echo "== 1. Initial social config (all disabled) =="
R=$(curl -s $B/api/auth/social-config)
chk "social-config reachable" "200" "$(curl -s -o /dev/null -w "%{http_code}" $B/api/auth/social-config)"
contains "all disabled initially" '"google":false' "$R"

echo "== 2. Admin settings: social masking round-trip =="
R=$(curl -s $B/api/admin/settings -H "Cookie: $ADMIN")
contains "GET returns googleEnabled flag" '"googleEnabled":false' "$R"
R=$(curl -s -X PUT $B/api/admin/settings -H "Cookie: $ADMIN" -H "Content-Type: application/json" \
  -d '{"key":"social","value":{"googleEnabled":true,"googleClientId":"test-google-id.apps.googleusercontent.com","googleClientSecret":"GOCSPX-testsecret123","facebookEnabled":true,"facebookClientId":"1234567890","facebookClientSecret":"fb-secret-abc","telegramEnabled":true,"telegramBotUsername":"almachaab_test_bot","telegramBotToken":"7654321:TEST-token-for-e2e"}}')
contains "PUT social ok" '"ok":true' "$R"
contains "PUT returns masked google secret" '"googleClientSecret":"••••t123"' "$R"
contains "PUT returns masked facebook secret" '"facebookClientSecret":"••••c-abc"' "$R"
contains "PUT returns masked telegram token" '"telegramBotToken":"••••-e2e"' "$R"
R=$(curl -s $B/api/admin/settings -H "Cookie: $ADMIN")
contains "GET masks google secret" '"googleClientSecret":"••••t123"' "$R"
contains "GET masks facebook secret" '"facebookClientSecret":"••••c-abc"' "$R"
contains "GET masks telegram token" '"telegramBotToken":"••••-e2e"' "$R"

echo "== 3. Social-config now reflects enabled providers =="
R=$(curl -s $B/api/auth/social-config)
contains "google public flag on" '"google":true' "$R"
contains "telegram public flag on" '"telegram":true' "$R"
contains "telegram bot name exposed" '"telegramBot":"almachaab_test_bot"' "$R"
if echo "$R" | grep -q "TEST-token\|GOCSPX"; then FAIL=$((FAIL+1)); echo "✗ secrets leaked in public config"; else PASS=$((PASS+1)); echo "✓ no secrets in public config"; fi

echo "== 4. NextAuth providers list =="
R=$(curl -s $B/api/auth/providers)
contains "google provider configured" '"google"' "$R"
contains "facebook provider configured" '"facebook"' "$R"
contains "google callback url" 'api/auth/callback/google' "$R"

echo "== 5. OAuth authorize redirect (POST + CSRF, to gateway boundary) =="
CSRF=$(curl -s -c /tmp/csrf.txt $B/api/auth/csrf | python3 -c "import json,sys; print(json.load(sys.stdin)['csrfToken'])")
LOC=$(curl -s -b /tmp/csrf.txt -o /dev/null -w "%{redirect_url}" -X POST $B/api/auth/signin/google -H "Content-Type: application/x-www-form-urlencoded" -d "csrfToken=$CSRF&callbackUrl=$B/api/auth/social/bridge")
contains "google authorize URL" "accounts.google.com/o/oauth2" "$LOC"
contains "google redirect_uri" "api%2Fauth%2Fcallback%2Fgoogle" "$LOC"
LOC=$(curl -s -b /tmp/csrf.txt -o /dev/null -w "%{redirect_url}" -X POST $B/api/auth/signin/facebook -H "Content-Type: application/x-www-form-urlencoded" -d "csrfToken=$CSRF&callbackUrl=$B/api/auth/social/bridge")
contains "facebook authorize URL" "facebook.com" "$LOC"
contains "facebook redirect_uri" "api%2Fauth%2Fcallback%2Ffacebook" "$LOC"

echo "== 6. Telegram HMAC verification =="
# 6a. valid payload (signed with the stored test token)
PAYLOAD=$(node -e '
const { createHash, createHmac } = require("crypto");
const token = "7654321:TEST-token-for-e2e";
const data = { id: 555000111, first_name: "E2E", last_name: "Telegram", username: "e2e_tg", auth_date: Math.floor(Date.now()/1000) };
const dcs = Object.keys(data).sort().map(k => `${k}=${data[k]}`).join("\n");
const secret = createHash("sha256").update(token).digest();
data.hash = createHmac("sha256", secret).update(dcs).digest("hex");
process.stdout.write(JSON.stringify(data));
')
R=$(curl -s -c /tmp/tg-cookies.txt -X POST $B/api/auth/telegram -H "Content-Type: application/json" -d "$PAYLOAD")
contains "valid telegram payload accepted" '"ok":true' "$R"
contains "telegram user provisioned" 'tg-555000111@users.almachaab.lt' "$R"
contains "alma_user cookie issued" "alma_user" "$(cat /tmp/tg-cookies.txt)"

# 6b. tampered hash rejected
TAMPERED=$(echo "$PAYLOAD" | sed 's/"hash":"\([a-f0-9]\)/"hash":"0/')
R=$(curl -s -o /dev/null -w "%{http_code}" -X POST $B/api/auth/telegram -H "Content-Type: application/json" -d "$TAMPERED")
chk "tampered hash rejected (401)" "401" "$R"

# 6c. stale auth_date rejected (>24h)
STALE=$(node -e '
const { createHash, createHmac } = require("crypto");
const token = "7654321:TEST-token-for-e2e";
const data = { id: 555000111, first_name: "E2E", auth_date: Math.floor(Date.now()/1000) - 90000 };
const dcs = Object.keys(data).sort().map(k => `${k}=${data[k]}`).join("\n");
const secret = createHash("sha256").update(token).digest();
data.hash = createHmac("sha256", secret).update(dcs).digest("hex");
process.stdout.write(JSON.stringify(data));
')
R=$(curl -s -o /dev/null -w "%{http_code}" -X POST $B/api/auth/telegram -H "Content-Type: application/json" -d "$STALE")
chk "stale auth_date rejected (401)" "401" "$R"

# 6d. disabled provider rejected — tested later after clearing

echo "== 7. Bridge without session =="
R=$(curl -s -o /dev/null -w "%{http_code}" $B/api/auth/social/bridge)
chk "bridge redirects on missing session (307)" "307" "$R"

echo "== 8. Password login regression + social-only guard =="
# social-only user tries password login → friendly 409
R=$(curl -s -o /dev/null -w "%{http_code}" -X POST $B/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"tg-555000111@users.almachaab.lt","password":"whatever123"}')
chk "social-only password login blocked (409)" "409" "$R"
# normal register + login still works
R=$(curl -s -X POST $B/api/auth/register -H "Content-Type: application/json" \
  -d '{"email":"e2e-social-reg@test.lt","password":"Test12345!","name":"Reg Test"}')
contains "password register still works" '"ok":true' "$R"
R=$(curl -s -o /dev/null -w "%{http_code}" -X POST $B/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"e2e-social-reg@test.lt","password":"Test12345!"}')
chk "password login still works (200)" "200" "$R"

echo "== 9. DB-level account linking (email is the identity) =="
node -e '
const { PrismaClient } = require("@prisma/client");
(async () => {
  const db = new PrismaClient();
  const u = await db.user.findUnique({ where: { email: "e2e-social-reg@test.lt" } });
  if (!u) { console.log("LINK:FAIL no user"); process.exit(1); }
  const { upsertSocialUser } = await import("./scripts/social-e2e-helper.mjs");
  await upsertSocialUser({ provider: "google", providerAccountId: "gg-123", email: u.email, name: "Reg Test" });
  const accounts = await db.account.findMany({ where: { userId: u.id } });
  const total = await db.user.count({ where: { email: u.email } });
  console.log(`LINK:${accounts.length === 1 && total === 1 && accounts[0].provider === "google" ? "OK" : "FAIL"} accounts=${accounts.length} users=${total}`);
  await db.$disconnect();
})();
' 2>&1 | grep "LINK:"

echo "== 10. Telegram user has loyalty profile =="
node -e '
const { PrismaClient } = require("@prisma/client");
(async () => {
  const db = new PrismaClient();
  const u = await db.user.findUnique({ where: { email: "tg-555000111@users.almachaab.lt" }, include: { loyalty: true, accounts: true } });
  const ok = u && u.loyalty && u.accounts.length === 1 && u.accounts[0].provider === "telegram";
  console.log(`TGPROFILE:${ok ? "OK" : "FAIL"} loyalty=${!!u?.loyalty} account=${u?.accounts[0]?.provider}`);
  await db.$disconnect();
})();
' 2>&1 | grep "TGPROFILE:"

echo
echo "RESULT: PASS=$PASS FAIL=$FAIL"
