/**
 * One-time migration — encrypt existing plaintext secrets in SQLite (review fix #4).
 * Idempotent: already-encrypted values (enc:v1:...) are left untouched.
 * Uses the same AES-256-GCM scheme as src/lib/vault.ts with APP_SECRET_KEY from .env.
 */
import fs from "node:fs";
import crypto from "node:crypto";
import { PrismaClient } from "@prisma/client";

const PREFIX = "enc:v1:";

function loadEnvKey() {
  const env = fs.readFileSync(new URL("../.env", import.meta.url), "utf8");
  const m = env.match(/^APP_SECRET_KEY=(\S+)/m);
  if (!m) {
    console.error("APP_SECRET_KEY missing in .env — refusing to migrate (secrets would use the fallback key).");
    process.exit(1);
  }
  return crypto.createHash("sha256").update(m[1]).digest();
}

const KEY = loadEnvKey();

function encrypt(plain) {
  if (!plain || plain.startsWith(PREFIX)) return plain;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const ct = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return PREFIX + [iv.toString("base64"), c.getAuthTag().toString("base64"), ct.toString("base64")].join(":");
}

const isEnc = (v) => typeof v === "string" && v.startsWith(PREFIX);

const STORE_SECRETS = ["stripeSecretKey", "stripeWebhookSecret", "paypalSecret", "googleClientSecret", "facebookClientSecret", "telegramBotToken", "turnstileSecretKey"];
const EMAIL_SECRETS = ["pass"];
const ADMIN_SECRETS = ["secret"];

const db = new PrismaClient();
let changed = 0;

try {
  // Store singleton (payment / social / turnstile secrets).
  const store = await db.settings.findUnique({ where: { id: "global" } });
  if (store) {
    const update = {};
    for (const k of STORE_SECRETS) {
      if (store[k] && !isEnc(store[k])) update[k] = encrypt(store[k]);
    }
    if (Object.keys(update).length) {
      await db.settings.update({ where: { id: "global" }, data: update });
      changed += Object.keys(update).length;
      console.log(`settings store: encrypted ${Object.keys(update).length} field(s)`);
    } else console.log("settings store: nothing to encrypt");
  }

  // KV settings rows (email.pass, admin.secret).
  for (const row of await db.setting.findMany({ where: { key: { in: ["email", "admin"] } } })) {
    const val = JSON.parse(row.value);
    const keys = row.key === "email" ? EMAIL_SECRETS : ADMIN_SECRETS;
    let touched = false;
    for (const k of keys) {
      if (val[k] && !isEnc(val[k])) {
        val[k] = encrypt(val[k]);
        touched = true;
      }
    }
    if (touched) {
      await db.setting.update({ where: { key: row.key }, data: { value: JSON.stringify(val) } });
      changed += 1;
      console.log(`setting "${row.key}": secrets encrypted`);
    } else console.log(`setting "${row.key}": nothing to encrypt`);
  }

  // Verify round-trip through the app's own decrypt (spot-check email row).
  const emailRow = await db.setting.findUnique({ where: { key: "email" } });
  if (emailRow) {
    const v = JSON.parse(emailRow.value);
    if (v.pass && v.pass.startsWith(PREFIX)) {
      const [ivB64, tagB64, ctB64] = v.pass.slice(PREFIX.length).split(":");
      const d = crypto.createDecipheriv("aes-256-gcm", KEY, Buffer.from(ivB64, "base64"));
      d.setAuthTag(Buffer.from(tagB64, "base64"));
      const out = Buffer.concat([d.update(Buffer.from(ctB64, "base64")), d.final()]).toString("utf8");
      console.log(`decrypt round-trip: ${out === v.passPlain ? "FAIL" : "OK"} (len ${out.length})`);
    }
  }
  console.log(changed ? `MIGRATION DONE — ${changed} record(s) updated.` : "NOTHING TO MIGRATE.");
} catch (e) {
  console.error("MIGRATION FAILED:", e);
  process.exit(1);
} finally {
  await db.$disconnect();
}
