/**
 * CRM win-back E2E — synthetic dormant customer (order 20 days old),
 * preview + campaign run + lastRun record + cleanup.
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const BASE = "http://localhost:3000";

const old = new Date(Date.now() - 20 * 86400000);

async function main() {
  // 1. Seed synthetic dormant customer with a 20-day-old completed order
  const user = await db.user.create({
    data: {
      email: `crm-e2e-${Date.now()}@test.lt`,
      name: "Senas Klientas",
      passwordHash: "x:y",
    },
  });
  await db.order.create({
    data: {
      number: "CRM-TEST-1",
      type: "pickup",
      status: "completed",
      customerName: "Senas Klientas",
      phone: "+37060000002",
      email: user.email,
      itemsJson: "[]",
      total: 25,
      userId: user.id,
      createdAt: old,
      updatedAt: old,
      historyJson: "[]",
    },
  });
  console.log("seeded dormant user + old order");

  // 2. Login admin
  const login = await fetch(`${BASE}/api/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password: "alma2026" }),
  }).then((r) => r.json());
  const H = { "x-admin-token": login.token, "Content-Type": "application/json" };

  // 3. Preview — must include the dormant customer, exclude fresh ones
  const preview = await fetch(`${BASE}/api/admin/crm/winback?days=14`, { headers: H }).then((r) => r.json());
  const found = preview.customers.find((c) => c.email === user.email);
  console.log(`preview: count=${preview.count}, dormant found=${found ? `yes (${found.daysSilent}d silent, hasPush=${found.hasPush})` : "NO"}`);
  if (!found) throw new Error("FAIL: dormant customer not in preview");

  // 4. Run campaign (both legs fire; no push sub + SMTP off → 0 sent but pipeline works)
  const run = await fetch(`${BASE}/api/admin/crm/winback`, {
    method: "POST",
    headers: H,
    body: JSON.stringify({ days: 14, sendEmail: true, sendPush: true }),
  }).then((r) => r.json());
  console.log(`campaign: targeted=${run.targeted}, pushSent=${run.pushSent}, emailsSent=${run.emailsSent}`);
  if (run.targeted < 1) throw new Error("FAIL: campaign targeted 0");

  // 5. lastRun recorded?
  const s = await db.setting.findUnique({ where: { key: "crmLastRun" } });
  console.log(`crmLastRun: ${s ? JSON.parse(s.value).at : "MISSING"}`);
  if (!s) throw new Error("FAIL: crmLastRun not recorded");

  // 6. Cron endpoint with bad secret
  const bad = await fetch(`${BASE}/api/cron/winback?secret=wrong`, { method: "POST" });
  console.log(`cron bad secret → ${bad.status} (want 401)`);
  if (bad.status !== 401) throw new Error("FAIL: cron secret bypass!");

  console.log("CRM E2E PASS");
}

main()
  .catch((e) => {
    console.error("CRM E2E FAIL:", e.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    // cleanup
    await db.order.deleteMany({ where: { number: "CRM-TEST-1" } });
    await db.user.deleteMany({ where: { email: { startsWith: "crm-e2e-" } } });
    await db.setting.deleteMany({ where: { key: "crmLastRun" } });
    console.log("cleaned up");
    await db.$disconnect();
  });
