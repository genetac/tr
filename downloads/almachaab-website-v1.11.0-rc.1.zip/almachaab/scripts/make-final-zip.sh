#!/bin/bash
# Build the final presentation zip for Alma Chaab website.
# Output: /home/z/my-project/download/almachaab-website-v1.0.zip
set -euo pipefail

SRC=/home/z/my-project
STAGE=/home/z/my-project/.zipstage
OUT=/home/z/my-project/download/almachaab-website-v1.0.zip

rm -rf "$STAGE"
mkdir -p "$STAGE/almachaab"
cd "$STAGE/almachaab"

# --- whitelist copy ---
cp -r "$SRC/src" src
cp -r "$SRC/prisma" prisma
mkdir -p db
cp "$SRC/db/custom.db" db/
cp -r "$SRC/public" public
mkdir -p scripts
for f in seed.ts seed-data.json seed-articles.mjs seed-keyword-articles.mjs seed-enterprise.mjs make_icons.py make_og.py inspect-db.mjs cleanup-e2e.mjs update-contact.mjs; do
  cp "$SRC/scripts/$f" scripts/
done
for f in package.json bun.lock tsconfig.json next.config.ts tailwind.config.ts \
         postcss.config.mjs eslint.config.mjs components.json Caddyfile \
         README.md DEPLOY.md .env .env.example .gitignore; do
  if [ -f "$SRC/$f" ]; then cp "$SRC/$f" ./; else echo "skip (missing): $f"; fi
done

# remove stray junk inside public
find public -name '*.zip' -delete 2>/dev/null || true
find . -name '.DS_Store' -delete 2>/dev/null || true

# --- build zip ---
mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"
cd "$STAGE"
zip -r -9 -q "$OUT" almachaab

# --- report ---
echo "=== zip created: $OUT ==="
ls -lh "$OUT"
echo "=== file count ==="
unzip -l "$OUT" | tail -1
echo "=== sanity: key files present ==="
ZIP_LISTING=$(unzip -l "$OUT")
for f in almachaab/src/components/admin/kitchen.css almachaab/src/components/admin/KitchenApp.tsx \
         almachaab/src/app/api/admin/kitchen/route.ts almachaab/public/images/og-cover.jpg \
         almachaab/DEPLOY.md almachaab/src/lib/schema.ts almachaab/scripts/seed-keyword-articles.mjs \
         almachaab/src/components/seo/JsonLd.tsx almachaab/src/components/site/icons.tsx \
         almachaab/scripts/update-contact.mjs \
         almachaab/src/app/virtuve/page.tsx almachaab/src/app/virtuve/VirtuveClient.tsx \
         almachaab/src/components/site/PayMarks.tsx almachaab/src/components/site/PayLaterBox.tsx; do
  grep -q " $f" <<< "$ZIP_LISTING" && echo "OK  $f" || echo "MISSING  $f"
done
rm -rf "$STAGE"
