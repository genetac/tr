#!/bin/bash
# Package the latest Alma Chaab website into download/almachaab-website-<version>.zip
# Review hardening: fails on any .zip/.db inside public/ (would be served publicly),
# runs tsc --noEmit before packaging, and ships the uploads/ media library.
set -e
cd /home/z/my-project
VERSION="${1:-v1.9}"
STAGE=.zipstage/almachaab

# --- Guard 1: no archives or databases in public/ (they'd be served as-is) ---
LEAKS=$(find public -maxdepth 3 \( -name '*.zip' -o -name '*.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.env*' \) 2>/dev/null || true)
if [ -n "$LEAKS" ]; then
  echo "RELEASE BLOCKED — sensitive files inside public/:" >&2
  echo "$LEAKS" >&2
  echo "Delete them (or move to uploads/ or db/) and re-run." >&2
  exit 1
fi

# --- Guard 2: type errors must not ship ---
npx tsc --noEmit
echo "tsc --noEmit: clean"

rm -rf "$STAGE"
mkdir -p "$STAGE"

# Root files (match previous release manifest). .env is NEVER shipped —
# real values must be created on the server (see DEPLOY.md §5 first-deploy);
# .env.example documents every variable name.
for f in .gitignore .env.example Caddyfile DEPLOY.md README.md bun.lock components.json \
         eslint.config.mjs next.config.ts package.json postcss.config.mjs \
         tailwind.config.ts tsconfig.json CHANGES-*.md; do
  cp "$f" "$STAGE/" 2>/dev/null || echo "skip missing: $f"
done

# Dirs — QA screenshots only live under scripts/, so the *.png exclude is
# scoped there (public/icon-*.png + apple-touch-icon.png MUST ship — the
# metadata icons reference them). DB backups / scratch files stay out.
rsync -a --exclude '*.log' db prisma public src uploads "$STAGE/"
rsync -a --exclude '*.png' --exclude '*.log' scripts "$STAGE/"
rm -f "$STAGE"/db/*.bak-* "$STAGE"/db/backup-articles-*.json
rm -f "$STAGE"/db/*.db-journal "$STAGE"/db/*.db-wal "$STAGE"/db/*.db-shm
# SEC-001/008: scrub install-specific secrets (admin HMAC secret, VAPID keys,
# provider secrets) from the STAGED copy — the working DB is left as-is.
DATABASE_URL="file:$PWD/$STAGE/db/custom.db" npx tsx scripts/prepare-release-db.mts

cd .zipstage
rm -f "../download/almachaab-website-$VERSION.zip"
zip -qr "../download/almachaab-website-$VERSION.zip" almachaab
cd ..
rm -rf "$STAGE"

echo "== packaged download/almachaab-website-$VERSION.zip =="
ls -lh "download/almachaab-website-$VERSION.zip"
unzip -l "download/almachaab-website-$VERSION.zip" | tail -3
