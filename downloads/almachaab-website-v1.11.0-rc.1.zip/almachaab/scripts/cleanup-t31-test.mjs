// Task 31 cleanup — remove PayPal E2E test orders, keep owner data intact.
// E2E markers: customerName "E2E PayPal Test" / "E2E Mobile PayPal",
// phones +37061100031 / +37061100032, paymentRef 9CY14020HT2906646.
process.env.DATABASE_URL = process.env.DATABASE_URL || "file:/home/z/my-project/db/custom.db";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const E2E_MARKERS = [
  { customerName: { startsWith: "E2E " } },
  { phone: { in: ["+37061100031", "+37061100032"] } },
];

const orders = await db.order.findMany({
  where: { OR: E2E_MARKERS },
  select: { id: true, number: true, customerName: true, paymentRef: true },
});

for (const o of orders) {
  await db.order.delete({ where: { id: o.id } });
  console.log("deleted order", o.number, `(${o.customerName}, ref=${o.paymentRef})`);
}

// Counter = (highest kept order number) + 1
const kept = await db.order.findMany({ select: { number: true } });
const maxNum = kept.reduce((m, o) => {
  const n = parseInt(String(o.number).replace(/^[A-Z]+-?/, ""), 10);
  return Number.isFinite(n) ? Math.max(m, n) : m;
}, 0);
const counter = await db.setting.findUnique({ where: { key: "orders" } });
const parsed = JSON.parse(counter?.value || "{}");
if (parsed.nextNumber !== maxNum + 1) {
  await db.setting.update({ where: { key: "orders" }, data: { value: JSON.stringify({ ...parsed, nextNumber: maxNum + 1 }) } });
}
console.log(`counter → next ${JSON.parse((await db.setting.findUnique({ where: { key: "orders" } })).value).nextNumber} (max kept AC-${maxNum})`);

console.log(`remaining — orders:${await db.order.count()} users:${await db.user.count()} accounts:${await db.account.count()}`);
const survivors = await db.order.findMany({ orderBy: { number: "desc" }, take: 6, select: { number: true, customerName: true, status: true, paymentStatus: true } });
console.log("kept orders:", JSON.stringify(survivors));
await db.$disconnect();
