#!/usr/bin/env python3
"""Authoritative check of [hidden] selector state — prints ONLY numbers/booleans
so no display layer can eat bracket sequences from the report."""
import re

FILES = [
    "/home/z/my-project/src/app/site.css",
    "/home/z/my-project/src/app/site-scoped.css",
]

def classify(s: str):
    correct = 0      # [hidden]  (char before 'hidden]' is 'h', char before that is '[')
    botched = 0      # [[hidden]] double bracket
    corrupt = 0      # Xidden] with a word char directly before 'idden]' that is not the h of [h
    corrupt_ctx = []
    for m in re.finditer(r"hidden\]", s):
        i = m.start()
        two_before = s[i - 2 : i]  # chars before 'h'
        if two_before.endswith("["):
            if i >= 3 and s[i - 3] == "[":
                botched += 1
            else:
                correct += 1
        else:
            ch = s[i - 1] if i >= 1 else ""
            if ch.isalnum() or ch in "_-":
                corrupt += 1
                corrupt_ctx.append(s[max(0, i - 40) : i + 12])
    return correct, botched, corrupt, corrupt_ctx

ok = True
for path in FILES:
    s = open(path, encoding="utf-8").read()
    correct, botched, corrupt, ctx = classify(s)
    print(f"{path.split('/')[-1]}: correct={correct} botched={botched} corrupt={corrupt}")
    for c in ctx[:12]:
        print("   CORRUPT:", ascii(c).replace("[", "LBRACKET"))
    if botched or corrupt:
        ok = False

# Same classification for the menu-browser-area selector specifically
for path in FILES:
    s = open(path, encoding="utf-8").read()
    needle = "menu-browser-area"
    i = s.find(needle)
    seg = s[i : i + 40]
    has_hidden_sel = seg.startswith("menu-browser-area[hidden]")
    print(f"{path.split('/')[-1]}: first menu-browser-area followed-by-[hidden]={has_hidden_sel}")

# Verify the two React edits are intact
ts1 = open("/home/z/my-project/src/components/site/MenuBrowser.tsx", encoding="utf-8").read()
ts2 = open("/home/z/my-project/src/components/site/AlmaSite.tsx", encoding="utf-8").read()
print("MenuBrowser has new hide logic:", 'mode !== "menu-reserve" && mode !== "menu-pickup"' in ts1)
print("MenuBrowser old logic gone:", 'mode === "done"' not in ts1.split("menu-browser-area")[1][:300] if "menu-browser-area" in ts1 else None)
print("AlmaSite goMenu always reserve-form:", "setMode(\"reserve-form\");\n    setPanel(null);" in ts2)
print("AlmaSite old preserved-mode ternary gone:", 'm === "menu-reserve" || m === "menu-pickup"' not in ts2)
print("ALL-OK" if ok else "NEEDS-MORE-WORK")
