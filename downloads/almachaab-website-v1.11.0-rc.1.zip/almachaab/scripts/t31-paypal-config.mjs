// Task 31 — PayPal sandbox credential configuration (Settings singleton, id="global")
// Usage:
//   node scripts/t31-paypal-config.mjs show
//   node scripts/t31-paypal-config.mjs set <clientId> <clientSecret>
process.env.DATABASE_URL = process.env.DATABASE_URL || "file:/home/z/my-project/db/custom.db";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const mask = (v) => (v ? `${v.slice(0, 6)}…${v.slice(-4)} (len ${v.length})` : "(empty)");

const row = await db.settings.findUnique({ where: { id: "global" } });

if (process.argv[2] === "set") {
  const clientId = process.argv[3] || "";
  const secret = process.argv[4] || "";
  if (!clientId || !secret) {
    console.error("set requires clientId + secret");
    process.exit(1);
  }
  await db.settings.upsert({
    where: { id: "global" },
    update: { paypalClientId: clientId, paypalSecret: secret, paypalSandbox: true },
    create: { id: "global", paypalClientId: clientId, paypalSecret: secret, paypalSandbox: true },
  });
  console.log("UPDATED Settings.global → paypalClientId/paypalSecret set, paypalSandbox=true");
} else {
  console.log("=== Current Settings.global (payments) ===");
  console.log("paypalClientId:", mask(row?.paypalClientId));
  console.log("paypalSecret:  ", mask(row?.paypalSecret));
  console.log("paypalSandbox: ", row?.paypalSandbox);
  console.log("stripePublicKey:", mask(row?.stripePublicKey));
  console.log("stripeSecretKey:", mask(row?.stripeSecretKey));
}

const orderRow = await db.setting.findUnique({ where: { key: "orders" } });
console.log("orders counter:", orderRow?.value);
console.log("order rows:", await db.order.count(), " users:", await db.user.count(), " accounts:", await db.account.count());
const last = await db.order.findMany({ orderBy: { id: "desc" }, take: 3, select: { number: true, status: true, paymentStatus: true, paymentMethod: true, total: true, customerName: true } });
console.log("last 3 orders:", JSON.stringify(last, null, 1));
await db.$disconnect();
