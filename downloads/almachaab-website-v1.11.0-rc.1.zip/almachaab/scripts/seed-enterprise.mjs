/**
 * Enterprise suite seed — idempotent, safe to re-run:
 *  - default Location (Alma Chaab — Kėdainiai) so multi-branch pricing works
 *  - loyalty program config (Setting key "loyalty")
 *  - starter rewards catalog
 * Run: bun scripts/seed-enterprise.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const REWARDS = [
  { name: "Nemokamas gėrimas", description: "Pasirinktas gėrimas iš meniu — dovanų", pointsCost: 30, sortOrder: 0 },
  { name: "Nemokamas desertas", description: "Bet kuris desertas iš meniu", pointsCost: 50, sortOrder: 1 },
  { name: "Hummus su duona", description: "Dovanų užkandis dalijimuisi", pointsCost: 70, sortOrder: 2 },
  { name: "10 € nuolaida", description: "Nuolaida kitam užsakymui atsiėmimo metu", pointsCost: 100, sortOrder: 3 },
  { name: "Pietų meniu dviem", description: "Pagrindinis patiekalas + gėrimas dviem asmenims", pointsCost: 220, sortOrder: 4 },
];

async function main() {
  // --- Default location ---
  const existingDefault = await db.location.findFirst({ where: { isDefault: true } });
  if (!existingDefault) {
    const anyLoc = await db.location.findFirst();
    if (!anyLoc) {
      await db.location.create({
        data: {
          name: "Alma Chaab — Kėdainiai",
          address: "Didžioji g. 25, Kėdainiai",
          phone: "+37066613055",
          isActive: true,
          isDefault: true,
          sortOrder: 0,
          // taxRate / deliveryFee null → inherit global Settings
        },
      });
      console.log("✓ Sukurtas pagrindinis filialas: Alma Chaab — Kėdainiai");
    } else {
      await db.location.update({ where: { id: anyLoc.id }, data: { isDefault: true, isActive: true } });
      console.log(`✓ Esamas filialas „${anyLoc.name}“ paskirtas pagrindiniu`);
    }
  } else {
    console.log(`• Pagrindinis filialas jau yra: ${existingDefault.name}`);
  }

  // --- Loyalty config (merge with existing Setting if present) ---
  const saved = await db.setting.findUnique({ where: { key: "loyalty" } });
  if (!saved) {
    await db.setting.create({
      data: {
        key: "loyalty",
        value: JSON.stringify({ enabled: true, pointsPerEuro: 1, stampGoal: 8, welcomeBonus: 0 }),
      },
    });
    console.log("✓ Lojalumo konfigūracija sukurta (1 taškas/€, 8 stampai)");
  } else {
    console.log("• Lojalumo konfigūracija jau egzistuoja — nekeičiama");
  }

  // --- Rewards catalog ---
  for (const r of REWARDS) {
    const exists = await db.reward.findFirst({ where: { name: r.name } });
    if (!exists) {
      await db.reward.create({ data: r });
      console.log(`✓ Prizas: ${r.name} (${r.pointsCost} taškų)`);
    }
  }

  console.log("Enterprise seed baigtas.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
