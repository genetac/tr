/**
 * Review fix #13 — copy quality:
 *  1. Fix "biiliardas" typo in article title/content.
 *  2. Rewrite the half-English Tawook description in Lithuanian.
 *  3. Fill all 36 empty menu-item descriptions with proper Lithuanian copy.
 * Idempotent: safe to run again (skips already-filled descriptions).
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const DESCRIPTIONS = {
  "Vištienos steikas": "Minkštas vištienos krūtinėlės steikas su prieskoniais, grilintas iki auksinės plutėlės.",
  "Lašiša": "Orkaitėje keptas lašišos filejas su citrina ir žolelėmis.",
  "Kafta": "Tradiciškai pagaminti maltos jautienos iešmeliai su Viduržemio jūros prieskoniais.",
  "Jautienos Cordon Bleu": "Jautienos vyniotinis su sūriu ir kumpiu, paneruotas ir kepamas iki auksinės plutėlės.",
  "Kiaulienos šonkauliai": "Marinuoti kiaulienos šonkauliai, lėtai kepti iki minkštumo su prieskonių glajumi.",
  "Cezario salotos su vištiena": "Klasikinės Cezario salotos su grilinta vištiena, parmezanu ir traškiais krutonais.",
  "Cezario salotos su krevetėmis": "Cezario salotos su keptomis krevetėmis, parmezanu ir traškiais krutonais.",
  "Graikiškos salotos": "Graikiškos salotos su fetos sūriu, alyvuogėmis ir šviežiomis daržovėmis.",
  "Fattoush": "Libanietiškos salotos su traškia pita, šviežiomis daržovėmis ir sumac prieskoniais.",
  "Marinuotos alyvuogės su prieskoniais": "Alyvuogės, marinuotos su alyvuogių aliejumi, česnaku ir Viduržemio jūros žolelėmis.",
  "Užkandžių rinkinys": "Įvairių šiltų ir šaltų užkandžių rinkinys dalijimuisi prie stalo.",
  "Humusas lėkštėje": "Kremištas avinžirnių humusas su alyvuogių aliejumi, patiekiamas su lavašu.",
  "Labneh lėkštėje": "Sūdyta labneh varškėlė su alyvuogių aliejumi ir zaatar prieskoniais.",
  "Aštrios girtos krevetės sidre (8 vnt.) 🌶️🌶️": "Krevetės, troškintos aštriame sidro ir pomidorų padaže (8 vnt.).",
  "Libanietiškų užkandžių rinkinys": "Tradiciškas libanietiškų užkandžių asortimentas dalijimuisi prie stalo.",
  "Jelapeno spurgytės 🌶️": "Traškios paneruotos jalapeno paprikos su sūrio įdaru.",
  "Skrudinta duona su česnakiniu padažu": "Ką tik skrudinta duona su naminis česnakiniu padažu.",
  "Lavašas": "Šviežias, plonas lavašo paplotėlis prie užkandžių ir padažų.",
  "Aštri jautienos sriuba 🌶️🌶️": "Soti aštri jautienos sriuba su daržovėmis ir Rytų prieskoniais.",
  "Jūros gėrybių sriuba su midijomis": "Kremišta jūros gėrybių sriuba su midijomis ir žolelėmis.",
  "Amerikietiški blyneliai su klevų sirupu": "Purūs amerikietiški blyneliai su klevų sirupu ir sviestu.",
  "Naminiai varškės blyneliai": "Naminiai varškės blyneliai su grietine ir uogiene.",
  "Virti varškėtukai": "Švelnūs virti varškėtukai su grietine ir sviestu.",
  "Vištienos kasneliai Chicken Nuggets": "Traškiai vištienos kasneliai, patiekiami su išsirinktu padažu.",
  "Skrudintos bulvytės": "Traškios skrudintos bulvytės su prieskoniais.",
  "Baklava": "Rytietiškas saldumas — sluoksniuota tešla su riešutais ir medaus sirupu.",
  "Sūrio pyragas": "Kremištas sūrio pyragas su uogomis.",
  "Česnakinis padažas": "Naminis česnakinis padažas.",
  "Garstyčių padažas": "Aštrus garstyčių padažas.",
  "Alyvuogių aliejus ir zaatar": "Alyvuogių aliejus su zaatar prieskoniais — duonai mirkyti.",
  "Fanta 250 ml": "Gazuotas apelsinų gėrimas Fanta, 250 ml.",
  "Gira Vilkmergės 410 ml": "Gaivus naminis gira Vilkmergės, 410 ml.",
  "Gazuotas vanduo": "Gazuotas mineralinis vanduo.",
  "Negazuotas vanduo": "Negazuotas mineralinis vanduo.",
  "Vilkmergės Craft nealkoholinis sidras 500 ml": "Nealkoholinis sidras Vilkmergės Craft, 500 ml.",
  "Vilkmergės Premium nealkoholinis alus 500 ml": "Nealkoholinis alus Vilkmergės Premium, 500 ml.",
};

let descFilled = 0;
let tawookFixed = 0;
let typoFixed = 0;

try {
  // 1. biiliardas → biliardas in articles (title/content/excerpt/slug kept).
  const articles = await db.article.findMany();
  for (const a of articles) {
    const patch = {};
    for (const field of ["title", "content", "excerpt", "description"]) {
      if (typeof a[field] === "string" && a[field].includes("biiliardas")) {
        patch[field] = a[field].replace(/biiliardas/g, "biliardas");
      }
    }
    if (Object.keys(patch).length) {
      await db.article.update({ where: { id: a.id }, data: patch });
      typoFixed++;
      console.log(`article fixed: ${patch.title || a.title}`);
    }
  }

  // 2. Tawook half-English description → Lithuanian.
  const tawook = await db.menuItem.findFirst({ where: { name: { contains: "Tawook" } } });
  if (tawook && /[A-Za-z]{3,}/.test(tawook.description || "") && /[A-Z][a-z]+ [a-z]+ [a-z]+ [a-z]+/.test(tawook.description)) {
    await db.menuItem.update({
      where: { id: tawook.id },
      data: { description: "Marinuoti vištienos iešmeliai su Levanto prieskoniais, grilinti iki auksinės plutėlės." },
    });
    tawookFixed++;
    console.log("Tawook description rewritten in Lithuanian");
  }

  // 3. Fill empty/short descriptions.
  const items = await db.menuItem.findMany();
  for (const item of items) {
    const desc = (item.description || "").trim();
    if (desc.length >= 25) continue; // already has a real description
    const fill = DESCRIPTIONS[item.name];
    if (fill) {
      await db.menuItem.update({ where: { id: item.id }, data: { description: fill } });
      descFilled++;
    } else {
      console.log(`  ! no mapping for: "${item.name}"`);
    }
  }

  console.log(`\nDONE — typo fixes: ${typoFixed}, Tawook rewritten: ${tawookFixed}, descriptions filled: ${descFilled}`);
} catch (e) {
  console.error("FAILED:", e);
  process.exit(1);
} finally {
  await db.$disconnect();
}
