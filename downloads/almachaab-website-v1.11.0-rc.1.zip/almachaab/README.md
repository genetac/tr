# AlmaChaab website — v1.11.0-rc.1

Locally validated release candidate imported from v1.9.3 and extended according to the supplied owner answers. Public deployment has not been performed. This is not a claim that every original proposal or production integration is complete.

Start with:

- `docs/LAISKAS-IRINAI.md` — concise Lithuanian client email.
- `docs/UNIFIED-PLAN.md` — unified scope, prices, decisions and launch gates.
- `docs/RELEASE-STATUS.md` — executed checks and remaining implementation/launch work.
- `docs/ADMIN-LT.md` — Lithuanian admin instructions.
- `docs/DEPLOYMENT-CANDIDATE.md` — current installation, migration, startup and rollback instructions.

Stack: Next.js 16, React, TypeScript, Prisma/SQLite, local durable uploads. Node 24 and Bun 1.3.4 were used for validation. The candidate includes 8 categories, 37 dishes, 10 review-draft articles and pending event notes. Loyalty remains disabled. Runtime secrets, customer/test records and build/dependency caches are excluded.

The original package documentation is retained as `README.imported.md` and `DEPLOY.md` for context. Prefer the candidate guide over historical hard-coded paths, environment-loading assumptions and claims of production readiness.
