# Alma Chaab v1.9.2 — preview + desktop spacing fixes

Small maintenance release on top of v1.9.1. No new features; two targeted fixes.

## Fixed

| ID | Fix |
|---|---|
| PREVIEW-1 | **Sandbox preview blocked by SEC-012 headers.** `next.config.ts` now applies the anti-framing headers only in production: CSP `frame-ancestors` becomes `*` and `X-Frame-Options` is omitted when `NODE_ENV !== "production"`, so the dev-server preview can render the site inside an iframe again. Production (`almachaab.lt`) is unchanged — `frame-ancestors 'none'` + `X-Frame-Options: DENY` stay fully strict, so the clickjacking protection from SEC-012 is not weakened. |
| UI-1 | **Desktop spacing of the three homepage bottom blocks tightened** (Wolt panel, Kontaktai, SEO text + FAQ) to match the compact rhythm the v1.5 pass already gave phones. New `@media (min-width: 761px)` block at the end of `src/app/site-mobile.css`: `#wolt.wolt-section` 68px → 40/36px, `.wolt-panel` vertical padding 38px → 30px, `#kontaktai.section` 90px → 48/40px with section-head margin 40px → 24px, `.alma-seo` 90px → 44/48px with tightened eyebrow/h2/copy gaps (~236px less scrolling above the footer). Mobile (≤760px) rules are untouched. |

## Files changed
- `next.config.ts` — dev-only frame-ancestors relaxation (PREVIEW-1)
- `src/app/site-mobile.css` — appended desktop spacing block (UI-1)
- `package.json` — version bump

## Deploy notes
- Same steps as v1.9.1 (DEPLOY.md §0 unchanged): three secrets in `.env`, systemd `Environment=HOSTNAME=127.0.0.1`, admin password change before DNS goes live.
- No database, dependency, or content changes in this release.
