# Deployment Guide — almachaab.lt

This guide takes the zip from unzip → live production site. Total time: ~30–60 min including DNS.

---

## 0. First deploy — before `bun run build` (v1.4+)

The release zip ships **`.env.example`, not `.env`** — real values are created on the server:

```bash
cp .env.example .env
# three DIFFERENT random values — run the line three times:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # → APP_SECRET_KEY, NEXTAUTH_SECRET, CRON_SECRET
```

Fill `.env` with:

| Variable | Value |
|---|---|
| `DATABASE_URL` | `file:../db/custom.db` (relative resolves against `prisma/`) or the absolute path |
| `APP_SECRET_KEY` | **required** — a NEW random value generated on this server. Encrypts secrets at rest. The app **refuses to run secret operations without it** in production (no built-in fallback). The shipped DB contains no secrets: the admin session secret and push keys are generated on first boot; enter SMTP / gateway keys in `/admin` after first login |
| `NEXTAUTH_URL` | `https://almachaab.lt` — **required**: every absolute link (emails, payment return URLs, redirects) is built from it, never from request headers |
| `NEXTAUTH_SECRET` | **separate** random value (not the same as `APP_SECRET_KEY`) — signs the short-lived social-login bridge token |
| `CRON_SECRET` | random value, only needed if you schedule the win-back cron (§5). Sent as a header, never in the URL |
| `UPLOAD_DIR` | e.g. `/var/www/almachaab/uploads` — `mkdir -p` it, copy the shipped `uploads/` (37 menu photos) into it: `cp -r uploads/* "$UPLOAD_DIR"/` |

**Network (SEC-006):** the Node process must listen on `127.0.0.1` only (`HOSTNAME=127.0.0.1` in the systemd unit, §4) and
ports 80/443 should accept only Cloudflare's IP ranges (VPS firewall, list at https://www.cloudflare.com/ips/).
The Caddyfile trusts `Cf-Connecting-Ip` only from Cloudflare and overwrites it before it reaches the app — keep its
`trusted_proxies` list in sync with that page. Needs **Caddy 2.7+**; check with `caddy validate --config /etc/caddy/Caddyfile` before reloading. Rate limits (admin login, order tracking, order form, customer login)
depend on this.

Then continue with §4. Re-run nothing else — the first admin login flow is described in §6.

---

## 1. What's in the box

- Full Next.js 16 source code (TypeScript, Tailwind 4)
- `db/custom.db` — SQLite database **with live content**: menu, texts, photos config, theme, working hours, articles, admin password hash
- PWA assets (manifest, service worker, icons), seed scripts, production `Caddyfile`
- Everything runs as **one Node process + one SQLite file** — no external database or services needed

---

## 2. Requirements

| Item | Notes |
|---|---|
| VPS / server | 1 vCPU / 1 GB RAM is enough (Ubuntu 22.04+ assumed below) |
| Node.js 20+ or [Bun](https://bun.sh) | Bun recommended (`curl -fsSL https://bun.sh/install \| bash`) |
| Domain | `almachaab.lt` A/AAAA record pointed at the server IP |
| HTTPS | **Required** for push notifications & installed-PWA features (Caddy obtains certificates automatically) |

---

## 3. Local preview (before deploying, 5 minutes)

```bash
unzip almachaab-website-v1.0.zip && cd almachaab
bun install
bun run db:generate
bun run dev            # → http://localhost:3000
```

- Public site: `/` · Tracking: `/mano` · Articles: `/straipsniai` · Kitchen: `/virtuve` · Admin: `/admin` (first login with the factory password forces a new one)

---

## 4. Deploy to a VPS (Ubuntu + Caddy — recommended)

### 4.1 Upload & build

```bash
# on the server, as a regular user
sudo apt update && sudo apt install -y unzip caddy
curl -fsSL https://bun.sh/install | bash && source ~/.bashrc

sudo mkdir -p /var/www && sudo chown $USER /var/www
cd /var/www
unzip almachaab-website-v1.0.zip          # creates ./almachaab
cd almachaab

bun install
bun run db:generate
bun run build
```

### 4.2 Run as a service (systemd)

```bash
sudo tee /etc/systemd/system/almachaab.service > /dev/null <<'EOF'
[Unit]
Description=Alma Chaab website (Next.js standalone)
After=network.target

[Service]
WorkingDirectory=/var/www/almachaab
ExecStart=/home/YOURUSER/.bun/bin/bun .next/standalone/server.js
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOSTNAME=127.0.0.1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now almachaab
sudo systemctl status almachaab        # should be "active (running)"
```

> Replace `YOURUSER` with your Linux username. If you use Node instead of Bun:
> `ExecStart=/usr/bin/node .next/standalone/server.js`

### 4.3 HTTPS reverse proxy (Caddy)

The included `Caddyfile` is ready for the real domain:

```bash
sudo cp /var/www/almachaab/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

It does two things: proxies `almachaab.lt` → `localhost:3000`, redirects `www.` → apex. Caddy issues and renews HTTPS certificates automatically.

### 4.4 Verify

```bash
curl -I https://almachaab.lt            # 200
curl -s  https://almachaab.lt/api/site  # JSON with site content (DB works)
```

Then in the browser: open `/admin`, log in, place a test pickup order from another device, watch it arrive in **Užsakymai**, accept it, check `/sekti`.

---

## 5. Environment variables

`.env` ships with working defaults:

```ini
DATABASE_URL=file:../db/custom.db
# NEXT_PUBLIC_SITE_URL=https://almachaab.lt   # uncomment/edit if the domain differs
```

- `DATABASE_URL` — relative SQLite paths are resolved against `prisma/`. An absolute path (`file:/var/www/almachaab/db/custom.db`) also works and is the most bulletproof option on a server. **Set it explicitly on the server** — never rely on the build machine's path.
- `UPLOAD_DIR` *(recommended in production)* — absolute folder for uploaded images, e.g. `/var/www/almachaab/uploads` (`mkdir -p` it once, keep it outside the app dir so deploys never wipe it). Admin image uploads (WebP re-encode, EXIF stripped) and menu photos live here, served via `/api/files/<name>`. Defaults to `./uploads` next to the app when unset.
- `NEXT_PUBLIC_SITE_URL` — canonical domain used in sitemap, robots, JSON-LD, OG tags. Rebuild (`bun run build`) after changing it.
- `APP_SECRET_KEY` — **required in production.** 64-char hex key that encrypts payment keys, the SMTP password and the admin session secret at rest (AES-256-GCM, see `src/lib/vault.ts`). Generate once with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` and keep it OUTSIDE the database (password manager / server env). If lost, stored secrets must be re-entered in `/admin`.
- `CRON_SECRET` *(optional)* — shared secret (≥ 24 chars) for the automated win-back endpoint `/api/cron/winback`. When unset the endpoint is disabled (no fallback). Sent only as the `x-cron-secret` header.
- `BACKUP_RSYNC_TARGET` *(optional)* — e.g. `backup@nas:/volume1/backups/almachaab`; mirrors the nightly DB backup off-server.
- Everything else (SMTP, VAPID push keys, **Stripe/PayPal keys**, content, theme) lives **in the database, encrypted at rest**, and is edited from `/admin` — never requires a redeploy.

**Automated win-back campaign (optional):** schedule a daily ping from the server crontab (`crontab -e`):

```cron
0 11 * * * curl -fsS -X POST -H "x-cron-secret: YOUR_CRON_SECRET" https://almachaab.lt/api/cron/winback >/dev/null 2>&1
```

---

## 6. Post-deploy checklist

1. **Admin password** — first login with the factory default opens a forced "nustatykite naują slaptažodį" screen; set a strong password (min. 12 characters). Login is rate-limited (5 fails / 15 min / IP).
2. **Email (SMTP)** — Nustatymai → El. paštas: choose the **Getspace** preset (host `mail.almachaab.lt`, port 465 SSL, e.g. `system@almachaab.lt`), paste the mailbox password, press the test-send button. Order confirmations + restaurant copies start flowing automatically.
3. **Push notifications** — on the owner's phone: open `/admin`, install the PWA (iOS: Share → Add to Home Screen, iOS 16.4+; Android: browser menu → Install app), then Nustatymai → Pranešimai → **Įgalinti**. Press the test button to verify a test notification arrives.
4. **Kitchen board** — on the kitchen tablet/phone: open `/virtuve`, install as app, unmute. It rings on every new order.
5. **Review content** — real photos (Nustatymai → Mediateka / Turinys), menu prices, working hours, Google rating (Nustatymai → Google: auto via Places API key or manual).
6. **SEO** — verify `https://almachaab.lt/sitemap.xml` and `robots.txt` respond; add the site to **Google Search Console**; link/create the **Google Business Profile** (Kėdainiai listing) — this drives the "best restaurants in Kėdainiai" answers in Google and AI assistants.
7. **Articles** — the seeded SEO articles are published; edit/extend them in `/admin` → Straipsniai with real photos for best results.
8. **Online payments** — Nustatymai → Mokėjimai ir parduotuvė: paste Stripe keys (webhook endpoint `https://almachaab.lt/api/webhooks/stripe`, event `checkout.session.completed`) and/or PayPal credentials; the card/PayPal options appear in checkout instantly once saved.
9. **Loyalty + CRM** — Nustatymai → Lojaluma: review the points rate and starter rewards. Nustatymai → CRM kampanijos: press "Peržiūrėti, kam siųsti" to preview dormant customers; optionally add the cron line above for fully automated win-back.
10. **Social sign-in (optional)** — Nustatymai → Socialiniai prisijungimai:
    - **Google**: create an OAuth client at console.cloud.google.com (Web application); add redirect URI `https://almachaab.lt/api/auth/callback/google`; paste Client ID + secret, toggle on.
    - **Facebook**: create an app at developers.facebook.com (Facebook Login); add `https://almachaab.lt/api/auth/callback/facebook` to Valid OAuth Redirect URIs; paste App ID + secret, toggle on.
    - **Telegram**: create a bot with @BotFather, paste the bot token and username, then run `/setdomain` in BotFather with `almachaab.lt` (mandatory — the widget refuses other domains); toggle on.
    - Buttons appear on `/mano` instantly. Set `NEXTAUTH_SECRET` in `.env` before enabling (openssl rand -base64 32).

---

## 7. Day-to-day content updates

Everything the restaurant edits lives in the database and takes effect **immediately, without redeploying**:

- Menu items, prices, categories, photos → `/admin` → Meniu
- All texts, section photos, hero, quick links → `/admin` → Turinys
- Colors, fonts, corner radius → `/admin` → Stilius
- Working hours (drives the open/closed chip & pickup slots) → `/admin` → Nustatymai → Darbo laikas
- Articles / stories → `/admin` → Straipsniai

Only **code changes** require a redeploy (`git pull` or re-upload → `bun install && bun run build && sudo systemctl restart almachaab`).

---

## 8. Backups & restore

The entire state is one file. A ready-made daily backup script ships with the project (`scripts/backup-db.mjs`) — it takes a consistent snapshot with `VACUUM INTO`, keeps the last 14 copies and can mirror them off-server:

```cron
# server crontab — daily 03:00, mirrored to off-server storage when BACKUP_RSYNC_TARGET is set
0 3 * * * cd /var/www/almachaab && node scripts/backup-db.mjs >> logs/backup.log 2>&1
```

Manual restore: stop service → copy a `backups/almachaab-YYYY-MM-DD.db` file back over `db/custom.db` → start service.

---

## 8a. Security notes (Cloudflare in front)

- **Rate-limit the login endpoint** in Cloudflare → Security → WAF → Rate limiting rules: match `http.request.uri.path eq "/api/admin/login"` and `http.request.method eq "POST"`, e.g. 10 requests / 1 min / same IP. The app itself additionally allows 5 failed logins / 15 min / IP.
- **Admin session cookie** is `SameSite=Lax`, `HttpOnly`; every write API additionally validates the `Origin` header (cross-site form posts are rejected with 403).
- **Tracking links** sent to customers contain a private random token (`/mano?nr=…&t=…`); a bare order number alone cannot open an order — the customer can also look one up with the last 4 digits of their phone.
- **Hosting target:** this app is a long-running Node server (standalone output + SQLite + SSE). It runs on a VPS behind Cloudflare (see section 4). It does **not** deploy to Cloudflare Pages/Workers — if a Pages/Workers deployment is ever requested, it would require a platform port (DB + SSE rework) first.

## 9. Troubleshooting

| Symptom | Fix |
|---|---|
| `Prisma Client did not initialize yet` | Run `bun run db:generate`, restart the service |
| Phantom 500s after schema change | `rm -rf .next` → rebuild → restart |
| Push notifications don't arrive | Site must be **HTTPS**; on iOS the PWA must be installed first; check Nustatymai → Pranešimai shows ≥1 device |
| Emails fail | Use port **465 (SSL)** with Getspace; username is the **full email address**; check the test-send error message |
| Port 3000 busy | `sudo lsof -i :3000`, kill the old process or change `PORT` in the service file |
| Admin logs out constantly behind a proxy | Ensure `X-Forwarded-Proto: https` reaches the app (the included Caddyfile does this) |

---

## 10. Alternative hosting

Any host that runs Node works (Vercel/Netlify need a managed DB — not recommended here since the system is designed around the bundled SQLite file and local uploads). The simplest options: **Hetzner/DO/Linode VPS + Caddy** (as above) or a small **Getspace VPS** in Lithuania for lowest latency to local customers.
