# Alma Chaab — Restaurant Website (almachaab.lt)

Complete, production-ready website system for the Lebanese restaurant **Alma Chaab** (Kėdainiai, Lithuania).
Stack: **Next.js 16 + TypeScript + Tailwind CSS 4 + Prisma (SQLite)** — one Node process, one SQLite file, no external services required.

## What's inside

| Area | Details |
|---|---|
| **Public site** (Lithuanian) | Home, menu browsing with filters & cart, 2-step reservation / pre-order, pickup ordering with time slots, order tracking `/sekti` (live status + ready-time ETA), articles `/straipsniai` |
| **Admin CMS** `/admin` | Edit every text, photo, color, font, menu item, category, working hours, quick links; orders dashboard with status flow; menu editor with image upload & media library; article editor with SEO keywords/slug; theme editor |
| **Kitchen board** `/virtuve` | Full-screen kitchen display: rings on new orders (WebAudio + vibration), accept, prep-time chips (15–60 min), status workflow, elapsed/late timers, wake lock — works as an installed app |
| **Push notifications** | "Incoming call" style system notification on every new order, with **Priimti / Atidaryti** buttons — even with the admin tab closed (PWA installed; iOS 16.4+). VAPID keys auto-generated, stored in DB |
| **Email** | Order & reservation confirmations via SMTP — preset for Getspace / Gmail / any provider, test-send button, restaurant copy |
| **SEO & AI visibility** | Sitemap, robots (explicitly allows GPTBot, ClaudeBot, PerplexityBot…), Restaurant + FAQ JSON-LD, per-article meta/OG, ~90 Kėdainiai keyword targets, 9 seeded SEO articles |
| **PWA** | Installable app (manifest + service worker); admin is network-first, API never cached |
| **Auth** | Session cookie **+** localStorage token fallback — works in iframes and strict cookie modes |
| **Social sign-in** | NextAuth.js (Google + Facebook OAuth) and Telegram Login Widget (HMAC-verified). Admin-managed keys with masking; accounts link by email so loyalty points and order history carry over |

## Quick start (development)

Requirements: **[Bun](https://bun.sh)** (recommended) or Node 20+.

```bash
bun install          # install dependencies
bun run db:generate  # generate Prisma client
bun run dev          # dev server → http://localhost:3000
```

The SQLite database is **included** at `db/custom.db` with live content: full menu (8 categories, 37 items), texts, theme, hours, articles, admin password hash. No seeding needed.

## Production build

```bash
bun run build
bun run start        # serves .next/standalone on port 3000
```

➡️ **For the full server setup guide (VPS, HTTPS, env vars, checklist) see [DEPLOY.md](DEPLOY.md).**

## Admin access

- URL: `https://YOUR-DOMAIN/admin`
- First login: if the factory default password is still in use, the panel **forces a new password** before anything else can be opened (the default value is intentionally not documented here)
- Login rate limit: 5 failed attempts / 15 min per IP — add a Cloudflare WAF rate-limit rule on `/api/admin/login` for defense in depth
- ⚠️ **Change it after handover:** `/admin` → Nustatymai → Saugumas

## Enterprise modules (payments, branches, loyalty, CRM)

| Module | Where | Notes |
|---|---|---|
| Online payments | `/admin` → Nustatymai → Mokėjimai ir parduotuvė | Stripe Checkout + webhook, PayPal Smart Buttons — keys stored in DB, masked in UI |
| Multi-branch | `/admin` → Nustatymai → Filialai | Each branch can override PVM % and delivery fee; the marked "Pagrindinis" branch prices new orders |
| Loyalty program | `/admin` → Nustatymai → Lojaluma | Points per €, stamp card goal, welcome bonus, rewards catalog; customers redeem vouchers in `/mano` |
| Retention CRM | `/admin` → Nustatymai → CRM kampanijos | Win-back push + email to customers dormant 14+ days (preview before send) |
| Real-time KDS | `/virtuve` + SSE | Live order feed `/api/orders/stream`, customer sync via `/api/track/[number]/stream` |

**Automated win-back (optional cron):**

```bash
# daily at 11:00 — add CRON_SECRET to .env first
curl -fsS -X POST "https://YOUR-DOMAIN/api/cron/winback?secret=$CRON_SECRET"
```

## Environment variables (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `file:../db/custom.db` | SQLite path (relative paths resolve against `prisma/`) |
| `NEXT_PUBLIC_SITE_URL` | `https://almachaab.lt` | Canonical URL used in sitemap, robots, JSON-LD, OG tags |
| `CRON_SECRET` | *(optional)* | Shared secret for `/api/cron/winback`; falls back to the admin session secret |

All other configuration (SMTP credentials, VAPID keys, payment gateway keys, content, theme) lives in the database and is managed from `/admin` — no redeploy needed to change it.

## Project structure

```
prisma/schema.prisma       # DB models: Setting, Settings, Location, User, Category, MenuItem, Order, LoyaltyProfile/Transaction, Reward/Redemption, Article, PushSubscription, Media
db/custom.db               # SQLite database (content included)
src/app/                   # pages (home, /sekti, /straipsniai, /virtuve, /admin) + API routes
src/components/site/       # public site components (menu, checkout, tracking…)
src/components/admin/      # admin tabs (Orders, Kitchen, Menu, Content, Theme, Articles, Settings)
src/lib/                   # auth, db, settings, mail, orders, push, schema, theme helpers
public/                    # icons, manifest, sw.js, seed photos, OG cover
scripts/                   # seed & maintenance utilities (see below)
Caddyfile                  # production reverse-proxy config (Caddy, auto-HTTPS)
DEPLOY.md                  # step-by-step production deployment guide
```

### Utility scripts

| Script | Purpose |
|---|---|
| `scripts/seed.ts` (+ `seed-data.json`) | Reset all site content to the original seed |
| `scripts/seed-articles.mjs` | Seed the base sample articles |
| `scripts/seed-keyword-articles.mjs` | Seed the SEO keyword articles |
| `scripts/make_icons.py` | Regenerate PWA icons from the logo |
| `scripts/make_og.py` | Regenerate the 1200×630 OG cover image |
| `scripts/inspect-db.mjs` | Quick DB content inspector |
| `scripts/cleanup-e2e.mjs` | Remove test orders / test data |

## Notes & troubleshooting

- If the Prisma client is out of sync after `bun install`, run `bun run db:generate`.
- To reset content: `bun run db:push` then `bun tsx scripts/seed.ts` (⚠️ overwrites everything).
- After a Prisma schema change, delete `.next/` if you see phantom 500s (stale Turbopack cache), then rebuild.
- `dev.log` / `server.log` are runtime logs — safe to delete.
- **Backup** = copy the single file `db/custom.db` (contains all content, orders, settings).
