import { AccountClient } from "@/components/site/AccountClient";
import { getSettings } from "@/lib/settings";
import "../track.css";
import "./account.css";

export const dynamic = "force-dynamic";

export const metadata = {
  title: { absolute: "Mano paskyra | Alma Chaab" },
  description: "Jūsų Alma Chaab užsakymų istorija ir greitas pakartojimas.",
  robots: { index: false, follow: false },
};

export default async function AccountPage() {
  const s = await getSettings();
  return (
    <AccountClient phone={s.site.phone} phoneDisplay={s.site.phoneDisplay} facebookUrl={s.site.facebookUrl} />
  );
}
