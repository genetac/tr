import {publicMenuItem} from "@/lib/public-menu";
import { visitorInfo } from "@/lib/visitor";
import { can } from "@/lib/auth";
import { getSetting } from "@/lib/settings";
import { db } from "@/lib/db";
import { getSettings, publicSettings } from "@/lib/settings";
import { themeCss } from "@/lib/theme-css";
import { restaurantJsonLd, faqJsonLd } from "@/lib/schema";
import { JsonLd } from "@/components/seo/JsonLd";
import { AlmaSite } from "@/components/site/AlmaSite";
import "./site-scoped.css";
import "./site-addendum.css";
import "./site-mobile.css";

export const dynamic = "force-dynamic";

export async function generateMetadata({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
  return (await searchParams).preview === '1' ? { robots: { index: false, follow: false } } : {};
}

async function fetchGoogleRating(apiKey: string, placeId: string): Promise<{ score: number; count: number } | null> {
  const g = globalThis as unknown as { __almaRatingCache?: Record<string, { at: number; data: { score: number; count: number } }> };
  g.__almaRatingCache = g.__almaRatingCache || {};
  const cached = g.__almaRatingCache[placeId];
  if (cached && Date.now() - cached.at < 12 * 3600 * 1000) return cached.data;
  try {
    const res = await fetch(`https://places.googleapis.com/v1/places/${encodeURIComponent(placeId)}?languageCode=lt`, {
      headers: { "X-Goog-Api-Key": apiKey, "X-Goog-FieldMask": "rating,userRatingCount" },
      cache: "no-store",
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { rating?: number; userRatingCount?: number };
    if (typeof json.rating === "number") {
      const data = { score: Math.round(json.rating * 10) / 10, count: json.userRatingCount || 0 };
      g.__almaRatingCache[placeId] = { at: Date.now(), data };
      return data;
    }
  } catch {
    // silent — fall back to manual values
  }
  return null;
}

export default async function Home({ searchParams }: { searchParams: Promise<{ preview?: string }> }) {
  const s = await getSettings();
  const preview = (await searchParams).preview === '1' && await can("content");
  if (preview) {
    const draft = await getSetting<{ content: any }>('contentDraft');
    if (draft) s.content = draft.content;
  }
  const categories = await db.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: { items: { where: { active: true }, orderBy: { sortOrder: "asc" } } },
  });
  const activeCats = categories
    .filter((cat) => cat.active)
    .map((cat) => ({
      id: cat.id,
      name: cat.name,
      items: cat.items.map(item=>publicMenuItem(item,s.dietaryDisplay)),
    }));

  // Rating resolution: auto (Google Places) → manual → hidden
  let rating = { mode: s.rating.mode as string, score: s.rating.score, count: s.rating.count, note: s.rating.note };
  if (rating.mode === "auto" && s.rating.placesApiKey && s.rating.placesPlaceId) {
    const live = await fetchGoogleRating(s.rating.placesApiKey, s.rating.placesPlaceId);
    if (live) {
      rating = { ...rating, score: live.score, count: live.count };
      rating.note = rating.note || `${live.count} Google atsiliepimas · dabartinis viešas įvertinimas`;
    } else {
      rating.mode = "manual";
    }
  }

  const themeCssOut = themeCss(s.theme);
  const hours = s.hours as Record<string, [number, number] | null>;

  const jsonLd = restaurantJsonLd(s.site, rating, hours, activeCats, s.content);

  // FAQ — mirrors the visible section below; targets long-tail searches and AI answers
  const info = visitorInfo(s.content);
  const faq = [
    { q: "Ar reikia rezervuoti staliuką?", a: info.reservations },
    { q: "Ką žinoti apie mitybos pasirinkimus?", a: info.dietary },
    { q: "Ar pristatote maistą?", a: info.delivery },
    { q: "Ar galima rezervuoti salę šventei?", a: info.privateRoom },
    { q: "Kokiomis valandomis dirbate?", a: `${hoursLine(s.hours)}. ${info.kitchen}` },
  ];
  const faqLd = faqJsonLd(faq);

  return (
    <>
      {preview && <div role="status" style={{ background: '#ffe09d', padding: 16, position: 'relative', zIndex: 100 }}>Juodraščio peržiūra – pakeitimai dar nepaskelbti.</div>}
      <style dangerouslySetInnerHTML={{ __html: themeCssOut }} />
      <JsonLd data={[jsonLd, faqLd]} />
      <AlmaSite
        data={{ settings: publicSettings(s), categories: activeCats }}
        rating={rating}
        seoSlot={
          <section key="alma-seo" className="alma-seo" aria-label="Informacija apie restoraną">
            <div className="shell alma-seo-inner">
              <p className="eyebrow">Alma Chaab — libaniška virtuvė Kėdainiuose</p>
              <h2>Šeimos restoranas Kėdainių senamiestyje</h2>
              <div className="alma-seo-copy">
                <p>
                  {s.site.name} įsikūrė adresu {s.site.address}. Restoraną įkūrė kėdainietė Irina Eid ir
                  jos vyras Elie Eid, kilęs iš Libano — jis ir vadovauja virtuvei. Gaminame daugiausia libanietiškus patiekalus:
                  humusą ir labneh su lavašu, fattoush salotas, vištienos tawook ir kaftą nuo grilio, o desertui — baklavą.
                  Šalia jų meniu rasite ir pažįstamų europietiškų patiekalų. Užkandžius čia įprasta statyti į stalo vidurį ir dalytis, tad vakarienė dažnai užsitęsia ilgiau nei
                  planuota.
                </p>
                <p>
                  Užsukite pietų darbo dieną arba vakarienės dviese — savaitgaliais duris atveriame jau 11 val. Didesnei progai
                  antrame aukšte yra salė iki 30 svečių, pasiekiama tik laiptais. Sąlygas deriname individualiai. Vaikams paruoštas atskiras kampelis
                  ir vaikų meniu.
                </p>
                <p>
                  Jei nespėjate prisėsti, maistą išsinešti galite užsisakyti internetu: pasirinkite atsiėmimo laiką ir sekite, kada
                  užsakymas bus paruoštas. Į namus pristatome per Wolt. Daugiau apie mus papasakojome skiltyje{" "}
                  <a href="/apie-mus">Apie mus</a>, o patarimų, ką paragauti, rasite{" "}
                  <a href="/straipsniai">straipsniuose</a>.
                </p>
              </div>
              <div className="alma-seo-faq">
                <h3>Dažniausiai užduodami klausimai</h3>
                {faq.map((f, i) => (
                  <details key={i}>
                    <summary>{f.q}</summary>
                    <p>{f.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </section>
        }
      />
    </>
  );
}

function hoursLine(hours: Record<string, [number, number] | null>): string {
  // "II–V 12:00–22:00, VI 11:00–22:00, VII 11:00–20:00, I nedirbame" (groups consecutive days, handles :30)
  const order = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  const roman: Record<string, string> = { mon: "I", tue: "II", wed: "III", thu: "IV", fri: "V", sat: "VI", sun: "VII" };
  const hm = (n: number) => `${String(Math.floor(n)).padStart(2, "0")}:${n % 1 ? "30" : "00"}`;
  const groups: { days: string[]; label: string }[] = [];
  for (const d of order) {
    const v = hours[d];
    const label = v ? `${hm(v[0])}–${hm(v[1])}` : "nedirbame";
    const last = groups[groups.length - 1];
    if (last && last.label === label) last.days.push(d);
    else groups.push({ days: [d], label });
  }
  if (!groups.some((g) => g.label !== "nedirbame")) return "Darbo laiką rasite svetainėje";
  return groups
    .map((g) => `${roman[g.days[0]]}${g.days.length > 1 ? "–" + roman[g.days[g.days.length - 1]] : ""} ${g.label}`)
    .join(", ");
}
