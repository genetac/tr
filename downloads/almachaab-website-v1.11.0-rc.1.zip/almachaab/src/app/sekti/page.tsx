import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

/**
 * /sekti has been merged into /mano — one page for order tracking and the
 * customer account. Old links (and the ?nr= deep links) keep working; the
 * tracking token (t) is passed through.
 */
export default async function TrackPage({
  searchParams,
}: {
  searchParams: Promise<{ nr?: string; t?: string }>;
}) {
  const { nr, t } = await searchParams;
  if (!nr) redirect("/mano");
  redirect(`/mano?nr=${encodeURIComponent(nr)}${t ? `&t=${encodeURIComponent(t)}` : ""}`);
}
