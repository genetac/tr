import {notFound,permanentRedirect} from 'next/navigation';import {can} from '@/lib/auth';import {getDocument,publishedPage,pageRecords} from '@/lib/cms';import {getSettings,publicSettings} from '@/lib/settings';import {StandalonePage} from '@/components/cms/StandalonePage';import '../privatumas.css';
export const dynamic='force-dynamic';
type Props={params:Promise<{slug:string}>;searchParams:Promise<{preview?:string;doc?:string}>};
export async function generateMetadata({params,searchParams}:Props){const {slug}=await params;const q=await searchParams;if(q.preview==='1')return {title:'Juodraščio peržiūra',robots:{index:false,follow:false}};const record=await publishedPage(slug);return record?{title:record.published.title,description:record.published.description,alternates:{canonical:`/${slug}`}}:{title:'Puslapis nerastas',robots:{index:false}};}
export default async function Page({params,searchParams}:Props){const {slug}=await params;const q=await searchParams;const preview=q.preview==='1'&&await can('content');let page;
 if(preview&&q.doc){page=(await getDocument(`page:${q.doc}`)).draft;}
 else{const record=await publishedPage(slug);page=record?.published;if(!page){const moved=(await pageRecords()).find(p=>p.published?.visible!==false&&p.redirects?.includes(slug));if(moved)permanentRedirect(`/${moved.published.slug}`);}}
 if(!page)notFound();return <StandalonePage page={page} settings={publicSettings(await getSettings())} preview={preview}/>;
}
