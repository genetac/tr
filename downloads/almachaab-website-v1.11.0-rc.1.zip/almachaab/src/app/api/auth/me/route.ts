import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/userauth";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Returns the signed-in customer (or null) — used by checkout prefill and /mano.
 *
 * The /mano profile view additionally renders which sign-in providers are
 * linked to the account (`accounts`: e.g. ["google","telegram"]) and whether a
 * password is set, so the UI can offer "Prijungti …" linking buttons only for
 * the providers that are actually missing. Additive fields — checkout prefill
 * keeps reading just name/phone/email.
 */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null });

  const [accounts, row] = await Promise.all([
    db.account.findMany({ where: { userId: user.id }, select: { provider: true } }),
    db.user.findUnique({ where: { id: user.id }, select: { passwordHash: true } }),
  ]);

  return NextResponse.json({
    user: {
      ...user,
      hasPassword: Boolean(row?.passwordHash),
      accounts: accounts.map((a) => a.provider),
    },
  });
}
