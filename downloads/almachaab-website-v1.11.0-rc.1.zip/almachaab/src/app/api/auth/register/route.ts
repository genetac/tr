import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashUserPassword, setUserCookie } from "@/lib/userauth";
import { grantWelcomeBonus, ensureProfile, getLoyaltyConfig } from "@/lib/loyalty";
import { verifyTurnstile, clientIp } from "@/lib/turnstile";
import { clientIp as trustedClientIp } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/** Customer self-registration (email + password). Signs the user in immediately. */
export async function POST(req: NextRequest) {
  // SEC-005: max 5 sign-ups per IP per hour (no Turnstile until a real key exists).
  const rl = rateLimit(`register|${trustedClientIp(req.headers)}`, 5, 60 * 60_000);
  if (rl.limited) return NextResponse.json({ error: "Per daug registracijų. Bandykite vėliau." }, { status: 429 });
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || "").trim().toLowerCase().slice(0, 120);
  const password = String(b.password || "");
  const name = String(b.name || "").trim().slice(0, 80);
  const phone = String(b.phone || "").trim().slice(0, 30);

  if (!(await verifyTurnstile(String(b.turnstileToken || ""), clientIp(req.headers.get("x-forwarded-for"))))) {
    return NextResponse.json({ error: "Patvirtinkite, kad esate žmogus (Cloudflare patikra)." }, { status: 403 });
  }

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ error: "Įveskite tikrą el. pašto adresą." }, { status: 400 });
  }
  if (password.length < 8) {
    return NextResponse.json({ error: "Slaptažodis per trumpas — bent 8 simboliai." }, { status: 400 });
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: "Šis el. paštas jau registruotas — prisijunkite." }, { status: 409 });
  }

  const user = await db.user.create({
    data: { email, name, phone, passwordHash: hashUserPassword(password) },
  });

  await setUserCookie(user.id);
  // Loyalty: create the profile immediately (0 points card) + optional welcome
  // bonus (configured in /admin → Lojaluma; off by default).
  const cfg = await getLoyaltyConfig().catch(() => null);
  let bonus: number | null = null;
  if (cfg?.enabled) {
    await ensureProfile(user.id).catch(() => null);
    bonus = await grantWelcomeBonus(user.id).catch(() => null);
  }
  return NextResponse.json({
    ok: true,
    user: { id: user.id, email: user.email, name: user.name, phone: user.phone },
    ...(bonus ? { welcomeBonus: bonus } : {}),
  });
}
