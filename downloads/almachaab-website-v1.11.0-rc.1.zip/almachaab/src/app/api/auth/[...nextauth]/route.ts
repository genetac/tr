import { NextRequest } from "next/server";
import NextAuth from "next-auth";
import { buildAuthOptions } from "@/lib/nextauth-options";

export const dynamic = "force-dynamic";

/**
 * NextAuth.js route handler (Auth.js v4) — Google + Facebook OAuth.
 * Options are rebuilt per request because provider credentials live in the
 * database (admin panel) and can change without a redeploy.
 *
 * Provider callbacks (configured in each provider's console):
 *   {origin}/api/auth/callback/google
 *   {origin}/api/auth/callback/facebook
 */
async function handler(req: NextRequest, ctx: { params: Promise<{ nextauth: string[] }> }) {
  const options = await buildAuthOptions();
  // SEC-002: with no provider enabled the endpoint does not exist at all.
  if (!options.providers.length) return new Response("Not found", { status: 404 });
  return NextAuth(req, ctx, options);
}

export { handler as GET, handler as POST };
