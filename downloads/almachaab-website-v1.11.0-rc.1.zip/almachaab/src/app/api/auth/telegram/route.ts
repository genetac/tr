import { NextRequest, NextResponse } from "next/server";
import { getSocialConfig, upsertSocialUser, linkProviderAccount, verifyTelegramAuth, telegramAuthDateFresh, type TelegramAuthPayload } from "@/lib/social-auth";
import { getCurrentUser, userCookieHeaderValue } from "@/lib/userauth";
import { verifyTurnstile, clientIp } from "@/lib/turnstile";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Telegram Login Widget verifier.
 *
 * The widget (rendered on /mano) calls the global `onTelegramAuth` callback,
 * which POSTs the signed payload here. Verification follows the official
 * algorithm: secret = SHA256(bot_token), data_check_string = sorted
 * "key=value" lines joined with \n, valid = hex(HMAC_SHA256(secret, dcs)) === hash.
 * Payloads older than 24 h are rejected (replay protection).
 *
 * Two modes:
 * - Sign-in (no native session): provision the deterministic `tg-{id}@`
 *   identity, exactly like the OAuth providers, and issue the 30-day cookie.
 * - Linking (valid `alma_user` session present): attach the Telegram identity
 *   to the CURRENT user — email, loyalty points, stamps and orders stay as
 *   they are; only the Account row is recorded.
 */
export async function POST(req: NextRequest) {
  const cfg = await getSocialConfig();
  if (!cfg.telegram.enabled || !cfg.telegram.botToken || !cfg.telegram.botUsername) {
    return NextResponse.json({ error: "Telegram prisijungimas išjungtas." }, { status: 404 });
  }

  // The client sends { ...telegramUser, turnstileToken } — the token must be
  // stripped BEFORE HMAC verification (it is not part of Telegram's payload).
  const raw = (await req.json().catch(() => null)) as (TelegramAuthPayload & { turnstileToken?: string }) | null;
  const { turnstileToken, ...p } = raw ?? ({} as TelegramAuthPayload & { turnstileToken?: string });
  if (!p || !p.id || !p.hash) {
    return NextResponse.json({ error: "Netinkamas Telegram atsakymas." }, { status: 400 });
  }

  if (!verifyTelegramAuth(p, cfg.telegram.botToken)) {
    return NextResponse.json({ error: "Telegram duomenų patikra nepavyko — bandykite dar kartą." }, { status: 401 });
  }
  if (!telegramAuthDateFresh(p)) {
    return NextResponse.json({ error: "Telegram sesija pasenusi — prisijunkite iš naujo." }, { status: 401 });
  }

  const name = [p.first_name, p.last_name].filter(Boolean).join(" ").trim();

  try {
    // Linking mode: an authenticated customer connects Telegram to their
    // existing profile — keep their identity untouched, only record the link.
    // (Turnstile is not required here: the session itself is the proof.)
    const current = await getCurrentUser();
    if (current) {
      await linkProviderAccount(current.id, "telegram", String(p.id));
      const accounts = await db.account.findMany({ where: { userId: current.id }, select: { provider: true } });
      return NextResponse.json({
        ok: true,
        linked: true,
        user: { ...current, accounts: accounts.map((a) => a.provider) },
      });
    }

    // Sign-in mode (unauthenticated): the anti-bot gate applies.
    if (!(await verifyTurnstile(String(turnstileToken || ""), clientIp(req.headers.get("x-forwarded-for"))))) {
      return NextResponse.json({ error: "Patvirtinkite, kad esate žmogus (Cloudflare patikra)." }, { status: 403 });
    }

    // Telegram does not expose the phone/email — build a deterministic in-app
    // identity from the telegram id (documented, stable, unique per user).
    const email = `tg-${p.id}@users.almachaab.lt`;

    const user = await upsertSocialUser({
      provider: "telegram",
      providerAccountId: String(p.id),
      email,
      name: name || (p.username ? `@${p.username}` : "Telegram svečias"),
      image: p.photo_url || "",
    });

    const proto = (req.headers.get("x-forwarded-proto") || "").split(",")[0].trim() || "http";
    const isHttps = proto === "https";
    const setCookie = await userCookieHeaderValue(user.id, isHttps);

    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, email: user.email, name: user.name, phone: user.phone, accounts: ["telegram"] },
    });
    res.headers.set("Set-Cookie", setCookie);
    return res;
  } catch (err) {
    console.error("[telegram-auth] provisioning failed:", err);
    return NextResponse.json({ error: "Nepavyko sukurti paskyros — bandykite dar kartą." }, { status: 500 });
  }
}
