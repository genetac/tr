import { NextResponse } from "next/server";
import { clearUserCookie } from "@/lib/userauth";

export const dynamic = "force-dynamic";

/** Customer logout — clears the session cookie. */
export async function POST() {
  await clearUserCookie();
  return NextResponse.json({ ok: true });
}
