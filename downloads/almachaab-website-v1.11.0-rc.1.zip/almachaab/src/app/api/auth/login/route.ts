import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyUserPassword, hashUserPassword, setUserCookie } from "@/lib/userauth";
import { verifyTurnstile, clientIp } from "@/lib/turnstile";
import { clientIp as trustedClientIp } from "@/lib/auth";
import { failBlocked, failRecord, failClear } from "@/lib/rate-limit";

// SEC-005: customer password guessing limits (per IP, per account, global).
const WINDOW = 15 * 60_000;
const MAX_PER_IP = 10;
const MAX_PER_EMAIL = 5;
const MAX_GLOBAL = 300;
const TOO_MANY = "Per daug nesėkmingų bandymų. Bandykite po 15 min.";
// Constant-time-ish path for unknown emails (no account enumeration by timing).
const DUMMY_HASH = hashUserPassword("timing-equalizer-not-a-password");

export const dynamic = "force-dynamic";

/** Customer login with email + password. */
export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || "").trim().toLowerCase();
  const password = String(b.password || "");

  if (!(await verifyTurnstile(String(b.turnstileToken || ""), clientIp(req.headers.get("x-forwarded-for"))))) {
    return NextResponse.json({ error: "Patvirtinkite, kad esate žmogus (Cloudflare patikra)." }, { status: 403 });
  }

  const ip = trustedClientIp(req.headers);
  const keys = { ip: `cust-login|ip|${ip}`, email: `cust-login|em|${email}`, global: "cust-login|global" };
  for (const [k, max] of [[keys.global, MAX_GLOBAL], [keys.ip, MAX_PER_IP], [keys.email, MAX_PER_EMAIL]] as const) {
    if (failBlocked(k, max).blocked) return NextResponse.json({ error: TOO_MANY }, { status: 429 });
  }
  const fail = () => {
    failRecord(keys.ip, WINDOW);
    failRecord(keys.email, WINDOW);
    failRecord(keys.global, WINDOW);
    return NextResponse.json({ error: "Neteisingas el. paštas arba slaptažodis." }, { status: 401 });
  };

  const user = await db.user.findUnique({ where: { email } });
  if (!user) {
    verifyUserPassword(password, DUMMY_HASH);
    return fail();
  }
  // Social-only accounts (Google / Facebook / Telegram) have no password.
  if (!user.passwordHash) {
    return NextResponse.json(
      { error: "Ši paskyra sukurta per socialinį tinklą — prisijunkite mygtuku žemiau (Google / Facebook / Telegram)." },
      { status: 409 }
    );
  }
  if (!verifyUserPassword(password, user.passwordHash)) return fail();
  failClear(keys.ip);
  failClear(keys.email);

  await setUserCookie(user.id);
  return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name, phone: user.phone } });
}
