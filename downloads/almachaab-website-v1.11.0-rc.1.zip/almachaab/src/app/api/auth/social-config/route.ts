import { NextResponse } from "next/server";
import { getSocialConfig, publicSocialConfig, telegramBotActive } from "@/lib/social-auth";
import { getTurnstileConfig, publicTurnstileConfig } from "@/lib/turnstile";

export const dynamic = "force-dynamic";

/** Public-safe social sign-in + anti-bot availability for the /mano login form. */
export async function GET() {
  try {
    const cfg = await getSocialConfig();
    const social = publicSocialConfig(cfg);
    if (social.telegram) {
      // Live check (cached 10 min): placeholder vs. real widget on /mano.
      social.telegramBotActive = await telegramBotActive(cfg.telegram.botToken, cfg.telegram.botUsername);
    }
    const turnstile = await getTurnstileConfig();
    return NextResponse.json({ social, turnstile: publicTurnstileConfig(turnstile) });
  } catch {
    // Fail-safe: the login form simply hides the social buttons and the gate.
    return NextResponse.json({
      social: { google: false, facebook: false, telegram: false, telegramBot: "", telegramBotActive: false },
      turnstile: { enabled: false, siteKey: "" },
    });
  }
}
