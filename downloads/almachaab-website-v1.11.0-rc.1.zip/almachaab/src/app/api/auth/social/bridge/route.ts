import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { getToken } from "next-auth/jwt";
import { db } from "@/lib/db";
import { nextAuthSecret } from "@/lib/nextauth-options";
import { userCookieHeaderValue } from "@/lib/userauth";

export const dynamic = "force-dynamic";

/**
 * Social sign-in bridge — the only glue between the NextAuth session and the
 * app's native `alma_user` cookie.
 *
 * Flow: OAuth provider → /api/auth/callback/{google|facebook} → NextAuth signs
 * its short-lived JWT (10 min) carrying token.uid → redirect callback sends the
 * browser here → we read the JWT server-side, issue the native 30-day
 * `alma_user` cookie and continue to /mano.
 *
 * Every downstream feature (orders, loyalty points, stamps, history, push
 * opt-in) reads `alma_user`, so social sessions behave exactly like
 * email/password sessions.
 */
export async function GET(req: NextRequest) {
  const readUid = async (): Promise<string | null> => {
    try {
      const secret = await nextAuthSecret();
      // getToken accepts a NextRequest directly and reads its session cookie.
      const token = await getToken({ req, secret });
      // SEC-002: only a token minted by our own jwt callback after a real
      // OAuth sign-in is accepted — never a bare email claim.
      if (token?.bridge === "alma-social-v1" && typeof token.uid === "string" && token.uid) return token.uid;
    } catch {
      /* fall through */
    }
    return null;
  };

  const uid = await readUid();

  const proto = (req.headers.get("x-forwarded-proto") || "").split(",")[0].trim() || "http";
  const isHttps = proto === "https";
  const base = siteBaseUrl(req); // SEC-016

  if (!uid || !(await db.user.findUnique({ where: { id: uid } }))) {
    const res = NextResponse.redirect(`${base}/mano?social=error`);
    // Clear the now-useless NextAuth bridge cookie.
    res.cookies.set("next-auth.session-token", "", { path: "/", maxAge: 0 });
    return res;
  }

  const setCookie = await userCookieHeaderValue(uid, isHttps);
  const res = NextResponse.redirect(`${base}/mano?social=ok`);
  res.headers.set("Set-Cookie", setCookie);
  res.headers.set("Cache-Control", "no-store");
  return res;
}
