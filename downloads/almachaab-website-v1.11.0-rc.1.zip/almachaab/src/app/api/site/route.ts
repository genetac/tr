import {publicMenuItem} from "@/lib/public-menu";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const s = await getSettings();
  const categories = await db.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: {
      items: { where: { active: true }, orderBy: { sortOrder: "asc" } },
    },
  });
  const activeCats = categories.filter((c) => c.active).map(c=>({...c,items:c.items.map(item=>publicMenuItem(item,s.dietaryDisplay))}));
  return NextResponse.json({ settings: publicSettings(s), categories: activeCats });
}
