import { NextResponse } from "next/server";
import { getSettings } from "@/lib/settings";
import { stripeEnabled, paypalEnabled } from "@/lib/payments";
import { resolvePricing } from "@/lib/locations";

export const dynamic = "force-dynamic";

/**
 * Public payment/store configuration for guest-facing pages.
 * Returns only non-sensitive data — publishable/secret keys never leave the server
 * (PayPal needs its client id client-side, which is public by design).
 * PVM / delivery fee reflect the default branch's overrides when present.
 */
export async function GET() {
  const s = await getSettings();
  const pricing = await resolvePricing();
  return NextResponse.json({
    restaurantName: s.store.restaurantName,
    isOpen: s.store.isOpen,
    pickupEnabled: s.pickup.enabled,
    currency: s.store.currency,
    taxRate: pricing.taxRate,
    deliveryFee: pricing.deliveryFee,
    stripeEnabled: stripeEnabled(s.store),
    paypalEnabled: paypalEnabled(s.store),
    paypalClientId: paypalEnabled(s.store) ? s.store.paypalClientId : null,
    paypalSandbox: s.store.paypalSandbox,
  });
}
