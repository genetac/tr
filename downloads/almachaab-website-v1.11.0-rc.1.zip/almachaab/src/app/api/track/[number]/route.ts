import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { STATUS_LT } from "@/lib/orders";
import { authorizeTrackLimited, trackFailSweep, TRACK_RATE_MESSAGE } from "@/lib/track-auth";
import { clientIp } from "@/lib/auth";
import { getCurrentUser } from "@/lib/userauth";

export const dynamic = "force-dynamic";

/** Matches "AC-1042" and the bare "1042" form (any prefix). */
function lookupWhere(clean: string) {
  if (/^[A-Z]+-/.test(clean)) {
    const bare = clean.replace(/^[A-Z]+-?/, "");
    return bare ? { OR: [{ number: clean }, { number: { equals: bare } }] } : { number: clean };
  }
  // Bare digits: exact (unlikely) or any prefix ending with these digits.
  return { OR: [{ number: clean }, { number: { endsWith: clean } }] };
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ number: string }> }) {
  const { number } = await ctx.params;
  const clean = number.trim().toUpperCase().replace(/^#/, "");
  const order = await db.order.findFirst({
    where: lookupWhere(clean),
    select: {
      id: true, userId: true, number: true, trackToken: true, phone: true, type: true, status: true, total: true,
      paymentStatus: true, paymentMethod: true, pickupTime: true, resDate: true, resTime: true,
      guests: true, itemsJson: true, createdAt: true, updatedAt: true, prepMinutes: true, prepSetAt: true,
      historyJson: true,
    },
  });
  if (!order) return NextResponse.json({ error: "Tokio užsakymo nerasta." }, { status: 404 });

  // Sequential order numbers are guessable — require the emailed tracking
  // token or the last 4 phone digits (review fix #3). The signed-in customer
  // who owns the order is always allowed (A1) — no token needed on /mano.
  const ip = clientIp(req.headers);
  const t = req.nextUrl.searchParams.get("t");
  const p4 = req.nextUrl.searchParams.get("p4");
  const user = await getCurrentUser();
  const isOwner = Boolean(user && order.userId && order.userId === user.id);
  if (!isOwner) {
    trackFailSweep();
    const verdict = authorizeTrackLimited(order, t, p4, ip);
    if (verdict === "limited") return NextResponse.json({ error: TRACK_RATE_MESSAGE }, { status: 429 });
    if (verdict === "forbidden") {
      return NextResponse.json(
        { error: "Neteisingas patvirtinimas — naudokite laiške gautą nuorodą arba įveskite paskutinius 4 telefono skaitmenis." },
        { status: 403 }
      );
    }
  }

  const items = JSON.parse(order.itemsJson || "[]");

  // Live ready-time: prep time set from the admin Skydelis board
  let readyAt: string | null = null;
  let prepMinutesLeft: number | null = null;
  if (order.prepMinutes && order.prepSetAt) {
    const ready = new Date(order.prepSetAt.getTime() + order.prepMinutes * 60_000);
    readyAt = ready.toISOString();
    prepMinutesLeft = Math.max(0, Math.ceil((ready.getTime() - Date.now()) / 60_000));
  }

  // NOTE: customer name is intentionally NOT returned to the public API.
  return NextResponse.json({
    number: order.number,
    type: order.type,
    status: order.status,
    statusLabel: STATUS_LT[order.status] || order.status,
    total: order.total,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod,
    pickupTime: order.pickupTime,
    resDate: order.resDate,
    resTime: order.resTime,
    guests: order.guests,
    items,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    readyAt,
    prepMinutesLeft,
    history: JSON.parse(order.historyJson || "[]").map((h: { status: string; at: string }) => ({
      status: h.status,
      label: STATUS_LT[h.status] || h.status,
      at: h.at,
    })),
  });
}
