import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { orderBus, type OrderEvent } from "@/lib/events";
import { authorizeTrackLimited, trackFailSweep, TRACK_RATE_MESSAGE } from "@/lib/track-auth";
import { clientIp } from "@/lib/auth";
import { getCurrentUser } from "@/lib/userauth";

export const dynamic = "force-dynamic";

/**
 * SSE feed for a single order — powers the live customer tracking view
 * (/mano, formerly /sekti). Requires the same authorization as
 * /api/track/[number]: the order's tracking token or the last 4 phone digits.
 */
export async function GET(req: NextRequest, ctx: { params: Promise<{ number: string }> }) {
  const { number } = await ctx.params;
  const clean = number.trim().toUpperCase().replace(/^#/, "");
  if (!clean) return NextResponse.json({ error: "bad-number" }, { status: 400 });

  // Matches "AC-1042" and the bare "1042" form, same as the track API.
  const order = await db.order.findFirst({
    where: /^[A-Z]+-/.test(clean)
      ? { OR: [{ number: clean }, { number: { equals: clean.replace(/^[A-Z]+-?/, "") } }] }
      : { OR: [{ number: clean }, { number: { endsWith: clean } }] },
    select: { id: true, userId: true, number: true, trackToken: true, phone: true },
  });
  if (!order) return NextResponse.json({ error: "not-found" }, { status: 404 });
  // Same authorization as the track API — token, phone last 4, or the
  // signed-in owner (A1). Failed p4 guesses are rate-limited (A2).
  const ip = clientIp(req.headers);
  const t = req.nextUrl.searchParams.get("t");
  const p4 = req.nextUrl.searchParams.get("p4");
  const user = await getCurrentUser();
  const isOwner = Boolean(user && order.userId && order.userId === user.id);
  if (!isOwner) {
    trackFailSweep();
    const verdict = authorizeTrackLimited(order, t, p4, ip);
    if (verdict === "limited") return NextResponse.json({ error: TRACK_RATE_MESSAGE }, { status: 429 });
    if (verdict === "forbidden") return NextResponse.json({ error: "unauthorized" }, { status: 403 });
  }

  // Matches "AC-1042" and bare "1042" forms, same as the track API.
  const match = (evNumber: string) =>
    evNumber === clean || evNumber.replace(/^[A-Z]+-?/, "") === clean.replace(/^[A-Z]+-?/, "");

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      const send = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      send("retry: 3000\n\n");
      send(`event: ready\ndata: {"number":"${clean}"}\n\n`);

      const onOrder = (ev: OrderEvent) => {
        if (match(ev.number)) send(`event: order\ndata: ${JSON.stringify(ev)}\n\n`);
      };
      orderBus().on("order", onOrder);

      const heartbeat = setInterval(() => send(`: ping\n\n`), 25_000);

      const close = () => {
        if (closed) return;
        closed = true;
        clearInterval(heartbeat);
        orderBus().off("order", onOrder);
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      req.signal.addEventListener("abort", close);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
