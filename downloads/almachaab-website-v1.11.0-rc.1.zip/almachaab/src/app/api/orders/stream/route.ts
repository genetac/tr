import { NextRequest, NextResponse } from "next/server";
import { can, verifyAdminToken } from "@/lib/auth";
import { orderBus, type OrderEvent } from "@/lib/events";

export const dynamic = "force-dynamic";

/**
 * Server-Sent Events feed of every order change — the real-time backbone of
 * the Kitchen Display System (admin Skydelis tab). A customer checkout, a kitchen
 * status change or a payment webhook here becomes an instant update there.
 *
 * Auth: admin session cookie, or `?token=` fallback (EventSource cannot send
 * custom headers, and some browser contexts block cookies).
 */
export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token");
  const authed =
    (await can("orders")) || (token ? await verifyAdminToken(token) : false);
  if (!authed) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      const send = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      send("retry: 3000\n\n");
      send(`event: ready\ndata: {"ok":true}\n\n`);

      const onOrder = (ev: OrderEvent) => {
        send(`event: order\ndata: ${JSON.stringify(ev)}\n\n`);
      };
      orderBus().on("order", onOrder);

      // Heartbeat keeps proxies from closing the idle connection.
      const heartbeat = setInterval(() => send(`: ping\n\n`), 25_000);

      const close = () => {
        if (closed) return;
        closed = true;
        clearInterval(heartbeat);
        orderBus().off("order", onOrder);
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      req.signal.addEventListener("abort", close);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
