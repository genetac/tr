import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { nextOrderNumber, priceCart, pushHistory, computeTotals, STATUS_LT } from "@/lib/orders";
import { emailOrderEvent, emailReservationEvent, notifyRestaurant } from "@/lib/mail";
import { sendPushToAll } from "@/lib/push";
import { getCurrentUser } from "@/lib/userauth";
import { publishOrderEvent } from "@/lib/events";
import { resolvePricing } from "@/lib/locations";
import { newTrackToken } from "@/lib/track-auth";
import { clientIp } from "@/lib/auth";
import { rateLimit, rateLimitSweep } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

interface Payload {
  type?: "pickup" | "reservation";
  customerName?: string;
  phone?: string;
  email?: string;
  items?: { id: string; qty: number }[];
  pickupTime?: string;
  resDate?: string;
  resTime?: string;
  guests?: number;
  experiences?: string;
  note?: string;
  /** Honeypot (v1.4 §F): hidden form field — humans leave it empty. */
  company?: string;
}

function baseUrlFrom(req: NextRequest) {
  return siteBaseUrl(req); // SEC-016: never from Host / X-Forwarded-Host
}

export async function POST(req: NextRequest) {
  // F: per-IP order cap — 10 orders per 10 minutes per client IP.
  const ip = clientIp(req.headers);
  rateLimitSweep();
  const rl = rateLimit(`orders|${ip}`, 10, 10 * 60_000);
  if (rl.limited) {
    return NextResponse.json(
      { error: `Per daug užsakymų iš vieno įrenginio. Pabandykite po ${Math.ceil(rl.retryAfterSec / 60)} min. arba paskambinkite mums.` },
      { status: 429 }
    );
  }

  let p: Payload;
  try {
    p = await req.json();
  } catch {
    return NextResponse.json({ error: "Netinkama užklausos forma." }, { status: 400 });
  }

  // F: honeypot — the hidden “company” input is filled only by bots.
  // Reply with a generic error (never reveal which check failed).
  if ((p.company || "").trim() !== "") {
    return NextResponse.json({ error: "Netinkama užklausos forma." }, { status: 400 });
  }

  const type = p.type === "reservation" ? "reservation" : "pickup";
  const name = String(p.customerName || "").trim().slice(0, 80); // SEC-015: bounded lengths
  const phone = String(p.phone || "").trim().slice(0, 30);
  const email = String(p.email || "").trim().slice(0, 120);

  if (name.length < 2) return NextResponse.json({ error: "Įveskite vardą." }, { status: 400 });
  if (phone.replace(/\D/g, "").length < 8) return NextResponse.json({ error: "Įveskite tikrą telefono numerį." }, { status: 400 });
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return NextResponse.json({ error: "Netinkamas el. pašto adresas." }, { status: 400 });

  const s = await getSettings();

  // Store-closed override — the admin can stop all incoming orders instantly.
  if (!s.store.isOpen) {
    return NextResponse.json(
      { error: "Šiuo metu nepriimame užsakymų — paskambinkite mums telefonu." },
      { status: 503 }
    );
  }

  // Price cart server-side (also rejects 86'd / sold-out items)
  const { clean, total, soldOut } = await priceCart(Array.isArray(p.items) ? p.items.slice(0, 100) : []); // SEC-015
  if (soldOut.length > 0) {
    return NextResponse.json(
      { error: `Šie patiekalai jau išparduoti: ${soldOut.join(", ")}. Pašalinkite juos iš krepšelio.` },
      { status: 409 }
    );
  }
  // Server-authoritative totals: subtotal + PVM + delivery fee.
  // PVM/fee come from the default branch when it overrides the global values.
  const pricing = await resolvePricing();
  const totals = computeTotals(total, { taxRate: pricing.taxRate, deliveryFee: pricing.deliveryFee });

  // Type-specific validation
  let pickupTime = "";
  let resDate = "";
  let resTime = "";
  let guests = 0;
  let experiences = "";

  if (type === "pickup") {
    pickupTime = (p.pickupTime || "").trim();
    if (!/^\d{2}:\d{2}$/.test(pickupTime)) return NextResponse.json({ error: "Pasirinkite atsiėmimo laiką." }, { status: 400 });
  } else {
    resDate = (p.resDate || "").trim();
    resTime = (p.resTime || "").trim();
    guests = Math.max(1, Math.min(80, Math.floor(Number(p.guests) || 0)));
    experiences = String(p.experiences || "").trim().slice(0, 300);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(resDate)) return NextResponse.json({ error: "Pasirinkite rezervacijos datą." }, { status: 400 });
    if (!/^\d{2}:\d{2}$/.test(resTime)) return NextResponse.json({ error: "Pasirinkite rezervacijos laiką." }, { status: 400 });
    if (!guests) return NextResponse.json({ error: "Pasirinkite svečių skaičių." }, { status: 400 });
  }

  const number = await nextOrderNumber();
  const user = await getCurrentUser();
  const order = await db.order.create({
    data: {
      number,
      trackToken: newTrackToken(),
      type,
      status: "new",
      customerName: name,
      phone,
      email,
      itemsJson: JSON.stringify(clean),
      total: totals.total,
      taxAmount: totals.tax,
      pickupTime,
      resDate,
      resTime,
      guests,
      experiences,
      note: String(p.note || "").slice(0, 1000),
      historyJson: JSON.stringify([{ status: "new", at: new Date().toISOString() }]),
      userId: user?.id || null,
      locationId: pricing.locationId,
    },
  });

  // Instant fan-out: kitchen display + tracking page update without polling delay
  publishOrderEvent({
    type: "created",
    orderId: order.id,
    number: order.number,
    status: order.status,
    paymentStatus: order.paymentStatus,
  });

  // Fire-and-forget emails
  const baseUrl = baseUrlFrom(req);
  const emailResults: Record<string, unknown> = {};
  if (type === "pickup") {
    emailResults.customer = await emailOrderEvent(order, "received", baseUrl);
  } else {
    emailResults.customer = await emailReservationEvent(order, "received", baseUrl);
  }
  emailResults.restaurant = await notifyRestaurant(order, baseUrl);
  await db.order.update({
    where: { id: order.id },
    data: { historyJson: pushHistory(order, "new", { emails: emailResults }) },
  });

  // Fire-and-forget push notification to every owner device ("incoming call" style).
  // Not awaited so the customer's response stays instant.
  const pushBody =
    type === "pickup"
      ? `${name} · ${total > 0 ? total.toFixed(2).replace(".", ",") + " €" : ""} · atsiėmimas ${pickupTime}`
      : `${name} · ${guests} svečias(-ai) · ${resDate} ${resTime}`;
  sendPushToAll({
    title: `🔔 Naujas ${type === "pickup" ? "užsakymas" : "rezervacija"} #${number}`,
    body: pushBody,
    tag: "alma-new-order",
    url: "/admin",
    orderId: order.id,
  })
    .then((r) =>
      db.order
        .update({ where: { id: order.id }, data: { historyJson: pushHistory(order, "new", { push: r }) } })
        .catch(() => {})
    )
    .catch(() => {});

  return NextResponse.json({
    ok: true,
    number: order.number,
    trackToken: order.trackToken,
    status: STATUS_LT[order.status],
    total: order.total,
    tax: totals.tax,
    subtotal: totals.subtotal,
    type: order.type,
  });
}
