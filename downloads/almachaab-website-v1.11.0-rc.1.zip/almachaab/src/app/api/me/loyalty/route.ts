import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/userauth";
import { getLoyaltyConfig } from "@/lib/loyalty";

export const dynamic = "force-dynamic";

/** The signed-in customer's loyalty card: balance, stamps, rewards, vouchers, ledger. */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const cfg = await getLoyaltyConfig();
  const profile = await db.loyaltyProfile.findUnique({ where: { userId: user.id } });

  const [rewards, redemptions, transactions] = await Promise.all([
    db.reward.findMany({ where: { active: true }, orderBy: [{ pointsCost: "asc" }, { createdAt: "asc" }] }),
    profile
      ? db.rewardRedemption.findMany({
          where: { profileId: profile.id },
          orderBy: { createdAt: "desc" },
          take: 20,
          include: { reward: { select: { name: true } } },
        })
      : Promise.resolve([]),
    profile
      ? db.loyaltyTransaction.findMany({ where: { profileId: profile.id }, orderBy: { createdAt: "desc" }, take: 20 })
      : Promise.resolve([]),
  ]);

  return NextResponse.json({
    enabled: cfg.enabled,
    stampGoal: cfg.stampGoal,
    pointsPerEuro: cfg.pointsPerEuro,
    profile: profile
      ? {
          points: profile.points,
          lifetimePoints: profile.lifetimePoints,
          stamps: profile.stamps,
          totalStamps: profile.totalStamps,
        }
      : null,
    rewards: rewards.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      pointsCost: r.pointsCost,
      affordable: (profile?.points || 0) >= r.pointsCost,
    })),
    redemptions: redemptions.map((r) => ({
      id: r.id,
      code: r.code,
      status: r.status,
      pointsSpent: r.pointsSpent,
      rewardName: r.reward.name,
      createdAt: r.createdAt,
      usedAt: r.usedAt,
    })),
    transactions: transactions.map((t) => ({
      id: t.id,
      type: t.type,
      points: t.points,
      note: t.note,
      createdAt: t.createdAt,
    })),
  });
}
