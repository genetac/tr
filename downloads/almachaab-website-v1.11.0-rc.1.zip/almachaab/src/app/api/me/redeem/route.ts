import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/userauth";
import { redeemReward } from "@/lib/loyalty";
import { sendPushToUser } from "@/lib/push";

export const dynamic = "force-dynamic";

/** Spend loyalty points on a reward → unique voucher code. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const rewardId = String(b.rewardId || "");
  if (!rewardId) return NextResponse.json({ error: "Pasirinkite prizą." }, { status: 400 });

  try {
    const redemption = await redeemReward(user.id, rewardId);
    // Confirm the spend with a push when the customer opted in.
    sendPushToUser(user.id, {
      title: "Prizas iškeistas ✓",
      body: `${redemption.code} — parodykite šį kodą atsiėmimo metu.`,
      tag: "alma-reward",
      url: "/mano",
    }).catch(() => {});
    return NextResponse.json({ ok: true, redemption });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Iškeisti nepavyko." }, { status: 400 });
  }
}
