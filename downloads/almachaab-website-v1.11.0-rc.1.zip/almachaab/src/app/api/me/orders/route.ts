import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/userauth";
import { STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

/** Order history for the signed-in customer (newest first, 50 latest). */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const orders = await db.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { location: { select: { name: true } } },
  });

  return NextResponse.json({
    orders: orders.map((o) => ({
      number: o.number,
      // Owner-scoped endpoint — the customer may deep-link their own order
      // into the tracker (/mano?nr=…&t=…) without typing the phone digits.
      trackToken: o.trackToken,
      type: o.type,
      status: o.status,
      statusLabel: STATUS_LT[o.status] || o.status,
      paymentStatus: o.paymentStatus,
      paymentMethod: o.paymentMethod,
      total: o.total,
      taxAmount: o.taxAmount,
      locationName: o.location?.name || "",
      items: JSON.parse(o.itemsJson || "[]"),
      pickupTime: o.pickupTime,
      resDate: o.resDate,
      resTime: o.resTime,
      guests: o.guests,
      createdAt: o.createdAt,
    })),
  });
}
