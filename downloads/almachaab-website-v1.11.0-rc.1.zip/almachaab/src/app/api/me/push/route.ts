import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/userauth";
import { ensureVapid } from "@/lib/push";

export const dynamic = "force-dynamic";

interface SubJSON {
  endpoint?: string;
  keys?: { p256dh?: string; auth?: string };
}

/**
 * Customer marketing-push opt-in (loyalty award confirmations + win-back
 * campaigns). Separate from the owner's /api/admin/push — subscriptions are
 * stored with audience="customer" and linked to the signed-in account.
 */

/** GET → VAPID public key + whether this browser's endpoint is already saved. */
export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { publicKey } = await ensureVapid();
  const endpoint = new URL(req.url).searchParams.get("endpoint") || "";
  const subscribed = endpoint ? await db.pushSubscription.findFirst({ where: { endpoint, userId: user.id, audience: "customer" } }) : null;
  return NextResponse.json({ publicKey, subscribed: Boolean(subscribed) });
}

/** POST → save/refresh this device as a customer-marketing subscription. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const sub = (body.subscription || {}) as SubJSON;
  const endpoint = sub.endpoint || "";
  const p256dh = sub.keys?.p256dh || "";
  const auth = sub.keys?.auth || "";
  if (!endpoint.startsWith("https://") || !p256dh || !auth) {
    return NextResponse.json({ error: "invalid-subscription" }, { status: 400 });
  }
  await db.pushSubscription.upsert({
    where: { endpoint },
    update: { p256dh, auth, userId: user.id, audience: "customer" },
    create: { endpoint, p256dh, auth, userId: user.id, audience: "customer", label: (user.name || user.email).slice(0, 60) },
  });
  return NextResponse.json({ ok: true });
}

/** DELETE → unsubscribe this device from marketing push. */
export async function DELETE(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const endpoint = String(body.endpoint || "");
  if (!endpoint) return NextResponse.json({ error: "missing-endpoint" }, { status: 400 });
  await db.pushSubscription.deleteMany({ where: { endpoint, userId: user.id, audience: "customer" } });
  return NextResponse.json({ ok: true });
}
