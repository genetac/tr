import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import Stripe from "stripe";
import { getStoreSettings } from "@/lib/settings";
import { markOrderPaid } from "@/lib/fulfill";

export const dynamic = "force-dynamic";

/**
 * Stripe webhook receiver. Verifies the signature with the admin-configured
 * webhook secret, then fulfils the order: paymentStatus=paid, status jumps to
 * "confirmed" (kitchen starts immediately), SSE event fans out to the kitchen
 * display and tracking view.
 *
 * Setup: in the Stripe dashboard add an endpoint pointing here with the
 * "checkout.session.completed" event and paste the signing secret into
 * /admin → Nustatymai → Mokėjimai.
 */
export async function POST(req: NextRequest) {
  const store = await getStoreSettings();
  if (!store.stripeSecretKey || !store.stripeWebhookSecret) {
    return NextResponse.json({ error: "Webhook nesukonfigūruotas." }, { status: 400 });
  }

  const signature = req.headers.get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Nėra parašo." }, { status: 400 });

  const raw = await req.text();
  const stripe = new Stripe(store.stripeSecretKey);

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(raw, signature, store.stripeWebhookSecret);
  } catch (err) {
    console.error("stripe webhook signature verification failed", err);
    return NextResponse.json({ error: "Netinkamas parašas." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const orderId = session.metadata?.orderId;
    if (orderId) {
      await markOrderPaid(orderId, { method: "stripe", ref: session.id, baseUrl: siteBaseUrl(req) }); // SEC-016
    }
  }

  // Other event types are acknowledged so Stripe stops retrying them.
  return NextResponse.json({ received: true });
}
