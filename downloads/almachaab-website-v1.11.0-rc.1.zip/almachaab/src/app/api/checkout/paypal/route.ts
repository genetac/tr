import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { db } from "@/lib/db";
import { getStoreSettings, } from "@/lib/settings";
import { paypalEnabled, paypalCreateOrder } from "@/lib/payments";
import { prepareOnlineOrder, type OnlineCheckoutInput } from "@/lib/checkout";
import { publishOrderEvent } from "@/lib/events";

export const dynamic = "force-dynamic";

/**
 * Creates a PayPal order (REST v2) for a pickup order or reservation paid
 * with the admin-configured PayPal credentials. Returns the PayPal order id
 * for the client-side Smart Payment Buttons; capture happens server-side in
 * /api/checkout/paypal/capture.
 */
export async function POST(req: NextRequest) {
  let body: OnlineCheckoutInput;
  try {
    body = (await req.json()) as OnlineCheckoutInput;
  } catch {
    return NextResponse.json({ error: "Netinkama užklausos forma." }, { status: 400 });
  }

  const prepared = await prepareOnlineOrder(body);
  if ("error" in prepared) return NextResponse.json({ error: prepared.error }, { status: prepared.status });

  const store = await getStoreSettings();
  if (!paypalEnabled(store)) {
    return NextResponse.json({ error: "PayPal mokėjimai dar nesukonfigūruoti." }, { status: 400 });
  }
  const { order, totals, clean } = prepared;

  const baseUrl = siteBaseUrl(req); // SEC-016

  try {
    const paypalOrderId = await paypalCreateOrder(store, {
      orderId: order.id,
      orderNumber: order.number,
      items: clean,
      currency: store.currency,
      subtotal: totals.subtotal,
      tax: totals.tax,
      deliveryFee: totals.deliveryFee,
      total: totals.total,
      baseUrl,
    });

    await db.order.update({
      where: { id: order.id },
      data: { paymentMethod: "paypal", paymentRef: paypalOrderId },
    });

    publishOrderEvent({
      type: "created",
      orderId: order.id,
      number: order.number,
      status: order.status,
      paymentStatus: "unpaid",
    });

    return NextResponse.json({ ok: true, paypalOrderId, number: order.number, trackToken: order.trackToken });
  } catch (err) {
    console.error("paypal create failed", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "PayPal klaida." }, { status: 502 });
  }
}
