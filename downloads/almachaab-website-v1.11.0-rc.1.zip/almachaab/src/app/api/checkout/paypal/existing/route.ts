import { NextRequest, NextResponse } from "next/server";
import { authorizeOrderAccess, ORDER_ACCESS_DENIED } from "@/lib/order-access";
import { TRACK_RATE_MESSAGE } from "@/lib/track-auth";
import { getUnpaidOrderByNumber, pushHistory } from "@/lib/checkout";
import { paypalEnabled, paypalCreateOrder, type PaypalCreateInput } from "@/lib/payments";
import { db } from "@/lib/db";
import { publishOrderEvent } from "@/lib/events";

export const dynamic = "force-dynamic";

/**
 * Creates a PayPal order for an EXISTING unpaid order (pay-later from
 * /mano or the tracking card). The stored order row is the single source
 * of truth for items and amounts — nothing is recomputed from the client.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { number?: string; t?: string; p4?: string };
  const found = await getUnpaidOrderByNumber(String(body.number || ""));
  if ("error" in found) return NextResponse.json({ error: found.error }, { status: found.status });

  const { order, store } = found;
  // SEC-010: same authorisation as order tracking — never a bare number.
  const access = await authorizeOrderAccess(req, order, body);
  if (access === "limited") return NextResponse.json({ error: TRACK_RATE_MESSAGE }, { status: 429 });
  if (access !== "ok") return NextResponse.json({ error: ORDER_ACCESS_DENIED }, { status: 403 });
  if (!paypalEnabled(store)) {
    return NextResponse.json({ error: "PayPal mokėjimai dar nesukonfigūruoti." }, { status: 400 });
  }

  const items = JSON.parse(order.itemsJson || "[]") as { name: string; price: number; qty: number }[];
  const subtotal = Math.round(items.reduce((s, i) => s + i.price * i.qty, 0) * 100) / 100;

  const input: PaypalCreateInput = {
    orderId: order.id,
    orderNumber: order.number,
    items,
    currency: store.currency,
    subtotal,
    tax: order.taxAmount,
    deliveryFee: 0,
    total: order.total,
    baseUrl: "",
  };

  try {
    const paypalOrderId = await paypalCreateOrder(store, input);
    await db.order.update({
      where: { id: order.id },
      data: {
        paymentMethod: "paypal",
        paymentRef: paypalOrderId,
        historyJson: pushHistory(order, order.status, { by: "paylater", label: "Pradėtas PayPal apmokėjimas" }),
      },
    });
    publishOrderEvent({
      type: "created",
      orderId: order.id,
      number: order.number,
      status: order.status,
      paymentStatus: "unpaid",
    });
    return NextResponse.json({ ok: true, paypalOrderId, number: order.number });
  } catch (err) {
    console.error("paypal existing create failed", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "PayPal klaida." }, { status: 502 });
  }
}
