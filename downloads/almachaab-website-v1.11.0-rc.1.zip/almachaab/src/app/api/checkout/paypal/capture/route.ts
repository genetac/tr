import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { db } from "@/lib/db";
import { getStoreSettings } from "@/lib/settings";
import { paypalEnabled, paypalCaptureOrder } from "@/lib/payments";
import { markOrderPaid } from "@/lib/fulfill";
import { STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

/**
 * Captures an approved PayPal payment server-side and fulfils the order.
 * Our internal order id is resolved from up to two sources:
 *   1. the capture response's custom_id (PayPal echoes it — inconsistently),
 *   2. our own DB: Order.paymentRef was stored at create time, so the
 *      PayPal order id alone is always enough to find the row.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const paypalOrderId = String(body.paypalOrderId || "").trim();
  if (!paypalOrderId) return NextResponse.json({ error: "Trūksta PayPal užsakymo id." }, { status: 400 });

  const store = await getStoreSettings();
  if (!paypalEnabled(store)) return NextResponse.json({ error: "PayPal mokėjimai nesukonfigūruoti." }, { status: 400 });

  // DB-derived fallback — the authoritative mapping we stored at create time.
  const mapped = await db.order
    .findFirst({ where: { paymentRef: paypalOrderId }, select: { id: true, number: true } })
    .catch(() => null);

  try {
    const capture = await paypalCaptureOrder(store, paypalOrderId, mapped?.id || "");
    if (!capture.orderId) {
      console.error("paypal capture: no order mapping", { paypalOrderId, mapped: mapped?.id || null });
      return NextResponse.json({ error: "PayPal grąžino be mūsų užsakymo nuorodos." }, { status: 502 });
    }
    const result = await markOrderPaid(capture.orderId, {
      method: "paypal",
      ref: capture.captureId || paypalOrderId,
      baseUrl: siteBaseUrl(req), // SEC-016
    });
    if (!result.ok) return NextResponse.json({ error: "Užsakymas nerastas." }, { status: 404 });

    return NextResponse.json({
      ok: true,
      number: result.number,
      trackToken: result.trackToken ?? "",
      status: result.status,
      statusLabel: STATUS_LT[result.status || "confirmed"],
      alreadyPaid: Boolean(result.alreadyPaid),
    });
  } catch (err) {
    console.error("paypal capture failed", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "PayPal klaida." }, { status: 502 });
  }
}
