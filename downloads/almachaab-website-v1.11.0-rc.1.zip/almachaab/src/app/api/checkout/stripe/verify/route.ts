import { NextRequest, NextResponse } from "next/server";
import { authorizeOrderAccess, ORDER_ACCESS_DENIED } from "@/lib/order-access";
import { TRACK_RATE_MESSAGE } from "@/lib/track-auth";
import { db } from "@/lib/db";
import { getStripeClient } from "@/lib/payments";
import { markOrderPaid } from "@/lib/fulfill";
import { STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

/**
 * Belt-and-braces for the Stripe redirect flow: the customer lands back on
 * the site before (or without) the webhook firing — e.g. in local development.
 * If the session is actually paid, the order is fulfilled right here.
 */
export async function GET(req: NextRequest) {
  const number = (req.nextUrl.searchParams.get("number") || "").trim().toUpperCase();
  if (!number) return NextResponse.json({ error: "bad-number" }, { status: 400 });

  const order = await db.order.findFirst({
    where: { OR: [{ number }, { number: number.replace(/^[A-Z]+-?/, "") }] },
  });
  if (!order) return NextResponse.json({ error: "Užsakymas nerastas." }, { status: 404 });
  // SEC-010: status / payment state only with the tracking token, p4 or as owner.
  const access = await authorizeOrderAccess(req, order);
  if (access === "limited") return NextResponse.json({ error: TRACK_RATE_MESSAGE }, { status: 429 });
  if (access !== "ok") return NextResponse.json({ error: ORDER_ACCESS_DENIED }, { status: 403 });

  if (order.paymentStatus === "paid") {
    return NextResponse.json({ paid: true, number: order.number, status: order.status, statusLabel: STATUS_LT[order.status] });
  }
  if (order.paymentMethod !== "stripe" || !order.paymentRef) {
    return NextResponse.json({ paid: false, number: order.number, status: order.status, statusLabel: STATUS_LT[order.status] });
  }

  const client = await getStripeClient();
  if (!client) return NextResponse.json({ error: "Mokėjimai nesukonfigūruoti." }, { status: 400 });

  try {
    const session = await client.stripe.checkout.sessions.retrieve(order.paymentRef);
    if (session.payment_status === "paid" || session.payment_status === "no_payment_required") {
      await markOrderPaid(order.id, { method: "stripe", ref: session.id });
      return NextResponse.json({ paid: true, number: order.number, status: "confirmed", statusLabel: STATUS_LT["confirmed"] });
    }
    return NextResponse.json({ paid: false, number: order.number, status: order.status, statusLabel: STATUS_LT[order.status] });
  } catch {
    return NextResponse.json({ error: "Nepavyko patikrinti apmokėjimo." }, { status: 502 });
  }
}
