import { NextRequest, NextResponse } from "next/server";
import { authorizeOrderAccess, ORDER_ACCESS_DENIED } from "@/lib/order-access";
import { TRACK_RATE_MESSAGE } from "@/lib/track-auth";
import { siteBaseUrl } from "@/lib/base-url";
import { getUnpaidOrderByNumber, pushHistory } from "@/lib/checkout";
import { getStripeClient } from "@/lib/payments";
import { db } from "@/lib/db";
import { publishOrderEvent } from "@/lib/events";

export const dynamic = "force-dynamic";

/**
 * Creates a Stripe Checkout Session for an EXISTING unpaid order
 * (pay-later from /mano). The stored order row is the single source of
 * truth for items and amounts. The customer returns to /mano.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { number?: string; t?: string; p4?: string };
  const found = await getUnpaidOrderByNumber(String(body.number || ""));
  if ("error" in found) return NextResponse.json({ error: found.error }, { status: found.status });

  const { order, store } = found;
  // SEC-010: same authorisation as order tracking — never a bare number.
  const access = await authorizeOrderAccess(req, order, body);
  if (access === "limited") return NextResponse.json({ error: TRACK_RATE_MESSAGE }, { status: 429 });
  if (access !== "ok") return NextResponse.json({ error: ORDER_ACCESS_DENIED }, { status: 403 });
  const client = await getStripeClient();
  if (!client) {
    return NextResponse.json({ error: "Mokėjimai kortelemis dar nesukonfigūruoti." }, { status: 400 });
  }
  const { stripe } = client;

  const items = JSON.parse(order.itemsJson || "[]") as { name: string; price: number; qty: number }[];
  const currency = store.currency.toLowerCase();
  const lineItems = items.map((i) => ({
    price_data: {
      currency,
      product_data: { name: i.name.slice(0, 120) },
      unit_amount: Math.round(i.price * 100),
    },
    quantity: i.qty,
  }));
  if (order.taxAmount > 0) {
    lineItems.push({
      price_data: {
        currency,
        product_data: { name: `PVM ${store.taxRate}%` },
        unit_amount: Math.round(order.taxAmount * 100),
      },
      quantity: 1,
    });
  }

  const baseUrl = siteBaseUrl(req); // SEC-016

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: lineItems,
      success_url: `${baseUrl}/mano?paid=${encodeURIComponent(order.number)}&t=${encodeURIComponent(order.trackToken)}`,
      cancel_url: `${baseUrl}/mano?cancelled=${encodeURIComponent(order.number)}&t=${encodeURIComponent(order.trackToken)}`,
      client_reference_id: order.number,
      metadata: { orderId: order.id, orderNumber: order.number },
      ...(order.email ? { customer_email: order.email } : {}),
      locale: "lt",
    });
    await db.order.update({
      where: { id: order.id },
      data: {
        paymentMethod: "stripe",
        paymentRef: session.id,
        historyJson: pushHistory(order, order.status, { by: "paylater", label: "Pradėtas apmokėjimas kortele" }),
      },
    });
    publishOrderEvent({
      type: "created",
      orderId: order.id,
      number: order.number,
      status: order.status,
      paymentStatus: "unpaid",
    });
    return NextResponse.json({ ok: true, url: session.url, number: order.number });
  } catch (err) {
    console.error("stripe existing checkout failed", err);
    return NextResponse.json({ error: "Stripe klaida — patikrinkite nustatymuose suvestus raktus." }, { status: 502 });
  }
}
