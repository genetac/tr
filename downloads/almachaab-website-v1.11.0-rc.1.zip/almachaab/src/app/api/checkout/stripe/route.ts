import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { db } from "@/lib/db";
import { getStripeClient } from "@/lib/payments";
import { prepareOnlineOrder, type OnlineCheckoutInput } from "@/lib/checkout";
import { publishOrderEvent } from "@/lib/events";

export const dynamic = "force-dynamic";

/**
 * Creates a Stripe Checkout Session for a pickup order or a reservation,
 * using the Stripe secret key stored in the admin Settings singleton
 * (not env vars). The order is created first (awaiting / unpaid); the
 * webhook or the return-page verification marks it paid. The customer
 * returns to /mano — the merged tracking + account page.
 */
export async function POST(req: NextRequest) {
  let body: OnlineCheckoutInput;
  try {
    body = (await req.json()) as OnlineCheckoutInput;
  } catch {
    return NextResponse.json({ error: "Netinkama užklausos forma." }, { status: 400 });
  }

  const prepared = await prepareOnlineOrder(body);
  if ("error" in prepared) return NextResponse.json({ error: prepared.error }, { status: prepared.status });

  const client = await getStripeClient();
  if (!client) {
    // Roll the just-created order back to a plain unpaid record — it stays
    // visible for staff, who can confirm it manually as a pay-on-pickup order.
    return NextResponse.json({ error: "Mokėjimai kortelemis dar nesukonfigūruoti." }, { status: 400 });
  }
  const { stripe, store } = client;
  const { order, totals, clean } = prepared;

  const currency = store.currency.toLowerCase();
  const lineItems = [
    ...clean.map((i) => ({
      price_data: {
        currency,
        product_data: { name: i.name.slice(0, 120) },
        unit_amount: Math.round(i.price * 100),
      },
      quantity: i.qty,
    })),
  ];
  if (totals.tax > 0) {
    lineItems.push({
      price_data: {
        currency,
        product_data: { name: `PVM ${store.taxRate}%` },
        unit_amount: Math.round(totals.tax * 100),
      },
      quantity: 1,
    });
  }
  if (totals.deliveryFee > 0) {
    lineItems.push({
      price_data: {
        currency,
        product_data: { name: "Pristatymas" },
        unit_amount: Math.round(totals.deliveryFee * 100),
      },
      quantity: 1,
    });
  }

  const baseUrl = siteBaseUrl(req); // SEC-016

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: lineItems,
      success_url: `${baseUrl}/mano?paid=${encodeURIComponent(order.number)}&t=${encodeURIComponent(order.trackToken)}`,
      cancel_url: `${baseUrl}/mano?cancelled=${encodeURIComponent(order.number)}&t=${encodeURIComponent(order.trackToken)}`,
      client_reference_id: order.number,
      metadata: { orderId: order.id, orderNumber: order.number },
      ...(order.email ? { customer_email: order.email } : {}),
      locale: "lt",
    });

    await db.order.update({
      where: { id: order.id },
      data: { paymentMethod: "stripe", paymentRef: session.id },
    });

    publishOrderEvent({
      type: "created",
      orderId: order.id,
      number: order.number,
      status: order.status,
      paymentStatus: "unpaid",
    });

    return NextResponse.json({ ok: true, url: session.url, number: order.number });
  } catch (err) {
    console.error("stripe checkout failed", err);
    return NextResponse.json({ error: "Stripe klaida — patikrinkite nustatymuose suvestus raktus." }, { status: 502 });
  }
}
