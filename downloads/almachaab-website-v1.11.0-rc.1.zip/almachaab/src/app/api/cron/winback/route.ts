import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { runWinBackCampaign } from "@/lib/crm";
import { timingSafeEqual } from "crypto";

export const dynamic = "force-dynamic";

/**
 * Scheduled win-back trigger for the owner's server crontab, e.g. daily 11:00:
 *   curl -fsS -X POST -H "x-cron-secret: $CRON_SECRET" https://almachaab.lt/api/cron/winback
 * SEC-009: CRON_SECRET (≥ 24 chars) must be set in the server environment —
 * there is no fallback to the admin session secret, the value is accepted only
 * in a header (never the URL, which ends up in logs) and compared in constant time.
 */
async function guard(req: NextRequest): Promise<boolean> {
  const expected = (process.env.CRON_SECRET || "").trim();
  if (expected.length < 24) return false;
  const provided = (req.headers.get("x-cron-secret") || "").trim();
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

function baseUrlFrom(req: NextRequest) {
  return siteBaseUrl(req); // SEC-016: never from Host / X-Forwarded-Host
}

async function handle(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const result = await runWinBackCampaign({
    days: Math.max(1, Math.min(365, Math.floor(Number(url.searchParams.get("days")) || 14))),
    baseUrl: baseUrlFrom(req),
  });
  return NextResponse.json({ ok: true, at: new Date().toISOString(), ...result });
}

export async function POST(req: NextRequest) {
  return handle(req);
}

export async function GET(req: NextRequest) {
  return handle(req);
}
