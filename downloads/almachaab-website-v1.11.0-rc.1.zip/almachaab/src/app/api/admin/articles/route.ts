import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { slugify } from "@/lib/slug";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const articles = await db.article.findMany({ orderBy: { updatedAt: "desc" } });
  return NextResponse.json({ articles });
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const title = String(b.title || "").trim();
  if (!title) return NextResponse.json({ error: "Įveskite pavadinimą." }, { status: 400 });

  let slug = slugify(String(b.slug || "") || title) || "straipsnis";
  // Ensure uniqueness
  const taken = await db.article.findMany({ where: { slug: { startsWith: slug } }, select: { slug: true } });
  if (taken.some((t) => t.slug === slug)) {
    let i = 2;
    while (taken.some((t) => t.slug === `${slug}-${i}`)) i++;
    slug = `${slug}-${i}`;
  }

  const published = false; // New articles remain drafts until explicit CMS publication.
  const article = await db.article.create({
    data: {
      slug,
      title,
      excerpt: String(b.excerpt || ""),
      coverImage: String(b.coverImage || ""),
      keywords: String(b.keywords || ""),
      bodyJson: JSON.stringify(Array.isArray(b.body) ? b.body : []),
      published,
      publishedAt: published ? (b.publishedAt ? new Date(b.publishedAt) : new Date()) : null,
    },
  });
  return NextResponse.json({ ok: true, article });
}
