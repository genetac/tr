import {getDocument,saveDocument} from "@/lib/cms";
import {validateDocument} from "@/lib/cms-schema";
import {can,cmsActor} from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { slugify } from "@/lib/slug";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req:NextRequest,ctx:Ctx){
 if(!await can('content'))return NextResponse.json({error:'unauthorized'},{status:401});
 try{const {id}=await ctx.params;const key=`article:${id}`;const current=await getDocument(key);const b=await req.json();const value=validateDocument(key,{...current.draft,...b});
 if(b.mode==='publish'&&!await can('publish'))return NextResponse.json({error:'forbidden'},{status:403});
 const r=await saveDocument(key,value,b.revision??current.revision,b.mode==='publish'?'publish':'draft',await cmsActor(),async(tx,v)=>{await tx.article.update({where:{id},data:{title:v.title,slug:v.slug,excerpt:v.excerpt,coverImage:v.coverImage,keywords:v.keywords,bodyJson:JSON.stringify(v.body),published:v.published,publishedAt:v.published?new Date():null}});});return NextResponse.json({ok:true,article:r.draft,revision:r.revision});
 }catch(e:any){return NextResponse.json({error:e.message},{status:e.status||400});}
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const key=`article:${id}`;const doc=await getDocument(key);await saveDocument(key,{...doc.draft,published:false},doc.revision,"draft",await cmsActor());
  return NextResponse.json({ ok: true });
}
