import {NextRequest,NextResponse} from 'next/server';
import {can,cmsActor} from '@/lib/auth';
import {db} from '@/lib/db';
import {getDocument,saveDocument,documentHistory,pageRecords,CmsError} from '@/lib/cms';
import {validateDocument} from '@/lib/cms-schema';
import {randomUUID} from 'crypto';
export const dynamic='force-dynamic';
const keyPermission=(key:string)=>(key.startsWith('menu:')||key==='menu-layout'||key==='dietaryDisplay')?'menu':key==='site'||key==='hours'?'settings':'content';
function failure(e:any){return NextResponse.json({error:e instanceof CmsError?e.message:e?.issues?.[0]?.message||e.message||'Nepavyko išsaugoti.'},{status:e instanceof CmsError?e.status:400});}
export async function GET(req:NextRequest){try{
 const key=req.nextUrl.searchParams.get('key');const kind=req.nextUrl.searchParams.get('kind');
 if(key){if(!await can(keyPermission(key)))return NextResponse.json({error:'unauthorized'},{status:401});const record=await getDocument(key);return NextResponse.json({key,...record,history:req.nextUrl.searchParams.has('history')?await documentHistory(key):undefined});}
 if(!await can('content'))return NextResponse.json({error:'unauthorized'},{status:401});
 if(kind==='page')return NextResponse.json({documents:(await pageRecords()).map(p=>({key:`page:${p.id}`,...p}))});
 if(kind==='article'){const articles=await db.article.findMany({orderBy:{updatedAt:'desc'}});return NextResponse.json({documents:await Promise.all(articles.map(async a=>({key:`article:${a.id}`,...await getDocument(`article:${a.id}`)})))});}
 const rows=await db.setting.findMany({where:{key:{startsWith:'cms:'}},orderBy:{updatedAt:'desc'}});return NextResponse.json({documents:rows.map(r=>({key:r.key.slice(4),...JSON.parse(r.value)}))});
 }catch(e){return failure(e);}}
export async function POST(req:NextRequest){try{
 if(!await can('content'))return NextResponse.json({error:'unauthorized'},{status:401});
 const b=await req.json();const title=String(b.title||'Naujas puslapis').slice(0,200);let key;
 if(b.kind==='article'){const a=await db.article.create({data:{title,slug:`straipsnis-${randomUUID()}`,published:false}});key=`article:${a.id}`;}
 else if(b.kind==='page'){key=`page:${randomUUID()}`;await saveDocument(key,{title,slug:`puslapis-${randomUUID()}`,description:'',visible:true,blocks:[{id:randomUUID(),t:'p',text:''}],coverImage:'',author:''},0,'draft',await cmsActor());}
 else throw new CmsError('Netinkamas tipas.');
 return NextResponse.json({key,...await getDocument(key)});
 }catch(e){return failure(e);}}
export async function PUT(req:NextRequest){try{
 const raw=await req.text();if(raw.length>1_000_000)throw new CmsError('Dokumentas per didelis.',413);const b=JSON.parse(raw);
 const key=String(b.key||'');if(!await can(keyPermission(key)))return NextResponse.json({error:'unauthorized'},{status:401});
 if(b.mode==='publish'&&!await can('publish'))return NextResponse.json({error:'Neturite publikavimo teisės.'},{status:403});
 if(!['draft','publish'].includes(b.mode)||!Number.isInteger(b.revision))throw new CmsError('Netinkamas veiksmas.');
 let value=b.value;
 if(b.restore==='published'){const current=await getDocument(key);if(!current.published)throw new CmsError('Paskelbtos versijos nėra.');value=current.published;}
 else if(b.restore){const old=(await documentHistory(key)).find(r=>r.id===b.restore);if(!old)throw new CmsError('Versija nerasta.',404);value=old.draft;}
 const data=validateDocument(key,value);
 const record=await saveDocument(key,data,b.revision,b.restore?'draft':b.mode,await cmsActor(),async(tx,published)=>{
  if(key.startsWith('article:')){
   const id=key.split(':')[1];const collision=await tx.article.findUnique({where:{slug:published.slug}});if(collision&&collision.id!==id)throw new CmsError('Šis adresas jau naudojamas.',409);
   await tx.article.update({where:{id},data:{title:published.title,slug:published.slug,excerpt:published.excerpt,keywords:published.keywords,coverImage:published.coverImage,bodyJson:JSON.stringify(published.body),published:published.published,publishedAt:published.published?new Date():null}});
  } else if(key==='menu-layout'){
    for(const [index,category] of published.entries()){
      await tx.category.update({where:{id:category.id},data:{name:category.name,active:category.active,sortOrder:index}});
      for(const [sortOrder,id] of category.itemOrder.entries()){
        const item=await tx.menuItem.findUnique({where:{id}});if(!item||item.categoryId!==category.id)throw new CmsError('Netinkama patiekalų tvarka.');
        await tx.menuItem.update({where:{id},data:{sortOrder}});
      }
    }
  } else if(key.startsWith('menu:'))await tx.menuItem.update({where:{id:key.split(':')[1]},data:published});
  else if(key.startsWith('page:')){
   if(['admin','api','mano','virtuve','straipsniai','sekti','robots.txt','sitemap.xml'].includes(published.slug))throw new CmsError('Šis adresas rezervuotas.');
   const other=await tx.setting.findMany({where:{key:{startsWith:'cms:page:'}}});
   if(other.some(r=>r.key!==`cms:${key}`&&JSON.parse(r.value).published?.slug===published.slug))throw new CmsError('Puslapio adresas jau naudojamas.',409);
  } else {const value=JSON.stringify(published);await tx.setting.upsert({where:{key},update:{value},create:{key,value}});}
 });
 return NextResponse.json({key,...record});
 }catch(e){return failure(e);}}
