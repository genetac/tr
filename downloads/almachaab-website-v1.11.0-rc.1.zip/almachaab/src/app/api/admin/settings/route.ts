import {getDocument,saveDocument} from "@/lib/cms";
import {validateDocument} from "@/lib/cms-schema";
import {cmsActor} from "@/lib/auth";
import { safeContentUrl, validateManagedContent } from "@/lib/content-management";
import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import {
  isAdmin,
  isAdminAllowUnchanged,
  checkPassword,
  hashPassword,
  createSessionToken,
  setSessionCookie,
  revokeAllAdminSessions,
} from "@/lib/auth";
import { getSettings, setSetting, setStoreSettings } from "@/lib/settings";
import { maskSecret, isMasked } from "@/lib/payments";

export const dynamic = "force-dynamic";

const EDITABLE_KEYS = ["site", "hours", "theme", "rating", "email", "orders", "pickup", "content", "store"];

function safeStore(s: Awaited<ReturnType<typeof getSettings>>) {
  // Secrets never leave the server unmasked.
  return {
    ...s.store,
    stripeSecretKey: maskSecret(s.store.stripeSecretKey),
    stripeWebhookSecret: maskSecret(s.store.stripeWebhookSecret),
    paypalSecret: maskSecret(s.store.paypalSecret),
    googleClientSecret: maskSecret(s.store.googleClientSecret),
    facebookClientSecret: maskSecret(s.store.facebookClientSecret),
    telegramBotToken: maskSecret(s.store.telegramBotToken),
    turnstileSecretKey: maskSecret(s.store.turnstileSecretKey),
  };
}

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const s = await getSettings();
  const { admin, ...safe } = s;
  // SEC-007: the SMTP password never leaves the server — the form shows a
  // mask, and saving the mask back keeps the stored value (see PUT "email").
  const email = { ...safe.email, pass: safe.email?.pass ? "••••••••" : "" };
  return NextResponse.json({ settings: { ...safe, email, store: safeStore(s) } });
}

export async function PUT(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const key = String(b.key || "");

  if (key === "password") {
    // Allowed even while the session is in "must change password" state —
    // this is the only route that lifts that state.
    if (!(await isAdminAllowUnchanged())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    const { current, next } = b;
    if (!(await checkPassword(String(current || "")))) {
      return NextResponse.json({ error: "Neteisingas dabartinis slaptažodis." }, { status: 403 });
    }
    const np = String(next || "");
    // SEC-014: 12+ characters, not the factory default, not a trivial pattern.
    const weak = new Set(["alma2026", "almachaab", "alma chaab", "slaptazodis", "password", "123456789012", "qwertyuiop12"]);
    if (np.length < 12) return NextResponse.json({ error: "Slaptažodis per trumpas (min. 12 simbolių)." }, { status: 400 });
    if (np.length > 200) return NextResponse.json({ error: "Slaptažodis per ilgas." }, { status: 400 });
    if (weak.has(np.toLowerCase()) || /^(.)\1+$/.test(np) || np === String(current || "")) {
      return NextResponse.json({ error: "Pasirinkite kitą, sunkiau atspėjamą slaptažodį." }, { status: 400 });
    }
    const s = await getSettings();
    await setSetting("admin", { ...s.admin, passwordHash: hashPassword(np) });
    // SEC-011: a password change logs out every other device, then
    // re-issues this session (also lifts the must-change flag).
    await revokeAllAdminSessions();
    await setSessionCookie(await createSessionToken(false));
    return NextResponse.json({ ok: true });
  }

  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  if (['site','hours','theme','content'].includes(key)) {
    try {
      const current=await getDocument(key);const data=validateDocument(key,b.value);
      const r=await saveDocument(key,data,b.revision??current.revision,b.mode==='publish'?'publish':'draft',await cmsActor(),async(tx,v)=>{await tx.setting.upsert({where:{key},update:{value:JSON.stringify(v)},create:{key,value:JSON.stringify(v)}});});
      return NextResponse.json({ok:true,revision:r.revision,draft:r.pending});
    }catch(e:any){return NextResponse.json({error:e.message},{status:e.status||400});}
  }
  if (key === "store") {
    const v = (b.value || {}) as Record<string, unknown>;
    const patch: Record<string, unknown> = {};
    if (typeof v.restaurantName === "string") patch.restaurantName = v.restaurantName.trim().slice(0, 80) || "Alma Chaab";
    if (typeof v.isOpen === "boolean") patch.isOpen = v.isOpen;
    if (typeof v.stripePublicKey === "string") patch.stripePublicKey = v.stripePublicKey.trim();
    if (typeof v.paypalClientId === "string") patch.paypalClientId = v.paypalClientId.trim();
    if (typeof v.paypalSandbox === "boolean") patch.paypalSandbox = v.paypalSandbox;
    if (typeof v.turnstileEnabled === "boolean") patch.turnstileEnabled = v.turnstileEnabled;
    if (v.turnstileSiteKey === null) patch.turnstileSiteKey = "";
    else if (typeof v.turnstileSiteKey === "string") patch.turnstileSiteKey = v.turnstileSiteKey.trim().slice(0, 100);
    // Secrets: empty or masked value = "keep what is stored"; explicit null = clear.
    for (const secret of ["stripeSecretKey", "stripeWebhookSecret", "paypalSecret", "turnstileSecretKey"] as const) {
      const val = v[secret];
      if (val === null) {
        patch[secret] = "";
        continue;
      }
      if (typeof val === "string" && val.trim() !== "" && !isMasked(val)) patch[secret] = val.trim();
    }
    if (v.currency !== undefined) {
      const cur = String(v.currency || "EUR").trim().toUpperCase().slice(0, 3);
      patch.currency = /^[A-Z]{3}$/.test(cur) ? cur : "EUR";
    }
    if (v.taxRate !== undefined) {
      const t = Number(v.taxRate);
      patch.taxRate = Number.isFinite(t) ? Math.min(100, Math.max(0, Math.round(t * 100) / 100)) : 0;
    }
    if (v.deliveryFee !== undefined) {
      const f = Number(v.deliveryFee);
      patch.deliveryFee = Number.isFinite(f) ? Math.min(1000, Math.max(0, Math.round(f * 100) / 100)) : 0;
    }
    const store = await setStoreSettings(patch);
    return NextResponse.json({
      ok: true,
      store: {
        ...store,
        stripeSecretKey: maskSecret(store.stripeSecretKey),
        stripeWebhookSecret: maskSecret(store.stripeWebhookSecret),
        paypalSecret: maskSecret(store.paypalSecret),
        turnstileSecretKey: maskSecret(store.turnstileSecretKey),
      },
    });
  }

  if (key === "social") {
    // Social sign-in providers — same masking rules as payment secrets.
    const v = (b.value || {}) as Record<string, unknown>;
    const patch: Record<string, unknown> = {};
    for (const flag of ["googleEnabled", "facebookEnabled", "telegramEnabled"] as const) {
      if (typeof v[flag] === "boolean") patch[flag] = v[flag];
    }
    // Non-secret string fields: null or "" = clear.
    for (const field of ["googleClientId", "facebookClientId", "telegramBotUsername"] as const) {
      const val = v[field];
      if (val === null) {
        patch[field] = "";
        continue;
      }
      if (typeof val === "string") {
        patch[field] =
          field === "telegramBotUsername" ? val.trim().replace(/^@/, "").slice(0, 60) : val.trim().slice(0, 200);
      }
    }
    for (const secret of ["googleClientSecret", "facebookClientSecret", "telegramBotToken"] as const) {
      const val = v[secret];
      if (val === null) {
        patch[secret] = "";
        continue;
      }
      if (typeof val === "string" && val.trim() !== "" && !isMasked(val)) patch[secret] = val.trim().slice(0, 300);
    }
    const store = await setStoreSettings(patch);
    return NextResponse.json({
      ok: true,
      store: {
        ...store,
        googleClientSecret: maskSecret(store.googleClientSecret),
        facebookClientSecret: maskSecret(store.facebookClientSecret),
        telegramBotToken: maskSecret(store.telegramBotToken),
      },
    });
  }

  if (key === "site" && b.value) {
    for (const field of ['woltUrl','boltFoodUrl','mapsUrl','facebookUrl']) {
      if (b.value[field] !== undefined && (typeof b.value[field] !== 'string' || !safeContentUrl(b.value[field]))) return NextResponse.json({ error:'Netinkama svetainės nuoroda.' },{ status:400 });
    }
  }
  if (key === "hours") {
    const value=b.value;
    if (!value || typeof value !== 'object' || Object.entries(value).some(([day,h]) => !['mon','tue','wed','thu','fri','sat','sun'].includes(day) || (h !== null && (!Array.isArray(h) || h.length !== 2 || h.some(n => typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n > 24) || h[0] >= h[1])))) return NextResponse.json({ error:'Patikrinkite darbo valandas.' },{ status:400 });
  }
  if (!EDITABLE_KEYS.includes(key)) return NextResponse.json({ error: "bad-key" }, { status: 400 });
  if (key === "email" && b.value && typeof b.value === "object") {
    const v = b.value as Record<string, unknown>;
    if (typeof v.pass === "string" && isMasked(v.pass)) {
      // Masked value from the form = "keep the stored password".
      const cur = await getSettings();
      await setSetting("email", { ...v, pass: cur.email.pass });
      return NextResponse.json({ ok: true });
    }
  }
  if (key === "content") {
    const error = validateManagedContent(b.value);
    if (error) return NextResponse.json({ error }, { status: 400 });
    await db.$transaction(async tx => {
      const old=await tx.setting.findUnique({ where:{key:'contentDraft'} });
      const revision=old ? JSON.parse(old.value).revision : 0;
      const value=JSON.stringify({ revision:revision+1,content:b.value,pending:false });
      await tx.setting.upsert({ where:{key:'contentDraft'},update:{value},create:{key:'contentDraft',value} });
      const published=JSON.stringify(b.value);
      await tx.setting.upsert({ where:{key:'content'},update:{value:published},create:{key:'content',value:published} });
    });
    return NextResponse.json({ ok:true });
  }
  await setSetting(key, b.value);
  return NextResponse.json({ ok: true });
}
