import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { sanitizeLocationInput } from "@/lib/locations";

export const dynamic = "force-dynamic";

/** Multi-branch management — full CRUD, admin-only. */
export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const locations = await db.location.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    include: { _count: { select: { orders: true } } },
  });
  return NextResponse.json({ locations });
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const data = sanitizeLocationInput(b);
  const name = String(data.name || "");
  if (name.length < 2) return NextResponse.json({ error: "Įveskite filialo pavadinimą." }, { status: 400 });

  // Only one default at a time.
  if (data.isDefault) await db.location.updateMany({ data: { isDefault: false } });
  const count = await db.location.count();
  const location = await db.location.create({
    data: {
      name,
      address: String(data.address || ""),
      phone: String(data.phone || ""),
      isActive: data.isActive === undefined ? true : Boolean(data.isActive),
      isDefault: Boolean(data.isDefault) || count === 0,
      taxRate: data.taxRate === undefined ? null : (data.taxRate as number | null),
      deliveryFee: data.deliveryFee === undefined ? null : (data.deliveryFee as number | null),
      sortOrder: (data.sortOrder as number) ?? count,
    },
  });
  return NextResponse.json({ ok: true, location });
}

export async function PUT(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const id = String(b.id || "");
  const existing = await db.location.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Filialas nerastas." }, { status: 404 });
  const data = sanitizeLocationInput(b);
  if (data.isDefault) await db.location.updateMany({ where: { id: { not: id } }, data: { isDefault: false } });
  const location = await db.location.update({ where: { id }, data: data as { [k: string]: unknown } });
  return NextResponse.json({ ok: true, location });
}

export async function DELETE(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id") || "";
  const existing = await db.location.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Filialas nerastas." }, { status: 404 });
  // Orders keep their history (SetNull) — the branch row itself is removed.
  await db.location.delete({ where: { id } });
  // Guarantee at least one default remains.
  const remaining = await db.location.count();
  if (remaining > 0 && !(await db.location.findFirst({ where: { isDefault: true } }))) {
    const first = await db.location.findFirst({ orderBy: { sortOrder: "asc" } });
    if (first) await db.location.update({ where: { id: first.id }, data: { isDefault: true } });
  }
  return NextResponse.json({ ok: true });
}
