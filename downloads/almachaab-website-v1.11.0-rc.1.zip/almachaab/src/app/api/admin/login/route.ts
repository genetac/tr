import { staffAccounts, verifyStaffPassword } from "@/lib/staff";
import { createStaffSession } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import {
  checkPassword,
  setSessionCookie,
  createSessionToken,
  isDefaultPasswordInUse,
  migratePasswordHash,
  loginRateStatus,
  loginRateFail,
  loginRateReset,
  clientIp,
  ADMIN_TOKEN_FALLBACK,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const ip = clientIp(req.headers);
  const rate = loginRateStatus(ip);
  if (rate.blocked) {
    return NextResponse.json(
      { error: `Per daug nesėkmingų bandymų. Bandykite po ${Math.ceil(rate.retryAfterSec / 60)} min.` },
      { status: 429 }
    );
  }

  const body = await req.json().catch(() => ({}));
  const pw = String(body.password || "");
  const username=String(body.username||'').trim().toLowerCase();
  if(username){
    const staff=(await staffAccounts()).find(a=>a.active&&a.username.toLowerCase()===username);
    if(!staff||!verifyStaffPassword(pw,staff.passwordHash)){loginRateFail(ip);return NextResponse.json({error:'Neteisingi prisijungimo duomenys.'},{status:401});}
    loginRateReset(ip);const token=await setSessionCookie(await createStaffSession(staff.id));
    return NextResponse.json({ok:true,mustChangePassword:false,...(ADMIN_TOKEN_FALLBACK?{token}:{})});
  }

  if (!(await checkPassword(pw))) {
    loginRateFail(ip);
    return NextResponse.json({ error: "Neteisingas slaptažodis." }, { status: 401 });
  }
  loginRateReset(ip);
  // Transparent upgrade: legacy SHA-256 hash -> salted scrypt.
  await migratePasswordHash(pw);

  // Factory default password forces a change before the panel opens.
  const mustChangePassword = await isDefaultPasswordInUse();
  // Cookie is set for normal browsing; token is returned so the client can
  // keep a fallback in localStorage (some contexts block cookies entirely).
  const token = await setSessionCookie(await createSessionToken(mustChangePassword));
  // SEC-011: the raw token is handed to the browser only in development.
  return NextResponse.json({ ok: true, ...(ADMIN_TOKEN_FALLBACK ? { token } : {}), mustChangePassword });
}
