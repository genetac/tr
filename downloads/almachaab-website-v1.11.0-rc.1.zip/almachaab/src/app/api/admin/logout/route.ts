import { NextResponse } from "next/server";
import { clearSessionCookie, revokeCurrentSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  // SEC-011: logout revokes every issued admin token, not just this cookie.
  await revokeCurrentSession();
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
