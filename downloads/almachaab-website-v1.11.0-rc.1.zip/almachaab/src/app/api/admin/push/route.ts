import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { can } from "@/lib/auth";
import { ensureVapid } from "@/lib/push";

export const dynamic = "force-dynamic";

interface SubJSON {
  endpoint?: string;
  keys?: { p256dh?: string; auth?: string };
}

// GET → VAPID public key (needed by the browser to subscribe) + device count
export async function GET() {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { publicKey } = await ensureVapid();
  const count = await db.pushSubscription.count({ where: { audience: "owner" } });
  return NextResponse.json({ publicKey, count });
}

// POST → save/refresh a device subscription
export async function POST(req: NextRequest) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const sub = (body.subscription || {}) as SubJSON;
  const endpoint = sub.endpoint || "";
  const p256dh = sub.keys?.p256dh || "";
  const auth = sub.keys?.auth || "";
  const label = typeof body.label === "string" ? body.label.slice(0, 60) : "";
  if (!endpoint.startsWith("https://") || !p256dh || !auth) {
    return NextResponse.json({ error: "invalid-subscription" }, { status: 400 });
  }
  await db.pushSubscription.upsert({
    where: { endpoint },
    update: { p256dh, auth, label, audience: "owner", userId: null },
    create: { endpoint, p256dh, auth, label, audience: "owner" },
  });
  const count = await db.pushSubscription.count({ where: { audience: "owner" } });
  return NextResponse.json({ ok: true, count });
}

// DELETE → remove a device (unsubscribe)
export async function DELETE(req: NextRequest) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const endpoint = String(body.endpoint || "");
  if (!endpoint) return NextResponse.json({ error: "missing-endpoint" }, { status: 400 });
  await db.pushSubscription.deleteMany({ where: { endpoint } });
  return NextResponse.json({ ok: true });
}
