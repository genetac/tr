import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { getLoyaltyConfig, setLoyaltyConfig, markRedemptionUsed } from "@/lib/loyalty";

export const dynamic = "force-dynamic";

/**
 * Loyalty admin — one route, several operations:
 *   GET                      → config + catalog + stats + latest redemptions
 *   PUT  { value }           → save config (enabled / pointsPerEuro / stampGoal / welcomeBonus)
 *   POST { action: ... }     → "saveReward" | "deleteReward" | "useVoucher"
 */
export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const config = await getLoyaltyConfig();
  const [rewards, profileCount, redeemed, recent] = await Promise.all([
    db.reward.findMany({ orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] }),
    db.loyaltyProfile.count(),
    db.rewardRedemption.findMany({ where: { status: "issued" }, select: { id: true } }),
    db.loyaltyTransaction.findMany({
      orderBy: { createdAt: "desc" },
      take: 25,
      include: { profile: { include: { user: { select: { name: true, email: true } } } } },
    }),
  ]);
  return NextResponse.json({ config, rewards, stats: { profileCount, openVouchers: redeemed.length }, recent });
}

export async function PUT(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const v = (b.value || {}) as Record<string, unknown>;
  const patch: Record<string, unknown> = {};
  if (typeof v.enabled === "boolean") patch.enabled = v.enabled;
  if (v.pointsPerEuro !== undefined) {
    const n = Number(v.pointsPerEuro);
    if (!Number.isFinite(n) || n < 0 || n > 100) return NextResponse.json({ error: "Netinkamas taškų kursas." }, { status: 400 });
    patch.pointsPerEuro = n;
  }
  if (v.stampGoal !== undefined) {
    const n = Number(v.stampGoal);
    if (!Number.isFinite(n) || n < 1 || n > 100) return NextResponse.json({ error: "Stampų tikslas turi būti 1–100." }, { status: 400 });
    patch.stampGoal = Math.floor(n);
  }
  if (v.welcomeBonus !== undefined) {
    const n = Number(v.welcomeBonus);
    if (!Number.isFinite(n) || n < 0 || n > 10000) return NextResponse.json({ error: "Netinkama sveikinimo dovana." }, { status: 400 });
    patch.welcomeBonus = Math.floor(n);
  }
  const config = await setLoyaltyConfig(patch);
  return NextResponse.json({ ok: true, config });
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const action = String(b.action || "");

  if (action === "saveReward") {
    const id = String(b.id || "");
    const name = String(b.name || "").trim().slice(0, 120);
    if (name.length < 2) return NextResponse.json({ error: "Įveskite prizo pavadinimą." }, { status: 400 });
    const pointsCost = Math.max(0, Math.min(1_000_000, Math.floor(Number(b.pointsCost) || 0)));
    const description = String(b.description || "").slice(0, 300);
    const active = b.active === undefined ? true : Boolean(b.active);
    const data = { name, pointsCost, description, active };
    const reward = id
      ? await db.reward.update({ where: { id }, data })
      : await db.reward.create({ data: { ...data, sortOrder: await db.reward.count() } });
    return NextResponse.json({ ok: true, reward });
  }

  if (action === "deleteReward") {
    const id = String(b.id || "");
    // Redemptions reference the reward — history rows keep meaning if we only deactivate.
    const used = await db.rewardRedemption.count({ where: { rewardId: id } });
    if (used > 0) {
      await db.reward.update({ where: { id }, data: { active: false } });
      return NextResponse.json({ ok: true, deactivated: true });
    }
    await db.reward.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  }

  if (action === "useVoucher") {
    const code = String(b.code || "").trim().toUpperCase();
    try {
      const redemption = await markRedemptionUsed(code);
      return NextResponse.json({ ok: true, redemption });
    } catch (e) {
      return NextResponse.json({ error: e instanceof Error ? e.message : "Klaida." }, { status: 400 });
    }
  }

  return NextResponse.json({ error: "unknown-action" }, { status: 400 });
}
