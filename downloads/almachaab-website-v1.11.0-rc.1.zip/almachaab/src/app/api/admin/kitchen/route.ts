import { can } from "@/lib/auth";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { parseItems, STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

const ACTIVE = ["confirmed", "preparing", "ready"];

function shape(o: {
  id: string; number: string; type: string; status: string; customerName: string;
  phone: string; itemsJson: string; total: number; pickupTime: string;
  resDate: string; resTime: string; guests: number; note: string;
  prepMinutes: number | null; prepSetAt: Date | null; createdAt: Date; isRead: boolean;
  paymentStatus: string; paymentMethod: string;
}) {
  return {
    id: o.id,
    number: o.number,
    type: o.type,
    status: o.status,
    statusLabel: STATUS_LT[o.status] || o.status,
    customerName: o.customerName,
    phone: o.phone,
    items: parseItems(o.itemsJson).map((i: { name: string; qty: number }) => ({ name: i.name, qty: i.qty })),
    total: o.total,
    pickupTime: o.pickupTime,
    resDate: o.resDate,
    resTime: o.resTime,
    guests: o.guests,
    note: o.note,
    prepMinutes: o.prepMinutes,
    prepSetAt: o.prepSetAt,
    readyAt: o.prepMinutes && o.prepSetAt ? new Date(o.prepSetAt.getTime() + o.prepMinutes * 60_000).toISOString() : null,
    createdAt: o.createdAt,
    isRead: o.isRead,
    // Paid / not-paid visibility for the kitchen (collect money or not)
    paymentStatus: o.paymentStatus,
    paymentMethod: o.paymentMethod,
  };
}

export async function GET() {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);

  const [incoming, active, todayRows, unread] = await Promise.all([
    db.order.findMany({
      where: { status: { in: ["new", "awaiting"] } },
      orderBy: { createdAt: "asc" },
    }),
    db.order.findMany({
      where: { status: { in: ACTIVE } },
      orderBy: { createdAt: "asc" },
    }),
    db.order.findMany({
      where: { createdAt: { gte: dayStart } },
      orderBy: { createdAt: "desc" },
    }),
    db.order.count({ where: { isRead: false, status: { in: ["new", "awaiting"] } } }),
  ]);

  const doneToday = todayRows.filter((o) => ["completed", "cancelled"].includes(o.status)).length;

  return NextResponse.json({
    incoming: incoming.map(shape),
    active: active.map(shape),
    today: {
      count: todayRows.length,
      done: doneToday,
      revenue: Math.round(todayRows.reduce((s, o) => s + (o.type === "pickup" ? o.total : 0), 0) * 100) / 100,
    },
    unread,
  });
}
