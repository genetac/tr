import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { findDormantCustomers, runWinBackCampaign, getLastRun, type WinBackOptions } from "@/lib/crm";

export const dynamic = "force-dynamic";

/** GET ?days=14 → dry-run preview of who would be targeted. */
export async function GET(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const days = Math.max(1, Math.min(365, Math.floor(Number(new URL(req.url).searchParams.get("days")) || 14)));
  const [customers, lastRun] = await Promise.all([findDormantCustomers(days), getLastRun()]);
  return NextResponse.json({
    days,
    count: customers.length,
    pushCount: customers.filter((c) => c.hasPush).length,
    customers: customers.slice(0, 50),
    lastRun,
  });
}

/** POST → run the campaign now (push + email legs configurable). */
export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const opts: WinBackOptions = {
    days: Math.max(1, Math.min(365, Math.floor(Number(b.days) || 14))),
    message: typeof b.message === "string" ? b.message : undefined,
    sendPush: b.sendPush !== false,
    sendEmail: b.sendEmail !== false,
  };
  try {
    const result = await runWinBackCampaign(opts);
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Kampanijos nepavyko įvykdyti." },
      { status: 500 }
    );
  }
}
