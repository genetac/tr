import { can } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";
import sharp from "sharp";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { UPLOAD_DIR } from "@/lib/uploads";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const MAX_BYTES = 10 * 1024 * 1024; // 10 MB per file
const MAX_FILES = 10;
const MAX_EDGE = 1920; // px, longest side

/**
 * Admin image upload used by ImagePicker (components/admin/ui.tsx).
 * Accepts multipart "files", re-encodes every image to WebP with sharp
 * (which also strips EXIF/GPS and rejects non-images), stores it in UPLOAD_DIR
 * and registers it in the Media library. Returns { files: [{ url }] }.
 */
export async function POST(req: NextRequest) {
  if (!(await can("media"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const form = await req.formData().catch(() => null);
  const files = (form?.getAll("files") || []).filter((f): f is File => typeof f === "object" && "arrayBuffer" in f);
  if (!files.length) return NextResponse.json({ error: "Nepasirinktas failas." }, { status: 400 });
  if (files.length > MAX_FILES) return NextResponse.json({ error: `Daugiausia ${MAX_FILES} failų vienu metu.` }, { status: 400 });

  await mkdir(UPLOAD_DIR, { recursive: true });
  const out: { url: string; id: string }[] = [];

  for (const f of files) {
    if (f.size > MAX_BYTES) return NextResponse.json({ error: `Failas „${f.name}“ per didelis (max 10 MB).` }, { status: 400 });
    let webp: Buffer;
    try {
      webp = await sharp(Buffer.from(await f.arrayBuffer()), { failOn: "error", limitInputPixels: 40000000 })
        .rotate() // respect camera orientation, then EXIF is dropped
        .resize({ width: MAX_EDGE, height: MAX_EDGE, fit: "inside", withoutEnlargement: true })
        .webp({ quality: 80 })
        .toBuffer();
    } catch {
      return NextResponse.json({ error: `„${f.name}“ nėra palaikomas paveikslėlis.` }, { status: 400 });
    }
    const base = path.parse(f.name).name.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "img";
    const filename = `${base}-${randomBytes(4).toString("hex")}.webp`;
    await writeFile(path.join(UPLOAD_DIR, filename), webp);
    const m = await db.media.create({ data: { filename, mime: "image/webp", size: webp.length, title: f.name.slice(0, 120) } });
    out.push({ id: m.id, url: `/api/files/${filename}` });
  }
  return NextResponse.json({ files: out });
}
