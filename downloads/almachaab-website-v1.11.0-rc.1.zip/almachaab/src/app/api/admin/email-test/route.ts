import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { sendTestEmail } from "@/lib/mail";

export const dynamic = "force-dynamic";

/**
 * Admin-only SMTP test send (SettingsTab "Išbandyti" button).
 * Lives on its own route — it has nothing to do with the media library.
 */
export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const to = String(b.to || "").trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) {
    return NextResponse.json({ error: "Įveskite tinkamą el. pašto adresą." }, { status: 400 });
  }
  const result = await sendTestEmail(to);
  if (!result.ok) {
    return NextResponse.json(
      { error: result.error === "email-disabled" ? "El. pašto siuntimas išjungtas nustatymuose." : `Nepavyko išsiųsti: ${result.error}` },
      { status: 400 }
    );
  }
  return NextResponse.json({ ok: true });
}
