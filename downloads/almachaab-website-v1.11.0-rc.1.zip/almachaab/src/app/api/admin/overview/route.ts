import { can } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const today = new Date();
  const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const orders = await db.order.findMany({ orderBy: { createdAt: "desc" } });

  const unread = orders.filter((o) => !o.isRead).length;
  const active = orders.filter((o) => !["completed", "cancelled"].includes(o.status));
  const todayOrders = orders.filter((o) => o.createdAt >= startOfDay);
  const upcomingRes = orders.filter(
    (o) => o.type === "reservation" && ["new", "confirmed"].includes(o.status)
  );
  const openPickups = orders.filter(
    (o) => o.type === "pickup" && ["new", "awaiting", "confirmed", "preparing", "ready"].includes(o.status)
  );
  const revenueToday = todayOrders
    .filter((o) => o.type === "pickup" && o.status !== "cancelled")
    .reduce((s, o) => s + o.total, 0);

  return NextResponse.json({
    stats: {
      unread,
      activeCount: active.length,
      todayCount: todayOrders.length,
      upcomingReservations: upcomingRes.length,
      openPickups: openPickups.length,
      revenueToday,
    },
    latest: orders.slice(0, 12).map((o) => ({
      id: o.id,
      number: o.number,
      type: o.type,
      status: o.status,
      statusLabel: STATUS_LT[o.status],
      customerName: o.customerName,
      phone: o.phone,
      total: o.total,
      when: o.type === "pickup" ? o.pickupTime : `${o.resDate} ${o.resTime}`,
      guests: o.guests,
      isRead: o.isRead,
      createdAt: o.createdAt,
    })),
  });
}
