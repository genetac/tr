import { revokeCurrentSession } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import {
  checkPassword,
  setSessionCookie,
  createSessionToken,
  isDefaultPasswordInUse,
  migratePasswordHash,
  clearSessionCookie,
  isAdminAllowUnchanged,
  revokeAllAdminSessions,
  isAdmin,
  getSessionState,
  loginRateStatus,
  loginRateFail,
  loginRateReset,
  clientIp,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const st = await getSessionState();
  return NextResponse.json({ authenticated: st.ok && !st.mustChangePassword, mustChangePassword: st.mustChangePassword, role:st.role, name:st.name, canPublish:st.canPublish });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const url = new URL(req.url);
  const action = body.action || (url.pathname.endsWith("login") ? "login" : "");
  if (action === "logout") {
    await revokeCurrentSession(); // SEC-011
    await clearSessionCookie();
    return NextResponse.json({ ok: true });
  }
  const ip = clientIp(req.headers);
  const rate = loginRateStatus(ip);
  if (rate.blocked) {
    return NextResponse.json(
      { error: `Per daug nesėkmingų bandymų. Bandykite po ${Math.ceil(rate.retryAfterSec / 60)} min.` },
      { status: 429 }
    );
  }
  const pw = String(body.password || "");
  if (!(await checkPassword(pw))) {
    loginRateFail(ip);
    return NextResponse.json({ error: "Neteisingas slaptažodis." }, { status: 401 });
  }
  loginRateReset(ip);
  await migratePasswordHash(pw);
  const mustChangePassword = await isDefaultPasswordInUse();
  await setSessionCookie(await createSessionToken(mustChangePassword));
  return NextResponse.json({ ok: true, mustChangePassword });
}
