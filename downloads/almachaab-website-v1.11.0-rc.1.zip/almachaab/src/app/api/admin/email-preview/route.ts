import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { isAdmin } from "@/lib/auth";
import { renderTemplatePreview, sendMail } from "@/lib/mail";
import { EMAIL_TEMPLATE_KEYS, type EmailTemplateKey } from "@/lib/email-templates";

export const dynamic = "force-dynamic";

function baseUrlFrom(req: NextRequest) {
  return siteBaseUrl(req); // SEC-016: never from Host / X-Forwarded-Host
}

/**
 * POST { key, template?, to?, send? }
 *  - Renders the template (saved values merged with the posted draft) over
 *    sample data and returns { subject, html } for the admin live preview.
 *  - With send:true + to: also emails the rendered preview (test send).
 */
export async function POST(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const key = String(b.key || "") as EmailTemplateKey;
  if (!EMAIL_TEMPLATE_KEYS.includes(key)) return NextResponse.json({ error: "bad-key" }, { status: 400 });

  const draft = (b.template && typeof b.template === "object" ? b.template : undefined) as
    | Record<string, unknown>
    | undefined;
  // Whitelist draft fields — only known template fields are merged.
  const clean =
    draft &&
    Object.fromEntries(
      Object.entries(draft).filter(([k]) =>
        ["subject", "title", "body", "showDetails", "showItems", "showPayment", "showTrack"].includes(k)
      )
    );

  const rendered = await renderTemplatePreview(key, clean as never, baseUrlFrom(req));
  if (!rendered) return NextResponse.json({ error: "bad-key" }, { status: 400 });

  let sent: { ok: boolean; error?: string } | null = null;
  if (b.send && typeof b.to === "string" && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.to.trim())) {
    sent = await sendMail(b.to.trim(), rendered.subject, rendered.html);
  }

  return NextResponse.json({ ok: true, subject: rendered.subject, html: rendered.html, sent });
}
