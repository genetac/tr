import { can } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { siteBaseUrl } from "@/lib/base-url";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { ORDER_STATUSES, pushHistory } from "@/lib/orders";
import { emailOrderEvent, emailReservationEvent, STATUS_LT } from "@/lib/mail";
import { publishOrderEvent } from "@/lib/events";
import { awardLoyaltyFor, markOrderPaid } from "@/lib/fulfill";

export const dynamic = "force-dynamic";

function baseUrlFrom(req: NextRequest) {
  return siteBaseUrl(req); // SEC-016: never from Host / X-Forwarded-Host
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const order = await db.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: "not-found" }, { status: 404 });

  // Owner collected the money in person (cash / card terminal at the venue)
  // → run the SAME funnel as online payments (marks paid, auto-confirms,
  // history, SSE, loyalty). Later field updates below build on fresh data.
  let current = order;
  if (body.paid === true && order.paymentStatus !== "paid") {
    const paid = await markOrderPaid(order.id, {
      method: "venue",
      ref: `admin-${Date.now()}`,
      baseUrl: baseUrlFrom(req),
    });
    if (paid.ok) current = (await db.order.findUnique({ where: { id } })) || order;
  }

  const data: Record<string, unknown> = {};
  let emailEvent: string | null = null;

  if (body.status) {
    const status = String(body.status);
    if (!(ORDER_STATUSES as readonly string[]).includes(status)) return NextResponse.json({ error: "bad-status" }, { status: 400 });
    data.status = status;
    data.isRead = true;
    if (status !== current.status) {
      // Compare against current (post-payment) status — when `paid` arrived in
      // the same request, markOrderPaid already auto-confirmed and sent the
      // receipt, so a "confirmed" event here would double-email the customer.
      emailEvent = status; // confirmed | ready | cancelled (others are silent)
    }
  }
  if (typeof body.isRead === "boolean") data.isRead = body.isRead;
  if (typeof body.pickupTime === "string") data.pickupTime = body.pickupTime;
  if (typeof body.note === "string") data.note = body.note;
  if (body.prepMinutes !== undefined) {
    const mins = Math.max(0, Math.min(480, Math.floor(Number(body.prepMinutes) || 0)));
    if (mins > 0) {
      data.prepMinutes = mins;
      data.prepSetAt = new Date();
    } else {
      data.prepMinutes = null;
      data.prepSetAt = null;
    }
  }

  let updated = current;
  if (Object.keys(data).length) {
    data.historyJson = pushHistory(current, String(data.status || current.status), {
      by: "admin",
      ...(data.prepMinutes ? { prepMinutes: data.prepMinutes } : {}),
    });
    updated = await db.order.update({ where: { id }, data });

    // Real-time fan-out: kitchen display + customer tracking update instantly
    publishOrderEvent({
      type: "updated",
      orderId: updated.id,
      number: updated.number,
      status: updated.status,
      paymentStatus: updated.paymentStatus,
    });

    // Successful completion of an unpaid (pay-on-pickup) order earns loyalty.
    // Idempotent — paid orders were already awarded in markOrderPaid().
    if (data.status === "completed" && updated.paymentStatus !== "paid") {
      void awardLoyaltyFor(updated.id);
    }
  }

  let email: { ok: boolean; error?: string } | null = null;
  if (emailEvent) {
    const baseUrl = baseUrlFrom(req);
    if (updated.type === "pickup") {
      if (["confirmed", "ready", "cancelled"].includes(emailEvent)) {
        email = await emailOrderEvent(updated, emailEvent, baseUrl);
      }
    } else {
      if (["confirmed", "cancelled"].includes(emailEvent)) {
        email = await emailReservationEvent(updated, emailEvent, baseUrl);
      }
    }
    if (email) {
      await db.order.update({
        where: { id },
        data: { historyJson: pushHistory(updated, updated.status, { emailSent: email }) },
      });
    }
  }

  return NextResponse.json({ ok: true, order: { ...updated, statusLabel: STATUS_LT[updated.status] } , email });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const order = await db.order.delete({ where: { id } }).catch(() => null);
  if (order) {
    publishOrderEvent({ type: "deleted", orderId: order.id, number: order.number, status: order.status });
  }
  return NextResponse.json({ ok: true });
}
