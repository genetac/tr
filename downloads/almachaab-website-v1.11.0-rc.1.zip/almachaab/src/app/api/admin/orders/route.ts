import { can } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";
import { STATUS_LT } from "@/lib/orders";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  if (!(await can("orders"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const type = url.searchParams.get("type") || "all";
  const status = url.searchParams.get("status") || "all";
  const q = (url.searchParams.get("q") || "").trim().toLowerCase();

  const where: Record<string, unknown> = {};
  if (type !== "all") where.type = type;
  if (status !== "all") where.status = status;

  let orders = await db.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { location: { select: { name: true } } },
  });
  if (q) {
    orders = orders.filter(
      (o) =>
        o.number.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.phone.toLowerCase().includes(q)
    );
  }
  return NextResponse.json({
    orders: orders.map((o) => ({
      ...o,
      statusLabel: STATUS_LT[o.status] || o.status,
      locationName: o.location?.name || "",
      items: JSON.parse(o.itemsJson || "[]"),
      history: JSON.parse(o.historyJson || "[]"),
    })),
  });
}
