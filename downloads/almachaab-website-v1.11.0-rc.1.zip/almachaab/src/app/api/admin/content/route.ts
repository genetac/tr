import {NextRequest,NextResponse} from 'next/server';
import {can,cmsActor} from '@/lib/auth';
import {getDocument,saveDocument} from '@/lib/cms';
import {validateDocument} from '@/lib/cms-schema';
export const dynamic='force-dynamic';
export async function GET(){if(!await can('content'))return NextResponse.json({error:'unauthorized'},{status:401});const r=await getDocument('content');return NextResponse.json({content:r.draft,revision:r.revision,draftExists:r.pending});}
export async function PUT(req:NextRequest){if(!await can('content'))return NextResponse.json({error:'unauthorized'},{status:401});try{
 const raw=await req.text();if(raw.length>1000000)return NextResponse.json({error:'Turinys per didelis.'},{status:413});const b=JSON.parse(raw);
 if(!['draft','publish'].includes(b.mode))throw new Error('Netinkamas veiksmas.');if(b.mode==='publish'&&!await can('publish'))return NextResponse.json({error:'Neturite publikavimo teisės.'},{status:403});
 const data=validateDocument('content',b.content);const r=await saveDocument('content',data,b.revision,b.mode,await cmsActor(),async(tx,v)=>{await tx.setting.upsert({where:{key:'content'},update:{value:JSON.stringify(v)},create:{key:'content',value:JSON.stringify(v)}});});
 return NextResponse.json({ok:true,revision:r.revision,published:!r.pending});
 }catch(e:any){return NextResponse.json({error:e.message},{status:e.status||400});}}
