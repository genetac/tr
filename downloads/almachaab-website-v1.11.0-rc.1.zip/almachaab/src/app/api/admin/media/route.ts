import { can } from "@/lib/auth";
import {NextRequest} from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await can("media"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const media = await db.media.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
  const meta=await db.setting.findMany({where:{key:{startsWith:"media-meta:"}}});
  const byId=new Map(meta.map(r=>[r.key.slice(11),JSON.parse(r.value)]));
  return NextResponse.json({
    media: media.map((m) => ({ ...byId.get(m.id), id: m.id, url: `/api/files/${m.filename}`, title: m.title, size: m.size, createdAt: m.createdAt })),
  });
}


export async function PATCH(req:NextRequest){if(!await can('media'))return NextResponse.json({error:'unauthorized'},{status:401});const b=await req.json().catch(()=>({}));if(typeof b.id!=='string'||!await db.media.findUnique({where:{id:b.id}}))return NextResponse.json({error:'Nuotrauka nerasta.'},{status:404});for(const key of ['title','alt','caption'])if(b[key]!==undefined&&(typeof b[key]!=='string'||b[key].length>1000))return NextResponse.json({error:'Tekstas per ilgas.'},{status:400});const value=JSON.stringify({alt:b.alt||'',caption:b.caption||''});await db.$transaction([db.media.update({where:{id:b.id},data:{title:b.title||''}}),db.setting.upsert({where:{key:`media-meta:${b.id}`},update:{value},create:{key:`media-meta:${b.id}`,value}})]);return NextResponse.json({ok:true});}
