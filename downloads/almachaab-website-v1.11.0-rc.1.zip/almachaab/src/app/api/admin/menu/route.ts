import {getDocument,saveDocument} from "@/lib/cms";
import {safeContentUrl} from "@/lib/content-management";
import {validateDocument} from "@/lib/cms-schema";
import {can,cmsActor} from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function guard() {
  if (!(await can("menu"))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  return null;
}

export async function GET() {
  const g = await guard();
  if (g) return g;
  const categories = await db.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: { items: { orderBy: { sortOrder: "asc" } } },
  });
  const layout=(await getDocument('menu-layout')).draft;
  const merged=await Promise.all(categories.map(async category=>({...category,...layout?.find((c:any)=>c.id===category.id),items:await Promise.all(category.items.map(async item=>{
    const doc=await getDocument(`menu:${item.id}`);return {...item,...doc.draft,revision:doc.revision,pending:doc.pending};
  }))})));
  merged.sort((a,b)=>layout.findIndex((c:any)=>c.id===a.id)-layout.findIndex((c:any)=>c.id===b.id));
  for(const cat of merged){const order=layout.find((c:any)=>c.id===cat.id)?.itemOrder||[];cat.items.sort((a,b)=>order.indexOf(a.id)-order.indexOf(b.id));}
  return NextResponse.json({ categories:merged });
}

export async function POST(req: NextRequest) {
  const g = await guard();
  if (g) return g;
  const b = await req.json().catch(() => ({}));
  const action = String(b.action || "");
  if (b.price !== undefined && (typeof b.price !== "number" || !Number.isFinite(b.price) || b.price < 0 || b.price > 10000)) return NextResponse.json({ error: "Kaina turi būti nuo 0 iki 10 000 €." }, { status: 400 });

  if(b.name!==undefined&&(typeof b.name!=="string"||!b.name.trim()||b.name.length>200))return NextResponse.json({error:"Patikrinkite pavadinimą."},{status:400});
  if(b.image!==undefined&&(typeof b.image!=="string"||!safeContentUrl(b.image)))return NextResponse.json({error:"Netinkama nuotraukos nuoroda."},{status:400});
  if (action === "createCategory") {
    const max = await db.category.aggregate({ _max: { sortOrder: true } });
    const cat = await db.category.create({
      data: { name: String(b.name || "Nauja kategorija"), active:false, sortOrder: (max._max.sortOrder ?? 0) + 1 },
    });
    const doc=await getDocument('menu-layout');await saveDocument('menu-layout',[...doc.draft.filter((c:any)=>c.id!==cat.id),{id:cat.id,name:cat.name,active:true,itemOrder:[]}],doc.revision,'draft',await cmsActor());
    return NextResponse.json({ ok: true, category: cat });
  }
  if (action === "createItem") {
    const count = await db.menuItem.count({ where: { categoryId: String(b.categoryId) } });
    const item = await db.menuItem.create({
      data: {
        categoryId: String(b.categoryId),
        name: String(b.name || "Naujas patiekalas"),
        price: Number(b.price) || 0,
        description: String(b.description || ""),
        image: String(b.image || ""),
        sortOrder: count,
        active: false,
      },
    });
    await saveDocument(`menu:${item.id}`, {...item,active:true},0,"draft",await cmsActor());
    const layout=await getDocument("menu-layout");
    await saveDocument("menu-layout",layout.draft.map((c:any)=>c.id===item.categoryId?{...c,itemOrder:[...c.itemOrder,item.id]}:c),layout.revision,"draft",await cmsActor());
    return NextResponse.json({ ok: true, item });
  }
  return NextResponse.json({ error: "unknown-action" }, { status: 400 });
}

export async function PATCH(req: NextRequest) {
  const g = await guard();
  if (g) return g;
  const b = await req.json().catch(() => ({}));
  const action = String(b.action || "");
  if (b.price !== undefined && (typeof b.price !== "number" || !Number.isFinite(b.price) || b.price < 0 || b.price > 10000)) return NextResponse.json({ error: "Kaina turi būti nuo 0 iki 10 000 €." }, { status: 400 });

  if (action === "updateCategory") {
    const doc=await getDocument('menu-layout');const value=doc.draft.map((c:any)=>c.id===String(b.id)?{...c,...(typeof b.name==='string'?{name:b.name}:{}),...(typeof b.active==='boolean'?{active:b.active}:{})}:c);
    await saveDocument('menu-layout',validateDocument('menu-layout',value),doc.revision,'draft',await cmsActor());return NextResponse.json({ok:true});
  }

  if (action === "updateItem") {
    try {
      const key=`menu:${String(b.id)}`;const doc=await getDocument(key);
      const mode=b.mode==='publish'?'publish':'draft';
      if(mode==='publish'&&!await can('publish'))return NextResponse.json({error:'Neturite publikavimo teisės.'},{status:403});
      const data=validateDocument(key,{...doc.draft,...b});
      const result=await saveDocument(key,data,b.revision??doc.revision,mode,await cmsActor(),async(tx,v)=>{await tx.menuItem.update({where:{id:String(b.id)},data:v});});
      return NextResponse.json({ok:true,item:{...result.draft,id:b.id},revision:result.revision,pending:result.pending});
    }catch(e:any){return NextResponse.json({error:e.issues?.[0]?.message||e.message},{status:e.status||400});}
  }
  if(action==='inventory'){
    const data:any={};if(typeof b.inStock==='boolean')data.inStock=b.inStock;
    if(b.stockCount===null)data.stockCount=null;else if(Number.isInteger(b.stockCount)&&b.stockCount>=0)data.stockCount=b.stockCount;
    return NextResponse.json({ok:true,item:await db.menuItem.update({where:{id:String(b.id)},data})});
  }

  if (action === "moveItem" || action === "moveCategory") {
    const doc=await getDocument('menu-layout');const value=structuredClone(doc.draft);
    if(action==='moveCategory'){const a=value.findIndex((c:any)=>c.id===b.idA),other=value.findIndex((c:any)=>c.id===b.idB);if(a<0||other<0)return NextResponse.json({error:'not-found'},{status:404});[value[a],value[other]]=[value[other],value[a]];}
    else{const cat=value.find((c:any)=>c.itemOrder.includes(b.idA)&&c.itemOrder.includes(b.idB));if(!cat)return NextResponse.json({error:'not-found'},{status:404});const a=cat.itemOrder.indexOf(b.idA),other=cat.itemOrder.indexOf(b.idB);[cat.itemOrder[a],cat.itemOrder[other]]=[cat.itemOrder[other],cat.itemOrder[a]];}
    await saveDocument('menu-layout',value,doc.revision,'draft',await cmsActor());return NextResponse.json({ok:true});
  }
  return NextResponse.json({ error: "unknown-action" }, { status: 400 });
}

export async function DELETE(req: NextRequest) {
  const g = await guard();
  if (g) return g;
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind");
  const id = url.searchParams.get("id") || "";
  if (kind === "category") {
    const doc=await getDocument('menu-layout');await saveDocument('menu-layout',doc.draft.map((c:any)=>c.id===id?{...c,active:false}:c),doc.revision,'draft',await cmsActor());
  } else if (kind === "item") {
    const doc=await getDocument(`menu:${id}`);await saveDocument(`menu:${id}`,validateDocument(`menu:${id}`,{...doc.draft,active:false}),doc.revision,"draft",await cmsActor());
  } else {
    return NextResponse.json({ error: "bad-kind" }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
