import {NextRequest,NextResponse} from 'next/server';
import {isAdmin,getSessionState} from '@/lib/auth';
import {staffAccounts,staffById,saveStaff,newStaffId,staffHash,verifyStaffPassword} from '@/lib/staff';
export const dynamic='force-dynamic';
export async function GET(){if(!await isAdmin())return NextResponse.json({error:'unauthorized'},{status:401});return NextResponse.json({accounts:(await staffAccounts()).map(({passwordHash:_hash,...a})=>a)});}
export async function PUT(req:NextRequest){
 const b=await req.json().catch(()=>({}));
 if(b.action==='password'){
  const st=await getSessionState();if(!st.ok||!st.staffId)return NextResponse.json({error:'unauthorized'},{status:401});
  const a=await staffById(st.staffId);if(!a||!verifyStaffPassword(String(b.current||''),a.passwordHash))return NextResponse.json({error:'Neteisingas dabartinis slaptažodis.'},{status:403});
  if(typeof b.password!=='string'||b.password.length<12||b.password.length>200)return NextResponse.json({error:'Slaptažodis turi būti 12–200 simbolių.'},{status:400});
  await saveStaff({...a,passwordHash:staffHash(b.password),sessionVersion:a.sessionVersion+1});return NextResponse.json({ok:true});
 }
 if(!await isAdmin())return NextResponse.json({error:'unauthorized'},{status:401});
 if(!['editor','kitchen'].includes(b.role)||!/^[-a-zA-Z0-9_.@]{3,100}$/.test(b.username||'')||typeof b.name!=='string'||!b.name.trim()||b.name.length>100)return NextResponse.json({error:'Patikrinkite vardą, prisijungimą ir vaidmenį.'},{status:400});
 const accounts=await staffAccounts();if(accounts.some(a=>a.id!==b.id&&a.username.toLowerCase()===b.username.toLowerCase()))return NextResponse.json({error:'Prisijungimas jau naudojamas.'},{status:409});
 const existing=b.id?await staffById(b.id):null;if(b.id&&!existing)return NextResponse.json({error:'Paskyra nerasta.'},{status:404});
 if((!existing||b.password)&&(!(typeof b.password==='string')||b.password.length<12||b.password.length>200))return NextResponse.json({error:'Slaptažodis turi būti 12–200 simbolių.'},{status:400});
 await saveStaff({id:existing?.id||newStaffId(),username:b.username.toLowerCase(),name:b.name,role:b.role,canPublish:b.canPublish===true,active:b.active!==false,passwordHash:b.password?staffHash(b.password):existing!.passwordHash,sessionVersion:(existing?.sessionVersion||0)+1});
 return NextResponse.json({ok:true});
}
