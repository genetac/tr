import { NextRequest, NextResponse } from "next/server";
import { recommendForCart } from "@/lib/recommendations";

export const dynamic = "force-dynamic";

/**
 * Public "Frequently Bought Together" suggestions for the checkout.
 * GET /api/recommendations?ids=menuItemA,menuItemB&limit=3
 * Optional `cats=gerimai,desertai` narrows suggestions to those categories
 * (the checkout upsell asks for drinks only).
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const ids = (url.searchParams.get("ids") || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 30);
  if (ids.length === 0) return NextResponse.json({ recommendations: [] });
  const cats = (url.searchParams.get("cats") || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 6);
  try {
    const limit = Math.max(1, Math.min(6, Math.floor(Number(url.searchParams.get("limit")) || 3)));
    const recommendations = await recommendForCart(ids, { limit, onlyCategories: cats });
    return NextResponse.json({ recommendations });
  } catch {
    // Upsells must never break the checkout — fail silent with an empty list.
    return NextResponse.json({ recommendations: [] });
  }
}
