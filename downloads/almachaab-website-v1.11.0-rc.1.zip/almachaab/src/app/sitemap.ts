import {pageRecords} from "@/lib/cms";
import type { MetadataRoute } from "next";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXTAUTH_URL || "https://almachaab.lt";

  // Stable lastModified values: newest article/settings change instead of
  // `new Date()` on every request (a fresh date on every crawl makes Google
  // distrust the sitemap). /privatumas is static — fixed to its effective date.
  let contentDate = new Date("2026-10-14T00:00:00Z"); // privatumas effective date fallback
  let articlesDate = contentDate;
  try {
    const [lastArticle, lastSetting] = await Promise.all([
      db.article.aggregate({ _max: { updatedAt: true } }),
      db.setting.aggregate({ _max: { updatedAt: true } }),
    ]);
    const a = lastArticle._max.updatedAt;
    const s = lastSetting._max.updatedAt;
    if (a && a > articlesDate) articlesDate = a;
    const newest = [a, s].filter((d): d is Date => !!d).reduce<Date | null>((m, d) => (!m || d > m ? d : m), null);
    if (newest && newest > contentDate) contentDate = newest;
  } catch {
    // DB unavailable — fall back to the static dates above
  }

  const entries: MetadataRoute.Sitemap = [
    { url: base, lastModified: contentDate, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/straipsniai`, lastModified: articlesDate, changeFrequency: "weekly", priority: 0.7 },
    { url: `${base}/apie-mus`, lastModified: new Date("2026-10-15T00:00:00Z"), changeFrequency: "monthly", priority: 0.6 },
    { url: `${base}/privatumas`, lastModified: new Date("2026-10-14T00:00:00Z"), changeFrequency: "yearly", priority: 0.3 },
  ];
  try {
    const articles = await db.article.findMany({
      where: { published: true },
      orderBy: { publishedAt: "desc" },
      select: { slug: true, updatedAt: true },
    });
    for (const a of articles) {
      entries.push({ url: `${base}/straipsniai/${a.slug}`, lastModified: a.updatedAt, changeFrequency: "monthly", priority: 0.6 });
    }
  } catch {
    // DB unavailable — return base entries
  }
  for(const record of await pageRecords())if(record.published?.visible!==false&&record.published?.slug&&!entries.some(e=>e.url===`${base}/${record.published.slug}`))entries.push({url:`${base}/${record.published.slug}`,lastModified:new Date(record.updatedAt)});
  return entries;
}
