import type { Metadata } from "next";
import VirtuveClient from "./VirtuveClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: { absolute: "Virtuvė — Alma Chaab" },
  robots: { index: false, follow: false },
};

/**
 * Standalone kitchen display (/virtuve) — restored by popular demand.
 * Shows every incoming + active order as a live board and — new — whether
 * each order is PAID or will be paid at the venue, so the kitchen knows
 * whether to collect money. The same board also lives in /admin → Skydelis.
 */
export default function VirtuvePage() {
  return <VirtuveClient />;
}
