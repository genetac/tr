"use client";

import { useEffect, useState, type FormEvent } from "react";
import KitchenApp from "@/components/admin/KitchenApp";
import { getToken, setToken } from "@/components/admin/ui";

/**
 * Gate for the standalone /virtuve screen: if this browser already holds an
 * admin session (cookie or the localStorage token from a previous /admin
 * login) the board renders immediately; otherwise a compact password card
 * appears right here — ideal for the kitchen tablet, no /admin detour.
 */
export default function VirtuveClient() {
  const [state, setState] = useState<"checking" | "login" | "ready">("checking");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    const check = async () => {
      try {
        const token = getToken();
        const res = await fetch("/api/admin/session", {
          headers: token ? { "x-admin-token": token } : undefined,
          cache: "no-store",
        });
        const json = (await res.json().catch(() => ({}))) as { authenticated?: boolean };
        if (alive) setState(json.authenticated ? "ready" : "login");
      } catch {
        if (alive) setState("login");
      }
    };
    void check();
    return () => {
      alive = false;
    };
  }, []);

  async function login(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      const json = (await res.json().catch(() => ({}))) as { ok?: boolean; token?: string; error?: string };
      if (!res.ok || !json.ok) throw new Error(json.error || "Neteisingas slaptažodis.");
      if (json.token) setToken(json.token);
      setState("ready");
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : "Klaida.");
      setBusy(false);
    }
  }

  if (state === "checking") {
    return (
      <div className="vg-wrap">
        <div className="vg-wait">Tikrinama sesija…</div>
      </div>
    );
  }

  if (state === "login") {
    return (
      <div className="vg-wrap">
        <form className="vg-card" onSubmit={login}>
          <h1>🔥 Virtuvės skydelis</h1>
          <p>Šis ekranas skirtas restorano personalui. Įveskite administratoriaus slaptažodį, kad pamatytumėte užsakymus realiu laiku.</p>
          <label>
            Slaptažodis
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Administratoriaus slaptažodis"
              autoComplete="current-password"
              autoFocus
            />
          </label>
          {err && <div className="vg-err" role="alert">{err}</div>}
          <button className="vg-btn" type="submit" disabled={busy || !pw}>
            {busy ? "Jungiamasi…" : "Atidaryti skydelį"}
          </button>
        </form>
      </div>
    );
  }

  return <KitchenApp />;
}
