import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/lib/db";
import { getSettings, publicSettings } from "@/lib/settings";
import { themeCss } from "@/lib/theme-css";
import "../straipsniai.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: { absolute: "Straipsniai ir istorijos | Alma Chaab" },
  description:
    "Istorijos apie Alma Chaab restoraną Kėdainiuose: libanietiškos virtuvės patiekalai, degustacijos, renginiai ir gyvenimas Kėdainių senamiestyje.",
  alternates: { canonical: "/straipsniai" },
};

function fmtDate(d: Date | null) {
  if (!d) return "";
  return new Intl.DateTimeFormat("lt-LT", { day: "numeric", month: "long", year: "numeric" }).format(d);
}

export default async function ArticlesPage() {
  const s = await getSettings();
  const articles = await db.article.findMany({
    where: { published: true },
    orderBy: { publishedAt: "desc" },
  });

  return (
    <div className="alma-root art-page">
      <style dangerouslySetInnerHTML={{ __html: themeCss(s.theme) }} />

      <div className="art-topbar">
        <div className="art-topbar-in">
          <Link href="/" className="brand">
            <strong>✦ Alma Chaab</strong>
          </Link>
          <Link href="/" className="art-back">
            ← Į pagrindinį puslapį
          </Link>
        </div>
      </div>

      <div className="art-shell">
        <div className="art-hero">
          <p className="art-eyebrow">{publicSettings(s).site.name} · Kėdainių senamiestis</p>
          <h1>Straipsniai ir istorijos</h1>
          <p>Pasakojimai apie mūsų virtuvę, patiekalus ir vakarus Kėdainių senamiestyje — tiek istorija, tiek naujienos.</p>
        </div>

        {articles.length === 0 ? (
          <div className="art-empty">Straipsnių kol kas nėra — greitai pasirodys pirmieji.</div>
        ) : (
          <div className="art-grid">
            {articles.map((a) => (
              <Link href={`/straipsniai/${a.slug}`} className="art-card" key={a.id}>
                <div className="art-card-media">
                  {a.coverImage ? (
                     
                    <img src={a.coverImage} alt={a.title} loading="lazy" />
                  ) : (
                    <span>📰</span>
                  )}
                </div>
                <div className="art-card-body">
                  <div className="art-card-meta">{fmtDate(a.publishedAt)}</div>
                  <h2>{a.title}</h2>
                  <p>{a.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
