import {can} from "@/lib/auth";
import {getDocument} from "@/lib/cms";
import {DocumentBlocks} from "@/components/cms/DocumentBlocks";
import { isAdmin } from "@/lib/auth";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound,permanentRedirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { themeCss } from "@/lib/theme-css";
import { articleJsonLd, faqJsonLd, SITE_URL } from "@/lib/schema";
import { JsonLd } from "@/components/seo/JsonLd";
import { renderBlock, extractFaq, type Block } from "@/lib/article-body";
import "../../straipsniai.css";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ preview?: string; doc?:string }> };

function fmtDate(d: Date | null) {
  if (!d) return "";
  return new Intl.DateTimeFormat("lt-LT", { day: "numeric", month: "long", year: "numeric" }).format(d);
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  if ((await searchParams).preview === "1") return { title: "Straipsnio peržiūra", robots: { index:false, follow:false } };
  const { slug } = await params;
  const a = await db.article.findUnique({ where: { slug } });
  // Plain string → root layout template appends the brand suffix once: "<Article title> | Alma Chaab"
  if (!a || !a.published) return { title: { absolute: "Straipsnis nerastas | Alma Chaab" } };
  const description = a.excerpt || `Alma Chaab straipsnis: ${a.title}`;
  const metaAuthor = String(((await getSettings()).content as Record<string, any>)?.articles?.authorName ?? "Irina Eid").trim() || "Alma Chaab";
  const cover = a.coverImage
    ? a.coverImage.startsWith("http")
      ? a.coverImage
      : `${SITE_URL}${a.coverImage}`
    : `${SITE_URL}/images/og-cover.jpg`;
  return {
    title: a.title,
    description,
    alternates: { canonical: `/straipsniai/${a.slug}` },
    openGraph: {
      type: "article",
      title: a.title,
      description,
      url: `${SITE_URL}/straipsniai/${a.slug}`,
      siteName: "Alma Chaab",
      locale: "lt_LT",
      publishedTime: (a.publishedAt ?? a.createdAt).toISOString(),
      modifiedTime: a.updatedAt.toISOString(),
      authors: [metaAuthor],
      // no fixed width/height: covers are not always 1200×630
      images: [{ url: cover, alt: a.title }],
    },
    twitter: {
      card: "summary_large_image",
      title: a.title,
      description,
      images: [cover],
    },
  };
}

export default async function ArticlePage({ params, searchParams }: Props) {
  const query=await searchParams;
  const preview=query.preview === "1" && await can("content");
  const { slug } = await params;
  let a = await db.article.findUnique({ where: { slug } });
  if(preview&&query.doc){const record=await getDocument(`article:${query.doc}`);const original=await db.article.findUnique({where:{id:query.doc}});if(original)a={...original,...record.draft,bodyJson:JSON.stringify(record.draft.body)};}
  if(!a&&!preview){const records=await db.setting.findMany({where:{key:{startsWith:'cms:article:'}}});for(const row of records){const r=JSON.parse(row.value);if(r.published?.published&&r.redirects?.includes(slug))permanentRedirect(`/straipsniai/${r.published.slug}`);}}
  if (!a || (!a.published && !preview)) notFound();

  const s = await getSettings();
  let body: Block[] = [];
  try {
    const parsed = JSON.parse(a.bodyJson || "[]");
    body = Array.isArray(parsed) ? parsed : [];
  } catch {
    body = [];
  }

  // "Skaitykite toliau": 3 most recent other published articles
  const related = await db.article.findMany({
    where: { published: true, NOT: { id: a.id } },
    orderBy: { publishedAt: "desc" },
    take: 3,
    select: { slug: true, title: true, excerpt: true },
  });

  const faq = extractFaq(body);
  // Byline (admin → Turinys → Straipsnių autorius). Empty name = organisation byline.
  const authorName = String((s.content as Record<string, any>)?.articles?.authorName ?? "Irina Eid").trim();
  const authorRole = String((s.content as Record<string, any>)?.articles?.authorRole ?? "„AlmaChaab“ vadovė").trim();
  const author = authorName ? { name: authorName, role: authorRole } : null;
  const ld: Record<string, unknown>[] = [articleJsonLd(a, s.site.name, author)];
  if (faq.length) ld.push(faqJsonLd(faq));

  return (
    <div className="alma-root art-page">
      <style dangerouslySetInnerHTML={{ __html: themeCss(s.theme) }} />
      {!preview && <JsonLd data={ld} />}
      {preview && <div role="status" style={{ padding:16,background:"#ffe09d" }}>Straipsnio peržiūra – tekstą reikia peržiūrėti prieš skelbiant.</div>}

      <div className="art-topbar">
        <div className="art-topbar-in">
          <Link href="/" className="brand">
            <strong>✦ Alma Chaab</strong>
          </Link>
          <Link href="/straipsniai" className="art-back">
            ← Visi straipsniai
          </Link>
        </div>
      </div>

      <article className="art-single">
        <p className="art-eyebrow">Alma Chaab · istorijos</p>
        <h1>{a.title}</h1>
        <div className="art-meta">
          <b>{fmtDate(a.publishedAt)}</b>
          <span>·</span>
          {author ? (
            <span>
              <Link href="/apie-mus">{author.name}</Link>
              {author.role ? `, ${author.role}` : ""}
            </span>
          ) : (
            <span>Kėdainių senamiestis</span>
          )}
        </div>

        {a.coverImage && (
          <div className="art-cover">
            <img src={a.coverImage} alt={a.title} fetchPriority="high" decoding="async" />
          </div>
        )}

        <div className="art-prose">
          {a.excerpt && (
            <p className="art-lead">
              <em>{a.excerpt}</em>
            </p>
          )}
          <DocumentBlocks blocks={body} settings={s} />
        </div>

        <div className="art-cta">
          <div>
            <strong>Skamba skaniai?</strong>
            <small>Rezervuokite stalą arba užsisakykite atsiėmimui internetu.</small>
          </div>
          <Link href="/#meniu">Meniu ir rezervacija →</Link>
        </div>

        {related.length > 0 && (
          <nav className="art-related" aria-label="Skaitykite toliau">
            <h2>Skaitykite toliau</h2>
            <ul>
              {related.map((r) => (
                <li key={r.slug}>
                  <Link href={`/straipsniai/${r.slug}`}>
                    <strong>{r.title}</strong>
                    {r.excerpt && <small>{r.excerpt}</small>}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        )}
      </article>

      <div className="art-footer-links">
        <Link href="/straipsniai">← Visi straipsniai</Link>
      </div>
    </div>
  );
}
