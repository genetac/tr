import {notFound} from "next/navigation";
import {publishedPage,getDocument,pageRecords} from "@/lib/cms";
import {can} from "@/lib/auth";
import {StandalonePage} from "@/components/cms/StandalonePage";
import type { Metadata } from "next";
import Link from "next/link";
import { getSettings } from "@/lib/settings";
import { JsonLd } from "@/components/seo/JsonLd";
import { OWNERS, PRESS, SITE_URL } from "@/lib/schema";
import { themeCss } from "@/lib/theme-css";
import "../privatumas.css";
import "./apie-mus.css";

const legacyMetadata: Metadata = {
  title: { absolute: "Apie mus — Irina ir Elie Eid | Alma Chaab Kėdainiai" },
  description:
    "Alma Chaab — šeimos restoranas Kėdainių senamiestyje. Susipažinkite su vadove Irina Eid ir šefu Elie Eid, sužinokite, ką reiškia pavadinimas ir kaip kepyklėlės idėja virto restoranu.",
  alternates: { canonical: "/apie-mus" },
  openGraph: {
    title: "Apie Alma Chaab — Irina ir Elie Eid",
    description: "Šeimos restoranas Kėdainių senamiestyje: žmonės, istorija ir erdvės.",
    images: [{ url: "/images/irina-eid-alma-chaab.webp", width: 1024, height: 684 }],
    locale: "lt_LT",
    type: "website",
  },
};

export async function generateMetadata({searchParams}:{searchParams:Promise<{preview?:string}>}){
 if((await searchParams).preview==='1')return {title:'Juodraščio peržiūra',robots:{index:false,follow:false}};
 const record=await publishedPage('apie-mus');return record?{...legacyMetadata,title:{absolute:record.published.title},description:record.published.description}:legacyMetadata;
}

export const dynamic = "force-dynamic";

export default async function AboutPage({searchParams}:{searchParams:Promise<{preview?:string;doc?:string}>}) {
 const query=await searchParams;const preview=query.preview==='1'&&await can('content');
 const record=preview&&query.doc?await getDocument(`page:${query.doc}`):(await pageRecords()).find(p=>p.published?.slug==='apie-mus');
 const page=preview?(record as any)?.draft:(record as any)?.published;
 if(page?.visible===false&&!preview)notFound();
 if(page)return <StandalonePage page={page} settings={await getSettings()} preview={preview}/>;

  const s = await getSettings();
  const site = s.site;
  const legalName = site.legalName || "UAB „Chaab“";
  const companyCode = site.companyCode || "307075624";
  const press = PRESS[0];

  const ld = {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    "@id": `${SITE_URL}/apie-mus`,
    url: `${SITE_URL}/apie-mus`,
    name: "Apie Alma Chaab",
    inLanguage: "lt-LT",
    primaryImageOfPage: `${SITE_URL}/images/irina-eid-alma-chaab.webp`,
    mainEntity: {
      "@type": "Restaurant",
      "@id": SITE_URL,
      name: site.name,
      legalName,
      identifier: { "@type": "PropertyValue", propertyID: "Juridinio asmens kodas", value: companyCode },
      founder: OWNERS,
      subjectOf: PRESS,
    },
  };

  return (
    <div className="alma-root priv-page about-page">
      <style dangerouslySetInnerHTML={{ __html: themeCss(s.theme) }} />
      <JsonLd data={ld} />
      <div className="priv-topbar">
        <div className="priv-topbar-in">
          <Link href="/" className="brand">
            <strong>✦ Alma Chaab</strong>
          </Link>
          <Link href="/" className="priv-back">
            ← Į pagrindinį puslapį
          </Link>
        </div>
      </div>

      <main className="priv-shell">
        <header className="priv-hero">
          <p className="priv-eyebrow">{site.name} · {site.address}</p>
          <h1>Apie mus</h1>
          <p>
            Alma Chaab — šeimos restoranas Kėdainių senamiestyje. Jį įkūrė kėdainietė Irina Eid ir
            jos vyras Elie Eid, kilęs iš Libano. Virtuvėje daugiausia libanietiški patiekalai, šalia
            jų — sirietiškos ir turkiškos klasikos bei keli europietiški patiekalai su rytietiškais
            prieskoniais.
          </p>
        </header>


        <article className="priv-prose">
          <section>
            <h2>Ką reiškia „Alma Chaab“</h2>
            <p>
              Pavadinimas kilęs iš Pietų Libano kaimo, iš kurio kilusi Elie šeima, o arabiškai
              „chaab“ reiškia „žmonės“. Beje, svečiai dažnai Iriną vadina Alma — manydami, kad
              restoranas pavadintas jos vardu.
            </p>
          </section>

          <section className="about-people">
            <h2>Žmonės už stalo ir virtuvėje</h2><p>{s.content.visitor?.ownership}</p>
            <figure className="about-figure">
              <img
                src="/images/irina-eid-alma-chaab.webp"
                alt="Irina Eid, Alma Chaab vadovė, su didele rytietiškų patiekalų lėkšte"
                width={1400}
                height={934}
                loading="lazy"
                decoding="async"
              />
              <figcaption>Irina Eid, Alma Chaab vadovė.</figcaption>
            </figure>
            <p>
              <strong>Irina Eid</strong> — restorano vadovė, kėdainietė ir profesionali fotografė.
              Jos darytos Libano pakrantės nuotraukos puošia restorano sienas.
            </p>
            <p>
              <strong>Elie Eid</strong> — virtuvės šefas, kilęs iš Libano. 
            </p>
          </section>

          <section>
            <h2>Nuo kepyklėlės idėjos iki restorano</h2>
            <p>
              Viskas prasidėjo nuo duonos: draugai taip mėgo Elie kepamą duoną, ypač fokačą, kad
              šeima ėmė svajoti apie nedidelę kepyklėlę. Patalpos Didžiojoje gatvėje iš pradžių
              atrodė per didelės, tačiau apžiūrėję jas trečią kartą nusprendė rizikuoti — ir
              kepyklėlės idėja išaugo į restoraną.
            </p>
            <blockquote>
              „Nenorim šokti aukščiau, norim sveikai konkuruoti.“
              <cite>— Irina Eid apie kainas, „Kėdainių mugė“</cite>
            </blockquote>
          </section>

          <section>
            <h2>Erdvės</h2>
            <ul>
              <li>{s.content.visitor?.privateRoom}</li>
              <li>Privačiam renginiui galima užsisakyti ir pirmą aukštą.</li>
              <li>Vaikų kampelis, kurio sienas išpiešė kėdainietė menininkė Vitalija Danusienė.</li>
              <li>Alyvmedžiai ir bananmedžiai salėje, jaukus kiemelis.</li>
            </ul>
            <p>
              <Link href="/#meniu">Peržiūrėti meniu ir rezervuoti staliuką →</Link>
            </p>
          </section>

          <section className="about-press">
            <h2>Apie mus rašė</h2>
            <a className="about-press-card" href={press.url} target="_blank" rel="noopener">
              <small>
                {press.publisher.name} · 2025 m. liepos 16 d. · {press.author.name}
              </small>
              <strong>{press.headline}</strong>
              <span>Skaityti straipsnį muge.eu →</span>
            </a>
            <p>
              Trumpą šio straipsnio santrauką rasite ir mūsų{" "}
              <Link href="/straipsniai/kedainiu-muge-apie-alma-chaab">straipsnių skiltyje</Link>.
            </p>
          </section>

          <section className="priv-contact">
            <h2>Rekvizitai ir kontaktai</h2>
            <address>
              <span>{legalName}</span>
              <span>Įmonės kodas {companyCode}</span>
              <span>{site.address}</span>
              <a href={`tel:${site.phone}`}>{site.phoneDisplay}</a>
              <a href={`mailto:${site.email}`}>{site.email}</a>
              {site.mapsUrl && (
                <a href={site.mapsUrl} target="_blank" rel="noopener">
                  Atsiliepimai Google
                </a>
              )}
              {site.facebookUrl && (
                <a href={site.facebookUrl} target="_blank" rel="noopener">
                  Facebook
                </a>
              )}
            </address>
          </section>
        </article>
      </main>
    </div>
  );
}
