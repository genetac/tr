import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./cms-public.css";
import { Toaster } from "@/components/ui/toaster";

const SITE = process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXTAUTH_URL || "https://almachaab.lt";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: {
    default: "Alma Chaab — libaniškas restoranas Kėdainių senamiestyje",
    template: "%s | Alma Chaab",
  },
  description:
    "Libaniškos virtuvės restoranas Kėdainių senamiestyje, Didžioji g. 25. Pietūs, vakarienė, šventės, maistas išsinešimui ir staliuko rezervacija internetu.",
  keywords: [
    "restoranai Kėdainiuose",
    "geriausi restoranai Kėdainiuose",
    "restoranas Kėdainiai",
    "kur pavalgyti Kėdainiuose",
    "restoranai Kėdainių centre",
    "restoranai Kėdainių senamiestyje",
    "libanietiškas restoranas Kėdainiuose",
    "pietūs Kėdainiuose",
    "vakarienė Kėdainiuose",
    "banketas Kėdainiuose",
    "maistas išsinešti Kėdainiuose",
    "rezervacija restorane Kėdainiuose",
    "kavinės Kėdainiuose",
    "Alma Chaab",
  ],
  applicationName: "Alma Chaab",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/icon-192.png", type: "image/png", sizes: "192x192" },
    ],
    apple: "/apple-touch-icon.png",
  },
  authors: [{ name: "Alma Chaab" }],
  creator: "Alma Chaab",
  publisher: "Alma Chaab",
  formatDetection: {
    email: false,
    address: true,
    telephone: true,
  },
  openGraph: {
    type: "website",
    locale: "lt_LT",
    url: SITE,
    siteName: "Alma Chaab",
    title: "Alma Chaab — libaniškos virtuvės restoranas Kėdainių senamiestyje",
    description:
      "Kur pavalgyti Kėdainiuose? Alma Chaab — Libano skoniai, pietūs, vakarienės, banketai ir maistas išsinešimui Didžiojoje g. 25, Kėdainių senamiestyje.",
    images: [
      {
        url: "/images/og-cover.jpg",
        width: 1200,
        height: 630,
        alt: "Alma Chaab — restoranas Kėdainiuose, Didžioji g. 25",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Alma Chaab — restoranas Kėdainiuose · Libano virtuvė",
    description:
      "Libano skoniai Kėdainių senamiestyje: pietūs, vakarienės, banketai, maistas išsinešimui ir staliuko rezervacija internetu.",
    images: ["/images/og-cover.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: { canonical: SITE },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#f7f1e8",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="lt" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground">{children}</body>
    </html>
  );
}
