import '../../privatumas.css';
import {notFound} from 'next/navigation';import {can} from '@/lib/auth';import Home from '@/app/page';import {getDocument} from '@/lib/cms';import {getSettings,publicSettings} from '@/lib/settings';import {StandalonePage} from '@/components/cms/StandalonePage';import {PreviewSelectionBridge} from '@/components/admin/PreviewSelectionBridge';
export const dynamic='force-dynamic';export const metadata={title:'Privati peržiūra',robots:{index:false,follow:false}};
export default async function Preview({searchParams}:{searchParams:Promise<{key?:string}>}){if(!await can('content'))notFound();const q=await searchParams;const key=q.key||'content';let rendered;
 if(key==='content')rendered=await Home({searchParams:Promise.resolve({preview:'1'})});
 else if(key.startsWith('page:')||key.startsWith('article:')){const doc=await getDocument(key);rendered=<StandalonePage page={key.startsWith('article:')?{...doc.draft,blocks:doc.draft.body,description:doc.draft.excerpt}:doc.draft} settings={publicSettings(await getSettings())} preview/>;}
 else notFound();
 return <><PreviewSelectionBridge/>{rendered}</>;
}
