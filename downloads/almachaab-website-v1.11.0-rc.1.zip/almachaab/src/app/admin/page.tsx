import { can,getSessionState } from "@/lib/auth";
import { AdminGate } from "@/components/admin/AdminApp";
import "../site-scoped.css";
import "../site-addendum.css";
import "../site-mobile.css";
import "./admin.css";

export const dynamic = "force-dynamic";

export const metadata = {
  title: { absolute: "Alma Chaab · Valdymas" },
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  // Cookie-based check for the normal case; AdminGate re-checks with the
  // localStorage token fallback when cookies are blocked (preview iframes).
  const authed = await can("help");
  return <AdminGate initialAuthed={authed} initialMustChange={(await getSessionState()).mustChangePassword} />;
}
