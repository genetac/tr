import {notFound} from "next/navigation";
import {publishedPage,getDocument,pageRecords} from "@/lib/cms";
import {can} from "@/lib/auth";
import {StandalonePage} from "@/components/cms/StandalonePage";
import type { Metadata } from "next";
import Link from "next/link";
import { CookieConsent } from "@/components/site/CookieConsent";
import { getSettings } from "@/lib/settings";
import { getStoreSettings } from "@/lib/settings";
import { stripeEnabled, paypalEnabled } from "@/lib/payments";
import { getSocialConfig, publicSocialConfig } from "@/lib/social-auth";
import { getSetting } from "@/lib/settings";
import "../privatumas.css";

const legacyMetadata: Metadata = {
  title: { absolute: "Privatumo politika | Alma Chaab" },
  description:
    "Kaip UAB „Chaab“ renka, naudoja ir saugo jūsų duomenis: užsakymų formos, staliuko rezervacijos, kliento paskyros, slapukai ir BDAR teisės. Susisiekite: info@almachaab.lt.",
  alternates: { canonical: "/privatumas" },
};

// Reads live settings for the conditional sections (payments / email / social).
export async function generateMetadata({searchParams}:{searchParams:Promise<{preview?:string}>}){
 if((await searchParams).preview==='1')return {title:'Juodraščio peržiūra',robots:{index:false,follow:false}};
 const record=await publishedPage('privatumas');return record?{...legacyMetadata,title:{absolute:record.published.title},description:record.published.description}:legacyMetadata;
}

export const dynamic = "force-dynamic";

export default async function PrivacyPage({searchParams}:{searchParams:Promise<{preview?:string;doc?:string}>}) {
 const query=await searchParams;const preview=query.preview==='1'&&await can('content');
 const record=preview&&query.doc?await getDocument(`page:${query.doc}`):(await pageRecords()).find(p=>p.published?.slug==='privatumas');
 const page=preview?(record as any)?.draft:(record as any)?.published;
 if(page?.visible===false&&!preview)notFound();
 if(page)return <StandalonePage page={page} settings={await getSettings()} preview={preview}/>;

  const [s, store, socialCfg] = await Promise.all([getSettings(), getStoreSettings(), getSocialConfig()]);
  const social = publicSocialConfig(socialCfg);
  const stripeOn = stripeEnabled(store);
  const paypalOn = paypalEnabled(store);
  const anyPayments = stripeOn || paypalOn;
  const emailOn = s.email?.enabled === true;
  const pushOn = Boolean(await getSetting<{ publicKey: string }>("vapid"));
  const socialOn = social.google || social.facebook || social.telegram;
  const analyticsOn = s.analytics?.enabled === true;
  const legalName = s.site.legalName || "UAB „Chaab“";
  const companyCode = s.site.companyCode || "307075624";

  return (
    <div className="alma-root priv-page">
      <div className="priv-topbar">
        <div className="priv-topbar-in">
          <Link href="/" className="brand">
            <strong>✦ Alma Chaab</strong>
          </Link>
          <Link href="/" className="priv-back">
            ← Į pagrindinį puslapį
          </Link>
        </div>
      </div>

      <main className="priv-shell">
        <header className="priv-hero">
          <p className="priv-eyebrow">Alma Chaab · Kėdainių senamiestis</p>
          <h1>Privatumo politika</h1>
          <p>
            Ši politika paaiškina, kokių duomenų renkamės ir kaip juos naudojame dirbdami su
            svetaine almachaab.lt — priimdami užsakymus, staliuko rezervacijas ir tvarkydami
            kliento paskyras. Renkame tik tuos duomenis, kurių reikia paslaugoms suteikti.
          </p>
        </header>

        <article className="priv-prose">
          <section className="priv-contact">
            <h2>Duomenų valdytojas</h2>
            <address>
              <span>{legalName}</span>
              <span>Įmonės kodas {companyCode}</span>
              <span>Didžioji g. 25, Kėdainiai</span>
              <a href="mailto:info@almachaab.lt">info@almachaab.lt</a>
            </address>
          </section>

          <section>
            <h2>Kokius duomenis renkame</h2>
            <p>Priklausomai nuo to, kaip naudojatės svetaine, galime tvarkyti šiuos duomenis:</p>
            <ul>
              <li>
                <strong>Užsakymų formos:</strong> vardas, telefonas, el. paštas bei jūsų užsakymų
                istorija — pasirinkti patiekalai, užsakymo data, suma ir mokėjimo būdas.
              </li>
              <li>
                <strong>Staliuko rezervacijos:</strong> rezervacijos data ir laikas, svečių
                skaičius bei jūsų pateiktos pastabos (pvz., dėl alergijų ar progos).
              </li>
              <li>
                <strong>Kliento paskyros:</strong> el. paštas, vardas, telefonas ir sukaupti
                lojalumo taškai.
              </li>
              <li>
                <strong>Techniniai sesijos slapukai:</strong> būtini, kad svetainė veiktų —
                įsimintų prekių krepšelį ir jūsų pasirinkimus apsilankymo metu. Jie nustatomi
                automatiškai ir jūsų tapatybės neatskleidžia.
              </li>
            </ul>
          </section>

          <section>
            <h2>Kaip naudojame duomenis</h2>
            <ul>
              <li>
                <strong>Užsakymams ir rezervacijoms vykdyti</strong> — paruošti patiekalus,
                suderinti stalelį ir priimti mokėjimą.
              </li>
              <li>
                <strong>Susisiekimui su jumis</strong> — išsiųsti užsakymo ar rezervacijos
                patvirtinimus, kvitus ir būsenos pranešimus.
              </li>
            </ul>
            <p>
              Jūsų duomenų nenaudojame reklamos tikslams ir jų neperduodame kitiems tikslams, nei
              nurodyta šioje politikoje.
            </p>
          </section>

          <section>
            <h2>Slapukai</h2>
            <p>
              Ši svetainė naudoja <strong>tik būtinuosius slapukus</strong>: jie įsimena prekių
              krepšelį ir jūsų pasirinkimus apsilankymo metu, be jūsų sutikimo veikti svetainės
              neįmanoma, todėl jie nustatomi automatiškai. Jokios statistikos ar rinkodaros
              slapukų šiuo metu nenaudojame.
            </p>
            <p>
              Jei ateityje įdiegsime svetainės statistikos įrankius, jie veiks tik gavę jūsų
              aiškų sutikimą — tuomet puslapyje atsiras sutikimo pranešimas, kuriame statistiką
              galėsite ir atšaukti.
            </p>
          </section>

          <section>
            <h2>Duomenų perdavimas tretiesiems asmenims</h2>
            <p>Jūsų duomenų neparduodame. Juos teikiame tik tiek, kiek būtina paslaugai suteikti:</p>
            <ul>
              {anyPayments && (
                <li>
                  <strong>
                    Mokėjimų paslaugų teikėjams{stripeOn && paypalOn ? " (Stripe, PayPal)" : stripeOn ? " (Stripe)" : " (PayPal)"}
                  </strong>{" "}
                  — kad jūsų mokėjimas būtų saugiai įvykdytas.
                </li>
              )}
              {emailOn && (
                <li>
                  <strong>Pašto serveriui</strong> — kad užsakymų patvirtinimai ir kvitai pasiektų
                  jūsų nurodytą el. paštą.
                </li>
              )}
              {pushOn && (
                <li>
                  <strong>Naršyklės pranešimų paslaugai</strong> — tik jūsų prašymu įjungus push
                  pranešimus apie užsakymo būseną.
                </li>
              )}
              {socialOn && (
                <li>
                  <strong>Socialinio prisijungimo paslaugų teikėjams</strong>
                  {social.google && social.facebook ? " (Google, Facebook)" : social.google ? " (Google)" : " (Facebook)"}
                  {social.telegram ? " ir Telegram" : ""} — tik prisijungdami per juos.
                </li>
              )}
            </ul>
            <p>
              Užsakymus galite atlikti ir Wolt platformoje — ten duomenis tvarko pati Wolt pagal
              savo privatumo politiką; į Wolt iš šios svetainės jūsų duomenys nesiunčiami.
            </p>
          </section>

          <section>
            <h2>Kiek laiko saugome duomenis</h2>
            <p>
              Užsakymų ir rezervacijų duomenis saugome ne ilgiau kaip 2 metus nuo užsakymo — tiek,
              kad galėtume aptarnauti pasikartojančius svečius ir, prireikus, pateikti užsakymo
              kopijas. Gavus jūsų prašymą, duomenis pašaliname anksčiau.
            </p>
          </section>

          <section>
            <h2>Jūsų teisės</h2>
            <p>
              Pagal Bendrąjį duomenų apsaugos reglamentą (BDAR) turite teisę susipažinti su jūsų
              tvarkomais duomenimis, reikalauti netikslius duomenis ištaisyti, o duomenis —
              ištrinti. Pareiškimą galite pateikti el. paštu{" "}
              <a href="mailto:info@almachaab.lt">info@almachaab.lt</a> — atsakysime per 30 dienų.
              Jei manote, kad jūsų teisės pažeistos, turite teisę skųstis Valstybinei duomenų
              apsaugos inspekcijai (<a href="https://vdai.lrv.lt" target="_blank" rel="noopener">vdai.lrv.lt</a>).
            </p>
          </section>

          <section className="priv-contact">
            <h2>Susisiekite su mumis</h2>
            <p>Dėl privatumo klausimų ar duomenų prašymų kreipkitės:</p>
            <address>
              <span>{legalName}</span>
              <span>Įmonės kodas {companyCode}</span>
              <span>Didžioji g. 25, Kėdainiai</span>
              <a href="mailto:info@almachaab.lt">info@almachaab.lt</a>
              <a href="tel:+37066613055">+370 666 13 055</a>
            </address>
          </section>

          <p className="priv-effective">
            Galioja nuo 2026-10-14. Jei politiką atnaujinsime, naujausia jos versija visada bus
            paskelbta šiame puslapyje.
          </p>
        </article>
      </main>

      {/* Consent banner only while web analytics is enabled (D1). */}
      {analyticsOn && <CookieConsent enabled />}
    </div>
  );
}
