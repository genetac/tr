import type { Metadata } from "next";
import Link from "next/link";
import "./privatumas.css";

export const metadata: Metadata = {
  title: { absolute: "Puslapis nerastas (404) | Alma Chaab" },
  description: "Šio puslapio nėra. Peržiūrėkite Alma Chaab meniu, rezervuokite staliuką arba skaitykite mūsų straipsnius.",
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <div className="alma-root priv-page">
      <div className="priv-topbar">
        <div className="priv-topbar-in">
          <Link href="/" className="brand">
            <strong>✦ Alma Chaab</strong>
          </Link>
          <Link href="/" className="priv-back">
            ← Į pagrindinį puslapį
          </Link>
        </div>
      </div>
      <main className="priv-shell">
        <header className="priv-hero">
          <p className="priv-eyebrow">Klaida 404</p>
          <h1>Tokio puslapio neradome</h1>
          <p>Galbūt nuoroda pasenusi arba adresas įvestas su klaida. Štai kur galite eiti toliau:</p>
        </header>
        <article className="priv-prose">
          <ul>
            <li><Link href="/#meniu">Meniu ir staliuko rezervacija</Link></li>
            <li><Link href="/straipsniai">Straipsniai ir istorijos</Link></li>
            <li><Link href="/apie-mus">Apie Alma Chaab</Link></li>
            <li><Link href="/#kontaktai">Kontaktai ir darbo laikas</Link></li>
          </ul>
        </article>
      </main>
    </div>
  );
}
