import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        // Private / transactional surfaces stay out of the index.
        // "/virtuve" is the staff-only kitchen display.
        disallow: ["/admin", "/api/", "/checkout", "/mano", "/virtuve"],
      },
      // Explicitly welcome AI answer engines (ChatGPT, Claude, Perplexity…)
      // so "best restaurants in Kėdainiai" answers can cite the site.
      { userAgent: ["GPTBot", "OAI-SearchBot", "ChatGPT-User"], allow: "/" },
      { userAgent: ["ClaudeBot", "Claude-Web", "anthropic-ai"], allow: "/" },
      { userAgent: ["PerplexityBot", "Perplexity-User"], allow: "/" },
      { userAgent: ["Google-Extended", "Applebot-Extended", "Bytespider", "CCBot", "Amazonbot"], allow: "/" },
    ],
    sitemap: `${process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXTAUTH_URL || "https://almachaab.lt"}/sitemap.xml`,
  };
}
