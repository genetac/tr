"use client";

/**
 * Slapukų sutikimo juosta + Google Consent Mode v2.
 *
 * Savarankiška by design: GA4 kol kas neprijungtas, todėl visi consent
 * įvykiai push'inami į window.dataLayer per standartinį gtag šimą
 * (window.dataLayer = window.dataLayer || []; gtag(){dataLayer.push(args);}).
 * Kai ateityje atsiras GA4 scenarijus, jis paveldės šiuos įvykius be jokių
 * papildomų pakeitimų.
 *
 * Pasirinkimas saugomas localStorage "alma-consent-v2":
 * { v: 2, analytics: boolean, at: ISO-date }
 * Juostą galima vėl atidaryti nuėjus į bet kokį puslapį su #slapukai
 * (pvz., /privatumas#slapukai).
 */

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import "./CookieConsent.css";

const STORAGE_KEY = "alma-consent-v2";
const REOPEN_HASH = "#slapukai";

type ConsentValue = "granted" | "denied";

/** Consent Mode v2 laukai (reklamos — visada denied, atnaujiname tik analitiką). */
interface ConsentFields {
  ad_storage: ConsentValue;
  ad_user_data: ConsentValue;
  ad_personalization: ConsentValue;
  analytics_storage: ConsentValue;
}

/** Išsaugoto sutikimo įrašo forma localStorage. */
interface StoredConsent {
  v: 2;
  analytics: boolean;
  at: string;
}

type GtagFn = (...args: unknown[]) => void;

type WindowWithConsent = Window & {
  dataLayer?: unknown[];
  gtag?: GtagFn;
};

function deniedAll(): ConsentFields {
  return {
    ad_storage: "denied",
    ad_user_data: "denied",
    ad_personalization: "denied",
    analytics_storage: "denied",
  };
}

function consentFor(analytics: boolean): ConsentFields {
  return { ...deniedAll(), analytics_storage: analytics ? "granted" : "denied" };
}

/**
 * Standartinis Consent Mode šablonas: jei gtag dar neapibrėžtas, sukuriame
 * window.dataLayer ir gtag funkciją, kuri tik pushina argumentus į eilę.
 */
function pushConsent(cmd: "default" | "update", fields: ConsentFields): void {
  if (typeof window === "undefined") return;
  const w = window as WindowWithConsent;
  if (typeof w.gtag !== "function") {
    const layer: unknown[] = Array.isArray(w.dataLayer) ? w.dataLayer : [];
    w.dataLayer = layer;
    w.gtag = (...args: unknown[]): void => {
      layer.push(args);
    };
  }
  w.gtag("consent", cmd, fields);
}

function readStoredConsent(): StoredConsent | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (parsed !== null && typeof parsed === "object" && "analytics" in parsed) {
      const v = (parsed as { v?: unknown }).v;
      const analytics = (parsed as { analytics?: unknown }).analytics;
      if (v === 2 && typeof analytics === "boolean") {
        const at = (parsed as { at?: unknown }).at;
        return {
          v: 2,
          analytics,
          at: typeof at === "string" ? at : new Date(0).toISOString(),
        };
      }
    }
  } catch {
    /* sugedęs arba neprieinamas localStorage — laikome, kad pasirinkimo nėra */
  }
  return null;
}

export function CookieConsent({ enabled = false }: { enabled?: boolean }) {
  // D1: no analytics configured → the site only uses essential storage,
  // which needs no consent banner. Nothing renders and no consent events
  // are pushed; the component stays ready for when analytics.enabled flips.
  if (!enabled) return null;

  return (
    <CookieConsentInner />
  );
}

function CookieConsentInner() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // 1) Numatytieji Consent Mode v2 nustatymai — viskas "denied", prieš
    //    bet kokią (būsimą) analitiką.
    pushConsent("default", deniedAll());

    // 2) Ankstesni apsilankymai: atkuriame išsaugotą pasirinkimą dar prieš
    //    bet kokį būsimą GA4 paleidimą.
    const stored = readStoredConsent();
    if (stored) pushConsent("update", consentFor(stored.analytics));

    // 3) Pirmas apsilankymas (nėra pasirinkimo) arba #slapukai — rodome juostą.
    //    Sprendimas priimamas po pirmo paint (ne sinchroniškai efekte), kad
    //    išvengtume kaskadinių renderių.
    const raf = window.requestAnimationFrame(() => {
      setOpen(window.location.hash === REOPEN_HASH || !stored);
    });

    const onHashChange = (): void => {
      if (window.location.hash === REOPEN_HASH) setOpen(true);
    };
    window.addEventListener("hashchange", onHashChange);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("hashchange", onHashChange);
    };
  }, []);

  const decide = useCallback((analytics: boolean): void => {
    const record: StoredConsent = { v: 2, analytics, at: new Date().toISOString() };
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(record));
    } catch {
      /* neprieinamas localStorage — sutikimas galios tik šiam apsilankymui */
    }
    pushConsent("update", consentFor(analytics));
    setOpen(false);
  }, []);

  if (!open) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-modal="false" aria-label="Slapukų sutikimas">
      <div className="cookie-banner-card">
        <p className="cookie-banner-text">
          <strong>Naudojame slapukus.</strong> Būtini slapukai reikalingi, kad svetainė veiktų —
          įsimintų jūsų prekių krepšelį ir pasirinkimus. Statistikos slapukai („Google Analytics")
          įsijungia tik jūsų sutikimu ir padeda mums gerinti svetainę.{" "}
          <Link href="/privatumas">Privatumo politika</Link>
        </p>
        <div className="cookie-banner-actions">
          <button type="button" className="cookie-btn cookie-accept" onClick={() => decide(true)}>
            Sutinku
          </button>
          <button type="button" className="cookie-btn cookie-reject" onClick={() => decide(false)}>
            Tik būtini
          </button>
        </div>
      </div>
    </div>
  );
}
