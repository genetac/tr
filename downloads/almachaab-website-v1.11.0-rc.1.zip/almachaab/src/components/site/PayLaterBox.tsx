"use client";

import { useEffect, useId, useRef, useState } from "react";
import { AmexMark, MastercardMark, VisaMark } from "./PayMarks";

/* ------------------------------------------------------------------ */
/* PayLaterBox — pay-now wall for an EXISTING unpaid order (on /mano:  */
/* the guest tracker card + the logged-in order history).              */
/* Same professional style as the checkout wall: the official gold     */
/* PayPal Smart Buttons (horizontal → gold PayPal + PayPal's own black */
/* card button side by side) next to the branded "Mokėti kortele"      */
/* button (Stripe) when cards are configured. createOrder fires AT     */
/* CLICK TIME → /api/checkout/paypal/existing, and an identical click  */
/* reuses the same PayPal order (no duplicate rows after cancel).      */
/* ------------------------------------------------------------------ */

interface PayCfg {
  isOpen: boolean;
  currency: string;
  stripeEnabled: boolean;
  paypalEnabled: boolean;
  paypalClientId: string | null;
}

// Minimal shape of the PayPal Smart Payment Buttons SDK we use.
interface PaypalSdk {
  Buttons: (opts: {
    style?: Record<string, string | number>;
    createOrder: () => string | Promise<string>;
    onApprove: (data: { orderID: string }) => void;
    onCancel?: () => void;
    onError?: (err: unknown) => void;
  }) => { render: (selector: string) => void };
}

// One fetch per session for the public gateway flags.
let payCfgCache: PayCfg | null = null;

async function loadPayCfg(): Promise<PayCfg | null> {
  if (payCfgCache) return payCfgCache;
  try {
    const res = await fetch("/api/payments/config", { cache: "no-store" });
    if (res.ok) {
      payCfgCache = (await res.json()) as PayCfg;
      return payCfgCache;
    }
  } catch {
    /* offline — treat as unavailable */
  }
  return null;
}

export function PayLaterBox({ number, auth, onPaid }: { number: string; auth?: { t?: string; p4?: string }; onPaid?: () => void }) {
  const [cfg, setCfg] = useState<PayCfg | null>(payCfgCache);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  // Hooks must run unconditionally — the container id is used further down.
  const containerId = `pp-existing-${useId().replace(/[^a-zA-Z0-9-]/g, "")}`;

  useEffect(() => {
    if (!cfg) void loadPayCfg().then((c) => setCfg(c));
  }, [cfg]);

  const online = Boolean(cfg && cfg.stripeEnabled) || Boolean(cfg && cfg.paypalEnabled);
  if (done) {
    return <div className="paylater-done">✓ Apmokėta — dėkojame!</div>;
  }
  if (!online) return null;

  async function payStripe() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/checkout/stripe/existing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ number, ...(auth || {}) }), // SEC-010: same credentials as tracking
      });
      const json = await res.json();
      if (!res.ok || !json.url) throw new Error(json.error || "Nepavyko pradėti apmokėjimo.");
      window.location.assign(json.url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Klaida.");
      setBusy(false);
    }
  }

  return (
    <div className="paylater-box" aria-label={`Apmokėti užsakymą ${number}`}>
      <span className="paylater-title">Šis užsakymas dar neapmokėtas</span>
      <div className={"paylater-wall" + (cfg?.stripeEnabled ? "" : " solo")}>
        {cfg?.paypalEnabled && cfg?.paypalClientId && (
          <PaypalExistingButtons
            containerId={containerId}
            number={number}
            auth={auth}
            currency={cfg.currency}
            clientId={cfg.paypalClientId}
            onCaptured={() => {
              setDone(true);
              onPaid?.();
            }}
            onError={setError}
          />
        )}
        {cfg?.stripeEnabled && (
          <button type="button" className="pay-btn-card" onClick={payStripe} disabled={busy}>
            <span className="pay-btn-card-copy">
              <strong>Mokėti kortele</strong>
              <small>Greitas ir saugus apmokėjimas</small>
            </span>
            <span className="card-marks" aria-hidden="true">
              <VisaMark />
              <MastercardMark />
              <AmexMark />
            </span>
          </button>
        )}
      </div>
      {error && <div className="checkout-error" role="alert">{error}</div>}
    </div>
  );
}

/* PayPal Smart Buttons for an existing order — the SDK is loaded once per
 * page and each box renders its own button row into a unique container. */
function PaypalExistingButtons({
  containerId,
  number,
  auth,
  currency,
  clientId,
  onCaptured,
  onError,
}: {
  containerId: string;
  number: string;
  auth?: { t?: string; p4?: string };
  currency: string;
  clientId: string;
  onCaptured: () => void;
  onError: (msg: string) => void;
}) {
  const renderedRef = useRef(false);
  const ppOrderIdRef = useRef("");
  // remember when WE set a precise error so PayPal's generic onError does
  // not overwrite it (it always fires after a rejected createOrder)
  const customErrAt = useRef(0);
  const onCapturedRef = useRef(onCaptured);
  const onErrorRef = useRef(onError);
  useEffect(() => {
    onCapturedRef.current = onCaptured;
    onErrorRef.current = onError;
  }, [onCaptured, onError]);

  useEffect(() => {
    const fail = (msg: string) => {
      customErrAt.current = Date.now();
      onErrorRef.current(msg);
    };
    const render = () => {
      const pp = (window as unknown as { paypal?: PaypalSdk }).paypal;
      if (!pp || renderedRef.current) return;
      renderedRef.current = true;
      pp.Buttons({
        // horizontal → gold PayPal + PayPal's black card button SIDE BY SIDE,
        // exactly like the checkout wall
        // PayPal typings declare style values as string|number, but the JS SDK
        // accepts booleans — tagline:false hides the caption line under the button.
        style: { layout: "horizontal", color: "gold", shape: "rect", label: "paypal", height: 46, tagline: false } as unknown as { layout: "horizontal"; color: "gold"; shape: "rect"; label: "paypal"; height: number },
        createOrder: async () => {
          try {
            // Same order number → reuse the same PayPal order (cancel → retry
            // must not pile up duplicate gateway orders).
            if (ppOrderIdRef.current) return ppOrderIdRef.current;
            const res = await fetch("/api/checkout/paypal/existing", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ number, ...(auth || {}) }), // SEC-010: same credentials as tracking
            });
            const json = await res.json();
            if (!res.ok || !json.paypalOrderId) throw new Error(json.error || "Nepavyko pradėti PayPal apmokėjimo.");
            ppOrderIdRef.current = json.paypalOrderId as string;
            return ppOrderIdRef.current;
          } catch (e) {
            fail(e instanceof Error ? e.message : "PayPal klaida.");
            throw e; // aborts the popup — the message is already on screen
          }
        },
        onApprove: async (approval) => {
          try {
            const res = await fetch("/api/checkout/paypal/capture", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ paypalOrderId: approval.orderID }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || "PayPal apmokėjimo nepavyko patvirtinti.");
            onCapturedRef.current();
          } catch (e) {
            onErrorRef.current(e instanceof Error ? e.message : "PayPal klaida.");
          }
        },
        onCancel: () => {
          onErrorRef.current("Apmokėjimas atšauktas — galite bandyti dar kartą.");
        },
        onError: () => {
          if (Date.now() - customErrAt.current < 1500) return;
          onErrorRef.current("PayPal klaida — pabandykite dar kartą arba paskambinkite mums.");
        },
      }).render(`#${containerId}`);
    };

    const w = window as unknown as { paypal?: PaypalSdk };
    if (w.paypal) {
      render();
      return;
    }
    let script = document.querySelector<HTMLScriptElement>("script[data-paypal-sdk]");
    if (!script) {
      script = document.createElement("script");
      script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=${currency || "EUR"}&intent=capture&components=buttons&enable-funding=card&locale=lt_LT`;
      script.async = true;
      script.dataset.paypalSdk = "1";
      script.onload = () => {
        renderedRef.current = false;
        render();
      };
      script.onerror = () => onErrorRef.current("Nepavyko įkelti PayPal. Pabandykite atsiskaityti kortele arba paskambinkite.");
      document.head.appendChild(script);
    } else {
      script.addEventListener("load", () => {
        renderedRef.current = false;
        render();
      });
    }
  }, [containerId, number, currency, clientId]);

  return <div id={containerId} className="paylater-paypal-host" />;
}
