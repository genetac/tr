"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { c, eur, CATEGORY_TAG, CATEGORY_DESC, type SiteData } from "./helpers";

export type FlowMode = "choose" | "menu-reserve" | "menu-pickup" | "reserve-form" | "pickup-form" | "done";

interface Props {
  data: SiteData;
  menuOpen: boolean;
  mode: FlowMode;
  setMode: (m: FlowMode) => void;
  cart: Record<string, number>;
  setCart: (c: Record<string, number>) => void;
  onToast: (msg: string) => void;
}

export function MenuBrowser({ data, menuOpen, mode, setMode, cart, setCart, onToast }: Props) {
  const [filter, setFilter] = useState("all");
  const [dietaryFilter, setDietaryFilter] = useState<"all" | "vegetarian" | "vegan" | "halal">("all");
  const [failed, setFailed] = useState<Set<string>>(new Set());
  const railRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef(0);
  const prevModeRef = useRef<FlowMode>(mode);

  const categories = data.categories;
  const allDishes = useMemo(() => categories.flatMap((cat) => cat.items.map((it) => ({ ...it, categoryId: cat.id }))), [categories]);
  const dishById = useMemo(() => new Map(allDishes.map((d) => [d.id, d])), [allDishes]);

  const visibleCats = (filter === "all" ? categories : categories.filter((cat) => cat.id === filter)).map(cat => ({ ...cat, items: cat.items.filter(item => dietaryFilter === "all" || item[dietaryFilter] === true) })).filter(cat => cat.items.length);
  const cartEntries = Object.entries(cart)
    .map(([id, qty]) => ({ dish: dishById.get(id)!, qty }))
    .filter((e) => e.dish && e.qty > 0);
  const cartTotal = cartEntries.reduce((s, e) => s + e.dish.price * e.qty, 0);
  const cartCount = cartEntries.reduce((s, e) => s + e.qty, 0);

  function addItem(id: string, delta = 1) {
    const d = dishById.get(id);
    if (delta > 0 && d && d.inStock === false) {
      onToast(`„${d.name}" šiuo metu išparduota`);
      return;
    }
    const next = Math.max(0, (cart[id] || 0) + delta);
    const copy = { ...cart };
    if (next === 0) delete copy[id];
    else copy[id] = next;
    setCart(copy);
    if (delta > 0) {
      onToast(`${d?.name || "Patiekalas"} pridėtas ✓`);
    }
  }

  // 3D rail effect
  function update3D() {
    const rail = railRef.current;
    if (!rail) return;
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      const rect = rail.getBoundingClientRect();
      const center = rect.left + rail.clientWidth / 2;
      rail.querySelectorAll<HTMLElement>(".category-3d-card").forEach((card) => {
        const r = card.getBoundingClientRect();
        const cardCenter = r.left + r.width / 2;
        const d = Math.max(-1.4, Math.min(1.4, (cardCenter - center) / (r.width + 12)));
        const ad = Math.min(1, Math.abs(d));
        card.style.setProperty("--cat-rot", `${d * 28}deg`);
        card.style.setProperty("--cat-z", `${(1 - ad) * 18}px`);
        card.style.setProperty("--cat-opacity", String(1 - ad * 0.3));
      });
    });
  }

  useEffect(() => {
    if (!menuOpen) return;
    update3D();
    const rail = railRef.current;
    if (rail) {
      rail.addEventListener("scroll", update3D, { passive: true });
      return () => rail.removeEventListener("scroll", update3D);
    }
  }, [menuOpen, filter]);

  // Entering the dish browser ("Pasirinkti patiekalus", pickup flow, "Keisti
  // patiekalus") glides so the TOP of the browser block (return bar + the
  // preorder note) sits right under the sticky header — the guest lands on
  // the menu instead of staring at the spot where the button was.
  useEffect(() => {
    const was = prevModeRef.current;
    prevModeRef.current = mode;
    if (!menuOpen) return;
    if (mode !== "menu-reserve" && mode !== "menu-pickup") return;
    if (was === "menu-reserve" || was === "menu-pickup") return; // already browsing
    const t = setTimeout(() => {
      document.getElementById("menuBrowserArea")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 60);
    return () => clearTimeout(t);
  }, [mode, menuOpen]);

  function centerCard(id: string) {
    const rail = railRef.current;
    if (!rail) return;
    const card = rail.querySelector<HTMLElement>(`[data-filter="${id}"]`);
    if (card) rail.scrollTo({ left: card.offsetLeft - (rail.clientWidth - card.offsetWidth) / 2, behavior: "smooth" });
  }

  function selectCategory(id: string) {
    setFilter(id);
    centerCard(id);
    update3D();
  }

  const menuIntro = data.settings.content;
  const isPickupFlow = mode === "menu-pickup";

  return (
    <div
      className="menu-browser-area"
      id="menuBrowserArea"
      /* Menu stays MINIMIZED until the guest makes their selections — it only
         unfolds while actively picking dishes ("Pasirinkti patiekalus" or the
         pickup flow). The unified reservation composer renders alone otherwise. */
      hidden={!menuOpen || (mode !== "menu-reserve" && mode !== "menu-pickup")}
    >
      <div className="menu-return-bar" id="menuReturnBar" hidden={mode === "choose"}>
        <button
          type="button"
          onClick={() => (isPickupFlow ? setMode("choose") : setMode("reserve-form"))}
        >
          {isPickupFlow ? "← Grįžti" : "Grįžti į rezervaciją →"}
        </button>
      </div>

      <p className="menu-preorder-note">
        <span className="note-icon">✓</span>
        <span>
          <strong>
            {isPickupFlow
              ? "Pasirinkite patiekalus atsiėmimui restorane."
              : "Pasirinkite patiekalus iš anksto — jie keliaus kartu su jūsų staliuko rezervacija."}
          </strong>{" "}
          Kiekvieną patiekalą galima pridėti kelis kartus.
        </span>
      </p>

      <div className="filters" id="filters" role="tablist" aria-label="Meniu kategorijos">
        <button className={`filter ${filter === "all" ? "active" : ""}`} data-filter="all" onClick={() => selectCategory("all")}>
          Visas meniu
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            className={`filter ${filter === cat.id ? "active" : ""}`}
            data-filter={cat.id}
            onClick={() => selectCategory(cat.id)}
          >
            {cat.name}
          </button>
        ))}
      </div>

      <div className="mobile-category-picker" id="mobileCategoryPicker">
        <div className="category-3d-rail" id="mobileCategoryRail" ref={railRef} aria-label="Meniu kategorijos">
          <button
            className={`category-3d-card all-card ${filter === "all" ? "active" : ""}`}
            type="button"
            data-filter="all"
            aria-label="Visas meniu"
            onClick={() => selectCategory("all")}
          >
            <span className="cat-check">✓</span>
            <span className="cat-name">Visas meniu</span>
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`category-3d-card ${filter === cat.id ? "active" : ""}`}
              type="button"
              data-filter={cat.id}
              aria-label={cat.name}
              onClick={() => selectCategory(cat.id)}
            >
              {cat.items[0]?.image && !failed.has(cat.items[0].id) && (
                 
                <img src={cat.items[0].image} alt={cat.items[0].name} loading="lazy" referrerPolicy="no-referrer" onError={() => setFailed(new Set(failed).add(cat.items[0].id))} />
              )}
              <span className="cat-check">✓</span>
              <span className="cat-name">{cat.name}</span>
            </button>
          ))}
        </div>
        <div className="category-active-label" id="mobileCategoryLabel" aria-live="polite">
          Rodoma: <strong>{filter === "all" ? "Visas meniu" : categories.find((x) => x.id === filter)?.name || "Meniu"}</strong>
        </div>
      </div>

      {data.settings.dietaryDisplay?.filters!==false&&<label className="dietary-filter">Mitybos pasirinkimai <select aria-label="Mitybos pasirinkimai" value={dietaryFilter} onChange={e => setDietaryFilter(e.target.value as typeof dietaryFilter)}>
        <option value="all">Visi patiekalai</option><option value="vegetarian">Vegetariški</option><option value="vegan">Veganiški</option><option value="halal">Halal</option>
      </select></label>}
      <p>Rodomos tik komandos priskirtos žymos. Dėl mitybos poreikių ir alergenų teiraukitės komandos.</p>
      {visibleCats.length === 0 && <p role="status">Šio pasirinkimo patiekalų kol kas nenurodyta.</p>}
      <div className="preorder-layout">
        <div className="menu-groups visual-menu" id="menuGroups">
          {visibleCats.map((cat) => (
            <section className="menu-group" key={cat.id} id={`group-${cat.id}`}>
              <div className="menu-group-title">
                <h3>{cat.name}</h3>
                <span>{cat.items.length} pasirinkimai</span>
              </div>
              <div className="menu-cards dish-grid">
                {cat.items.map((item) => {
                  const initials = item.name.split(/\s+/).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
                  const tags = [CATEGORY_TAG[cat.id] || "Patiekalas"];
                  if (item.name.includes("🌶")) tags.push("Aštru");
                  const soldOut = item.inStock === false;
                  return (
                    <article className={`dish-card ${soldOut ? "dish-soldout" : ""}`} key={item.id}>
                      <div className={`dish-photo-wrap ${failed.has(item.id) ? "" : "has-image"}`}>
                        <div className="dish-photo-fallback" aria-hidden="true">{initials}</div>
                        {item.image && !failed.has(item.id) && (
                           
                          <img
                            className="dish-photo"
                            src={item.image}
                            alt={item.name}
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            onError={() => setFailed(new Set(failed).add(item.id))}
                          />
                        )}
                        {soldOut && <span className="dish-soldout-badge" aria-label="Išparduota">Išparduota</span>}
                      </div>
                      <div className="dish-content">
                        <h4 className="dish-name">{item.name}</h4>
                        <p className="dish-description">{item.description || CATEGORY_DESC[cat.id] || "Alma Chaab meniu pasirinkimas."}</p>
                        <div className="dish-tags">
                          {item.vegetarian && <span className="dietary-vegetarian"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 4C9 2 3 7 5 15c7 5 16-1 15-11ZM4 21 16 9" fill="none" stroke="currentColor" strokeWidth="2" /></svg> V · Vegetariškas</span>}
                          {item.vegan && <span>Veganiškas</span>}
                          {item.halal && <span>Halal</span>}
                          {tags.map((t) => (
                            <span key={t}>{t}</span>
                          ))}
                        </div>
                        {item.dietaryNotes && <p className="dish-description">{item.dietaryNotes}</p>}
                        <div className="dish-meta">
                          <span className="dish-price">{eur(item.price)}</span>
                          <button
                            className="dish-add"
                            type="button"
                            disabled={soldOut}
                            onClick={() => addItem(item.id, 1)}
                            aria-label={soldOut ? `${item.name} — išparduota` : `Pridėti ${item.name}`}
                          >
                            <span>{soldOut ? "Išparduota" : "Pridėti"}</span>
                            {!soldOut && <b>＋</b>}
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          ))}
        </div>

        <aside className="preorder-card" id="preorderPanel" aria-label="Pasirinkti patiekalai">
          <p className="eyebrow">{isPickupFlow ? "Atsiėmimui" : "Išankstinis pasirinkimas"}</p>
          <h3>Jūsų pasirinkimai</h3>
          <p>{c(menuIntro, "flow.preorderHint", "Patiekalai bus pridėti prie jūsų užsakymo.")}</p>
          <div className="preorder-items" id="preorderItems">
            {cartEntries.length === 0 ? (
              <div className="preorder-empty">Kol kas nepasirinkote patiekalų.</div>
            ) : (
              cartEntries.map((e) => (
                <div className="preorder-line" key={e.dish.id}>
                  <div className="preorder-line-head">
                    <span className="preorder-line-name">{e.dish.name}</span>
                    <span className="preorder-line-price">{eur(e.dish.price * e.qty)}</span>
                  </div>
                  <div className="qty-row">
                    <button className="qty-btn" type="button" onClick={() => addItem(e.dish.id, -1)} aria-label={`Sumažinti kiekį`}>−</button>
                    <span className="qty-value">{e.qty}</span>
                    <button className="qty-btn" type="button" onClick={() => addItem(e.dish.id, 1)} aria-label="Padidinti kiekį">+</button>
                    <button className="remove-item" type="button" onClick={() => addItem(e.dish.id, -e.qty)}>Pašalinti</button>
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="preorder-total">
            <span>Iš viso</span>
            <strong id="preorderTotal">{eur(cartTotal)}</strong>
          </div>
          {cartCount > 0 && (
            <button className="btn btn-gold" id="goCheckoutBtn" type="button" onClick={() => setMode(isPickupFlow ? "pickup-form" : "reserve-form")}>
              {isPickupFlow ? "Tęsti į atsiėmimą →" : "Tęsti į rezervaciją →"}
            </button>
          )}
          {cartCount > 0 && (
            <button className="btn btn-ghost" id="clearPreorderBtn" type="button" onClick={() => setCart({})}>
              Išvalyti pasirinkimus
            </button>
          )}
        </aside>
      </div>
    </div>
  );
}
