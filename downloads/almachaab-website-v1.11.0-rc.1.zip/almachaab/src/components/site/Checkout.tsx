"use client";

import { useEffect, useMemo, useRef, useState, type MutableRefObject } from "react";
import { c, eur, generatePickupSlots, type SiteData, billiardsBookingNote } from "./helpers";
import type { FlowMode } from "./MenuBrowser";
import { AmexMark, MastercardMark, VisaMark } from "./PayMarks";

interface Props {
  data: SiteData;
  mode: FlowMode;
  setMode: (m: FlowMode) => void;
  cart: Record<string, number>;
  setCart: (c: Record<string, number>) => void;
  clearCart: () => void;
  onToast: (msg: string) => void;
  billiardsSignal: number;
  prefillExperiences?: string[];
  onAddItem?: (id: string) => void;
  /** Tells the page shell when the final checkout takes over, so the
   * intro column can step aside and the pay wall gets the full width. */
  onFinalStage?: (open: boolean) => void;
}

/** Public-safe payment config from /api/payments/config. */
interface PayCfg {
  isOpen: boolean;
  currency: string;
  taxRate: number;
  deliveryFee: number;
  stripeEnabled: boolean;
  paypalEnabled: boolean;
  paypalClientId: string | null;
}

/** "Frequently Bought Together" suggestion from /api/recommendations (drinks only). */
interface Suggestion {
  id: string;
  name: string;
  price: number;
  image: string;
  reason: string;
}

// Minimal shape of the PayPal Smart Payment Buttons SDK we use.
interface PaypalSdk {
  Buttons: (opts: {
    style?: Record<string, string | number>;
    createOrder: () => string | Promise<string>;
    onApprove: (data: { orderID: string }) => void;
    onCancel?: () => void;
    onError?: (err: unknown) => void;
  }) => { render: (selector: string) => void };
}

/* Visual experience composer (v1 prototype) — display text vs stored value.
   Stored values travel in the order's `experiences` field (admin + emails). */
const SCENES = [
  { cls: "scene-table", icon: "🍽", title: "Staliukas", desc: "Pagrindinė vieta jūsų vakarui · galima derinti su kitomis patirtimis", value: "Staliuko rezervacija" },
  { cls: "scene-event", icon: "✦", title: "Šventė / renginys", desc: "Šeimai, draugams ar įmonės vakarui · galima pridėti degustaciją ir biliardą", value: "Šventė / renginys" },
  { cls: "scene-tasting", icon: "◇", title: "Degustacija", desc: "Artimųjų Rytų skonių pažinimas · galima jungti su staliuku ir biliardu", value: "Degustacija" },
  { cls: "scene-billiards", icon: "🎱", title: "Biliardas", desc: "" /* filled from admin → Turinys (billiardsBookingNote) */, value: "Biliardo rezervacija" },
] as const;
const SCENE_CHIP: Record<string, string> = {
  "Staliuko rezervacija": "🍽 Staliukas",
  "Šventė / renginys": "✦ Šventė / renginys",
  "Degustacija": "◇ Degustacija",
  "Biliardo rezervacija": "🎱 Biliardas",
};

export function Checkout({ data, mode, setMode, cart, setCart, clearCart, onToast, billiardsSignal, onAddItem, onFinalStage }: Props) {
  const s = data.settings;
  const allDishes = useMemo(() => data.categories.flatMap((cat) => cat.items), [data.categories]);
  const dishById = useMemo(() => new Map(allDishes.map((d) => [d.id, d])), [allDishes]);

  const cartEntries = Object.entries(cart)
    .map(([id, qty]) => ({ dish: dishById.get(id)!, qty }))
    .filter((e) => e.dish && e.qty > 0);
  const cartTotal = cartEntries.reduce((sum, e) => sum + e.dish.price * e.qty, 0);
  // Client-side preview of the server-authoritative math (PVM %)
  const taxRateView = s.store?.taxRate ?? 0;
  const taxAmountView = Math.round(cartTotal * (taxRateView / 100) * 100) / 100;
  const fullTotal = Math.round((cartTotal + taxAmountView) * 100) / 100;

  // reservation state
  const [step, setStep] = useState(1);
  const [resDate, setResDate] = useState("");
  const [resTime, setResTime] = useState("");
  const [guests, setGuests] = useState(2);
  const [experiences, setExperiences] = useState<string[]>(["Staliuko rezervacija"]);
  const [billiardsTable, setBilliardsTable] = useState("");
  // contact state (shared)
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [note, setNote] = useState("");
  // pickup state
  const [pickupTime, setPickupTime] = useState("");
  const [pickupDay, setPickupDay] = useState("");

  const [error, setError] = useState("");
  // Online payments + customer account prefill
  const [payCfg, setPayCfg] = useState<PayCfg | null>(null);
  // Final checkout stage: after the reservation / pickup form is confirmed,
  // a separate professional checkout block takes over (order review with
  // −/+ steppers + the payment wall, Amazon/Temu style).
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [fetchedSuggestions, setSuggestions] = useState<Suggestion[]>([]);
  const storeClosed = s.store ? s.store.isOpen === false : false;
  // Guards against duplicate orders: sig = exact payload JSON. The PayPal
  // Smart Button reuses the same gateway order for an identical payload
  // (cancel → retry), and "pay at venue" redirects to the order a failed
  // gateway attempt already created instead of creating a twin.
  const payloadRef = useRef<Record<string, unknown>>({});
  const ppOrderRef = useRef<{ sig: string; paypalOrderId: string; number: string } | null>(null);
  const createdOrderRef = useRef<{ sig: string; number: string; trackToken: string } | null>(null);

  const slots = useMemo(
    () => (mode === "pickup-form" ? generatePickupSlots(s.hours as Record<string, [number, number] | null>, s.pickup) : []),
    [mode, s.hours, s.pickup]
  );
  const slotDays = useMemo(() => {
    const days: { ymd: string; label: string }[] = [];
    for (const sl of slots) if (!days.find((d) => d.ymd === sl.ymd)) days.push({ ymd: sl.ymd, label: sl.dayLabel });
    return days;
  }, [slots]);

  useEffect(() => {
    if (mode === "pickup-form" && slots.length && !pickupTime) {
      const t = setTimeout(() => {
        setPickupDay(slots[0].ymd);
        setPickupTime(slots[0].value);
      }, 0);
      return () => clearTimeout(t);
    }
  }, [mode, slots, pickupTime]);

  // Billiards CTA prefill
  useEffect(() => {
    if (billiardsSignal > 0) {
      const t = setTimeout(() => {
        setExperiences(["Biliardo rezervacija"]);
        setStep(1);
      }, 0);
      return () => clearTimeout(t);
    }
  }, [billiardsSignal]);

  useEffect(() => {
    if (mode === "reserve-form") {
      const t = setTimeout(() => {
        setStep(1);
        setCheckoutOpen(false);
      }, 0);
      return () => clearTimeout(t);
    }
  }, [mode]);

  // Entering the reservation / pickup form always glides down to the form
  // block — pressed "Tęsti į rezervaciją" or "Grįžti" → land on the form.
  useEffect(() => {
    if (mode !== "reserve-form" && mode !== "pickup-form") return;
    const t = setTimeout(() => {
      document.getElementById("rezervacija")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
    return () => clearTimeout(t);
  }, [mode]);

  // Opening the checkout block glides down to it as well.
  useEffect(() => {
    if (!checkoutOpen) return;
    const t = setTimeout(() => {
      document.getElementById("rezervacija")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 90);
    return () => clearTimeout(t);
  }, [checkoutOpen]);

  // Final checkout stage signal — the shell hides the sticky intro column
  // while the payment wall is up (everything reachable without scrolling).
  useEffect(() => {
    onFinalStage?.(checkoutOpen);
  }, [checkoutOpen, onFinalStage]);

  // Dynamic gateway/store configuration + signed-in customer prefill
  useEffect(() => {
    fetch("/api/payments/config")
      .then((r) => r.json())
      .then((j: PayCfg) => setPayCfg(j))
      .catch(() => {});
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((j: { user?: { name: string; phone: string; email: string } | null }) => {
        if (j.user) {
          setName((n) => n || j.user!.name || "");
          setPhone((p) => p || j.user!.phone || "");
          setEmail((e) => e || j.user!.email || "");
        }
      })
      .catch(() => {});
  }, []);

  // Smart upsell: "Frequently Bought Together" — debounced per cart contents
  const cartKey = cartEntries.map((e) => `${e.dish.id}:${e.qty}`).join(",");
  // Derived: nothing to suggest for an empty cart or a finished order.
  const suggestions = cartKey && mode !== "done" ? fetchedSuggestions : [];
  useEffect(() => {
    if (!cartKey || mode === "done") return;
    const t = setTimeout(() => {
      const ids = cartKey.split(",").map((pair) => pair.split(":")[0]);
      // Drinks-only upsell: „dažniausiai perkami kartu“ offers beverages, never
      // the whole menu. When the kitchen has no drinks to add, the checkout
      // shows a calm "selection not needed" note instead of the block.
      fetch(`/api/recommendations?ids=${encodeURIComponent(ids.join(","))}&cats=gerimai&limit=4`)
        .then((r) => r.json())
        .then((j: { recommendations?: Suggestion[] }) => {
          setSuggestions(
            (j.recommendations || []).filter((sg) => !ids.includes(sg.id))
          );
        })
        .catch(() => {});
    }, 400);
    return () => clearTimeout(t);
  }, [cartKey, mode]);

  function toggleExperience(exp: string) {
    setExperiences((prev) => (prev.includes(exp) ? prev.filter((x) => x !== exp) : [...prev, exp]));
  }

  const todayYmd = useMemo(() => {
    const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Vilnius", year: "numeric", month: "2-digit", day: "2-digit" });
    return fmt.format(new Date());
  }, []);

  /** Quantity stepper used by the checkout order lines (−/+ like Amazon/Temu). */
  function setQty(id: string, delta: number) {
    const d = dishById.get(id);
    if (delta > 0 && d && d.inStock === false) {
      onToast(`„${d.name}" šiuo metu išparduota`);
      return;
    }
    const next = Math.max(0, (cart[id] || 0) + delta);
    const copy = { ...cart };
    if (next === 0) delete copy[id];
    else copy[id] = Math.min(50, next);
    setCart(copy);
  }

  /** Shared order payload — the single source for every payment path. */
  function buildPayload(type: "pickup" | "reservation"): Record<string, unknown> {
    const payload: Record<string, unknown> = {
      type,
      customerName: name,
      phone,
      email,
      // Honeypot (§F): the hidden field is only filled by bots — normally "".
      company: (document.getElementById("hp-company") as HTMLInputElement | null)?.value || "",
      note:
        type === "reservation" && billiardsTable && experiences.includes("Biliardo rezervacija")
          ? `${note ? note + ". " : ""}Biliardo stalas: ${billiardsTable}`
          : note,
      items: cartEntries.map((e) => ({ id: e.dish.id, qty: e.qty })),
    };
    if (type === "pickup") {
      payload.pickupTime = pickupTime;
    } else {
      payload.resDate = resDate;
      payload.resTime = resTime;
      payload.guests = guests;
      payload.experiences = experiences.join(", ");
    }
    return payload;
  }

  /** Form validation shared by "confirm" and every payment button. */
  function validate(type: "pickup" | "reservation"): string {
    if (storeClosed) return "Šiuo metu nepriimame užsakymų — paskambinkite mums telefonu.";
    if (name.trim().length < 2) return "Įveskite savo vardą.";
    if (phone.replace(/\D/g, "").length < 8) return "Įveskite tikrą telefono numerį.";
    if (type === "reservation" && (!resDate || !resTime)) return "Pasirinkite rezervacijos datą ir laiką.";
    if (type === "pickup" && !pickupTime) return "Pasirinkite atsiėmimo laiką.";
    if (type === "pickup" && cartEntries.length === 0) return "Krepšelis tuščias — pridėkite bent vieną patiekalą.";
    return "";
  }

  /**
   * Reservation / pickup form confirmed → open the separate checkout block.
   * Nothing is charged and no order is created yet — the payment wall inside
   * the block decides what happens next (pay now via PayPal / card, or at
   * the restaurant).
   */
  function openCheckout(type: "pickup" | "reservation") {
    const problem = validate(type);
    setError(problem);
    if (problem) return;
    payloadRef.current = buildPayload(type);
    setCheckoutOpen(true);
    setTimeout(() => document.getElementById("rezervacija")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }

  /** Pay at the restaurant / at pickup — creates the order, no online charge. */
  async function payAtVenue(type: "pickup" | "reservation") {
    const problem = validate(type);
    setError(problem);
    if (problem) return;
    const payload = buildPayload(type);
    const sig = JSON.stringify(payload);
    // A cancelled PayPal / Stripe attempt may already have created this exact
    // order — redirect to it instead of creating a duplicate.
    if (createdOrderRef.current && createdOrderRef.current.sig === sig) {
      setMode("done");
      clearCart();
      const co = createdOrderRef.current;
      window.location.assign(`/mano?nr=${encodeURIComponent(co.number)}${co.trackToken ? `&t=${encodeURIComponent(co.trackToken)}` : ""}`);
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Nepavyko pateikti užsakymo. Pabandykite dar kartą.");
        return;
      }
      // Success → the merged tracking + account page shows live status and,
      // for unpaid orders with dishes, the pay-now choice stays available.
      setCheckoutOpen(false);
      setMode("done");
      clearCart();
      window.location.assign(`/mano?nr=${encodeURIComponent(json.number)}${json.trackToken ? `&t=${encodeURIComponent(json.trackToken)}` : ""}`);
    } catch {
      setError("Serverio klaida. Pabandykite dar kartą.");
    } finally {
      setBusy(false);
    }
  }

  /** Credit card → Stripe hosted checkout (order is created server-side). */
  async function payStripe(type: "pickup" | "reservation") {
    const problem = validate(type);
    setError(problem);
    if (problem) return;
    const payload = buildPayload(type);
    setBusy(true);
    try {
      const res = await fetch("/api/checkout/stripe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Nepavyko pradėti apmokėjimo.");
        return;
      }
      window.location.assign(json.url);
    } catch {
      setError("Serverio klaida. Pabandykite dar kartą.");
    } finally {
      setBusy(false);
    }
  }

  function resetAll() {
    setMode("choose");
    setStep(1);
    setName(""); setPhone(""); setEmail(""); setNote("");
    setCheckoutOpen(false);
    clearCart();
  }

  const content = s.content;

  // Successful submits redirect straight to /mano?nr=<number> — the merged
  // tracking + account page — so there is no inline confirmation view here.

  // ---------------------------------------------------------------
  // FINAL CHECKOUT — a separate, professional block (Amazon/Temu
  // style) shown only after the reservation / pickup form is
  // confirmed: order recap, editable −/+ order lines, drinks upsell
  // and the payment wall (PayPal Smart Button, card button, or pay
  // at the restaurant).
  // ---------------------------------------------------------------
  if (checkoutOpen) {
    const type: "pickup" | "reservation" = mode === "pickup-form" ? "pickup" : "reservation";
    const isPickup = type === "pickup";
    const cartCount = cartEntries.reduce((a, b) => a + b.qty, 0);
    // Badge mirrors the FIRST chosen experience (multi-selections are all
    // listed as chips in the recap row below).
    const badgeLabel = isPickup
      ? "🥡 Atsiėmimas restorane"
      : experiences[0]
        ? SCENE_CHIP[experiences[0]] || experiences[0]
        : "🍽 Staliuko rezervacija";
    const onlineAvailable = Boolean(
      payCfg && payCfg.isOpen && (payCfg.stripeEnabled || payCfg.paypalEnabled) && cartEntries.length > 0 && !storeClosed
    );
    return (
      <div className="reservation-inline" id="rezervacija" style={{ display: "block" }}>
        <div className="checkout-final" id="checkoutFinal">
          <div className="checkout-final-head">
            <span className="checkout-final-badge">{badgeLabel}</span>
            {/* Pure table reservation — nothing to pay, so no payment wording. */}
            <h3>
              {isPickup
                ? "Užsakymo apmokėjimas"
                : cartEntries.length > 0
                  ? "Rezervacijos apmokėjimas"
                  : "Rezervacijos patvirtinimas"}
            </h3>
            <p>
              {isPickup || cartEntries.length > 0
                ? "Peržiūrėkite užsakymą žemiau ir pasirinkite, kaip norite apmokėti."
                : "Peržiūrėkite savo rezervaciją žemiau ir patvirtinkite — apmokėjimo nereikia."}
            </p>
          </div>

          {storeClosed && (
            <div className="checkout-closed-banner" role="note">
              ⏸ Šiuo metu nepriimame internetinių užsakymų — paskambinkite mums: <a href={`tel:${s.site.phone}`}>{s.site.phoneDisplay}</a>
            </div>
          )}

          <div className="checkout-recap">
            {isPickup ? (
              <span className="recap-chip">🥡 Atsiėmimas: {pickupTime}</span>
            ) : (
              <>
                {/* Chosen experiences travel with the reservation — shown here
                    so the guest sees exactly WHAT they booked before paying. */}
                {experiences.map((exp) => (
                  <span key={exp} className="recap-chip">{SCENE_CHIP[exp] || exp}</span>
                ))}
                {experiences.includes("Biliardo rezervacija") && billiardsTable && (
                  <span className="recap-chip">🎱 {billiardsTable}</span>
                )}
                <span className="recap-chip">📅 {resDate} · {resTime}</span>
                <span className="recap-chip">👥 {guests} {guests === 1 ? "svečias" : "svečiai"}</span>
              </>
            )}
            <button type="button" className="recap-edit" onClick={() => setCheckoutOpen(false)}>
              Redaguoti
            </button>
          </div>

          {/* Two-column final checkout on wide screens: order review LEFT,
              payment wall RIGHT — every button reachable without scrolling.
              Below the breakpoint it stacks in the original single column. */}
          <div className="checkout-final-grid">
          <div className="checkout-final-left">
          {cartEntries.length > 0 ? (
            <div className="order-lines-card">
              <div className="order-lines-head">
                <strong>Jūsų užsakymas</strong>
                <span className="order-lines-count">{cartCount} vnt.</span>
              </div>
              <div className="order-lines">
                {cartEntries.map((e) => (
                  <div key={e.dish.id} className="order-line">
                    {e.dish.image ? (
                      <img className="order-line-img" src={e.dish.image} alt={e.dish.name} loading="lazy" />
                    ) : (
                      <span className="order-line-letter" aria-hidden="true">{e.dish.name.slice(0, 1)}</span>
                    )}
                    <div className="order-line-info">
                      <strong>{e.dish.name}</strong>
                      <small>{eur(e.dish.price)} / vnt.</small>
                    </div>
                    <div className="qty-stepper" role="group" aria-label={`Kiekis — ${e.dish.name}`}>
                      <button type="button" onClick={() => setQty(e.dish.id, -1)} aria-label={`Sumažinti ${e.dish.name} kiekį`}>−</button>
                      <b aria-live="polite">{e.qty}</b>
                      <button type="button" onClick={() => setQty(e.dish.id, 1)} aria-label={`Padidinti ${e.dish.name} kiekį`}>+</button>
                    </div>
                    <b className="order-line-sum">{eur(e.dish.price * e.qty)}</b>
                  </div>
                ))}
              </div>
              <button type="button" className="order-add-more" onClick={() => setMode(isPickup ? "menu-pickup" : "menu-reserve")}>
                ＋ Pridėti daugiau patiekalų
              </button>
            </div>
          ) : (
            <div className="order-lines-card order-lines-empty">
              <strong>{isPickup ? "Krepšelis tuščias" : "Rezervacija be patiekalų"}</strong>
              <small>
                {isPickup
                  ? "Pridėkite bent vieną patiekalą atsiėmimui."
                  : "Patiekalus galėsite užsisakyti prie stalo — išankstinis pasirinkimas nebūtinas."}
              </small>
            </div>
          )}

          {cartEntries.length > 0 && suggestions.length > 0 && (
            <div className="upsell-block" role="region" aria-label="Dažniausiai perkami kartu">
              <div className="upsell-head">
                <span className="upsell-title">✦ Dažniausiai perkami kartu</span>
                <span className="upsell-sub">Šie gėrimai dažniausiai papildo tokį užsakymą — pasirinkimas neprivalomas</span>
              </div>
              <div className="upsell-row">
                {suggestions.map((sg) => (
                  <div key={sg.id} className="upsell-card">
                    {sg.image ? <img src={sg.image} alt={sg.name} loading="lazy" /> : <span className="upsell-letter">{sg.name.slice(0, 1)}</span>}
                    <strong>{sg.name}</strong>
                    <small>{sg.reason}</small>
                    <div className="upsell-foot">
                      <b>{eur(sg.price)}</b>
                      {onAddItem && (
                        <button
                          type="button"
                          onClick={() => {
                            onAddItem(sg.id);
                            onToast(`${sg.name} pridėta ✓`);
                          }}
                          aria-label={`Pridėti ${sg.name}`}
                        >
                          ＋
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {cartEntries.length > 0 && suggestions.length === 0 && (
            <p className="upsell-none">✦ Gėrimų papildomai pasiūlyti šiuo metu nėra — pasirinkimas nebūtinas, tęskite be jų.</p>
          )}

          {cartEntries.length > 0 && (
            <div className="checkout-totals">
              <div className="totals-row"><span>Tarpinis</span><span>{eur(cartTotal)}</span></div>
              {taxRateView > 0 && (
                <div className="totals-row"><span>PVM {taxRateView}%</span><span>{eur(taxAmountView)}</span></div>
              )}
              <div className="totals-row grand"><strong>Iš viso</strong><strong>{eur(fullTotal)}</strong></div>
            </div>
          )}
          </div>{/* /checkout-final-left */}

          <div className="checkout-final-right">
          {error && <div className="checkout-error" role="alert" aria-live="polite">{error}</div>}

          {cartEntries.length > 0 && onlineAvailable ? (
            <div className="pay-wall">
              <span className="pay-wall-title">Apmokėjimo būdas</span>
              {/* With no Stripe the branded card button is hidden — let the
                PayPal Smart Button block (gold PayPal + PayPal's own black
                card button, horizontal layout) span the FULL width so the two
                payment blocks stretch across the screen instead of hugging
                one side. */}
            <div className={"pay-wall-grid" + (payCfg?.stripeEnabled ? "" : " pay-wall-grid-solo")}>
                {payCfg?.paypalEnabled && payCfg?.paypalClientId && (
                  <CheckoutPaypalButtons
                    cfg={payCfg}
                    payloadRef={payloadRef}
                    ppOrderRef={ppOrderRef}
                    createdOrderRef={createdOrderRef}
                    onDone={(number, trackToken) => {
                      setCheckoutOpen(false);
                      setMode("done");
                      clearCart();
                      window.location.assign(`/mano?nr=${encodeURIComponent(number)}${trackToken ? `&t=${encodeURIComponent(trackToken)}` : ""}`);
                    }}
                    onError={(msg) => setError(msg)}
                  />
                )}
                {payCfg?.stripeEnabled && (
                  <button type="button" className="pay-btn-card" onClick={() => payStripe(type)} disabled={busy || storeClosed}>
                    <span className="pay-btn-card-copy">
                      <strong>Mokėti kortele</strong>
                      <small>Greitas ir saugus apmokėjimas</small>
                    </span>
                    <span className="card-marks" aria-hidden="true">
                      <VisaMark />
                      <MastercardMark />
                      <AmexMark />
                    </span>
                  </button>
                )}
              </div>
              <div className="pay-divider"><span>arba</span></div>
              <button type="button" className="pay-venue-btn" onClick={() => payAtVenue(type)} disabled={busy}>
                <strong>{isPickup ? "Mokėsiu atsiėmimo metu" : "Mokėsiu restorane"}</strong>
                <small>Patvirtinti užsakymą dabar — apmokėkite atvykę</small>
              </button>
            </div>
          ) : (
            <button
              type="button"
              className="btn btn-gold checkout-confirm-btn"
              onClick={() => payAtVenue(type)}
              disabled={busy || storeClosed}
            >
              {busy
                ? "Siunčiama..."
                : cartEntries.length === 0
                  ? isPickup
                    ? "Krepšelis tuščias — pridėkite patiekalų"
                    : "Patvirtinti rezervaciją"
                  : isPickup
                    ? "Patvirtinti užsakymą — mokėsiu atsiėmimo metu"
                    : "Patvirtinti — mokėsiu restorane"}
            </button>
          )}

          {(cartEntries.length > 0 || isPickup) && (
            <div className="pay-trust">🔒 Saugus apmokėjimas · SSL šifravimas · Jūsų duomenys apsaugoti</div>
          )}

          <button type="button" className="btn btn-ghost checkout-back-btn" onClick={() => setCheckoutOpen(false)}>
            ← Grįžti į užsakymo formą
          </button>
          </div>{/* /checkout-final-right */}
          </div>{/* /checkout-final-grid */}
        </div>
      </div>
    );
  }

  if (mode === "pickup-form") {
    const daySlots = slots.filter((sl) => sl.ymd === pickupDay);
    return (
      <div className="reservation-inline" id="rezervacija" style={{ display: "block" }}>
        <div className="pickup-checkout-head">
          <h3>Užsakymas atsiėmimui restorane</h3>
          <p>{c(content, "pickup.help", "Užpildykite kontaktus ir pasirinkite atsiėmimo laiką.")}</p>
        </div>
        {storeClosed && (
          <div className="checkout-closed-banner" role="note">
            ⏸ Šiuo metu nepriimame internetinių užsakymų — paskambinkite mums: <a href={`tel:${s.site.phone}`}>{s.site.phoneDisplay}</a>
          </div>
        )}
        {cartEntries.length > 0 && (
          <div className="reservation-order-box">
            <div className="reservation-order-head">
              <strong>Pasirinkti patiekalai</strong>
              <span className="reservation-order-count">{cartEntries.reduce((a, b) => a + b.qty, 0)} vnt.</span>
            </div>
            <div className="reservation-order-list">
              {cartEntries.map((e) => (
                <div key={e.dish.id} className="reservation-order-line">
                  <span>{e.dish.name} × {e.qty}</span>
                  <b>{eur(e.dish.price * e.qty)}</b>
                </div>
              ))}
            </div>
            <div className="reservation-order-total">
              <span>Tarpinis</span>
              <span>{eur(cartTotal)}</span>
            </div>
            {taxRateView > 0 && (
              <div className="reservation-order-total">
                <span>PVM {taxRateView}%</span>
                <span>{eur(taxAmountView)}</span>
              </div>
            )}
            {taxRateView > 0 && (
              <div className="reservation-order-total">
                <strong>Iš viso</strong>
                <strong>{eur(fullTotal)}</strong>
              </div>
            )}
            <button className="reservation-edit-menu" type="button" onClick={() => setMode("menu-pickup")}>
              Keisti patiekalus →
            </button>
          </div>
        )}
        <form className="reservation-checkout" onSubmit={(e) => { e.preventDefault(); openCheckout("pickup"); }} noValidate>
          {/* Honeypot (v1.4 §F) — invisible to humans, autofill bait for bots. */}
          <input
            id="hp-company"
            name="company"
            type="text"
            value=""
            readOnly
            autoComplete="off"
            tabIndex={-1}
            aria-hidden="true"
            style={{ position: "absolute", left: "-9999px", height: 0, width: 0, opacity: 0, pointerEvents: "none" }}
          />
          <label>
            Atsiėmimo data
            <select className="field" value={pickupDay} onChange={(e) => {
              setPickupDay(e.target.value);
              const first = slots.find((sl) => sl.ymd === e.target.value);
              if (first) setPickupTime(first.value);
            }}>
              {slotDays.map((d) => (
                <option key={d.ymd} value={d.ymd}>{d.label}</option>
              ))}
            </select>
          </label>
          <label>
            Atsiėmimo laikas
            <select className="field" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)}>
              {daySlots.map((sl) => (
                <option key={sl.value} value={sl.value}>{sl.value}</option>
              ))}
            </select>
          </label>
          <label>
            Vardas
            <input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jūsų vardas" required />
          </label>
          <label>
            Telefonas
            <input className="field" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+370..." required />
          </label>
          <label>
            El. pašas (neprivaloma)
            <input className="field" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" />
          </label>
          <label>
            Pastaba (neprivaloma)
            <textarea className="field" value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="Pvz. alergijos, ypatumai" />
          </label>
          {error && <div className="checkout-error" aria-live="polite">{error}</div>}
          <div className="checkout-action-row">
            <button type="button" className="btn checkout-back" onClick={() => setMode(cartEntries.length ? "menu-pickup" : "choose")}>
              ← Atgal
            </button>
            <button className="btn btn-gold" type="submit" disabled={storeClosed}>
              Patvirtinti užsakymą →
            </button>
          </div>
        </form>
      </div>
    );
  }

  if (mode === "reserve-form") {
    const billiards = experiences.includes("Biliardo rezervacija");
    const hasDishes = cartEntries.length > 0;
    return (
      <div className="reservation-inline" id="rezervacija" style={{ display: "block" }}>
        <div className="reservation-checkout" id="reservationForm">
          <div className="checkout-steps">
            <div className={`checkout-step-pill ${step === 1 ? "active" : ""}`} id="checkoutPill1">
              <b>1</b>
              <span>Jūsų stalas</span>
            </div>
            <div className={`checkout-step-pill ${step === 2 ? "active" : ""}`} id="checkoutPill2">
              <b>2</b>
              <span>Kontaktai</span>
            </div>
          </div>

          <section className="checkout-pane" id="checkoutStep1" hidden={step !== 1}>
            {/* Experience composer (v1 prototype block): multi-select scene
                cards with ＋/✓ states + "Jūsų vakaro planas" chips summary. */}
            <div className="reservation-type-field">
              <div className="reservation-type-heading">
                <span className="guest-label">Ką norite įtraukti į vieną rezervaciją?</span>
                <small>Galite pasirinkti kelis variantus vienu metu — pvz. staliuką + degustaciją + biliardą + meniu.</small>
              </div>
              <div className="reservation-type-scenes" role="group" aria-label="Rezervacijos patirtys">
                {SCENES.map((sc) => {
                  const active = experiences.includes(sc.value);
                  return (
                    <button
                      key={sc.value}
                      type="button"
                      className={`reservation-type-scene ${sc.cls} ${active ? "active" : ""}`}
                      role="checkbox"
                      aria-checked={active}
                      onClick={() => toggleExperience(sc.value)}
                    >
                      <span className="scene-overlay" />
                      <span className="scene-check"><b>＋</b><i>✓</i></span>
                      <span className="scene-content">
                        <span className="scene-icon">{sc.icon}</span>
                        <strong>{sc.title}</strong>
                        <small>{sc.value === "Biliardo rezervacija" ? billiardsBookingNote(data.settings.content) : sc.desc}</small>
                      </span>
                    </button>
                  );
                })}
              </div>
              {billiards && (
                <div className="billiards-booking-options">
                  <div className="billiards-booking-head">
                    <span className="guest-label">Pasirinkite biliardo stalą</span>
                    <strong>{billiardsBookingNote(data.settings.content)}</strong>
                  </div>
                  <div className="guest-pills">
                    {["POOL", "Rusiškas / Piramidė", "Abu stalai"].map((t) => (
                      <button type="button" key={t} className={`guest-pill ${billiardsTable === t ? "active" : ""}`} onClick={() => setBilliardsTable(t)}>
                        🎱 {t}
                      </button>
                    ))}
                  </div>
                  <p className="billiards-booking-note">{billiardsBookingNote(data.settings.content)}</p>
                </div>
              )}
              <div className="reservation-plan-summary" aria-live="polite">
                <div className="reservation-plan-head">
                  <span>Jūsų vakaro planas</span>
                  <small>Visi pasirinkimai bus siunčiami kaip viena rezervacija.</small>
                </div>
                <div className="reservation-plan-chips">
                  {experiences.length === 0 && !hasDishes ? (
                    <span className="reservation-plan-empty">Pasirinkite bent vieną patirtį — arba tęskite su meniu.</span>
                  ) : (
                    <>
                      {experiences.map((exp) => (
                        <span key={exp} className="reservation-plan-chip">{SCENE_CHIP[exp] || exp}</span>
                      ))}
                      {hasDishes && <span className="reservation-plan-chip menu-chip">🍴 Meniu · {cartEntries.reduce((a, b) => a + b.qty, 0)} patiekalai</span>}
                    </>
                  )}
                </div>
              </div>
            </div>
            {/* When: Data / Laikas / Svečių skaičius sit BELOW the experience
                picker — the guest first shapes what the evening includes,
                then pins down the concrete date, time and party size. */}
            <div className="checkout-grid">
              <label>
                Data
                <input className="field" required type="date" value={resDate} min={todayYmd} onChange={(e) => setResDate(e.target.value)} />
              </label>
              <label>
                Laikas
                <input className="field" required type="time" value={resTime} onChange={(e) => setResTime(e.target.value)} />
              </label>
            </div>
            <div className="guest-block">
              <span className="guest-label">Svečių skaičius</span>
              <div className="guest-pills" role="group" aria-label="Svečių skaičius">
                {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((n) => (
                  <button type="button" key={n} className={`guest-pill ${guests === n ? "active" : ""}`} onClick={() => setGuests(n)}>
                    {n}
                  </button>
                ))}
              </div>
            </div>
            <div className="reservation-menu-choice">
              <div className="reservation-menu-copy">
                <strong>Išankstinis patiekalų pasirinkimas</strong>
                <small>
                  {hasDishes
                    ? `${cartEntries.reduce((a, b) => a + b.qty, 0)} patiekalai pridėti — ${eur(cartTotal)}. Jie keliaus kartu su rezervacija.`
                    : "Galite rezervuoti ir be išankstinio užsakymo."}
                </small>
              </div>
              <div className="reservation-menu-actions">
                <button
                  type="button"
                  className={`reservation-choice-btn ${!hasDishes ? "active" : ""}`}
                  onClick={() => {
                    if (hasDishes) {
                      clearCart();
                      onToast("Patiekalų pasirinkimas išvalytas");
                    }
                  }}
                  aria-pressed={!hasDishes}
                >
                  Be patiekalų
                </button>
                <button
                  type="button"
                  className={`reservation-choice-btn ${hasDishes ? "active" : ""}`}
                  onClick={() => setMode("menu-reserve")}
                  aria-pressed={hasDishes}
                >
                  Pasirinkti patiekalus
                </button>
              </div>
            </div>
            {error && <div className="checkout-error" aria-live="polite">{error}</div>}
            <div className="checkout-action-row">
              <button type="button" className="btn checkout-back" onClick={() => setMode("choose")}>
                ← Atgal
              </button>
              <button className="btn btn-gold" type="button" onClick={() => {
                if (!resDate || !resTime || guests < 1) return setError("Pasirinkite datą, laiką ir svečių skaičių.");
                setError("");
                setStep(2);
                // Align the checkout card's top with the viewport top so the
                // whole contact block (and its action buttons) is on screen.
                setTimeout(() => document.getElementById("reservationForm")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
              }}>
                Toliau · kontaktai →
              </button>
            </div>
          </section>

          <section className="checkout-pane" id="checkoutStep2" hidden={step !== 2}>
            {/* Reservation recap — everything chosen in step 1 stays visible
                here, so the guest confirms WHAT they booked before paying. */}
            <div className="reservation-recap" aria-label="Rezervacijos santrauka">
              <div className="reservation-recap-head">
                <strong>Jūsų rezervacija</strong>
                <button type="button" className="reservation-recap-edit" onClick={() => setStep(1)}>
                  Keisti
                </button>
              </div>
              <div className="reservation-plan-chips">
                {experiences.map((exp) => (
                  <span key={exp} className="reservation-plan-chip">{SCENE_CHIP[exp] || exp}</span>
                ))}
                {experiences.includes("Biliardo rezervacija") && billiardsTable && (
                  <span className="reservation-plan-chip">🎱 {billiardsTable}</span>
                )}
                {resDate && resTime && <span className="reservation-plan-chip">📅 {resDate} · {resTime}</span>}
                <span className="reservation-plan-chip">👥 {guests} {guests === 1 ? "svečias" : "svečiai"}</span>
              </div>
            </div>
            <p className="checkout-help">Patvirtinkite kontaktus — santrauka viršuje, pasirinkti patiekalai žemiau.</p>
            {cartEntries.length > 0 && (
              <div className="reservation-order-box">
                <div className="reservation-order-head">
                  <strong>Pasirinkti patiekalai</strong>
                  <span className="reservation-order-count">{cartEntries.reduce((a, b) => a + b.qty, 0)} vnt.</span>
                </div>
                <div className="reservation-order-list">
                  {cartEntries.map((e) => (
                    <div key={e.dish.id} className="reservation-order-line">
                      <span>{e.dish.name} × {e.qty}</span>
                      <b>{eur(e.dish.price * e.qty)}</b>
                    </div>
                  ))}
                </div>
                <div className="reservation-order-total">
                  <span>Numatoma suma</span>
                  <span>{eur(cartTotal)}</span>
                </div>
                <button className="reservation-edit-menu" type="button" onClick={() => setMode("menu-reserve")}>
                  Keisti patiekalus →
                </button>
              </div>
            )}
            {/* 2-column grid keeps the whole contact step (incl. action
                buttons) inside one laptop screen. */}
            <div className="checkout-fields">
              <label>
                Vardas
                <input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jūsų vardas" required />
              </label>
              {/* Same honeypot for the checkout-step form (only one form is mounted at a time). */}
              <input id="hp-company" aria-hidden="true" tabIndex={-1} autoComplete="off" style={{ display: "none" }} defaultValue="" />
              <label>
                Telefonas
                <input className="field" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+370..." required />
              </label>
              <label>
                El. pašas (neprivaloma)
                <input className="field" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" />
              </label>
              <label>
                Pastaba (neprivaloma)
                <textarea className="field" value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="Pvz. vaikų kėdė, alergijos" />
              </label>
            </div>
            {error && <div className="checkout-error" aria-live="polite">{error}</div>}
            <div className="checkout-action-row">
              <button
                type="button"
                className="btn checkout-back"
                onClick={() => {
                  setStep(1);
                  // land back on the top of the composer card
                  setTimeout(() => document.getElementById("reservationForm")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
                }}
              >
                ← Atgal
              </button>
              <button className="btn btn-gold" type="button" onClick={() => openCheckout("reservation")}>
                {hasDishes ? "Patvirtinti rezervaciją → apmokėjimas" : "Patvirtinti rezervaciją"}
              </button>
            </div>
          </section>
        </div>
      </div>
    );
  }

  return null;
}

/* ------------------------------------------------------------------ */
/* CheckoutPaypalButtons — the official gold Smart Payment Button,      */
/* rendered straight inside the checkout pay wall. createOrder fires    */
/* at click time and creates BOTH the order and the PayPal order, so    */
/* amounts always match the reviewed cart. An identical payload reuses  */
/* the same PayPal order (no duplicate rows after cancel → retry).      */
/* ------------------------------------------------------------------ */
function CheckoutPaypalButtons({
  cfg,
  payloadRef,
  ppOrderRef,
  createdOrderRef,
  onDone,
  onError,
}: {
  cfg: PayCfg;
  payloadRef: MutableRefObject<Record<string, unknown>>;
  ppOrderRef: MutableRefObject<{ sig: string; paypalOrderId: string; number: string } | null>;
  createdOrderRef: MutableRefObject<{ sig: string; number: string; trackToken: string } | null>;
  onDone: (number: string, trackToken?: string) => void;
  onError: (msg: string) => void;
}) {
  const renderedRef = useRef(false);
  // remember when WE set a precise error, so PayPal's generic onError
  // (which always fires after a rejected createOrder) does not overwrite it
  const customErrAt = useRef(0);
  const onDoneRef = useRef(onDone);
  const onErrorRef = useRef(onError);
  useEffect(() => {
    onDoneRef.current = onDone;
    onErrorRef.current = onError;
  }, [onDone, onError]);

  useEffect(() => {
    const containerId = "paypal-checkout-container";
    const fail = (msg: string) => {
      customErrAt.current = Date.now();
      onErrorRef.current(msg);
    };
    const renderButtons = () => {
      const pp = (window as unknown as { paypal?: PaypalSdk }).paypal;
      if (!pp || renderedRef.current) return;
      renderedRef.current = true;
      pp.Buttons({
        // horizontal → gold PayPal button and PayPal's black "Debeto arba
        // kredito kortelė" button sit SIDE BY SIDE, aligned across the wall.
        // PayPal typings declare style values as string|number, but the JS SDK
        // accepts booleans — tagline:false hides the caption line under the button.
        style: { layout: "horizontal", color: "gold", shape: "rect", label: "paypal", height: 46, tagline: false } as unknown as { layout: "horizontal"; color: "gold"; shape: "rect"; label: "paypal"; height: number },
        createOrder: async () => {
          try {
            const payload = payloadRef.current;
            const sig = JSON.stringify(payload);
            if (ppOrderRef.current && ppOrderRef.current.sig === sig) return ppOrderRef.current.paypalOrderId;
            const res = await fetch("/api/checkout/paypal", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || "Nepavyko pradėti PayPal apmokėjimo.");
            ppOrderRef.current = { sig, paypalOrderId: json.paypalOrderId, number: json.number };
            createdOrderRef.current = { sig, number: json.number, trackToken: json.trackToken || "" };
            return json.paypalOrderId as string;
          } catch (e) {
            fail(e instanceof Error ? e.message : "PayPal klaida.");
            throw e; // aborts the popup — the message is already on screen
          }
        },
        onApprove: async (approval) => {
          try {
            const res = await fetch("/api/checkout/paypal/capture", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ paypalOrderId: approval.orderID }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || "PayPal apmokėjimo nepavyko patvirtinti.");
            onDoneRef.current(json.number || ppOrderRef.current?.number || "", json.trackToken);
          } catch (e) {
            onErrorRef.current(e instanceof Error ? e.message : "PayPal klaida.");
          }
        },
        onCancel: () => {
          onErrorRef.current("Apmokėjimas atšauktas — užsakymas išliko neapmokėtas. Galite bandyti dar kartą arba mokėti restorane.");
        },
        onError: () => {
          // createOrder already surfaced the precise server message moments ago
          if (Date.now() - customErrAt.current < 1500) return;
          onErrorRef.current("PayPal klaida — pabandykite dar kartą arba paskambinkite mums.");
        },
      }).render(`#${containerId}`);
    };

    const w = window as unknown as { paypal?: PaypalSdk };
    if (w.paypal) {
      renderButtons();
      return;
    }
    let script = document.querySelector<HTMLScriptElement>("script[data-paypal-sdk]");
    if (!script) {
      script = document.createElement("script");
      script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(cfg.paypalClientId || "")}&currency=${cfg.currency || "EUR"}&intent=capture&components=buttons&enable-funding=card&locale=lt_LT`;
      script.async = true;
      script.dataset.paypalSdk = "1";
      script.onload = () => {
        renderedRef.current = false;
        renderButtons();
      };
      script.onerror = () => onErrorRef.current("Nepavyko įkelti PayPal. Pabandykite atsiskaityti kortele arba paskambinkite.");
      document.head.appendChild(script);
    } else {
      script.addEventListener("load", () => {
        renderedRef.current = false;
        renderButtons();
      });
    }
    return () => {
      renderedRef.current = false;
    };
  }, [cfg, payloadRef, ppOrderRef, createdOrderRef]);

  return <div id="paypal-checkout-container" className="pay-wall-paypal" aria-label="PayPal apmokėjimas" />;
}


