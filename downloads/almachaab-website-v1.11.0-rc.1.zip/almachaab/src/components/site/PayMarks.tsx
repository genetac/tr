/* Shared card-brand marks for the professional card buttons — used by the
 * checkout pay wall (Checkout.tsx) and the pay-later wall (PayLaterBox.tsx)
 * so both surfaces look identical. */
export function VisaMark() {
  return (
    <svg className="card-mark" viewBox="0 0 46 30" role="img" aria-label="Visa">
      <rect x=".5" y=".5" width="45" height="29" rx="4.5" fill="#fff" stroke="#e3d5c2" />
      <text x="23" y="19.5" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="10.5" fontWeight="800" fontStyle="italic" fill="#1a1f71">VISA</text>
    </svg>
  );
}

export function MastercardMark() {
  return (
    <svg className="card-mark" viewBox="0 0 46 30" role="img" aria-label="Mastercard">
      <rect x=".5" y=".5" width="45" height="29" rx="4.5" fill="#fff" stroke="#e3d5c2" />
      <circle cx="19" cy="15" r="7.5" fill="#eb001b" />
      <circle cx="27" cy="15" r="7.5" fill="#f79e1b" fillOpacity=".92" />
    </svg>
  );
}

export function AmexMark() {
  return (
    <svg className="card-mark" viewBox="0 0 46 30" role="img" aria-label="American Express">
      <rect x=".5" y=".5" width="45" height="29" rx="4.5" fill="#2e77bc" stroke="#2e77bc" />
      <text x="23" y="18.5" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="8.5" fontWeight="800" fill="#fff">AMEX</text>
    </svg>
  );
}
