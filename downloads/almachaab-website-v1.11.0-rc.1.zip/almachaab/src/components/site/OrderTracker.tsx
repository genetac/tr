"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { FacebookIcon, PhoneIcon } from "./icons";
import { PayLaterBox } from "./PayLaterBox";
import { useLoadEffect } from "@/hooks/use-load-effect";

/* ------------------------------------------------------------------ */
/* OrderTracker — live status card for a single order (was /sekti).    */
/* Guests track by order number; the card also offers pay-now for      */
/* unpaid orders. Embedded on /mano — tracking and account are one.    */
/* ------------------------------------------------------------------ */

interface TrackSupport {
  phone: string;
  phoneDisplay: string;
  facebookUrl?: string;
}

export interface TrackData {
  number: string;
  type: string;
  status: string;
  statusLabel: string;
  total: number;
  paymentStatus: string;
  paymentMethod: string;
  pickupTime: string;
  resDate: string;
  resTime: string;
  guests: number;
  items: { name: string; qty: number; price: number }[];
  createdAt: string;
  readyAt?: string | null;
  prepMinutesLeft?: number | null;
  history: { status: string; label: string; at: string }[];
}

const FLOW: Record<string, string[]> = {
  pickup: ["new", "awaiting", "confirmed", "preparing", "ready", "completed"],
  reservation: ["new", "confirmed", "completed"],
};

const FLOW_LABELS: Record<string, string> = {
  new: "Užsakymas gautas",
  awaiting: "Laukiama apmokėjimo",
  confirmed: "Patvirtintas",
  preparing: "Ruošiamas",
  ready: "Paruoštas",
  completed: "Užbaigtas",
  cancelled: "Atšauktas",
};

function eur(v: number) {
  return v.toFixed(2).replace(".", ",") + " €";
}

export function OrderTracker({
  initialNumber,
  initialToken,
  phone = "+37066613055",
  phoneDisplay = "+370 666 13 055",
  facebookUrl,
  onPaid,
}: {
  initialNumber?: string;
  initialToken?: string;
  phone?: string;
  phoneDisplay?: string;
  facebookUrl?: string;
  onPaid?: () => void;
}) {
  const [nr, setNr] = useState(initialNumber ?? "");
  const [p4, setP4] = useState("");
  const [data, setData] = useState<TrackData | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  // Authorization that worked for the currently displayed order — reused by
  // SSE and polling so live updates keep working after the first lookup.
  const authRef = useRef<{ t?: string; p4?: string }>(initialToken ? { t: initialToken } : {});
  // Same credentials as state, for rendering (PayLaterBox) — refs are not read during render.
  const [authForPay, setAuthForPay] = useState<{ t?: string; p4?: string }>(initialToken ? { t: initialToken } : {});

  function trackQuery(number: string, auth: { t?: string; p4?: string }) {
    const q = new URLSearchParams();
    if (auth.t) q.set("t", auth.t);
    if (auth.p4) q.set("p4", auth.p4);
    const qs = q.toString();
    return `/api/track/${encodeURIComponent(number)}${qs ? `?${qs}` : ""}`;
  }

  const lookup = useCallback(
    async (number: string, authOverride?: { t?: string; p4?: string }) => {
      const clean = number.trim().replace(/^#/, "");
      if (!clean) return;
      const auth = authOverride || authRef.current;
      setLoading(true);
      setError("");
      try {
        const res = await fetch(trackQuery(clean, auth), { cache: "no-store" });
        const json = await res.json();
        if (!res.ok) {
          setData(null);
          setError(json.error || "Užsakymas nerastas.");
        } else {
          authRef.current = auth;
          setAuthForPay(auth);
          setData(json);
        }
      } catch {
        setError("Klaida jungiantis į serverį.");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Deep link support — /mano?nr=AC-1042&t=<token> (also the /sekti target).
  const initialLookup = useCallback(() => {
    if (initialNumber) void lookup(initialNumber, initialToken ? { t: initialToken } : undefined);
  }, [initialNumber, initialToken, lookup]);
  useLoadEffect(initialLookup);

  // Live updates: SSE first, 15s polling as the safety net.
  useEffect(() => {
    if (!data) return;
    const number = data.number;
    const qs = new URLSearchParams();
    if (authRef.current.t) qs.set("t", authRef.current.t);
    if (authRef.current.p4) qs.set("p4", authRef.current.p4);
    const q = qs.toString();
    const es = new EventSource(`/api/track/${encodeURIComponent(number)}/stream${q ? `?${q}` : ""}`);
    es.addEventListener("order", () => lookup(number));
    const t = setInterval(() => lookup(number), 15000);
    return () => {
      es.close();
      clearInterval(t);
    };
  }, [data, lookup]);

  const refresh = useCallback(() => {
    if (data) lookup(data.number);
  }, [data, lookup]);

  const cancelled = data?.status === "cancelled";
  // Venue-paid orders (paymentMethod "", status "new") never sit in a
  // payment-waiting step — the "awaiting" stage only exists for orders that
  // were created for online payment (method stamped, or still awaiting).
  const showAwaiting = Boolean(data && (data.paymentMethod || data.status === "awaiting"));
  const flow = data ? (FLOW[data.type] || FLOW.pickup).filter((st) => showAwaiting || st !== "awaiting") : [];
  // "awaiting" (online payment pending) sits where "new" does.
  const currentIdx = data ? (flow.indexOf(data.status) >= 0 ? flow.indexOf(data.status) : data.status === "awaiting" ? 0 : -1) : -1;
  // Pay-now buttons are offered ONLY for orders created for online payment:
  // either the gateway already stamped its method, or the order still sits in
  // "awaiting" (gateway attempt failed / was abandoned before stamping).
  // Venue-paid orders (status "new", no method) are unpaid BY DESIGN — the
  // customer pays at the restaurant / at pickup, nothing is awaited.
  const onlineUnpaid = Boolean(
    data && (data.paymentMethod || data.status === "awaiting") && data.paymentStatus !== "paid" && data.total > 0 && !cancelled
  );
  const venueUnpaid = Boolean(
    data && !data.paymentMethod && data.status !== "awaiting" && data.paymentStatus !== "paid" && data.total > 0 && !cancelled
  );

  return (
    <div className="order-tracker">
      {!data && (
        <>
          <h2 className="account-h2">Sekti užsakymą</h2>
          <p className="account-hint">
            Įveskite užsakymo numerį (pvz. AC-1042) — būsena atnaujinama realiu laiku.
          </p>
        </>
      )}

      <form
        className="track-form"
        onSubmit={(e) => {
          e.preventDefault();
          lookup(nr, p4.trim().length === 4 ? { t: initialToken, p4: p4.trim() } : initialToken ? { t: initialToken } : undefined);
        }}
      >
        <input
          value={nr}
          onChange={(e) => setNr(e.target.value)}
          placeholder="AC-1042"
          aria-label="Užsakymo numeris"
          autoComplete="off"
        />
        <input
          value={p4}
          onChange={(e) => setP4(e.target.value.replace(/\D/g, "").slice(0, 4))}
          placeholder="4 sk. — tel."
          aria-label="Paskutiniai 4 telefono skaitmenys"
          inputMode="numeric"
          autoComplete="off"
          title="Paskutiniai 4 jūsų telefono numerio skaitmenys"
        />
        <button type="submit" disabled={loading}>
          {loading ? "Ieškoma..." : "Ieškoti"}
        </button>
      </form>

      {error && <div className="track-error">{error}</div>}

      {data && (
        <div className="track-card">
          <div className="track-card-head">
            <div>
              <span className="track-label">{data.type === "pickup" ? "Atsiėmimo užsakymas" : "Rezervacija"}</span>
              <h2>#{data.number}</h2>
            </div>
            <span className={`track-status-badge ${data.status}`}>
              {data.status === "awaiting" && data.paymentStatus !== "paid" ? FLOW_LABELS.awaiting : data.statusLabel}
            </span>
          </div>

          {cancelled ? (
            <div className="track-cancelled">Šis užsakymas atšauktas. Klausimų atveju skambinkite {phoneDisplay}.</div>
          ) : (
            <>
              {data.readyAt && (
                <div className={`track-eta ${data.prepMinutesLeft === 0 ? "late" : ""}`}>
                  ⏱ Paruošta apie{" "}
                  <b>{new Date(data.readyAt).toLocaleTimeString("lt-LT", { hour: "2-digit", minute: "2-digit" })}</b>
                  {typeof data.prepMinutesLeft === "number" && data.prepMinutesLeft > 0
                    ? ` (per ~${data.prepMinutesLeft} min)`
                    : data.prepMinutesLeft === 0
                      ? " — jau turėtų būti paruošta!"
                      : ""}
                </div>
              )}
              <ol className="track-steps">
                {flow.map((st, i) => {
                  const done = i <= currentIdx;
                  const active = i === currentIdx;
                  return (
                    <li key={st} className={`${done ? "done" : ""} ${active ? "active" : ""}`}>
                      <span className="track-dot">{done ? "✓" : i + 1}</span>
                      <span className="track-step-label">{FLOW_LABELS[st]}</span>
                    </li>
                  );
                })}
              </ol>
            </>
          )}

          <div className="track-meta">
            {data.type === "pickup" ? (
              <div>
                <span>Atsiėmimo laikas</span>
                <strong>{data.pickupTime || "— patvirtinsime —"}</strong>
              </div>
            ) : (
              <div>
                <span>Rezervacija</span>
                <strong>
                  {data.resDate} {data.resTime} · {data.guests} svečiai
                </strong>
              </div>
            )}
            {/* Pure table reservation (no pre-ordered dishes) — nothing to
                settle, so no amount and no payment row are shown at all. */}
            {data.total > 0 && (
              <div>
                <span>Suma</span>
                <strong>{eur(data.total)}</strong>
              </div>
            )}
            {data.total > 0 && (
              <div>
                <span>Apmokėjimas</span>
                <strong>
                  {data.paymentStatus === "paid"
                    ? "Apmokėta ✓"
                    : data.paymentMethod || data.status === "awaiting"
                      ? "Neapmokėta"
                      : data.type === "pickup"
                        ? "Atsiėmimo metu"
                        : "Restorane"}
                </strong>
              </div>
            )}
          </div>

          {data.items.length > 0 && (
            <div className="track-items">
              {data.items.map((i, idx) => (
                <div key={idx} className="track-item">
                  <span>
                    {i.name} × {i.qty}
                  </span>
                  <b>{eur(i.price * i.qty)}</b>
                </div>
              ))}
            </div>
          )}

          {onlineUnpaid && (
            <div className="track-paylater">
              <PayLaterBox number={data.number} auth={authForPay} onPaid={onPaid || refresh} />
            </div>
          )}
          {venueUnpaid && (
            <div className="track-venue-note" role="note">
              💰 {data.type === "pickup" ? "Apmokėsite atsiėmimo metu" : "Apmokėsite restorane"} — jokių išankstinių mokėjimų nereikia.
            </div>
          )}

          <div className="track-updated">Atnaujinta: {new Date().toLocaleTimeString("lt-LT")} · būsena atnaujinama automatiškai</div>
        </div>
      )}

      {!data && (
        <div className="track-support" role="note" aria-label="Pagalba telefonu">
          <span className="track-support-icon">
            <PhoneIcon size={19} />
          </span>
          <span className="track-support-copy">
            <strong>Klausimų apie užsakymą?</strong>
            <small>Paskambinkite — padėsime iš karto.</small>
          </span>
          <a className="track-support-call" href={`tel:${phone}`}>
            <PhoneIcon size={15} />
            <span>{phoneDisplay}</span>
          </a>
          {facebookUrl && (
            <a className="track-footer-fb" href={facebookUrl} target="_blank" rel="noopener" aria-label="Alma Chaab Facebook puslapis">
              <FacebookIcon size={14} /> Facebook
            </a>
          )}
        </div>
      )}
    </div>
  );
}
