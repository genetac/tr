"use client";
import {EditText,visualStyle} from "@/components/cms/EditText";

import { DEFAULT_NAVIGATION, safeContentUrl } from "@/lib/content-management";
import { visitorInfo, VISITOR_LABELS, billiardsInfo, billiardsPriceLine } from "@/lib/visitor";

import { useEffect, useState } from "react";
import Image from "next/image";
import { c, activeBilliards, openStatusText, starsFor, type SiteData } from "./helpers";
import { FacebookIcon, MapPinIcon, PhoneIcon } from "./icons";
import { sanitizeInlineHtml } from "@/lib/sanitize";

interface SectionProps {
  data: SiteData;
  rating: { mode: string; score: number; count: number; note: string };
  onGoMenu: () => void;
  onGoAbout: () => void;
  onOpenPanel: (id: string) => void;
  /** Only used by EventsPanel (billiards booking CTA). */
  onBilliards?: () => void;
}

/** Google Maps directions link (works on desktop and opens the Maps app on phones). */
function directionsUrl(name: string, address: string): string {
  const destination = [name, address].filter(Boolean).join(", ");
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`;
}

export function Header({ data, onGoMenu, onOpenPanel }: SectionProps) {
  const s = data.settings;
  const [scrolled, setScrolled] = useState(false);
  // Phone / tablet: one clean row — brand left, "+" right. Everything else
  // lives in the sheet the "+" opens (desktop keeps the inline nav).
  const [sheetOpen, setSheetOpen] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);
  useEffect(() => {
    if (!sheetOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSheetOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sheetOpen]);

  const closeThen = (fn: () => void) => {
    setSheetOpen(false);
    setTimeout(fn, 30);
  };

  const navigation: typeof DEFAULT_NAVIGATION = c(s.content, 'navigation', DEFAULT_NAVIGATION);
  const visibleNav = navigation.filter(n => n.visible && safeContentUrl(n.href) && (!n.parentId || navigation.some(p => p.id === n.parentId && p.visible)));
  const follow = (href: string, e: React.MouseEvent<HTMLAnchorElement>) => {
    if (href === '#meniu') { e.preventDefault(); closeThen(onGoMenu); }
    else if (['#renginiai','#galerija','#degustacijos','#skoniai'].includes(href)) { e.preventDefault(); closeThen(() => onOpenPanel(href.slice(1))); }
    else setSheetOpen(false);
  };
  const navLink = (item: typeof DEFAULT_NAVIGATION[number]) => <a href={item.href} onClick={e => follow(item.href,e)}>{item.label}</a>;

  return (
    <>
      <header className={`header${scrolled ? " is-scrolled" : ""}${sheetOpen ? " sheet-open" : ""}`} id="topHeader">
        <div className="shell header-row">
          <a className="logo" href="#pradzia" aria-label="Alma Chaab" onClick={() => setSheetOpen(false)}>
            <span className="logo-flourish">✦</span>
            <span className="logo-text">
              Alma Chaab
              <small>{s.site.tagline}</small>
            </span>
          </a>
          <nav className="nav header-primary-nav" aria-label="Greita navigacija">
            {visibleNav.filter(n => !n.parentId).map(n => <div className="managed-nav-item" key={n.id}>
              {navLink(n)}
              {visibleNav.some(x => x.parentId === n.id) && <details><summary aria-label={`Daugiau: ${n.label}`}>▾</summary><div className="managed-subnav">{visibleNav.filter(x => x.parentId === n.id).map(x => <div key={x.id}>{navLink(x)}</div>)}</div></details>}
            </div>)}
            <a className="phone" href={`tel:${s.site.phone}`} aria-label={`Skambinti ${s.site.phoneDisplay}`}>
              <PhoneIcon size={14} />
              <span>{s.site.phoneDisplay}</span>
            </a>
            {s.site.facebookUrl && (
              <a
                className="header-fb"
                href={s.site.facebookUrl}
                target="_blank"
                rel="noopener"
                aria-label="Alma Chaab Facebook puslapis"
              >
                <FacebookIcon size={16} />
              </a>
            )}
          </nav>
          {/* Phone + Facebook stay visible in the phone header (desktop shows them in the nav) */}
          <div className="header-quick">
            <a className="header-quick-phone" href={`tel:${s.site.phone}`} aria-label={`Skambinti ${s.site.phoneDisplay}`}>
              <PhoneIcon size={14} />
              <span>{s.site.phoneDisplay}</span>
            </a>
            {s.site.facebookUrl && (
              <a className="header-quick-fb" href={s.site.facebookUrl} target="_blank" rel="noopener" aria-label="Alma Chaab Facebook puslapis">
                <FacebookIcon size={16} />
              </a>
            )}
          </div>
          <button
            className="header-plus"
            type="button"
            aria-expanded={sheetOpen}
            aria-controls="headerSheet"
            aria-label={sheetOpen ? "Uždaryti meniu" : "Atidaryti meniu"}
            onClick={() => setSheetOpen((o) => !o)}
          >
            <span aria-hidden="true" />
          </button>
        </div>

        <div className="header-sheet" id="headerSheet" hidden={!sheetOpen}>
          <div className="shell header-sheet-inner">
            <div className="header-sheet-primary">
              <button type="button" className="sheet-cta sheet-cta-menu" onClick={() => closeThen(onGoMenu)}>
                <strong>Meniu ir rezervacija</strong>
                <small>Staliukas, patiekalai, atsiėmimas</small>
              </button>
              {s.site.woltUrl && (
                <a className="sheet-cta sheet-cta-wolt" href={s.site.woltUrl} target="_blank" rel="noopener" onClick={() => setSheetOpen(false)}>
                  <strong>Wolt</strong>
                  <small>Pristatymas į namus</small>
                </a>
              )}
            </div>
            <ul className="header-sheet-list">
              {visibleNav.filter(n => !n.parentId).flatMap(n => [n,...visibleNav.filter(x => x.parentId === n.id)]).map(n => <li className={n.parentId ? 'managed-nav-child' : ''} key={n.id}>{navLink(n)}</li>)}
              <li>
                <a href="/straipsniai">
                  <span className="sheet-icon" aria-hidden="true">✎</span>
                  <span className="sheet-copy">
                    <strong>Straipsniai</strong>
                    <small>Patarimai ir istorijos</small>
                  </span>
                  <span className="sheet-arrow" aria-hidden="true">›</span>
                </a>
              </li>
              <li>
                <a href="/mano">
                  <span className="sheet-icon" aria-hidden="true">◎</span>
                  <span className="sheet-copy">
                    <strong>Mano užsakymai</strong>
                    <small>Sekti užsakymą, paskyra</small>
                  </span>
                  <span className="sheet-arrow" aria-hidden="true">›</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </header>
      {sheetOpen && <div className="header-sheet-backdrop" aria-hidden="true" onClick={() => setSheetOpen(false)} />}
    </>
  );
}

export function Hero({ data, rating, onGoMenu }: SectionProps) {
  const s = data.settings;
  const content = s.content;
  const [status, setStatus] = useState({ open: false, text: "◌ Tikrinamas darbo laikas" });
  useEffect(() => {
    const t = setTimeout(() => setStatus(openStatusText(s.hours as Record<string, [number, number] | null>)), 0);
    return () => clearTimeout(t);
  }, [s.hours]);
  const titleLines: string[] = c(content, "hero.titleLines", ["Libano šiluma.", "Skonis, kuris", "lieka atmintyje."]);
  const heroSrc: string = c(content, "hero.image", "/logo.svg");
  return (
    <section className="hero" id="pradzia">
      {heroSrc.startsWith("/") ? (
        <Image
          className="hero-bg" data-cms-image="hero.image"
          src={heroSrc}
          alt="Alma Chaab restoranas Kėdainių senamiestyje"
          fill
          priority
          sizes="100vw"
        />
      ) : (
         
        <img className="hero-bg" src={heroSrc} alt="Alma Chaab restoranas Kėdainių senamiestyje" fetchPriority="high" decoding="async" />
      )}
      <div className="shell signature-hero-shell">
        <div className="signature-hero-copy">
          <div className="signature-mark"><EditText content={content} path="hero.mark" fallback="Alma Chaab · Kėdainių senamiestis" /></div>
          <h1>
            {titleLines.map((l, i) => (
              <span key={i} data-cms-path={`hero.titleLines.${i}`} style={visualStyle(content,`hero.titleLines.${i}`)}>{l}</span>
            ))}
          </h1>
          <p className="hero-lead"><EditText content={content} path="hero.lead" fallback="" /></p>
          <div className="signature-hero-meta">
            <span className={`signature-chip ${status.open ? "status-open" : "status-closed"}`}>{status.text}</span>
            <span className="signature-chip"><EditText content={content} path="hero.chipsAddress" fallback="⌖ Didžioji g. 25, Kėdainiai" /></span>
            {rating.mode !== "hidden" && (
              <span className="signature-chip">★ {rating.score} · {rating.count} Google atsiliepimas</span>
            )}
          </div>
          <div className="signature-hero-actions signature-hero-actions-v12">
            <button className="btn signature-main-action" type="button" onClick={onGoMenu}>
              <span className="cta-long"><EditText content={content} path="hero.mainCta" fallback="Peržiūrėti meniu + rezervuoti" /></span>
              <span className="cta-short">Meniu ir rezervacija</span>
              <span className="cta-arrow">→</span>
            </button>
            <a
              className="btn btn-wolt signature-wolt-action"
              href={s.site.woltUrl || "#wolt"}
              {...(s.site.woltUrl ? { target: "_blank", rel: "noopener" } : {})}
            >
              <strong>Wolt</strong>
              <span><EditText content={content} path="hero.woltCta" fallback="užsakyti pristatymą" /></span>
            </a>
            {/* Directions: opens Google Maps (the app on phones) with the route to the restaurant */}
            <a
              className="btn signature-maps-action"
              href={directionsUrl(s.site.name, s.site.address)}
              target="_blank"
              rel="noopener"
              aria-label={`Maršrutas iki ${s.site.name}, ${s.site.address} (Google Maps)`}
            >
              <MapPinIcon size={20} />
              <span className="maps-copy">
                <strong>Maršrutas</strong>
                <span>Google Maps</span>
              </span>
            </a>
          </div>
          <p className="hero-service-note"><EditText content={content} path="hero.serviceNote" fallback="" /></p>
          <div className="signature-line"></div>
        </div>
      </div>
      <a className="scroll-cue" href="#apie">⌄</a>
    </section>
  );
}

export function Proof({ data, rating }: SectionProps) {
  const items: { title: string; sub: string }[] = c(data.settings.content, "proof.items", []);
  return (
    <section className="signature-proof" aria-label="Alma Chaab faktai">
      <div className="shell">
        <div className="signature-proof-inner">
          {rating.mode !== "hidden" && (
            <div className="proof-item proof-rating">
              <strong>
                <span className="proof-stars">{starsFor(rating.score)}</span> {rating.score} / 5
              </strong>
              <span>{rating.note || `${rating.count} Google atsiliepimas`}</span>
            </div>
          )}
          {items.map((it, i) => (
            <div className="proof-item" key={i}>
              <strong>{it.title}</strong>
              <span>{it.sub}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function About({ data, onGoMenu }: SectionProps) {
  const content = data.settings.content;
  const stats: { n: string; label: string }[] = c(content, "about.stats", []);
  const paragraphs: string[] = c(content, "about.paragraphs", []);
  return (
    <section className="section about-seo" id="apie">
      <div className="shell about-seo-grid">
        <article className="about-seo-copy">
          <h2><EditText content={content} path="about.title" fallback="" /></h2>
          {paragraphs.map((p, i) => (
            <p key={i} dangerouslySetInnerHTML={{ __html: sanitizeInlineHtml(p) }} />
          ))}
        </article>
        <aside className="about-editorial-visual">
          <figure className="about-editorial-photo">
            { }
            <img src={c(content, "about.image", "/logo.svg")} data-cms-image="about.image" alt="Alma Chaab restoranas Kėdainių senamiestyje" loading="lazy" />
            <figcaption>
              <span><EditText content={content} path="about.caption1" fallback="Didžioji g. 25" /></span>
              <strong><EditText content={content} path="about.caption2" fallback="Kėdainių senamiestis" /></strong>
            </figcaption>
          </figure>
          <div className="about-editorial-stats" aria-label="Alma Chaab faktai">
            {stats.map((st, i) => (
              <div key={i}>
                <strong>{st.n}</strong>
                <span>{st.label}</span>
              </div>
            ))}
          </div>
          <button className="btn btn-gold about-editorial-cta" type="button" onClick={onGoMenu}>
            <EditText content={content} path="about.cta" fallback="Atrasti meniu ir rezervuoti →" />
          </button>
        </aside>
      </div>
    </section>
  );
}

export function Ribbon({ data }: SectionProps) {
  const images: { src: string; caption: string; alt?: string }[] = c(data.settings.content, "ribbon", []);
  return (
    <section className="signature-photo-ribbon" aria-label="Alma Chaab atmosfera">
      <div className="shell photo-ribbon-grid">
        {images.map((img, i) => (
          <figure key={i}>
            { }
            <img src={img.src} alt={img.caption || "Alma Chaab"} loading="lazy" referrerPolicy="no-referrer" />
            <figcaption className="photo-ribbon-caption">{img.caption}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

export function Social({ data, rating }: SectionProps) {
  const content = data.settings.content;
  return (
    <section className="signature-social" id="atsiliepimai">
      <div className="shell social-grid">
        <div className="social-score">
          {rating.mode !== "hidden" && (
            <div>
              <div className="score-big">
                {rating.score} <small>/ 5</small>
              </div>
              <div className="score-stars">{starsFor(rating.score)}</div>
              <p>
                {rating.count} <EditText content={content} path="social.scoreNote" fallback="viešas Google atsiliepimas." />
              </p>
            </div>
          )}
          <a href={data.settings.site.mapsUrl} target="_blank" rel="noopener">
            <EditText content={content} path="social.mapsLink" fallback="Peržiūrėti Google Maps →" />
          </a>
        </div>
        <div className="social-copy">
          <p className="eyebrow"><EditText content={content} path="social.eyebrow" fallback="Svečiai apie Alma Chaab" /></p>
          <h2><EditText content={content} path="social.title" fallback="" /></h2>
          <blockquote><EditText content={content} path="social.quote" fallback="" /></blockquote>
          <p className="review-note"><EditText content={content} path="social.note" fallback="" /></p>
        </div>
      </div>
    </section>
  );
}

export function Hub({ data, onOpenPanel }: SectionProps) {
  const content = data.settings.content;
  const cards: { id: string; icon: string; title: string; sub: string }[] = c(content, "hub.cards", []);
  return (
    <section className="section minimized-hub" id="daugiau">
      <div className="shell">
        <div className="minimized-hub-head">
          <div>
            <p className="eyebrow"><EditText content={content} path="hub.eyebrow" fallback="Atraskite daugiau" /></p>
            <h2><EditText content={content} path="hub.title" fallback="Visa kita — tik kai norite" /></h2>
            <p><EditText content={content} path="hub.sub" fallback="" /></p>
          </div>
        </div>
        <div className="minimized-actions" role="group" aria-label="Papildomos Alma Chaab skiltys">
          {cards.map((card) =>
            card.id === "straipsniai" ? (
              <a className="minimized-action" href="/straipsniai" key={card.id}>
                <span className="min-icon">{card.icon}</span>
                <span>
                  <strong>{card.title}</strong>
                  <small>{card.sub}</small>
                </span>
                <span className="min-arrow">＋</span>
              </a>
            ) : (
              <button className="minimized-action" type="button" key={card.id} onClick={() => onOpenPanel(card.id)}>
                <span className="min-icon">{card.icon}</span>
                <span>
                  <strong>{card.title}</strong>
                  <small>{card.sub}</small>
                </span>
                <span className="min-arrow">＋</span>
              </button>
            )
          )}
        </div>
      </div>
    </section>
  );
}

export function PanelBar({ title, onClose }: { title: string; onClose: () => void }) {
  return (
    <div className="shell optional-bar-shell">
      <div className="optional-panel-bar">
        <span>{title}</span>
        <button className="panel-close" type="button" onClick={onClose}>
          Suskleisti ×
        </button>
      </div>
    </div>
  );
}

export function SkoniaiPanel({ data, onClose, onGoMenu }: SectionProps & { onClose: () => void }) {
  const content = data.settings.content;
  const features: { img: string; title: string; text: string; price: string }[] = c(content, "skoniai.features", []);
  return (
    <section className="section white optional-section" id="skoniai">
      <PanelBar title="Atidaryta skiltis" onClose={onClose} />
      <div className="shell">
        <div className="section-head">
          <div>
            <p className="eyebrow"><EditText content={content} path="skoniai.eyebrow" fallback="Mūsų skoniai" /></p>
            <h2><EditText content={content} path="skoniai.title" fallback="Atraskite mėgstamus patiekalus" /></h2>
          </div>
          <a
            className="section-link"
            href="#meniu"
            onClick={(e) => {
              e.preventDefault();
              onClose();
              onGoMenu();
            }}
          >
            <EditText content={content} path="skoniai.link" fallback="Peržiūrėti visą meniu →" />
          </a>
        </div>
        <div className="feature-grid">
          {features.map((f, i) => (
            <article className="feature" key={i}>
              { }
              <img src={f.img} alt={f.title} loading="lazy" />
              <div className="feature-body">
                <h3>{f.title}</h3>
                <p>{f.text}</p>
                <div className="price">{f.price}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function DegustacijosPanel({ data, onClose }: SectionProps & { onClose: () => void }) {
  const content = data.settings.content;
  const stats: { n: string; label: string }[] = c(content, "degustacijos.stats", []);
  return (
    <section className="section optional-section" id="degustacijos">
      <PanelBar title="Atidaryta skiltis" onClose={onClose} />
      <div className="shell story-grid">
        <div>
          <p className="eyebrow"><EditText content={content} path="degustacijos.eyebrow" fallback="Alma Chaab istorija" /></p>
          <h2><EditText content={content} path="degustacijos.title" fallback="" /></h2>
          <p className="section-intro"><EditText content={content} path="degustacijos.intro" fallback="" /></p>
          <div className="story-card">
            {stats.map((st, i) => (
              <div key={i}>
                <strong>{st.n}</strong>
                <span>{st.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="story-photo">
          { }
          <img src={c(content, "degustacijos.image", "/logo.svg")} data-cms-image="degustacijos.image" alt="Alma Chaab restorano pastatas" loading="lazy" />
        </div>
      </div>
    </section>
  );
}

export function EventsPanel({ data, onClose, onBilliards }: SectionProps & { onClose: () => void }) {
  const content = data.settings.content;
  const b = activeBilliards(content);
  return (
    <section className="section events optional-section" id="renginiai">
      <PanelBar title="Atidaryta skiltis" onClose={onClose} />
      <div className="shell">
        <p className="eyebrow"><EditText content={content} path="events.eyebrow" fallback="Šventės ir renginiai" /></p>
        <h2><EditText content={content} path="events.title" fallback="" /></h2>
        <p className="section-intro"><EditText content={content} path="events.intro" fallback="" /></p>
        {b && (
          <article className="billiards-promo" aria-label={b.title}>
            <div className="billiards-promo-mark" aria-hidden="true">🎱</div>
            <div className="billiards-promo-copy">
              <div className="billiards-promo-kicker">{b.kicker}</div>
              <h3>{b.title}</h3>
              <p>{b.text}</p>
              <div className="billiards-choice-grid">
                {b.options?.map((o: { icon: string; name: string; sub: string }, i: number) => (
                  <div key={i}>
                    <span>{o.icon}</span>
                    <strong>{o.name}</strong>
                    <small>{o.sub}</small>
                  </div>
                ))}
              </div>
              <div className="billiards-meta">
                {b.meta?.map((m: string, i: number) => (
                  <span key={i}>{m}</span>
                ))}
              </div>
            </div>
            <div className="billiards-promo-action">
              <div className="billiards-price">
                <small>{b.priceSmall}</small>
                <strong>{billiardsPriceLine(content)}</strong>
                <span>Žaisti galima iki {billiardsInfo(content).cutoff}.</span>
              </div>
              <button className="btn btn-gold billiards-book-btn" type="button" onClick={onBilliards}>
                {b.cta}
              </button>
              <a className="billiards-phone" href={`tel:${data.settings.site.phone}`}>
                ☎ {data.settings.site.phoneDisplay}
              </a>
            </div>
          </article>
        )}
      </div>
    </section>
  );
}

export function GalleryPanel({ data, onClose }: SectionProps & { onClose: () => void }) {
  const content = data.settings.content;
  const images: { src: string; caption: string; alt?: string }[] = c(content, "gallery.images", []);
  return (
    <section className="section white optional-section" id="galerija">
      <PanelBar title="Atidaryta skiltis" onClose={onClose} />
      <div className="shell">
        <div className="section-head">
          <div>
            <p className="eyebrow"><EditText content={content} path="gallery.eyebrow" fallback="Galerija" /></p>
            <h2><EditText content={content} path="gallery.title" fallback="Alma Chaab atmosfera" /></h2>
          </div>
        </div>
        {images.length === 0 && <p>Restorano ir patiekalų nuotraukas papildysime netrukus.</p>}
        <div className="gallery">
          {images.map((img, i) => (
            <figure key={i}>
              { }
              <img src={img.src} alt={img.alt || img.caption || "Alma Chaab galerija"} loading="lazy" />
              <figcaption>{img.caption}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Wolt({ data }: SectionProps) {
  const content = data.settings.content;
  return (
    <section className="section wolt-section" id="wolt">
      <div className="shell">
        <div className="wolt-panel">
          <div className="wolt-copy">
            <span className="wolt-badge"><EditText content={content} path="wolt.badge" fallback="W · pristatymas atskirai" /></span>
            <p className="eyebrow"><EditText content={content} path="wolt.eyebrow" fallback="Kai norisi Alma Chaab namuose" /></p>
            <h2><EditText content={content} path="wolt.title" fallback="Pristatymas lieka paprastas – per Wolt." /></h2>
            <p><EditText content={content} path="wolt.text" fallback="" /></p>
          </div>
          {data.settings.site.boltFoodUrl && <a className="btn" href={data.settings.site.boltFoodUrl} target="_blank" rel="noopener">Bolt Food →</a>}
          <a className="btn btn-wolt wolt-main-btn" href={data.settings.site.woltUrl} target="_blank" rel="noopener">
            <strong>Wolt</strong> Atidaryti pristatymo meniu →
          </a>
        </div>
      </div>
    </section>
  );
}

export function Contacts({ data, onGoMenu }: SectionProps) {
  const content = data.settings.content;
  const s = data.settings.site;
  return (
    <section className="section" id="kontaktai">
      <div className="shell">
        <div className="section-head">
          <div>
            <p className="eyebrow"><EditText content={content} path="contacts.eyebrow" fallback="Kontaktai" /></p>
            <h2><EditText content={content} path="contacts.title" fallback="Susisiekite su Alma Chaab" /></h2>
          </div>
        </div>
        <div className="contact-box contact-box-wide">
          <div className="contact-line">
            <strong>Adresas</strong>
            <br />
            <a className="contact-directions" href={directionsUrl(s.name, s.address)} target="_blank" rel="noopener">
              {s.address} <span aria-hidden="true">· maršrutas ↗</span>
            </a>
          </div>
          <div className="contact-line">
            <strong>Telefonas</strong>
            <br />
            <a href={`tel:${s.phone}`}>{s.phoneDisplay}</a>
          </div>
          {s.facebookUrl && (
            <div className="contact-line">
              <strong>Facebook</strong>
              <br />
              <a href={s.facebookUrl} target="_blank" rel="noopener" className="contact-fb-link">
                <FacebookIcon size={15} /> restoranas.almachaab
              </a>
            </div>
          )}
          <div className="contact-line">
            <strong>Staliuko rezervacija</strong>
            <br />
            <a className="section-link" href="#meniu" onClick={(e) => { e.preventDefault(); onGoMenu(); }}>
              <EditText content={content} path="contacts.reservationLink" fallback="Atidaryti meniu ir rezervaciją →" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer({ data, onGoMenu }: SectionProps) {
  const content = data.settings.content;
  const s = data.settings.site;
  return (
    <footer className="footer">
      <div className="shell">
        <div className="footer-grid">
          <div>
            <h3>Alma Chaab</h3>
            <p><EditText content={content} path="footer.about" fallback="" /></p>
          </div>
          <div>
            <strong>Greitos nuorodos</strong>
            <a href="#meniu" onClick={(e) => { e.preventDefault(); onGoMenu(); }}>Meniu ir rezervacija</a>
            <a href="/apie-mus">Apie mus</a>
            <a href="/straipsniai">Straipsniai ir istorijos</a>
            <a href="/privatumas">Privatumas</a>
            <a href="#kontaktai">Kontaktai</a>
            <a href={s.woltUrl} target="_blank" rel="noopener">Wolt užsakymai</a>
            {/* /sekti merged into /mano — one link serves tracking + account. */}
            <a href="/mano">Mano paskyra · Sekti užsakymą</a>
            {/* /admin link removed: staff use a bookmark, no reason to advertise the panel publicly. */}
          </div>
          <div>
            <strong>Kontaktai</strong>
            <a className="footer-call-btn" href={`tel:${s.phone}`}>
              <PhoneIcon size={15} />
              <span>Skambinti {s.phoneDisplay}</span>
            </a>
            <a href={`mailto:${s.email}`}>{s.email}</a>
            <span>{s.address}</span>
            {s.facebookUrl && (
              <a className="footer-fb-link" href={s.facebookUrl} target="_blank" rel="noopener">
                <FacebookIcon size={15} />
                <span>Facebook</span>
              </a>
            )}
          </div>
        </div>
        <small>
          <EditText content={content} path="footer.copyright" fallback="Alma Chaab" /> · {new Date().getFullYear()}
          {s.legalName ? ` · ${s.legalName}` : ""}
          {s.companyCode ? `, į. k. ${s.companyCode}` : ""}
        </small>
      </div>
    </footer>
  );
}

export function VisitorInformation({ data }: { data: SiteData }) {
  const info = visitorInfo(data.settings.content);
  return <section className="section white" id="pries-atvykstant"><div className="shell">
    <div className="section-head"><div><p className="eyebrow">Jūsų apsilankymui</p><h2>Prieš atvykstant</h2></div></div>
    <div className="visitor-grid">{Object.entries(VISITOR_LABELS).map(([key, label]) => <article key={key}><h3>{label}</h3><p data-cms-path={`visitor.${key}`} style={visualStyle(data.settings.content,`visitor.${key}`)}>{info[key as keyof typeof info]}</p></article>)}</div>
    <a href={`tel:${data.settings.site.phone}`}>Susisiekite: {data.settings.site.phoneDisplay}</a>
  </div></section>;
}

export function ManagedPublicSections({ data }: { data: SiteData }) {
  const content=data.settings.content;
  const events=content.liveEvents || [];
  const pages=content.pages || [];
  return <>
    {events.length > 0 && <section className="section white" id="patvirtinti-renginiai"><div className="shell"><h2>Artėjantys renginiai</h2><div className="visitor-grid">{events.map((e: any) => <article key={e.id}><h3>{e.title}</h3><p><time dateTime={`${e.date}T${e.time}`}>{e.date} · {e.time}</time> (Lietuvos laiku)</p><p style={{ whiteSpace:'pre-line' }}>{e.description}</p>{e.image && <img src={e.image} alt={e.title} loading="lazy" style={{ maxWidth:'100%' }} />}{e.bookingUrl && <a href={e.bookingUrl}>Rezervuoti</a>}</article>)}</div></div></section>}
    {pages.filter((p: any) => p.visible).map((p: any) => <section className="section white" id={p.id} key={p.id}><div className="shell"><h2>{p.title}</h2><p style={{ whiteSpace:'pre-line' }}>{p.text}</p>{p.image && <img src={p.image} alt={p.alt} loading="lazy" style={{ maxWidth:'100%',maxHeight:600,objectFit:'contain' }} />}{p.ctaLabel && p.ctaHref && <a className="btn" href={p.ctaHref}>{p.ctaLabel}</a>}</div></section>)}
  </>;
}
