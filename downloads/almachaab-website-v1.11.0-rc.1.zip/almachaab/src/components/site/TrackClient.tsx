"use client";

import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { FacebookIcon, PhoneIcon } from "./icons";
import { useLoadEffect } from "@/hooks/use-load-effect";

interface TrackSupport {
  phone: string;
  phoneDisplay: string;
  facebookUrl?: string;
}

interface TrackData {
  number: string;
  type: string;
  status: string;
  statusLabel: string;
  customerName: string;
  total: number;
  pickupTime: string;
  resDate: string;
  resTime: string;
  guests: number;
  items: { name: string; qty: number; price: number }[];
  createdAt: string;
  readyAt?: string | null;
  prepMinutesLeft?: number | null;
  history: { status: string; label: string; at: string }[];
}

const FLOW: Record<string, string[]> = {
  pickup: ["new", "awaiting", "confirmed", "preparing", "ready", "completed"],
  reservation: ["new", "confirmed", "completed"],
};

const FLOW_LABELS: Record<string, string> = {
  new: "Užsakymas gautas",
  awaiting: "Laukiama patvirtinimo",
  confirmed: "Patvirtintas",
  preparing: "Ruošiamas",
  ready: "Paruoštas",
  completed: "Užbaigtas",
  cancelled: "Atšauktas",
};

function eur(v: number) {
  return v.toFixed(2).replace(".", ",") + " €";
}

export function TrackClient({
  phone = "+37066613055",
  phoneDisplay = "+370 666 13 055",
  facebookUrl = "https://www.facebook.com/restoranas.almachaab",
}: Partial<TrackSupport> = {}) {
  const params = useSearchParams();
  const [nr, setNr] = useState(params.get("nr") || "");
  const [data, setData] = useState<TrackData | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const lookup = useCallback(async (number: string) => {
    const clean = number.trim().replace(/^#/, "");
    if (!clean) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/track/${encodeURIComponent(clean)}`);
      const json = await res.json();
      if (!res.ok) {
        setData(null);
        setError(json.error || "Užsakymas nerastas.");
      } else {
        setData(json);
      }
    } catch {
      setError("Klaida jungiantis į serverį.");
    } finally {
      setLoading(false);
    }
  }, []);

  const initialLookup = useCallback(() => {
    const initial = params.get("nr");
    if (initial) void lookup(initial);
  }, [params, lookup]);
  useLoadEffect(initialLookup);

  // live polling fallback
  useEffect(() => {
    if (!data) return;
    const t = setInterval(() => lookup(data.number), 15000);
    return () => clearInterval(t);
  }, [data, lookup]);

  // real-time updates via SSE — status changes appear instantly
  useEffect(() => {
    if (!data) return;
    const number = data.number;
    const es = new EventSource(`/api/track/${encodeURIComponent(number)}/stream`);
    const refresh = () => lookup(number);
    es.addEventListener("order", refresh);
    // errors are fine: EventSource reconnects, polling still covers us
    return () => es.close();
  }, [data, lookup]);

  const flow = data ? FLOW[data.type] || FLOW.pickup : [];
  const cancelled = data?.status === "cancelled";
  const currentIdx = data ? flow.indexOf(data.status) : -1;

  return (
    <div className="alma-root track-page">
      <header className="track-header">
        <a className="track-logo" href="/">
          <span>✦</span> Alma Chaab
        </a>
        <a className="track-home" href="/">← Į svetainę</a>
      </header>
      <main className="track-main">
        <h1>Sekti užsakymą</h1>
        <p className="track-lead">Įveskite užsakymo numerį (pvz. AC-1042), kad pamatytumėte dabartinę būseną.</p>

        <div className="track-support" role="note" aria-label="Pagalba telefonu">
          <span className="track-support-icon">
            <PhoneIcon size={19} />
          </span>
          <span className="track-support-copy">
            <strong>Klausimų apie užsakymą?</strong>
            <small>Paskambinkite — padėsime iš karto.</small>
          </span>
          <a className="track-support-call" href={`tel:${phone}`}>
            <PhoneIcon size={15} />
            <span>{phoneDisplay}</span>
          </a>
        </div>

        <form
          className="track-form"
          onSubmit={(e) => {
            e.preventDefault();
            lookup(nr);
          }}
        >
          <input
            value={nr}
            onChange={(e) => setNr(e.target.value)}
            placeholder="AC-1042"
            aria-label="Užsakymo numeris"
            autoComplete="off"
          />
          <button type="submit" disabled={loading}>
            {loading ? "Ieškoma..." : "Ieškoti"}
          </button>
        </form>

        {error && <div className="track-error">{error}</div>}

        {data && (
          <div className="track-card">
            <div className="track-card-head">
              <div>
                <span className="track-label">{data.type === "pickup" ? "Atsiėmimo užsakymas" : "Rezervacija"}</span>
                <h2>#{data.number}</h2>
              </div>
              <span className={`track-status-badge ${data.status}`}>{data.statusLabel}</span>
            </div>

            {cancelled ? (
              <div className="track-cancelled">Šis užsakymas atšauktas. Klausimų atveju skambinkite {phoneDisplay}.</div>
            ) : (
              <>
                {data.readyAt && !cancelled && (
                  <div className={`track-eta ${data.prepMinutesLeft === 0 ? "late" : ""}`}>
                    ⏱ Paruošta apie{" "}
                    <b>
                      {new Date(data.readyAt).toLocaleTimeString("lt-LT", { hour: "2-digit", minute: "2-digit" })}
                    </b>
                    {typeof data.prepMinutesLeft === "number" && data.prepMinutesLeft > 0
                      ? ` (per ~${data.prepMinutesLeft} min)`
                      : data.prepMinutesLeft === 0
                        ? " — jau turėtų būti paruošta!"
                        : ""}
                  </div>
                )}
                <ol className="track-steps">
                {flow.map((st, i) => {
                  const done = i <= currentIdx;
                  const active = i === currentIdx;
                  return (
                    <li key={st} className={`${done ? "done" : ""} ${active ? "active" : ""}`}>
                      <span className="track-dot">{done ? "✓" : i + 1}</span>
                      <span className="track-step-label">{FLOW_LABELS[st]}</span>
                    </li>
                  );
                })}
              </ol>
              </>
            )}

            <div className="track-meta">
              {data.type === "pickup" ? (
                <div>
                  <span>Atsiėmimo laikas</span>
                  <strong>{data.pickupTime || "— patvirtinsime —"}</strong>
                </div>
              ) : (
                <div>
                  <span>Rezervacija</span>
                  <strong>
                    {data.resDate} {data.resTime} · {data.guests} svečiai
                  </strong>
                </div>
              )}
              <div>
                <span>Suma</span>
                <strong>{eur(data.total)}</strong>
              </div>
            </div>

            {data.items.length > 0 && (
              <div className="track-items">
                {data.items.map((i, idx) => (
                  <div key={idx} className="track-item">
                    <span>
                      {i.name} × {i.qty}
                    </span>
                    <b>{eur(i.price * i.qty)}</b>
                  </div>
                ))}
              </div>
            )}

            <div className="track-updated">Atnaujinta: {new Date().toLocaleTimeString("lt-LT")} · būsena atnaujinama automatiškai</div>
          </div>
        )}
      </main>
      <footer className="track-footer">
        <span>Alma Chaab · Didžioji g. 25, Kėdainiai · <a href={`tel:${phone}`}>{phoneDisplay}</a></span>
        {facebookUrl && (
          <a className="track-footer-fb" href={facebookUrl} target="_blank" rel="noopener" aria-label="Alma Chaab Facebook puslapis">
            <FacebookIcon size={14} /> Facebook
          </a>
        )}
      </footer>
    </div>
  );
}
