import { billiardsSummary } from "@/lib/visitor";
import type { PublicSettings } from "@/lib/settings";

export interface Dish {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  inStock?: boolean;
  vegetarian?: boolean;
  vegan?: boolean;
  halal?: boolean;
  dietaryNotes?: string;
}
export interface MenuCategory {
  id: string;
  name: string;
  items: Dish[];
}
export interface SiteData {
  settings: PublicSettings;
  categories: MenuCategory[];
}

// Safe content reader: c(content, "hero.title", "fallback")
 
export function c(content: any, path: string, fallback: any): any {
  let cur = content;
  for (const part of path.split(".")) {
    if (cur == null || typeof cur !== "object") return fallback;
    cur = cur[part];
  }
  return cur === undefined || cur === null ? fallback : cur;
}

/**
 * Billiards offer from admin → Turinys. Hidden when switched off or when its
 * "galioja iki" date (YYYY-MM-DD, inclusive, Vilnius time) has passed — so a
 * dated promotion can never stay on the site after it ends.
 */
export function activeBilliards(content: any): any | null {
  const b = c(content, "events.billiards", null);
  if (!b || b.enabled === false) return null;
  const until = typeof b.validUntil === "string" ? b.validUntil.trim() : "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(until)) {
    const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Vilnius" }).format(new Date());
    if (today > until) return null;
  }
  return b;
}

/** Short billiards line for the reservation composer (editable in admin). */
export function billiardsBookingNote(content: any): string {
  return billiardsSummary(content);
}

export const DAY_KEYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"] as const;
export const DAY_NAMES_LT = ["Sekmadienis", "Pirmadienis", "Antradienis", "Trečiadienis", "Ketvirtadienis", "Penktadienis", "Šeštadienis"];

export function hoursFor(hours: Record<string, [number, number] | null>, dayIdx: number) {
  return hours[DAY_KEYS[dayIdx]] || null;
}

export function vilniusParts(date = new Date()) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Vilnius",
    weekday: "short",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  const parts = fmt.formatToParts(date);
  const get = (t: string) => parts.find((p) => p.type === t)?.value || "";
  const map: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    dayIdx: map[get("weekday")] ?? 1,
    minutes: Number(get("hour")) * 60 + Number(get("minute")),
    ymd: `${get("year")}-${get("month")}-${get("day")}`,
    hhmm: `${get("hour")}:${get("minute")}`,
  };
}

export function openStatusText(hours: Record<string, [number, number] | null>) {
  const { dayIdx, minutes } = vilniusParts();
  const today = hoursFor(hours, dayIdx);
  const now = minutes;
  if (today) {
    const [open, close] = today;
    if (now >= open * 60 && now < close * 60) {
      return { open: true, text: `● Atidaryta dabar · iki ${String(close).padStart(2, "0")}:00` };
    }
    for (let i = 0; i < 8; i++) {
      const d = (dayIdx + i) % 7;
      const h = hoursFor(hours, d);
      if (!h) continue;
      if (i === 0 && now < h[0] * 60) {
        return { open: false, text: `Uždaryta dabar · šiandien ${String(h[0]).padStart(2, "0")}:00–${String(h[1]).padStart(2, "0")}:00` };
      }
      if (i > 0) {
        const when = i === 1 ? "rytoj" : DAY_NAMES_LT[d].toLowerCase();
        return { open: false, text: `Uždaryta · atsidarome ${when} ${String(h[0]).padStart(2, "0")}:00` };
      }
    }
  }
  for (let i = 1; i <= 7; i++) {
    const d = (dayIdx + i) % 7;
    const h = hoursFor(hours, d);
    if (h) return { open: false, text: `Uždaryta šiandien · atsidarome ${DAY_NAMES_LT[d].toLowerCase()} ${String(h[0]).padStart(2, "0")}:00` };
  }
  return { open: false, text: "Darbo laikas · žr. kontaktus" };
}

export interface PickupSlot {
  ymd: string;
  label: string;
  value: string;
  dayLabel: string;
}

export function generatePickupSlots(
  hours: Record<string, [number, number] | null>,
  cfg: { leadMinutes: number; slotMinutes: number; maxDaysAhead: number }
): PickupSlot[] {
  const slots: PickupSlot[] = [];
  const now = new Date();
  const today = vilniusParts(now);
  const fmtDay = new Intl.DateTimeFormat("lt-LT", { timeZone: "Europe/Vilnius", weekday: "long", day: "numeric", month: "long" });
  for (let i = 0; i <= Math.max(1, cfg.maxDaysAhead) && slots.length < 40; i++) {
    const d = new Date(now.getTime() + i * 24 * 3600 * 1000);
    const parts = vilniusParts(d);
    const h = hoursFor(hours, parts.dayIdx);
    if (!h) continue;
    const [open, close] = h;
    let start = open * 60;
    if (i === 0) start = Math.max(start, today.minutes + cfg.leadMinutes);
    const step = Math.max(10, cfg.slotMinutes);
    start = Math.ceil(start / step) * step;
    for (let m = start; m <= close * 60 - 30 && slots.length < 40; m += step) {
      const value = `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
      const dayLabel = i === 0 ? "Šiandien" : i === 1 ? "Rytoj" : fmtDay.format(d);
      slots.push({ ymd: parts.ymd, value, dayLabel, label: `${dayLabel} · ${value}` });
    }
  }
  return slots;
}

export function starsFor(score: number) {
  const full = Math.round(score);
  return "★".repeat(full) + "☆".repeat(Math.max(0, 5 - full));
}

export function calendarLink(title: string, details: string, location: string, date: string, time: string) {
  try {
    const start = new Date(`${date}T${time}:00`);
    const end = new Date(start.getTime() + 2 * 3600 * 1000);
    const fmt = (d: Date) => d.toISOString().replace(/[-:]|\.\d{3}/g, "");
    const params = new URLSearchParams({
      action: "TEMPLATE",
      text: title,
      details,
      location,
      dates: `${fmt(start)}/${fmt(end)}`,
    });
    return `https://calendar.google.com/calendar/render?${params.toString()}`;
  } catch {
    return "#";
  }
}

export function eur(v: number) {
  return "€" + v.toFixed(2);
}

export const CATEGORY_TAG: Record<string, string> = {
  pagrindiniai: "Pagrindinis",
  salotos: "Salotos",
  uzkandziai: "Dalijimuisi",
  sriubos: "Sriuba",
  vaikams: "Vaikams",
  desertai: "Desertas",
  padazai: "Priedas",
  gerimai: "Gėrimas",
};

export const CATEGORY_DESC: Record<string, string> = {
  pagrindiniai: "Sotus pagrindinis patiekalas pietums ar vakarienei Alma Chaab.",
  salotos: "Gaivesnis pasirinkimas pietums, vakarienei ar dalijimuisi prie stalo.",
  uzkandziai: "Užkandis, skirtas pradžiai arba dalijimuisi prie bendro stalo.",
  sriubos: "Šiltas pasirinkimas lengvesnei pietų ar vakarienės pradžiai.",
  vaikams: "Paprastas ir šeimai draugiškas pasirinkimas jaunesniems svečiams.",
  desertai: "Saldus pasirinkimas vakarienės pabaigai.",
  padazai: "Papildomas skonio akcentas prie pasirinkto patiekalo.",
  gerimai: "Gėrimas prie pietų, vakarienės ar desertų.",
};
