"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { signIn } from "next-auth/react";
import { FacebookIcon, PhoneIcon } from "./icons";
import { enableCustomerPush, disableCustomerPush, getCustomerPushStatus, type PushStatus } from "../admin/push-client";
import { OrderTracker } from "./OrderTracker";
import { PayLaterBox } from "./PayLaterBox";
import { useLoadEffect } from "@/hooks/use-load-effect";

/* ------------------------------------------------------------------ */
/* Mano paskyra — order tracking (ex /sekti) + login / history /       */
/* reorder / loyalty / push opt-in. Social: Google / Facebook /        */
/* Telegram. One page: track by number, pay later, register for perks. */
/* ------------------------------------------------------------------ */

interface SocialConfig {
  google: boolean;
  facebook: boolean;
  telegram: boolean;
  telegramBot: string;
  /** Server-verified via Telegram getMe (cached). Absent = assume active. */
  telegramBotActive?: boolean;
  /** Cloudflare Turnstile anti-bot gate (site key is public by design). */
  turnstile?: { enabled: boolean; siteKey: string };
}

interface TelegramWidgetUser {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  auth_date: number;
  hash: string;
}

interface Me {
  id: string;
  email: string;
  name: string;
  phone: string;
  hasPassword?: boolean;
  /** Social providers linked to this account, e.g. ["google","telegram"]. */
  accounts?: string[];
}

interface PastOrder {
  number: string;
  type: string;
  status: string;
  statusLabel: string;
  paymentStatus: string;
  paymentMethod: string;
  total: number;
  taxAmount: number;
  locationName?: string;
  items: { id: string; name: string; qty: number; price: number }[];
  pickupTime: string;
  resDate: string;
  resTime: string;
  guests: number;
  createdAt: string;
}

interface LoyaltyData {
  enabled: boolean;
  stampGoal: number;
  pointsPerEuro: number;
  profile: { points: number; lifetimePoints: number; stamps: number; totalStamps: number } | null;
  rewards: { id: string; name: string; description: string; pointsCost: number; affordable: boolean }[];
  redemptions: { id: string; code: string; status: string; pointsSpent: number; rewardName: string; createdAt: string; usedAt: string | null }[];
  transactions: { id: string; type: string; points: number; note: string; createdAt: string }[];
}

function eur(v: number) {
  return v.toFixed(2).replace(".", ",") + " €";
}

export function AccountClient({
  phone = "+37066613055",
  phoneDisplay = "+370 666 13 055",
  facebookUrl = "https://www.facebook.com/restoranas.almachaab",
}: {
  phone?: string;
  phoneDisplay?: string;
  facebookUrl?: string;
}) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [orders, setOrders] = useState<PastOrder[] | null>(null);
  // loyalty + marketing push
  const [loyalty, setLoyalty] = useState<LoyaltyData | null>(null);
  const [redeemMsg, setRedeemMsg] = useState("");
  const [redeeming, setRedeeming] = useState("");
  const [pushStatus, setPushStatus] = useState<PushStatus | null>(null);
  const [pushMsg, setPushMsg] = useState("");
  const [social, setSocial] = useState<SocialConfig | null>(null);
  // Merged tracking: /mano?nr=… (also the target of the former /sekti page)
  // and Stripe return params ?paid= / ?cancelled=.
  const [trackNumber, setTrackNumber] = useState("");
  const [trackToken, setTrackToken] = useState("");
  const [trackMsg, setTrackMsg] = useState("");
  // Telegram linking widget inside the logged-in "Prisijungimo būdai" card.
  const [showTgLink, setShowTgLink] = useState(false);
  // Login form: password reveal + Cloudflare Turnstile token.
  const [showPw, setShowPw] = useState(false);
  const [tsToken, setTsToken] = useState("");
  const [tsReset, setTsReset] = useState(0);

  const loadMe = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      const json = await res.json();
      setMe(json.user || null);
    } catch {
      setMe(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadOrders = useCallback(async () => {
    try {
      const res = await fetch("/api/me/orders", { cache: "no-store" });
      if (res.ok) {
        const json = await res.json();
        setOrders(json.orders);
      } else {
        setOrders([]);
      }
    } catch {
      setOrders([]);
    }
  }, []);

  const loadLoyalty = useCallback(async () => {
    try {
      const res = await fetch("/api/me/loyalty", { cache: "no-store" });
      if (res.ok) setLoyalty((await res.json()) as LoyaltyData);
      else setLoyalty(null);
    } catch {
      setLoyalty(null);
    }
  }, []);

  const loadPushStatus = useCallback(async () => {
    try {
      const st = await getCustomerPushStatus();
      setPushStatus(st);
    } catch {
      setPushStatus(null);
    }
  }, []);

  // On mount: session, public login flags and /mano deep links (?nr, ?t, ?paid…).
  const initFromUrl = useCallback(() => {
    void loadMe();
    // Social + anti-bot availability (public flags only — no secrets here).
    fetch("/api/auth/social-config", { cache: "no-store" })
      .then((r) => r.json())
      .then((j: { social?: SocialConfig; turnstile?: SocialConfig["turnstile"] }) =>
        setSocial(j.social ? { ...j.social, turnstile: j.turnstile } : null)
      )
      .catch(() => setSocial(null));
    // Deep links: /mano?nr=AC-… (tracking), ?paid= / ?cancelled= (Stripe
    // return), ?social=ok|error (OAuth bridge result).
    const params = new URLSearchParams(window.location.search);
    if (params.get("social") === "error") {
      setError("Socialinio prisijungimo klaida — bandykite dar kartą arba naudokite el. paštą.");
    }
    const nrParam = (params.get("nr") || "").trim();
    const paidParam = (params.get("paid") || "").trim();
    const cancelledParam = (params.get("cancelled") || "").trim();
    const tParam = (params.get("t") || "").trim();
    if (tParam) setTrackToken(tParam);
    if (nrParam) setTrackNumber(nrParam);
    if (cancelledParam) {
      setTrackNumber(cancelledParam);
      setTrackMsg("Apmokėjimas neįvyko — užsakymas liko neišmokėtas. Galite apmokėti žemiau.");
    }
    if (paidParam) {
      setTrackNumber(paidParam);
      fetch(`/api/checkout/stripe/verify?number=${encodeURIComponent(paidParam)}${tParam ? `&t=${encodeURIComponent(tParam)}` : ""}`, { cache: "no-store" })
        .then((r) => r.json())
        .then((j: { paid?: boolean; number?: string }) => {
          setTrackMsg(
            j.paid
              ? `✓ Apmokėta — užsakymas #${j.number || paidParam} patvirtintas.`
              : "Apmokėjimas dar nepatvirtintas — jei apmokėjimas įvyko, būsena atsinaujins per kelias minutes."
          );
        })
        .catch(() => setTrackMsg("Nepavyko patikrinti apmokėjimo — pabandykite atsinaujinti puslapį."));
    }
    if (params.get("social") || nrParam || paidParam || cancelledParam) {
      window.history.replaceState({}, "", "/mano");
    }
  }, [loadMe]);
  useLoadEffect(initFromUrl);

  // Signed in → load history, loyalty and push status (logout() clears them).
  const loadAccount = useCallback(() => {
    if (!me) return;
    void loadOrders();
    void loadLoyalty();
    void loadPushStatus();
  }, [me, loadOrders, loadLoyalty, loadPushStatus]);
  useLoadEffect(loadAccount);

  // Live-ish history: while an order is in flight, refresh every 20s so the
  // status badges and pay-later boxes stay current without a manual reload.
  const hasActiveOrder = Boolean(orders?.some((o) => ["new", "awaiting", "confirmed", "preparing"].includes(o.status)));
  useEffect(() => {
    if (!me || !hasActiveOrder) return;
    const t = setInterval(() => void loadOrders(), 20000);
    return () => clearInterval(t);
  }, [me, hasActiveOrder, loadOrders]);

  /** PayLaterBox on the tracker card → refresh history badges too. */
  const onTrackerPaid = useCallback(() => {
    if (me) void loadOrders();
  }, [me, loadOrders]);

  async function submitAuth(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const url = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body =
        mode === "login"
          ? { email, password, turnstileToken: tsToken }
          : { email, password, name, phone: regPhone, turnstileToken: tsToken };
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Klaida.");
        // Turnstile tokens are single-use — force a fresh check after a failure.
        setTsToken("");
        setTsReset((k) => k + 1);
        return;
      }
      setMe(json.user);
      setPassword("");
      setShowPw(false);
      setTsToken("");
      if (json.welcomeBonus) setTimeout(() => alert(`Sveikiname! Gavote ${json.welcomeBonus} lojalumo taškų dovaną.`), 200);
    } catch {
      setError("Serverio klaida — pabandykite dar kartą.");
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    setMe(null);
    setOrders(null);
    setLoyalty(null);
    setShowTgLink(false);
  }

  /** Store the previous cart and send the guest to the menu — AlmaSite picks it up. */
  function reorder(order: PastOrder) {
    const map: Record<string, number> = {};
    for (const it of order.items) {
      if (it.id) map[it.id] = (map[it.id] || 0) + it.qty;
    }
    try {
      localStorage.setItem("alma_reorder", JSON.stringify(map));
    } catch {
      /* storage blocked */
    }
    window.location.assign("/?reorder=1#meniu");
  }

  async function redeem(rewardId: string, rewardName: string) {
    if (!confirm(`Iškeisti taškus už „${rewardName}“? Kodo atšaukti negalima.`)) return;
    setRedeeming(rewardId);
    setRedeemMsg("");
    try {
      const res = await fetch("/api/me/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rewardId }),
      });
      const json = await res.json();
      if (!res.ok) {
        setRedeemMsg(json.error || "Iškeisti nepavyko.");
        return;
      }
      setRedeemMsg(`✓ Kuponas sukurtas: ${json.redemption.code} — parodykite jį atsiėmimo metu.`);
      void loadLoyalty();
    } catch {
      setRedeemMsg("Serverio klaida — pabandykite dar kartą.");
    } finally {
      setRedeeming("");
    }
  }

  async function togglePush() {
    setPushMsg("");
    if (pushStatus?.subscribed) {
      await disableCustomerPush();
      setPushMsg("Pranešimai išjungti šiame įrenginyje.");
      await loadPushStatus();
      return;
    }
    const r = await enableCustomerPush();
    if (r.ok) {
      setPushMsg("✓ Pasiūlymų ir lojalumo pranešimai įjungti!");
    } else {
      setPushMsg(r.error || "Nepavyko įjungti pranešimų.");
    }
    await loadPushStatus();
  }

  async function telegramCallback(user: TelegramWidgetUser) {
    setError("");
    setBusy(true);
    try {
      const res = await fetch("/api/auth/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...user, turnstileToken: tsToken }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Telegram prisijungimas nepavyko.");
        return;
      }
      setMe(json.user);
      setShowTgLink(false);
      void loadOrders();
      void loadLoyalty();
      void loadPushStatus();
    } catch {
      setError("Serverio klaida — pabandykite dar kartą.");
    } finally {
      setBusy(false);
    }
  }

  const greeting = me?.name ? me.name.split(" ")[0] : me?.email;

  /* Social sign-in block — stacked on top like the reference design,
     visible only when the owner enabled providers. */
  const socialBlock =
    social && (social.google || social.facebook || social.telegram) ? (
      <div className="social-block">
        <div className="social-stack">
          {social.google && (
            <button
              type="button"
              className="social-btn social-stack-btn"
              disabled={busy}
              onClick={() => signIn("google", { callbackUrl: "/api/auth/social/bridge" }).catch(() => setError("Nepavyko pradėti Google prisijungimo."))}
            >
              <GoogleIcon />
              Prisijungti su Google
            </button>
          )}
          {social.facebook && (
            <button
              type="button"
              className="social-btn social-stack-btn"
              disabled={busy}
              onClick={() => signIn("facebook", { callbackUrl: "/api/auth/social/bridge" }).catch(() => setError("Nepavyko pradėti Facebook prisijungimo."))}
            >
              <FacebookIcon size={17} />
              Prisijungti su Facebook
            </button>
          )}
        </div>
        {social.telegram && social.telegramBot && (
          <div className="social-telegram">
            <TelegramSlot bot={social.telegramBot} active={social.telegramBotActive !== false} onAuth={telegramCallback} />
          </div>
        )}
      </div>
    ) : null;

  const socialDivider = social && (social.google || social.facebook || social.telegram) ? (
    <div className="social-divider" role="separator">
      <span>Arba el. paštu</span>
    </div>
  ) : null;

  /* The login / register card — reused in both guest layouts. */
  const loginCard = (
    <div className="account-card">
            <div className="account-tabs" role="tablist">
              <button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>
                Prisijungti
              </button>
              <button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>
                Sukurti paskyrą
              </button>
            </div>
            {socialBlock}
            {socialDivider}
            <form className="account-form" onSubmit={submitAuth}>
              {mode === "register" && (
                <>
                  <label>
                    Vardas
                    <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jūsų vardas" autoComplete="name" />
                  </label>
                  <label>
                    Telefonas (neprivaloma)
                    <input value={regPhone} onChange={(e) => setRegPhone(e.target.value)} placeholder="+370..." autoComplete="tel" />
                  </label>
                </>
              )}
              <label>
                El. paštas
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" autoComplete="email" required />
              </label>
              <label>
                Slaptažodis
                <span className="pw-wrap">
                  <input
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={mode === "register" ? "Bent 8 simboliai" : "Jūsų slaptažodis"}
                    autoComplete={mode === "register" ? "new-password" : "current-password"}
                    required
                  />
                  <button
                    type="button"
                    className="pw-toggle"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Slėpti slaptažodį" : "Rodyti slaptažodį"}
                  >
                    {showPw ? <EyeOffIcon /> : <EyeIcon />}
                  </button>
                </span>
              </label>
              {social?.turnstile?.enabled && social.turnstile.siteKey && (
                <div className="account-captcha">
                  <TurnstileWidget siteKey={social.turnstile.siteKey} onToken={setTsToken} resetKey={tsReset} />
                </div>
              )}
              {error && <div className="track-error">{error}</div>}
              <button type="submit" className="account-submit" disabled={busy}>
                {busy ? "Siunčiama..." : mode === "login" ? "Prisijungti" : "Sukurti paskyrą"}
              </button>
              <small className="account-note">Paskyroje galite matyti užsakymų istoriją ir pakartoti užsakymą vienu paspaudimu.</small>
            </form>
          </div>
  );

  return (
    <div className="alma-root account-page">
      <header className="track-header">
        <a className="track-logo" href="/">
          <span>✦</span> Alma Chaab
        </a>
        <a className="track-home" href="/">
          ← Į svetainę
        </a>
      </header>
      <main className="account-main">
        <h1>Mano paskyra</h1>
        <p className="account-lead">Užsakymų sekimas, istorija ir greitas pakartojimas — vienoje paskyroje.</p>

        {loading ? (
          <p className="account-hint">Kraunama...</p>
        ) : !me ? (
          <>
            {trackMsg && (
              <div className="account-banner" role="status">
                {trackMsg}
              </div>
            )}
            {/* Tracking block at the VERY top of /mano (ex /sekti) — guests
                land on it first, login/register comes after. On wide screens
                tracker + login sit SIDE BY SIDE so a found order (status,
                timeline, items, payment) is fully visible without scrolling. */}
            <div className="account-guest-grid">
              <div className="account-guest-left">
                <div className="account-track-section">
                  <OrderTracker
                    initialNumber={trackNumber}
                    initialToken={trackToken}
                    phone={phone}
                    phoneDisplay={phoneDisplay}
                    facebookUrl={facebookUrl}
                    onPaid={onTrackerPaid}
                  />
                </div>
                <div className="account-register-pitch">
                  <strong>Sekite užsakymus be numerio</strong>
                  <small>Susikurkite paskyrą arba prisijunkite — užsakymų istorija visada po ranka.</small>
                </div>
              </div>
              <div className="account-guest-right">{loginCard}</div>
            </div>
          </>
        ) : (
          <>
            {trackMsg && (
              <div className="account-banner" role="status">
                {trackMsg}
              </div>
            )}
            {/* Tracking block at the VERY top for signed-in guests too —
                any order number can be checked without scrolling. */}
            <div className="account-track-section">
              <OrderTracker
                initialNumber={trackNumber}
                initialToken={trackToken}
                phone={phone}
                phoneDisplay={phoneDisplay}
                facebookUrl={facebookUrl}
                onPaid={onTrackerPaid}
              />
            </div>
            <div className="account-card account-profile">
              <div>
                <strong>Sveiki, {greeting}!</strong>
                <small>{me.email}</small>
              </div>
              <button onClick={logout}>Atsijungti</button>
            </div>

            {/* Linked sign-in methods — chips for connected providers,
                "Prijungti …" buttons for the ones still missing. */}
            {social && (social.google || social.facebook || social.telegram) && (
              <section className="account-methods" aria-label="Prisijungimo būdai">
                <div className="account-methods-head">
                  <strong>Prisijungimo būdai</strong>
                  <small>Susiekite — prisijungsite vienu paspaudimu.</small>
                </div>
                <div className="account-methods-row">
                  {social.google &&
                    (me.accounts?.includes("google") ? (
                      <span className="method-chip linked">
                        <GoogleIcon size={14} /> Google susietas ✓
                      </span>
                    ) : (
                      <button
                        type="button"
                        className="social-btn method-link-btn"
                        disabled={busy}
                        onClick={() =>
                          signIn("google", { callbackUrl: "/api/auth/social/bridge" }).catch(
                            () => setError("Nepavyko pradėti Google susiejimo.")
                          )
                        }
                      >
                        <GoogleIcon size={14} /> Prijungti Google
                      </button>
                    ))}
                  {social.facebook &&
                    (me.accounts?.includes("facebook") ? (
                      <span className="method-chip linked">
                        <FacebookIcon size={14} /> Facebook susietas ✓
                      </span>
                    ) : (
                      <button
                        type="button"
                        className="social-btn method-link-btn"
                        disabled={busy}
                        onClick={() =>
                          signIn("facebook", { callbackUrl: "/api/auth/social/bridge" }).catch(
                            () => setError("Nepavyko pradėti Facebook susiejimo.")
                          )
                        }
                      >
                        <FacebookIcon size={14} /> Prijungti Facebook
                      </button>
                    ))}
                  {social.telegram &&
                    (me.accounts?.includes("telegram") ? (
                      <span className="method-chip linked">
                        <TelegramIcon size={14} /> Telegram susietas ✓
                      </span>
                    ) : (
                      <button type="button" className="social-btn method-link-btn" disabled={busy} onClick={() => setShowTgLink((v) => !v)}>
                        <TelegramIcon size={14} /> Prijungti Telegram
                      </button>
                    ))}
                </div>
                {showTgLink && social.telegram && !me.accounts?.includes("telegram") && (
                  <div className="social-telegram">
                    <TelegramSlot bot={social.telegramBot} active={social.telegramBotActive !== false} onAuth={telegramCallback} />
                  </div>
                )}
                <p className="account-methods-note">
                  Google ir Facebook susiejami pagal el. paštą — naudokite tą patį, kuriuo prisiregistravote.
                  Telegram susiejamas su šia paskyra iškart.
                </p>
              </section>
            )}

            {loyalty?.enabled && (
              <section className="account-loyalty" aria-label="Lojalumo programa">
                <h2 className="account-h2">Lojalumo programa</h2>
                <div className="account-loyalty-grid">
                  <div className="account-points-card">
                    <div className="account-points-head">
                      <span className="account-points-value">{loyalty.profile?.points ?? 0}</span>
                      <span className="account-points-label">taškų</span>
                    </div>
                    <small>Viso uždirbta: {loyalty.profile?.lifetimePoints ?? 0} · už kiekvieną € — {loyalty.pointsPerEuro} taškas(-ai)</small>
                    <div className="account-stamps">
                      <span className="account-stamps-label">Stampų kortelė</span>
                      <div className="account-stamp-dots" role="img" aria-label={`${loyalty.profile?.stamps ?? 0} iš ${loyalty.stampGoal} stampų`}>
                        {Array.from({ length: loyalty.stampGoal }).map((_, i) => (
                          <span key={i} className={`account-stamp ${i < (loyalty.profile?.stamps ?? 0) ? "filled" : ""}`}>
                            ✦
                          </span>
                        ))}
                      </div>
                      <small>
                        {(loyalty.profile?.stamps ?? 0)} / {loyalty.stampGoal} — užsakymas su stampu kiekvieną kartą
                      </small>
                    </div>
                  </div>
                  <div className="account-rewards">
                    <span className="account-stamps-label">Keiskite taškus į prizus</span>
                    {loyalty.rewards.length === 0 ? (
                      <p className="account-hint">Prizai netrukus pasirodys čia.</p>
                    ) : (
                      <div className="account-reward-list">
                        {loyalty.rewards.map((r) => (
                          <div key={r.id} className={`account-reward ${r.affordable ? "" : "locked"}`}>
                            <div>
                              <strong>{r.name}</strong>
                              {r.description && <small>{r.description}</small>}
                            </div>
                            <button
                              className="account-redeem"
                              disabled={!r.affordable || redeeming === r.id}
                              onClick={() => redeem(r.id, r.name)}
                            >
                              {redeeming === r.id ? "..." : `${r.pointsCost} ✦`}
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    {redeemMsg && <div className="account-redeem-msg">{redeemMsg}</div>}
                  </div>
                </div>

                {loyalty.redemptions.length > 0 && (
                  <div className="account-vouchers">
                    <span className="account-stamps-label">Mano kuponas</span>
                    <div className="account-voucher-list">
                      {loyalty.redemptions.map((v) => (
                        <div key={v.id} className={`account-voucher ${v.status}`}>
                          <div>
                            <code>{v.code}</code>
                            <small>
                              {v.rewardName} · {v.pointsSpent} taškų ·{" "}
                              {v.status === "used" ? "panaudotas" : "galioja — parodykite atsiėmimo metu"}
                            </small>
                          </div>
                          <span className={`account-voucher-status ${v.status}`}>{v.status === "used" ? "✓" : "•"}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="account-push">
                  <div>
                    <strong>Pasiūlymų pranešimai</strong>
                    <small>Retkarčiais priminsime apie jūsų taškus ir naujus skonius. Jokių spam.</small>
                  </div>
                  <button className={`account-push-btn ${pushStatus?.subscribed ? "on" : ""}`} onClick={togglePush} disabled={pushStatus ? !pushStatus.supported : false}>
                    {pushStatus === null ? "..." : pushStatus.subscribed ? "Įjungta ✓ — išjungti" : pushStatus.supported ? "Įjungti" : "Nepalaikoma"}
                  </button>
                </div>
                {pushMsg && <div className="account-redeem-msg">{pushMsg}</div>}
              </section>
            )}

            <h2 className="account-h2">Užsakymų istorija</h2>
            {orders === null ? (
              <p className="account-hint">Kraunama...</p>
            ) : orders.length === 0 ? (
              <p className="account-hint">Kol kas neturite užsakymų. Rinkitės patiekalus meniu — jie atsiras čia.</p>
            ) : (
              <div className="account-orders">
                {orders.map((o) => (
                  <article key={o.number} className="account-order">
                    <div className="account-order-head">
                      <div>
                        <span className="account-order-label">{o.type === "pickup" ? "Atsiėmimas" : "Rezervacija"}</span>
                        <strong>#{o.number}</strong>
                      </div>
                      <div className="account-order-meta">
                        <span className={`track-status-badge ${o.status}`}>{o.statusLabel}</span>
                        {o.paymentStatus === "paid" && <span className="account-paid-badge">Apmokėta</span>}
                      </div>
                    </div>
                    <div className="account-order-when">
                      {o.type === "pickup"
                        ? `Atsiėmimas ${o.pickupTime || "— laiką patvirtinsime —"}`
                        : `${o.resDate} ${o.resTime} · ${o.guests} svečiai`}
                      {" · "}
                      {new Date(o.createdAt).toLocaleDateString("lt-LT", { day: "numeric", month: "long" })}
                      {o.locationName ? ` · ${o.locationName}` : ""}
                    </div>
                    {o.items.length > 0 && (
                      <div className="account-order-items">
                        {o.items.map((i, idx) => (
                          <span key={idx}>
                            {i.name} × {i.qty}
                          </span>
                        ))}
                      </div>
                    )}
                    {o.paymentStatus !== "paid" && o.total > 0 && o.status !== "cancelled" && (
                      o.paymentMethod || o.status === "awaiting" ? (
                        <PayLaterBox number={o.number} onPaid={() => void loadOrders()} />
                      ) : (
                        <div className="account-venue-note" role="note">
                          💰 {o.type === "pickup" ? "Apmokėsite atsiėmimo metu" : "Apmokėsite restorane"} — jokių išankstinių mokėjimų nereikia.
                        </div>
                      )
                    )}
                    <div className="account-order-foot">
                      {/* Table-only reservation — nothing to settle, no amount shown. */}
                      {o.total > 0 ? <b>{eur(o.total)}</b> : <b className="account-order-tableonly">Stalo rezervacija</b>}
                      {o.items.length > 0 && (
                        <button className="account-reorder" onClick={() => reorder(o)}>
                          ↻ Pakartoti užsakymą
                        </button>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </>
        )}
      </main>
      <footer className="track-footer">
        <span>
          Alma Chaab · Didžioji g. 25, Kėdainiai ·{" "}
          <a href={`tel:${phone}`}>
            <PhoneIcon size={12} /> {phoneDisplay}
          </a>
        </span>
        {facebookUrl && (
          <a className="track-footer-fb" href={facebookUrl} target="_blank" rel="noopener" aria-label="Alma Chaab Facebook puslapis">
            <FacebookIcon size={14} /> Facebook
          </a>
        )}
      </footer>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Telegram Login Widget — official script, rendered via ref container */
/* ------------------------------------------------------------------ */

declare global {
  interface Window {
    onTelegramAuth?: (user: TelegramWidgetUser) => void;
    turnstile?: {
      render: (el: HTMLElement, opts: Record<string, unknown>) => string;
      reset: (id?: string) => void;
      remove: (id: string) => void;
    };
  }
}

/* Brand icons (official colors) shared by the login buttons and method chips. */
function GoogleIcon({ size = 16 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="social-ico" width={size} height={size}>
      <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.2H12v4.1h6.5c-.1 1.1-.8 2.7-2.4 3.8l3.7 2.9c2.3-2.1 3.7-5.2 3.7-8.6z" />
      <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.7-2.9c-1 .7-2.4 1.2-4.2 1.2-3.2 0-5.9-2.1-6.8-5h-3.9v3c2 3.9 6 6.6 10.7 6.6z" />
      <path fill="#FBBC05" d="M5.2 14.4c-.2-.7-.4-1.5-.4-2.4s.2-1.7.4-2.4v-3h-3.9C.5 8.2 0 10 0 12s.5 3.8 1.3 5.4l3.9-3z" />
      <path fill="#EA4335" d="M12 4.7c1.8 0 3 .8 3.7 1.4l2.7-2.7C16.6 1.8 15.2 1 12 1 7.3 1 3.3 3.7 1.3 7.6l3.9 3c.9-2.9 3.6-5.9 6.8-5.9z" />
    </svg>
  );
}

function TelegramIcon({ size = 16 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="social-ico" width={size} height={size}>
      <path
        fill="#229ED9"
        d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"
      />
    </svg>
  );
}

/**
 * Telegram slot: real Login Widget when the bot is live (server-verified via
 * getMe), otherwise a calm branded placeholder instead of Telegram's raw
 * "Username invalid" error iframe.
 */
function TelegramSlot({ bot, active, onAuth }: { bot: string; active: boolean; onAuth: (u: TelegramWidgetUser) => void }) {
  if (!active) {
    return (
      <div className="tg-placeholder" role="status" aria-label="Telegram prisijungimas dar neaktyvuota">
        <TelegramIcon size={20} />
        <span>Telegram prisijungimas — dar neaktyvuota</span>
      </div>
    );
  }
  return <TelegramWidget bot={bot} onAuth={onAuth} />;
}

/* ---------------- Cloudflare Turnstile anti-bot widget ---------------- */

/**
 * Official Turnstile widget (explicit rendering). The script is injected once;
 * the token arrives via callback and is cleared on expire/error. Bumping
 * `resetKey` forces a fresh challenge (e.g. after a failed sign-in attempt —
 * tokens are single-use).
 */
function TurnstileWidget({ siteKey, onToken, resetKey }: { siteKey: string; onToken: (t: string) => void; resetKey: number }) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const widgetIdRef = useRef<string | null>(null);
  const onTokenRef = useRef(onToken);

  useEffect(() => {
    onTokenRef.current = onToken;
  }, [onToken]);

  useEffect(() => {
    if (!siteKey || !hostRef.current) return;
    const host = hostRef.current;
    let cancelled = false;

    const render = () => {
      if (cancelled || !host || !window.turnstile) return;
      host.innerHTML = "";
      const box = document.createElement("div");
      host.appendChild(box);
      widgetIdRef.current = window.turnstile.render(box, {
        sitekey: siteKey,
        theme: "light",
        callback: (t: string) => onTokenRef.current(t),
        "expired-callback": () => onTokenRef.current(""),
        "error-callback": () => onTokenRef.current(""),
      });
    };

    if (window.turnstile) {
      render();
    } else {
      // Load api.js once; queue renders until it is ready.
      const w = window as typeof window & { __almaTsQueue?: (() => void)[] };
      w.__almaTsQueue = w.__almaTsQueue || [];
      w.__almaTsQueue.push(render);
      if (!document.querySelector('script[src^="https://challenges.cloudflare.com/turnstile"]')) {
        const s = document.createElement("script");
        s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
        s.async = true;
        s.defer = true;
        s.onload = () => {
          (w.__almaTsQueue || []).forEach((fn) => fn());
          w.__almaTsQueue = [];
        };
        document.head.appendChild(s);
      }
    }

    return () => {
      cancelled = true;
      if (widgetIdRef.current && window.turnstile) {
        try {
          window.turnstile.remove(widgetIdRef.current);
        } catch {
          /* widget already gone */
        }
        widgetIdRef.current = null;
      }
    };
  }, [siteKey]);

  useEffect(() => {
    if (resetKey > 0 && window.turnstile && widgetIdRef.current) {
      try {
        window.turnstile.reset(widgetIdRef.current);
      } catch {
        /* noop */
      }
      onTokenRef.current("");
    }
  }, [resetKey]);

  return <div ref={hostRef} className="turnstile-host" aria-label="Cloudflare patikra" />;
}

/* ---------------- Password reveal icons ---------------- */

function EyeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
      <line x1="1" y1="1" x2="23" y2="23" />
    </svg>
  );
}

function TelegramWidget({ bot, onAuth }: { bot: string; onAuth: (u: TelegramWidgetUser) => void }) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  // Keep the widget stable across renders: the callback lives in a ref,
  // so the Telegram script is only (re)created when the bot changes.
  const onAuthRef = useRef(onAuth);
  useEffect(() => {
    onAuthRef.current = onAuth;
  }, [onAuth]);

  useEffect(() => {
    if (!bot || !hostRef.current) return;
    const w = window as Window & { onTelegramAuth?: (u: TelegramWidgetUser) => void };

    w.onTelegramAuth = (user) => {
      onAuthRef.current(user);
    };

    const host = hostRef.current;
    host.innerHTML = "";
    const s = document.createElement("script");
    s.src = "https://telegram.org/js/telegram-widget.js?22";
    s.async = true;
    s.setAttribute("data-telegram-login", bot);
    s.setAttribute("data-size", "medium");
    s.setAttribute("data-radius", "10");
    s.setAttribute("data-onauth", "onTelegramAuth(user)");
    s.setAttribute("data-request-access", "write");
    host.appendChild(s);

    return () => {
      if (w.onTelegramAuth) delete w.onTelegramAuth;
    };
  }, [bot]);

  return <div ref={hostRef} className="telegram-widget-host" aria-label="Prisijungti per Telegram" />;
}
