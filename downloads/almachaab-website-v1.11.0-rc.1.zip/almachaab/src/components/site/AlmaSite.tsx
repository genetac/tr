"use client";

import { Fragment,useCallback, useEffect, useRef, useState } from "react";
import { c, eur, type SiteData } from "./helpers";
import { ManagedPublicSections, VisitorInformation, Header, Hero, Proof, About, Ribbon, Social, Hub, SkoniaiPanel, DegustacijosPanel, EventsPanel, GalleryPanel, Wolt, Contacts, Footer } from "./sections";
// MenuBrowser & Checkout stay statically imported on purpose:
// 1) they are lean (no heavy deps) and render the server-provided menu into
//    the initial HTML (dish names are indexable content for local SEO);
// 2) the heavy client module (KitchenApp — polling/audio/timers) IS
//    code-split via next/dynamic in AdminApp (Skydelis tab).
import { MenuBrowser, type FlowMode } from "./MenuBrowser";
import { Checkout } from "./Checkout";
import { CookieConsent } from "./CookieConsent";

interface Props {
  data: SiteData;
  rating: { mode: string; score: number; count: number; note: string };
  /** Server-rendered SEO copy + FAQ section injected from page.tsx. */
  seoSlot?: React.ReactNode;
}

/**
 * Scroll to the booking block: the "Jūsų stalas" card itself (#rezervacija),
 * not the section intro text above it (on desktop the intro is a sticky
 * column beside the card, so it stays visible).
 * The section may still be expanding when this runs, so we wait two frames,
 * scroll, and correct once more after the smooth scroll settles.
 */
function scrollToBooking() {
  // Same target the checkout itself scrolls to on mode changes, so the two
  // never race each other (desktop used to stop with the card under the header).
  const target = () => document.getElementById("rezervacija") || document.getElementById("meniu");
  // Scroll the window directly: the booking area clips overflow on phones,
  // and scrollIntoView would align that inner box instead of honouring the
  // element's scroll-margin (it landed under the fixed header).
  const go = (smooth: boolean) => {
    const el = target();
    if (!el) return;
    const margin = parseFloat(getComputedStyle(el).scrollMarginTop) || 0;
    const top = el.getBoundingClientRect().top + window.scrollY - margin;
    window.scrollTo({ top: Math.max(0, top), behavior: smooth ? "smooth" : "auto" });
  };
  setTimeout(() => requestAnimationFrame(() => requestAnimationFrame(() => go(true))), 40);
  setTimeout(() => {
    const el = target();
    if (!el) return;
    const margin = parseFloat(getComputedStyle(el).scrollMarginTop) || 0;
    if (Math.abs(el.getBoundingClientRect().top - margin) > 24) go(false);
  }, 900);
}

export function AlmaSite({ data, rating, seoSlot }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [mode, setMode] = useState<FlowMode>("choose");
  const [cart, setCartState] = useState<Record<string, number>>({});
  const [panel, setPanel] = useState<string | null>(null);
  const [billiardsSignal, setBilliardsSignal] = useState(0);
  const [toast, setToast] = useState("");
  // True while the final checkout (order review + payment wall) is on
  // screen — the sticky intro column steps aside so the pay wall gets the
  // full width and every payment button is reachable without scrolling.
  const [finalStage, setFinalStage] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const onToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2400);
  }, []);

  const setCart = useCallback((next: Record<string, number>) => setCartState(next), []);
  const clearCart = useCallback(() => setCartState({}), []);
  // One-tap add used by checkout upsell cards (recommender already filters 86'd items server-side).
  const addCartItem = useCallback(
    (id: string) => setCartState((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 })),
    []
  );

  // Pressing "Meniu ir rezervacija" (header, hero, about, footer, mobile bar)
  // ALWAYS lands on the one unified block — the reservation form whose FIRST
  // section is the v1 experience composer (Staliukas / Šventė / Degustacija /
  // Biliardas scene cards). The menu stays minimized until the guest chooses
  // "Pasirinkti patiekalus", so no press ever exposes the old menu-browser
  // view with its "Grįžti į rezervaciją" return bar.
  const goMenu = useCallback(() => {
    setMenuOpen(true);
    setMode("reserve-form");
    setPanel(null);
    scrollToBooking();
  }, []);

  // Desktop split layout: while the unified reservation block (composer /
  // gateway / checkout) is what's shown, the section intro (eyebrow, heading,
  // subtitle, collapse button) sits BESIDE it as a sticky left column —
  // everything in one view. When the dish browser unfolds (menu-reserve /
  // menu-pickup) the section returns to the full-width stacked layout.

  const openPanel = useCallback((id: string) => {
    setPanel(id);
    setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }, []);

  const goAbout = useCallback(() => {
    document.getElementById("apie")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const bookBilliards = useCallback(() => {
    setPanel(null);
    setMenuOpen(true);
    setMode("reserve-form");
    setBilliardsSignal((n) => n + 1);
    scrollToBooking();
  }, []);

  // Mobile quick action bar labels
  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const cartTotal = Object.entries(cart).reduce((sum, [id, qty]) => {
    const dish = data.categories.flatMap((cat) => cat.items).find((d) => d.id === id);
    return sum + (dish ? dish.price * qty : 0);
  }, 0);
  // Pickup ordering flow (menu browser or its checkout form) — the mobile
  // bottom bar must speak cart, not reservations (Task 36-a).
  const isPickupFlow = mode === "menu-pickup" || mode === "pickup-form";

  // Stripe return: legacy links may still land here with ?paid=AC-xxxx or
  // ?cancelled=… — the checkout now returns to /mano, so forward them on.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paid = params.get("paid");
    const cancelled = params.get("cancelled");
    if (!paid && !cancelled) return;
    const target = paid ? `mano?paid=${encodeURIComponent(paid)}` : `mano?cancelled=${encodeURIComponent(cancelled!)}`;
    window.location.replace(target);
  }, []);

  // Quick reorder: /mano writes the previous cart to localStorage and links here
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem("alma_reorder");
    } catch {
      return;
    }
    if (!saved) return;
    const t = setTimeout(() => {
      try {
        localStorage.removeItem("alma_reorder");
        const items = JSON.parse(saved) as Record<string, number>;
        const valid: Record<string, number> = {};
        for (const [id, qty] of Object.entries(items)) {
          const dish = data.categories.flatMap((c) => c.items).find((d) => d.id === id);
          if (dish && dish.inStock !== false && qty > 0) valid[id] = Math.min(50, Math.floor(qty));
        }
        if (Object.keys(valid).length > 0) {
          setCart(valid);
          setMenuOpen(true);
          setMode("menu-pickup");
          onToast("Patiekalai pridėti iš ankstesnio užsakymo ✓");
          setTimeout(() => document.getElementById("meniu")?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
        }
      } catch {
        /* malformed payload — ignore */
      }
    }, 0);
    return () => clearTimeout(t);
  }, []);

  const sectionProps = { data, rating, onGoMenu: goMenu, onGoAbout: goAbout, onOpenPanel: openPanel, onBilliards: bookBilliards };

  const booking = (<section
          className={`section white menu-collapsible${menuOpen && !finalStage && mode !== "menu-reserve" && mode !== "menu-pickup" ? " menu-split" : ""}${finalStage ? " menu-final" : ""}`}
          id="meniu"
        >
          <div className="shell">
            <div className="menu-intro-col">
              <p className="eyebrow">{c(data.settings.content, "menuIntro.eyebrow", "Meniu ir rezervacija")}</p>
              <h2>{c(data.settings.content, "menuIntro.title", "Vienoje vietoje — meniu, išankstinis pasirinkimas ir staliukas.")}</h2>
              <p className="menu-section-sub">{c(data.settings.content, "menuIntro.sub", "")}</p>
              {/* Entry CTA renders only while the section is closed — once the
                  composer is open there is no "Suskleisti" button; the section
                  stays open and every "Meniu ir rezervacija" press re-lands on
                  the unified composer. */}
              {!menuOpen && (
                <button
                  className="menu-expand-btn"
                  id="menuExpandBtn"
                  type="button"
                  aria-expanded={false}
                  aria-controls="menuExpandableContent"
                  onClick={() => goMenu()}
                >
                  <span id="menuExpandLabel">Rodyti meniu ir rezervaciją</span>
                  <span className="menu-expand-icon" aria-hidden="true">⌄</span>
                </button>
              )}
            </div>

            <div className="menu-expandable-content" id="menuExpandableContent" hidden={!menuOpen}>
              {mode === "choose" && (
                <div className="flow-gateway" id="flowGateway">
                  <button className="flow-choice flow-choice-menu" id="flowMenuBtn" type="button" onClick={() => setMode("menu-reserve")}>
                    <span className="flow-choice-icon">🍽</span>
                    <span className="flow-choice-copy">
                      <strong>Staliuko rezervacija su išankstiniu pasirinkimu</strong>
                      <small>Persirinkite patiekalus iš meniu ir rezervuokite stalelį.</small>
                    </span>
                    <span className="flow-choice-arrow">→</span>
                  </button>
                  <button className="flow-choice flow-choice-reservation" id="flowReservationBtn" type="button" onClick={() => setMode("reserve-form")}>
                    <span className="flow-choice-icon">📋</span>
                    <span className="flow-choice-copy">
                      <strong>Tiesiog rezervuoti stalelį</strong>
                      <small>Be išankstinio maisto pasirinkimo.</small>
                    </span>
                    <span className="flow-choice-arrow">→</span>
                  </button>
                  {data.settings.pickup.enabled && (
                    <button className="flow-choice flow-choice-pickup" id="flowPickupBtn" type="button" onClick={() => setMode("menu-pickup")}>
                      <span className="flow-choice-icon">🥡</span>
                      <span className="flow-choice-copy">
                        <strong>Užsisakyti atsiėmimui restorane</strong>
                        <small>Be staliuko rezervacijos — atsiimkite be laukimo.</small>
                      </span>
                      <span className="flow-choice-arrow">→</span>
                    </button>
                  )}
                </div>
              )}

              <MenuBrowser data={data} menuOpen={menuOpen} mode={mode} setMode={setMode} cart={cart} setCart={setCart} onToast={onToast} />
              <Checkout
                data={data}
                mode={mode}
                setMode={setMode}
                cart={cart}
                setCart={setCart}
                clearCart={clearCart}
                onToast={onToast}
                billiardsSignal={billiardsSignal}
                onAddItem={addCartItem}
                onFinalStage={setFinalStage}
              />
            </div>
          </div>
        </section>

);
  const sections:Record<string,React.ReactNode>={
    hero:data.settings.content.visibility?.hero!==false&&<Hero {...sectionProps}/>,
    proof:data.settings.content.visibility?.proof!==false&&<Proof {...sectionProps}/>,
    about:data.settings.content.visibility?.about!==false&&<About {...sectionProps}/>,
    ribbon:<Ribbon {...sectionProps}/>,
    social:data.settings.content.visibility?.social!==false&&<Social {...sectionProps}/>,
    menu:booking,
    hub:data.settings.content.visibility?.hub!==false&&<Hub {...sectionProps}/>,
    wolt:data.settings.content.visibility?.wolt!==false&&<Wolt {...sectionProps}/>,
    contacts:<Contacts {...sectionProps}/>,
    custom:<ManagedPublicSections data={data}/>,
    visitor:data.settings.content.visibility?.visitor!==false&&<VisitorInformation data={data}/>,
    seo:seoSlot,
  };
  const configured:string[]=data.settings.content.sectionOrder||[];
  const order=[...new Set([...configured.filter(key=>Object.hasOwn(sections,key)),...Object.keys(sections)])];
  return (
    <div className="alma-root">
      <Header {...sectionProps} />
      <main>{order.filter(key=>data.settings.content.visibility?.[key]!==false).map(key=><Fragment key={key}>{sections[key]}</Fragment>)}
        {panel === "skoniai" && <SkoniaiPanel {...sectionProps} onClose={() => setPanel(null)} />}
        {panel === "degustacijos" && <DegustacijosPanel {...sectionProps} onClose={() => setPanel(null)} />}
        {panel === "renginiai" && <EventsPanel {...sectionProps} onClose={() => setPanel(null)} onBilliards={bookBilliards} />}
        {panel === "galerija" && <GalleryPanel {...sectionProps} onClose={() => setPanel(null)} />}
      </main>
      <Footer {...sectionProps} />

      <div className={`mobile-quick-actions mobile-conversion-bar ${menuOpen && (mode === "menu-reserve" || mode === "menu-pickup") ? "menu-mode" : ""}`} aria-label="Greiti veiksmai telefone">
        <button
          className="mobile-order-summary"
          id="mobileCartQuickBtn"
          type="button"
          onClick={() => {
            setMenuOpen(true);
            if (mode === "choose" || mode === "done") setMode("reserve-form");
            scrollToBooking();
          }}
        >
          <span className="mobile-order-copy">
            <strong id="mobileCartLead">{cartCount > 0 ? `${cartCount} patiekalai pasirinkti` : "🍽 Rinktis patiekalus"}</strong>
            <small id="mobileCartHint">{cartCount > 0 ? "Tęsti užsakymą" : "Atidaryti meniu"}</small>
          </span>
          <span className="mobile-order-total" id="mobileCartTotal">{cartCount > 0 ? eur(cartTotal) : ""}</span>
        </button>
        <button
          className="mobile-reserve-cta"
          id="mobileReserveQuickBtn"
          type="button"
          onClick={() => {
            // In the pickup flow the CTA stays in that flow — cart / dish
            // browser — instead of resetting to the reservation composer.
            if (isPickupFlow) {
              setMode("menu-pickup");
              setTimeout(() => document.getElementById("meniu")?.scrollIntoView({ behavior: "smooth" }), 40);
              return;
            }
            goMenu();
          }}
        >
          <span id="mobileReserveLabel">
            {isPickupFlow ? (cartCount > 0 ? `Krepšelis (${cartCount})` : "Užsisakyti atsiėmimui") : "Rezervuoti stalą"}
          </span>
          <b>→</b>
        </button>
      </div>

      {/* Slapukų sutikimo juosta (Consent Mode v2) — fiksuota apačioje, žemiau modalų.
          Rodyta tik kai svetainėje įjungta analitika (D1): be jos naudojami tik
          būtini slapukai ir sutikimo prašyti nereikia. */}
      <CookieConsent enabled={data.settings.analyticsEnabled === true} />

      <div className={`toast ${toast ? "show" : ""}`} id="toast" role="status" aria-live="polite">
        {toast || "Atlikta"}
      </div>
    </div>
  );
}
