export function visualStyle(content:any,path:string){return content?.visualStyles?.[path]||{};}
export function EditText({content,path,fallback}:{content:any;path:string;fallback:string}){
 let value=content;for(const part of path.split('.'))value=value?.[part];
 const style=visualStyle(content,path);
 return <span data-cms-path={path} style={{...style,...(style.textAlign?{display:'block'}:{})}}>{typeof value==='string'?value:fallback}</span>;
}
