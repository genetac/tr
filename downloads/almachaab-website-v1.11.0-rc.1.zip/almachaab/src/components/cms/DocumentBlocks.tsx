import ReactMarkdown from 'react-markdown';import {sanitizeInlineHtml} from '@/lib/sanitize';import {safeContentUrl} from '@/lib/content-management';import {visitorInfo,VISITOR_LABELS} from '@/lib/visitor';import {peopleInfo} from '@/lib/business-content';import type {DocumentBlock} from '@/lib/document-blocks';
export function DocumentBlocks({blocks,settings,selected,onSelect}:{blocks:DocumentBlock[];settings:any;selected?:string;onSelect?:(id:string)=>void}){
 const info=visitorInfo(settings.content);const people=peopleInfo(settings.content);
 return <div className="cms-document-body">{blocks.filter(b=>b.visible!==false).map((b,i)=>{
  const id=b.id||`legacy-${i}`;const style={color:b.color,backgroundColor:b.background,textAlign:b.align,whiteSpace:undefined} as React.CSSProperties;
  let node;
  if(b.t==='img')node=<figure><img src={b.url} alt={b.alt||''} loading="lazy"/><figcaption>{b.caption}</figcaption></figure>;
  else if(b.t==='md')node=<ReactMarkdown urlTransform={u=>safeContentUrl(u)?u:''}>{b.text||''}</ReactMarkdown>;
  else if(b.t==='h')node=<h2>{b.text}</h2>;
  else if(b.t==='q')node=<blockquote>{b.text}</blockquote>;
  else if(b.t==='ul')node=<ul>{b.items?.map((text,j)=><li key={j}>{text}</li>)}</ul>;
  else if(b.t==='button')node=<a className="btn btn-gold" href={safeContentUrl(b.url||'')?b.url:undefined}>{b.text}</a>;
  else if(b.t==='visitor')node=<div className="visitor-grid">{Object.entries(VISITOR_LABELS).map(([key,label])=><article key={key}><h3>{label}</h3><p>{info[key as keyof typeof info]}</p></article>)}</div>;
  else if(b.t==='people')node=<div className="visitor-grid">{people.map(person=><article key={person.id}>{person.image&&<img src={person.image} alt={person.name}/>}<h3>{person.name}</h3><p>{person.role}</p><p>{person.bio}</p></article>)}</div>;
  else if(b.t==='business')node=<address><p>{settings.site.name}</p><p>{settings.site.address}</p><a href={`tel:${settings.site.phone}`}>{settings.site.phoneDisplay}</a><br/><a href={`mailto:${settings.site.email}`}>{settings.site.email}</a>{Object.entries(settings.hours).map(([day,hours]:any)=><p key={day}>{({mon:'Pirmadienis',tue:'Antradienis',wed:'Trečiadienis',thu:'Ketvirtadienis',fri:'Penktadienis',sat:'Šeštadienis',sun:'Sekmadienis'}as any)[day]}: {hours?`${hours[0]}:00–${hours[1]}:00`:'Nedirbame'}</p>)}</address>;
  else node=/<[a-z]/i.test(b.text||'')?<p style={{whiteSpace:'pre-wrap'}} dangerouslySetInnerHTML={{__html:sanitizeInlineHtml(b.text||'')}}/>:<ReactMarkdown urlTransform={u=>safeContentUrl(u)?u:''}>{b.text||''}</ReactMarkdown>;
  return <div key={id} data-block-id={id} className={`cms-public-block ${b.width==='wide'?'cms-wide':''} ${onSelect?'cms-selectable':''} ${selected===id?'cms-selected':''}`} style={style} role={onSelect?"button":undefined} tabIndex={onSelect?0:undefined} aria-label={onSelect?`Pasirinkti bloką: ${b.t}`:undefined} onKeyDown={onSelect?(e)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(id);}}:undefined} onClick={onSelect?(e)=>{e.preventDefault();e.stopPropagation();onSelect(id);}:undefined}>{node}</div>;
 })}</div>;
}
