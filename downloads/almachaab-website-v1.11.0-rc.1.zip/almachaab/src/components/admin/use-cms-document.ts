'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {api} from './ui';
export function useCmsDocument(key:string){
 const [value,setValue]=useState<any>(null),[revision,setRevision]=useState(0),[dirty,setDirty]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState(''),[history,setHistory]=useState<any[]>([]);
 const valueRef=useRef<any>(null),revisionRef=useRef(0),busyRef=useRef(false),blocked=useRef(false),undoRef=useRef<any[]>([]),redoRef=useRef<any[]>([]);
 const load=useCallback(async()=>{try{const r=await api<any>(`/api/admin/cms?key=${encodeURIComponent(key)}`);valueRef.current=r.draft;setValue(r.draft);revisionRef.current=r.revision;setRevision(r.revision);setDirty(false);blocked.current=false;setError('');setMessage(r.pending?'Yra nepaskelbtas juodraštis.':'Rodoma paskelbta versija.');undoRef.current=[];redoRef.current=[];}catch(e:any){setError(e.message);}},[key]);
 useEffect(()=>{void load();},[load]);
 const edit=useCallback((next:any)=>{const resolved=typeof next==='function'?next(valueRef.current):next;undoRef.current=[...undoRef.current.slice(-59),valueRef.current];redoRef.current=[];valueRef.current=resolved;setValue(resolved);setDirty(true);setMessage('Yra neišsaugotų pakeitimų.');},[]);
 const save=useCallback(async(mode:'draft'|'publish'='draft',restore?:string)=>{
  if(busyRef.current)return;busyRef.current=true;setBusy(true);setError('');const snapshot=valueRef.current;
  try{
   const r=await api<any>('/api/admin/cms',{method:'PUT',body:JSON.stringify({key,value:snapshot,revision:revisionRef.current,mode,restore})});
   revisionRef.current=r.revision;setRevision(r.revision);
   if(restore||valueRef.current===snapshot){valueRef.current=r.draft;setValue(r.draft);setDirty(false);}
   blocked.current=false;setMessage(restore?'Ankstesnė versija atkurta kaip juodraštis.':mode==='publish'?'Paskelbta.':'Juodraštis išsaugotas.');
  }catch(e:any){blocked.current=true;setError(e.message);}finally{busyRef.current=false;setBusy(false);}
 },[key]);
 useEffect(()=>{if(!dirty||busy||blocked.current)return;const t=setTimeout(()=>{void save('draft');},1800);return()=>clearTimeout(t);},[value,dirty,busy,save]);
 useEffect(()=>{const before=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};const nav=(e:Event)=>{if(dirty&&!confirm('Yra neišsaugotų pakeitimų. Išeiti?'))e.preventDefault();};window.addEventListener('beforeunload',before);window.addEventListener('admin-before-navigate',nav);return()=>{window.removeEventListener('beforeunload',before);window.removeEventListener('admin-before-navigate',nav);};},[dirty]);
 const undo=()=>{const previous=undoRef.current.pop();if(previous){redoRef.current.push(valueRef.current);valueRef.current=previous;setValue(previous);setDirty(true);}};
 const redo=()=>{const next=redoRef.current.pop();if(next){undoRef.current.push(valueRef.current);valueRef.current=next;setValue(next);setDirty(true);}};
 const versions=async()=>{try{const r=await api<any>(`/api/admin/cms?key=${encodeURIComponent(key)}&history=1`);setHistory(r.history||[]);}catch(e:any){setError(e.message);}};
 return {value,edit,revision,dirty,busy,message,error,save,load,history,versions,undo,redo};
}
export type CmsEditorState=ReturnType<typeof useCmsDocument>;
