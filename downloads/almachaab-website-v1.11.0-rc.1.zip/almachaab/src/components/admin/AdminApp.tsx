"use client";

import { useCallback, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { api, getToken, setToken } from "./ui";
import {ContentAreaTab} from "./ContentAreaTab";
import {DocumentList} from "./DocumentEditor";
import {VisualSiteEditor} from "./VisualSiteEditor";
import {BusinessTab} from "./BusinessTab";
import {StaffTab,HelpTab,MyAccountTab} from "./StaffHelpTabs";
import {MediaTab} from "./MediaTab";
import {LoyaltyTab,CrmTab} from "./EnterpriseTabs";
import { OrdersTab } from "./OrdersTab";
import { MenuTab } from "./MenuTab";
import { ContentTab } from "./ContentTab";
import { ThemeTab } from "./ThemeTab";
import { SettingsTab } from "./SettingsTab";
import { ArticlesTab } from "./ArticlesTab";
import { AdminLogin } from "./AdminLogin";
import { enablePush } from "./push-client";

// Kitchen display is code-split: its chunk (WebAudio ring, wake lock, timers)
// loads only when the "Skydelis" tab is opened.
const KitchenApp = dynamic(() => import("./KitchenApp"), {
  ssr: false,
  loading: () => <p style={{ padding: 24, color: "#8a7f6d" }}>Kraunamas virtuvės skydelis…</p>,
});

interface Overview {
  stats: {
    unread: number;
    activeCount: number;
    todayCount: number;
    upcomingReservations: number;
    openPickups: number;
    revenueToday: number;
  };
  latest: {
    id: string;
    number: string;
    type: string;
    status: string;
    statusLabel: string;
    customerName: string;
    total: number;
    when: string;
    isRead: boolean;
    createdAt: string;
  }[];
}

const TABS = [
  { id: "overview", label: "Pradžia", icon: "◉" },
  { id: "orders", label: "Užsakymai", icon: "🥡" },
  { id: "reservations", label: "Rezervacijos", icon: "📋" },
  { id: "kitchen", label: "Skydelis", icon: "🔥" },
  { id: "menu", label: "Meniu", icon: "🍽" },
  { id: "pages", label: "Puslapiai", icon: "▤" },
  { id: "visual", label: "Vaizdinis redaktorius", icon: "✎" },
  { id: "content", label: "Išplėstinis turinys", icon: "▦" },
  { id: "business", label: "Bendra informacija", icon: "ⓘ" },
  { id: "media", label: "Mediateka", icon: "▧" },
  { id: "events", label: "Renginiai", icon: "▦" },
  { id: "navigation", label: "Navigacija", icon: "☰" },
  { id: "theme", label: "Išvaizda", icon: "◐" },
  { id: "articles", label: "Straipsniai", icon: "📰" },
  { id: "loyalty", label: "Klientai ir lojalumas", icon: "♡" },
  { id: "staff", label: "Darbuotojai", icon: "♙" },
  { id: "help", label: "Pagalba", icon: "?" },
  { id: "account", label: "Mano paskyra", icon: "♙" },
  { id: "settings", label: "Nustatymai", icon: "⚙" },
];

/**
 * Client-side gate: the server renders `initialAuthed` from the cookie, but in
 * cookie-blocked contexts (preview iframes) we re-check via the localStorage
 * token before falling back to the login screen.
 */
export function AdminGate({ initialAuthed, initialMustChange=false }: { initialAuthed: boolean; initialMustChange?:boolean }) {
  const [state, setState] = useState<"checking" | "in" | "out" | "must-change">(
    initialMustChange ? "must-change" : initialAuthed ? "in" : "checking"
  );

  useEffect(() => {
    if (state !== "checking") return;
    let alive = true;
    // Deferred: avoids synchronous setState within the effect body.
    const t = setTimeout(() => {
      const tok = getToken();
      // Plain fetch on purpose: api() reloads the page on 401, which would loop here.
      fetch("/api/admin/session", { headers: tok?{ "x-admin-token": tok }:{} })
        .then((r) => (r.ok ? r.json() : { authenticated: false }))
        .then((r: { authenticated: boolean; mustChangePassword?: boolean }) => {
          if (!alive) return;
          if (r.mustChangePassword) setState("must-change");
          else setState(r.authenticated ? "in" : "out");
        })
        .catch(() => alive && setState("out"));
    }, 0);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [state]);

  if (state === "in") return <AdminApp />;
  if (state === "must-change") return <ForcedPasswordChange onDone={() => setState("checking")} />;
  if (state === "checking") {
    return (
      <div className="adm-login-wrap">
        <p className="adm-hint">Jungiamasi...</p>
      </div>
    );
  }
  return <AdminLogin />;
}

/** Shown while the factory default password is still in use — blocks the panel. */
function ForcedPasswordChange({ onDone }: { onDone: () => void }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (next.length < 12) {
      setError("Naujas slaptažodis per trumpas (min. 12 simbolių).");
      return;
    }
    if (next !== confirm) {
      setError("Slaptažodžiai nesutampa.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: "password", current, next }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(json.error || "Klaida");
        return;
      }
      onDone();
    } catch {
      setError("Serverio klaida");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="adm-login-wrap">
      <form className="adm-login" onSubmit={submit}>
        <div className="adm-login-brand">
          <span>✦</span>
          <strong>Alma Chaab</strong>
          <small>Saugumas</small>
        </div>
        <p className="adm-hint">
          Naudojamas numatytasis slaptažodis. Nustatykite naują — kitos valdymo funkcijos atsidarys po pakeitimo.
        </p>
        <label>
          <span>Dabartinis slaptažodis</span>
          <input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
        </label>
        <label>
          <span>Naujas slaptažodis</span>
          <input type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
        </label>
        <label>
          <span>Pakartokite naują slaptažodį</span>
          <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
        </label>
        {error && <div className="adm-login-error">{error}</div>}
        <button type="submit" disabled={busy || !current || !next}>
          {busy ? "Išsaugoma..." : "Nustatyti naują slaptažodį"}
        </button>
      </form>
    </div>
  );
}

export function AdminApp() {
  const [tab, setTab] = useState("overview");
  const [profile,setProfile]=useState<any>(null);
  useEffect(()=>{api<any>('/api/admin/session').then(p=>{setProfile(p);const requested=new URLSearchParams(window.location.search).get('tab');const allowed=(id:string)=>p.role==='owner'||['help','account'].includes(id)||(p.role==='kitchen'?['kitchen','orders','reservations'].includes(id):['pages','visual','content','media','menu','articles','theme','events','navigation','business'].includes(id)&&id!=='business');setTab(requested&&allowed(requested)?requested:p.role==='kitchen'?'kitchen':p.role==='editor'?'pages':'overview');});},[]);
  const [overview, setOverview] = useState<Overview | null>(null);

  const loadOverview = useCallback(async () => {
    try {
      const r = await api<Overview>("/api/admin/overview");
      setOverview(r);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (tab === "overview" && profile?.role === "owner") {
      const t0 = setTimeout(loadOverview, 0);
      const t = setInterval(loadOverview, 20000);
      return () => {
        clearTimeout(t0);
        clearInterval(t);
      };
    }
  }, [tab, loadOverview, profile]);

  // PWA service worker registration
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);


  async function logout() {
    setToken("");
    await api("/api/admin/logout", { method: "POST" });
    window.location.reload();
  }

  if(!profile)return <p className="adm-hint">Kraunamos paskyros teisės…</p>;
  const allowedTabs=TABS.filter(t=>profile.role==='owner'||['help','account'].includes(t.id)||(profile.role==='kitchen'?['kitchen','orders','reservations'].includes(t.id):['pages','visual','content','media','menu','articles','theme','events','navigation'].includes(t.id)));
  return (
    <div className="adm-root">
      <header className="adm-header">
        <div className="adm-brand">
          <span className="adm-brand-mark">✦</span>
          <div>
            <strong>Alma Chaab</strong>
            <small>Valdymo sistema</small>
          </div>
        </div>
        <div className="adm-header-actions">
          <a href="/" target="_blank" rel="noopener" className="adm-header-link">
            Svetainė ↗
          </a>
          <button onClick={logout}>Atsijungti</button>
        </div>
      </header>

      <nav className="adm-nav" aria-label="Administravimo skiltys">
        {allowedTabs.map((t) => (
          <button key={t.id} className={tab === t.id ? "active" : ""} onClick={() => { if (window.dispatchEvent(new Event("admin-before-navigate", { cancelable: true }))) setTab(t.id); }}>
            <span className="adm-nav-icon">{t.icon}</span>
            {t.label}
            {t.id === "orders" && overview && overview.stats.unread > 0 && <b className="adm-nav-badge">{overview.stats.unread}</b>}
          </button>
        ))}
      </nav>

      {profile.role!=="editor"&&<PushBanner />}

      <main className="adm-main">
        {tab === "overview" && <OverviewTab overview={overview} onGo={setTab} />}
        {tab === "orders" && <OrdersTab type="pickup" />}
        {tab === "reservations" && <OrdersTab type="reservation" />}
        {tab === "kitchen" && <KitchenApp embedded />}
        {tab === "menu" && <MenuTab />}
        {tab === "pages" && <DocumentList kind="page" onHome={()=>setTab("visual")} />}
        {tab === "visual" && <VisualSiteEditor />}
        {tab === "content" && <ContentTab />}
        {tab === "business" && <BusinessTab />}
        {tab === "media" && <MediaTab />}
        {tab === "events" && <ContentAreaTab area="events"/>}
        {tab === "navigation" && <ContentAreaTab area="navigation"/>}
        {tab === "staff" && <StaffTab />}
        {tab === "help" && <HelpTab />}
        {tab === "account" && <MyAccountTab owner={profile.role==='owner'}/>}
        {tab === "loyalty" && <div className="adm-tab"><p className="adm-note">Bandomoji programa: prieš įjungdami sutarkite taisykles, atlygius ir sutikimus. Reklaminių laiškų siuntimas turi būti patikrintas atskirai.</p><LoyaltyTab/><CrmTab/></div>}
        {tab === "theme" && <ThemeTab />}
        {tab === "articles" && <ArticlesTab />}
        {tab === "settings" && <SettingsTab />}
      </main>

      <footer className="adm-footer">Alma Chaab admin · PWA: meniu „Įtraukti į pradžios ekraną“ — sistema veiks kaip programa</footer>
    </div>
  );
}

/**
 * One-tap banner: shown until the owner has granted (or blocked) notification
 * permission in this browser. Once granted, setup lives in Nustatymai → Pranešimai.
 */
function PushBanner() {
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const t = setTimeout(() => {
      if ("Notification" in window && Notification.permission === "default") setVisible(true);
    }, 1200); // wait a beat so the permission prompt never fights the first paint
    return () => clearTimeout(t);
  }, []);

  if (!visible) return null;

  async function onEnable() {
    setBusy(true);
    const r = await enablePush();
    setMsg(r.ok ? "" : r.error || "Klaida");
    if (r.ok) setVisible(false);
    setBusy(false);
  }

  return (
    <div className="adm-note adm-push-banner" style={{ margin: "0 0 4px", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
      <span>🔔 Įjunkite pranešimus — gaukite naujus užsakymus iškart kaip įspėjimą ekrane.</span>
      <button className="primary" disabled={busy} onClick={onEnable}>
        {busy ? "..." : "Įjungti"}
      </button>
      <button onClick={() => setVisible(false)}>Ne dabar</button>
      {msg && <small style={{ width: "100%" }}>{msg}</small>}
    </div>
  );
}

function OverviewTab({ overview, onGo }: { overview: Overview | null; onGo: (t: string) => void }) {
  const s = overview?.stats;
  return (
    <div className="adm-tab">
      <div className="adm-stats">
        <button className="adm-stat accent" onClick={() => onGo("orders")}>
          <b>{s?.unread ?? "—"}</b>
          <span>Nauji / neperskaityti</span>
        </button>
        <button className="adm-stat" onClick={() => onGo("orders")}>
          <b>{s?.openPickups ?? "—"}</b>
          <span>Vykstantys užsakymai</span>
        </button>
        <button className="adm-stat" onClick={() => onGo("reservations")}>
          <b>{s?.upcomingReservations ?? "—"}</b>
          <span>Rezervacijos</span>
        </button>
        <button className="adm-stat" onClick={() => onGo("orders")}>
          <b>{s?.todayCount ?? "—"}</b>
          <span>Šiandien iš viso</span>
        </button>
      </div>

      <div className="adm-card">
        <div className="adm-card-head">
          <h3>Paskutiniai įrašai</h3>
        </div>
        {!overview ? (
          <p className="adm-hint">Kraunama...</p>
        ) : overview.latest.length === 0 ? (
          <p className="adm-hint">Kol kas nėra užsakymų ar rezervacijų.</p>
        ) : (
          <div className="adm-list">
            {overview.latest.map((o) => (
              <div key={o.id} className={`adm-row static ${o.isRead ? "" : "unread"}`}>
                <div className="adm-row-top">
                  <strong>#{o.number}</strong>
                  <span className={`badge st-${o.status}`}>{o.statusLabel}</span>
                </div>
                <div className="adm-row-mid">
                  <span>{o.customerName}</span>
                  <b>{o.total > 0 ? o.total.toFixed(2).replace(".", ",") + " €" : ""}</b>
                </div>
                <div className="adm-row-sub">
                  {o.type === "pickup" ? "Atsiėmimas" : "Rezervacija"} · {o.when}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="adm-card">
        <div className="adm-card-head">
          <h3>Telefonu naudojimasis</h3>
        </div>
        <p className="adm-hint">
          Šį puslapį galite įsidėti kaip programėlę: <b>iPhone</b> — Safari → Pasidalinti → „Į pradžios ekraną“; <b>Android</b> — Chrome → meniu → „Įdiegti
          programėlę“. Sistema atsidarys be naršyklės juostų, kaip programa, ir rodys naujų užsakymų skaičių prie ikonos puslapyje.
        </p>
      </div>
    </div>
  );
}
