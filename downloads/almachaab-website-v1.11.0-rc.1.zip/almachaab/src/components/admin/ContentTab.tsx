"use client";

import { ManagedContentEditor } from "./ManagedContentEditor";
import { DEFAULT_NAVIGATION } from "@/lib/content-management";
import { useEffect, useState } from "react";
import { VISITOR_DEFAULTS, VISITOR_LABELS } from "@/lib/visitor";
import { api, Field, ImagePicker, Card } from "./ui";

 
type Content = any;

function getPath(obj: any, p: any): any {
  const path = typeof p === "string" ? p : String(p ?? "");
  if (typeof p !== "string") {
    console.warn("[ContentTab] getPath received non-string path:", p, new Error().stack);
  }
  let cur = obj;
  for (const part of path.split(".")) {
    if (cur == null) return undefined;
    cur = cur[part];
  }
  return cur;
}
function setPath(obj: any, path: string, value: any): any {
  const keys = path.split(".");
  const clone: any = Array.isArray(obj) ? [...obj] : { ...obj };
  let cur = clone;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    cur[k] = Array.isArray(cur[k]) ? [...cur[k]] : { ...cur[k] };
    cur = cur[k];
  }
  cur[keys[keys.length - 1]] = value;
  return clone;
}

export function ContentTab() {
  const [content, setContent] = useState<Content>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [revision, setRevision] = useState(0);
  const [dirty, setDirty] = useState(false);
  const [message, setMessage] = useState('');
  const [loadError, setLoadError] = useState('');
  useEffect(() => {
    const before = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };
    const navigate = (e: Event) => { if (dirty && !confirm('Yra neišsaugotų pakeitimų. Išeiti?')) e.preventDefault(); };
    window.addEventListener('beforeunload', before);
    window.addEventListener('admin-before-navigate', navigate);
    return () => { window.removeEventListener('beforeunload', before); window.removeEventListener('admin-before-navigate', navigate); };
  }, [dirty]);

  useEffect(() => {
    api<{ content: Content; revision: number; draftExists: boolean }>("/api/admin/content")
      .then((r) => {
        setContent({ ...r.content, navigation: r.content?.navigation || DEFAULT_NAVIGATION, visitor: { ...VISITOR_DEFAULTS, ...r.content?.visitor } });
        setRevision(r.revision);
        setMessage(r.draftExists ? "Yra nepaskelbtas juodraštis." : "Rodomas paskelbtas turinys.");
        setLoaded(true);
      })
      .catch(() => { setLoadError("Nepavyko įkelti turinio. Perkraukite puslapį."); setLoaded(true); });
  }, []);

  function upd(path: string, value: any) {
    setContent((c: Content) => setPath(c, path, value));
    setSaved(false);
    setDirty(true);
  }

  function T(path: string, label: string, multiline = false, hint?: string) {
    const value = getPath(content, path) ?? "";
    return (
      <Field label={label} hint={hint}>
        {multiline ? (
          <textarea rows={3} value={value} onChange={(e) => upd(path, e.target.value)} />
        ) : (
          <input value={value} onChange={(e) => upd(path, e.target.value)} />
        )}
      </Field>
    );
  }

  function IMG(path: string, label: string) {
    return <ImagePicker label={label} value={getPath(content, path) || ""} onChange={(v) => upd(path, v)} />;
  }

  // Render helpers (called as functions, not components — keeps input focus while typing).
  function ListEditor({ path, label, fields, blank }: { path: string; label: string; fields: { key: string; label: string; type?: "text" | "image" }[]; blank: Record<string, unknown> }) {
    const list: any[] = getPath(content, path) || [];
    return (
      <Card title={`${label} (${list.length})`}>
        <div className="adm-list">
          {list.map((row, i) => (
            <div key={i} className="adm-listrow">
              <div className="adm-listrow-fields">
                {fields.map((f) =>
                  f.type === "image" ? (
                    <ImagePicker key={f.key} label={f.label} value={row[f.key] || ""} onChange={(v) => upd(`${path}.${i}.${f.key}`, v)} />
                  ) : (
                    <Field key={f.key} label={f.label}>
                      <input value={row[f.key] ?? ""} onChange={(e) => upd(`${path}.${i}.${f.key}`, e.target.value)} />
                    </Field>
                  )
                )}
              </div>
              <div className="adm-listrow-actions">
                <button
                  disabled={i === 0}
                  onClick={() => {
                    const copy = [...list];
                    [copy[i - 1], copy[i]] = [copy[i], copy[i - 1]];
                    upd(path, copy);
                  }}
                >
                  ↑
                </button>
                <button
                  disabled={i === list.length - 1}
                  onClick={() => {
                    const copy = [...list];
                    [copy[i + 1], copy[i]] = [copy[i], copy[i + 1]];
                    upd(path, copy);
                  }}
                >
                  ↓
                </button>
                <button
                  className="danger"
                  onClick={() => { if (confirm("Pašalinti šį įrašą?")) upd(path, list.filter((_, j) => j !== i)); }}
                >
                  Šalinti
                </button>
              </div>
            </div>
          ))}
        </div>
        <button className="ghost" onClick={() => upd(path, [...list, { ...blank }])}>
          ＋ Pridėti
        </button>
      </Card>
    );
  }

  function StrList({ path, label, hint }: { path: string; label: string; hint?: string }) {
    const list: string[] = getPath(content, path) || [];
    return (
      <Field label={label} hint={hint}>
        <textarea
          rows={3}
          value={list.join("\n")}
          onChange={(e) => upd(path, e.target.value.split("\n").filter((x) => x.trim() !== ""))}
        />
      </Field>
    );
  }

  async function save(mode: "draft" | "publish" = "draft") {
    setSaving(true);
    try {
      const result = await api<{ revision: number }>("/api/admin/content", { method: "PUT", body: JSON.stringify({ content, mode, revision }) });
      setRevision(result.revision);
      setDirty(false);
      setMessage(mode === "publish" ? "Turinys paskelbtas." : "Juodraštis išsaugotas. Svetainėje dar nerodomas.");
      setSaved(true);
    } catch (e) {
      alert(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  if (loadError) return <p role="alert">{loadError}</p>;
  if (!loaded) return <p className="adm-hint">Kraunama...</p>;

  return (
    <div className="adm-tab">
      <div className="adm-savebar">
        <span role="status">{dirty ? "Yra neišsaugotų pakeitimų" : saved ? `✓ ${message}` : message}</span>
        <button className="primary" onClick={() => save("draft")} disabled={saving}>
          {saving ? "Išsaugoma..." : "Išsaugoti juodraštį"}
        </button>
      </div>

        <a href="/?preview=1" target="_blank" rel="noopener">Peržiūrėti išsaugotą juodraštį ↗</a>
        <button className="primary" disabled={saving} onClick={() => save('publish')}>Paskelbti pakeitimus</button>
        <p className="adm-hint">Prieš peržiūrą išsaugokite juodraštį. Peržiūrai reikalingas prisijungimas šiame naršyklės lange.</p>
      <ManagedContentEditor content={content} update={upd} />
      <Card title="Informacija lankytojams ir paslaugos">
        <p className="adm-hint">Patvirtinta informacija. Pakeitimai po išsaugojimo rodomi svetainėje ir atitinkamuose DUK atsakymuose.</p>
        {Object.entries(VISITOR_LABELS).map(([key, label]) => <div key={key}>{T(`visitor.${key}`, label, true)}</div>)}
      </Card>
      <Card title="Pagrindinė antraštė">
        {T("hero.mark", "Viršutinis užrašas")}
        {T("hero.titleLines.0", "Antraštės 1 eilutė")}
        {T("hero.titleLines.1", "Antraštės 2 eilutė")}
        {T("hero.titleLines.2", "Antraštės 3 eilutė")}
        {T("hero.lead", "Pagrindinis aprašymas", true)}
        {T("hero.mainCta", "Pagrindinis mygtukas")}
        {T("hero.woltCta", "Wolt mygtuko tekstas")}
        {T("hero.serviceNote", "Pastaba po mygtukais", true)}
        {IMG("hero.image", "Hero fono nuotrauka")}
      </Card>

      <Card title="Apie mus (SEO skiltis)">
        {T("about.title", "Antraštė", true)}
        {T("about.paragraphs.0", "1 pastraipa", true)}
        {T("about.paragraphs.1", "2 pastraipa", true)}
        {T("about.paragraphs.2", "3 pastraipa", true)}
        {T("about.cta", "Mygtuko tekstas")}
        {IMG("about.image", "Nuotrauka")}
        {T("about.caption1", "Nuotraukos antraštė (viršus)")}
        {T("about.caption2", "Nuotraukos antraštė (apačia)")}
      </Card>

      {ListEditor({ path: "about.stats", label: "Skaitmenys (faktai)", fields: [{ key: "n", label: "Skaičius" }, { key: "label", label: "Aprašymas" }], blank: { n: "0", label: "" } })}
      {ListEditor({ path: "ribbon", label: "Nuotraukų juosta", fields: [{ key: "src", label: "Nuotrauka", type: "image" }, { key: "caption", label: "Antraštė" }, { key: "alt", label: "Alternatyvus tekstas" }], blank: { src: "", caption: "", alt: "" } })}
      {ListEditor({ path: "proof.items", label: "Faktų juosta po hero", fields: [{ key: "title", label: "Pavadinimas" }, { key: "sub", label: "Aprašymas" }], blank: { title: "", sub: "" } })}

      <Card title="Atsiliepimų skiltis">
        {T("social.eyebrow", "Minisėjos tekstas")}
        {T("social.title", "Antraštė")}
        {T("social.quote", "Citata", true)}
        {T("social.note", "Pastaba")}
        {T("social.mapsLink", "Nuoroda į Google Maps (tekstas)")}
        {T("social.scoreNote", "Tekstas po įvertinimu", true)}
      </Card>

      <Card title="Meniu skilties įvadas">
        {T("menuIntro.eyebrow", "Minisėjos tekstas")}
        {T("menuIntro.title", "Antraštė", true)}
        {T("menuIntro.sub", "Aprašymas", true)}
      </Card>

      <Card title="Pasirinkimo būdai (rezervacija / atsiėmimas)">
        {T("flow.reserveTitle", "Rezervacijos kortelės pavadinimas")}
        {T("flow.reserveSub", "Rezervacijos kortelės aprašymas")}
        {T("flow.pickupTitle", "Atsiėmimo kortelės pavadinimas")}
        {T("flow.pickupSub", "Atsiėmimo kortelės aprašymas")}
        {T("flow.preorderHint", "Krepšelio užrašas")}
      </Card>

      <Card title="Rezervacijos / atsiėmimo patvirtinimai">
        {T("reservation.successTitle", "Rezervacijos patvirtinimo antraštė")}
        {T("reservation.successSub", "Rezervacijos patvirtinimo aprašymas")}
        {T("pickup.successTitle", "Užsakymo patvirtinimo antraštė")}
        {T("pickup.successSub", "Užsakymo patvirtinimo aprašymas")}
      </Card>

      <Card title="Atraskite daugiau (suskleistos skiltys)">
        {T("hub.eyebrow", "Minisėjos tekstas")}
        {T("hub.title", "Antraštė")}
        {T("hub.sub", "Aprašymas", true)}
      </Card>
      {ListEditor({ path: "hub.cards", label: "Skilčių kortelės", fields: [
          { key: "icon", label: "Ikona (emoji)" },
          { key: "title", label: "Pavadinimas" },
          { key: "sub", label: "Aprašymas" },
        ], blank: { id: `x${Date.now()}`, icon: "✦", title: "", sub: "" } })}

      <Card title="Mūsų skoniai (skiltis)">
        {T("skoniai.eyebrow", "Minisėjos tekstas")}
        {T("skoniai.title", "Antraštė")}
        {T("skoniai.link", "Nuorodos tekstas")}
      </Card>
      {ListEditor({ path: "skoniai.features", label: "Skonio kortelės", fields: [{ key: "img", label: "Nuotrauka", type: "image" }, { key: "title", label: "Pavadinimas" }, { key: "text", label: "Aprašymas" }, { key: "price", label: "Kaina" }], blank: { img: "", title: "", text: "", price: "" } })}

      <Card title="Istorija / degustacijos (skiltis)">
        {T("degustacijos.eyebrow", "Minisėjos tekstas")}
        {T("degustacijos.title", "Antraštė")}
        {T("degustacijos.intro", "Aprašymas", true)}
        {IMG("degustacijos.image", "Nuotrauka")}
      </Card>

      <Card title="Šventės ir renginiai (skiltis)">
        {T("events.eyebrow", "Minisėjos tekstas")}
        {T("events.title", "Antraštė")}
        {T("events.intro", "Aprašymas", true)}
        <p className="adm-hint">Biliardo pasiūlymas redaguojamas žemiau. Išjungus arba pasibaigus „Galioja iki“ datai, blokas svetainėje automatiškai paslepiamas.</p>
        <Field label="Rodyti biliardo pasiūlymą svetainėje">
          <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={getPath(content, "events.billiards.enabled") !== false}
              onChange={(e) => upd("events.billiards.enabled", e.target.checked)}
            />
            <span>{getPath(content, "events.billiards.enabled") !== false ? "Rodomas" : "Paslėptas"}</span>
          </label>
        </Field>
        <Field label="Galioja iki (neprivaloma)" hint="Pvz. akcijos pabaiga. Po šios dienos blokas pasislėps pats. Palikite tuščią, jei pasiūlymas nuolatinis.">
          <input
            type="date"
            value={getPath(content, "events.billiards.validUntil") || ""}
            onChange={(e) => upd("events.billiards.validUntil", e.target.value)}
          />
        </Field>
        {T("events.billiards.kicker", "Biliardas: antraštės viršus")}
        {T("events.billiards.title", "Biliardas: antraštė")}
        {T("events.billiards.text", "Biliardas: aprašymas", true)}
        {([['studentPrice', 'Moksleiviams ir studentams (€/val.)'], ['adultPrice', 'Suaugusiesiems (€/val.)']] as const).map(([key, label]) => <Field key={key} label={label}><input type="number" min="0" max="10000" step="0.01" value={getPath(content, `events.billiards.${key}`) ?? (key === 'studentPrice' ? 5 : 10)} onChange={e => upd(`events.billiards.${key}`, Number(e.target.value))} /></Field>)}
        <Field label="Žaisti galima iki"><input type="time" value={getPath(content, 'events.billiards.cutoff') || '20:00'} onChange={e => upd('events.billiards.cutoff', e.target.value)} /></Field>
        {T("events.billiards.cta", "Mygtuko tekstas")}
        <p className="adm-hint">Kainos ir laikas rezervacijos formoje atnaujinami automatiškai.</p>
      </Card>
      {StrList({ path: "events.billiards.meta", label: "Biliardo metainformacija (viena eilutė = vienas įrašas)" })}

      <Card title="Straipsnių autorius">
        <p className="adm-hint">Rodomas po kiekvieno straipsnio antrašte ir Google duomenyse. Nurodykite tik tikrą žmogų, kuris rengia ar peržiūri straipsnius. Palikus tuščią vardą, autoriumi rodomas restoranas.</p>
        {T("articles.authorName", "Vardas ir pavardė")}
        {T("articles.authorRole", "Pareigos")}
      </Card>

      <Card title="Galerija (skiltis)">
        {T("gallery.eyebrow", "Minisėjos tekstas")}
        {T("gallery.title", "Antraštė")}
      </Card>
      {ListEditor({ path: "gallery.images", label: "Galerijos nuotraukos", fields: [{ key: "src", label: "Nuotrauka", type: "image" }, { key: "caption", label: "Antraštė" }, { key: "alt", label: "Alternatyvus tekstas" }], blank: { src: "", caption: "", alt: "" } })}

      <Card title="Wolt skiltis">
        {T("wolt.badge", "Ženkliukas")}
        {T("wolt.eyebrow", "Minisėjos tekstas")}
        {T("wolt.title", "Antraštė")}
        {T("wolt.text", "Aprašymas", true)}
      </Card>

      <Card title="Kontaktai ir poraštė">
        {T("contacts.eyebrow", "Minisėjos tekstas")}
        {T("contacts.title", "Antraštė")}
        {T("contacts.reservationLink", "Nuorodos tekstas")}
        {T("footer.about", "Poraštės aprašymas", true)}
        {T("footer.copyright", "Poraštės eilutė")}
      </Card>

      <div className="adm-savebar">
        <span>{saved ? "✓ Išsaugota" : ""}</span>
        <button className="primary" onClick={() => save("draft")} disabled={saving}>
          {saving ? "Išsaugoma..." : "Išsaugoti juodraštį"}
        </button>
      </div>
    </div>
  );
}
