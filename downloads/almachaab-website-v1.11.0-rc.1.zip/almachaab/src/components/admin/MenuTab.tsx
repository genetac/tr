"use client";

import { useCallback, useEffect, useState } from "react";
import { DietaryRow,DietaryDisplaySettings } from "./DietaryRow";
import {useCmsDocument} from "./use-cms-document";
import {DraftToolbar} from "./DraftToolbar";
import { api, Field, ImagePicker, Switch } from "./ui";
import { useLoadEffect, useClientValue } from "@/hooks/use-load-effect";

interface Item {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  image: string;
  active: boolean;
  inStock: boolean;
  stockCount: number | null;
  sortOrder: number;
  vegetarian: boolean;
  vegan: boolean;
  halal: boolean;
  dietaryNotes: string;
}
interface Category {
  id: string;
  name: string;
  active: boolean;
  sortOrder: number;
  items: Item[];
}

export function MenuTab() {
  const layoutState=useCmsDocument("menu-layout");
  const [cats, setCats] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Item | null>(null);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [search,setSearch]=useState("");
  const [dietaryOpen,setDietaryOpen]=useState<string|null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api<{ categories: Category[] }>("/api/admin/menu");
      setCats(r.categories);
    } finally {
      setLoading(false);
    }
  }, []);

  useLoadEffect(load);

  async function action(body: Record<string, unknown>) {
    await api("/api/admin/menu", { method: "PATCH", body: JSON.stringify(body) });
    load();
    layoutState.load();
  }

  async function addItem(cat: Category) {
    const name = prompt("Naujo patiekalo pavadinimas:");
    if (!name) return;
    const price = Number(prompt("Kaina (€):", "0") || 0);
    await api("/api/admin/menu", { method: "POST", body: JSON.stringify({ action: "createItem", categoryId: cat.id, name, price }) });
    load();
    layoutState.load();
  }

  async function addCategory() {
    const name = prompt("Naujos kategorijos pavadinimas:");
    if (!name) return;
    await api("/api/admin/menu", { method: "POST", body: JSON.stringify({ action: "createCategory", name }) });
    load();
    layoutState.load();
  }

  async function del(kind: "category" | "item", id: string, name: string) {
    if (!confirm(`Ištrinti „${name}“?`)) return;
    await api(`/api/admin/menu?kind=${kind}&id=${id}`, { method: "DELETE" });
    load();
    layoutState.load();
  }

  // Instant "86" — grey the dish out on the guest menu without opening the editor
  async function toggleStock(item: Item) {
    await action({ action: "inventory", id: item.id, inStock: !item.inStock });
  }

  async function moveItem(cat: Category, item: Item, dir: -1 | 1) {
    const siblings = cat.items;
    const idx = siblings.findIndex((x) => x.id === item.id);
    const other = siblings[idx + dir];
    if (!other) return;
    await action({ action: "moveItem", idA: item.id, idB: other.id });
  }

  async function moveCat(cat: Category, dir: -1 | 1) {
    const idx = cats.findIndex((x) => x.id === cat.id);
    const other = cats[idx + dir];
    if (!other) return;
    await action({ action: "moveCategory", idA: cat.id, idB: other.id });
  }

  if (loading && cats.length === 0) return <p className="adm-hint">Kraunama...</p>;

  return (
    <div className="adm-tab"><DietaryDisplaySettings/><DraftToolbar state={layoutState}/><p className="adm-hint">Viršutinė juosta skelbia kategorijų pavadinimus ir tvarką. Patiekalai ir jų mitybos informacija turi atskirus juodraščius.</p>
      <div className="adm-toolbar">
        <Field label="Rasti patiekalą pagal meniu pavadinimą"><input type="search" value={search} onChange={e=>setSearch(e.target.value)} /></Field>
        <button className="primary" onClick={addCategory}>＋ Nauja kategorija</button>
      </div>
      {cats.map((cat, ci) => (
        <div key={cat.id} className="adm-card">
          <div className="adm-card-head">
            <h3>{cat.name}</h3>
            <div className="adm-rowbtns">
              <button title="Aukštyn" onClick={() => moveCat(cat, -1)} disabled={ci === 0}>↑</button>
              <button title="Žemyn" onClick={() => moveCat(cat, 1)} disabled={ci === cats.length - 1}>↓</button>
              <button onClick={() => setEditingCat(cat)}>Pervadinti</button>
              <button className="danger" onClick={() => del("category", cat.id, cat.name)}>Ištrinti</button>
            </div>
          </div>
          <div className="adm-list">
            {cat.items.filter(item=>item.name.toLocaleLowerCase("lt").includes(search.toLocaleLowerCase("lt"))).map((item, ii) => {
              const outOfStock = !item.inStock || item.stockCount === 0;
              return (
              <div key={item.id}><div className={`adm-menuitem ${item.active ? "" : "inactive"} ${outOfStock ? "out-of-stock" : ""}`}>
                <div className="adm-menuitem-thumb">
                  {item.image ? (
                     
                    <img src={item.image} alt="" />
                  ) : (
                    <span>{item.name.slice(0, 2).toUpperCase()}</span>
                  )}
                </div>
                <div className="adm-menuitem-info">
                  <strong>{item.name}</strong>
                  <span>
                    {item.price.toFixed(2).replace(".", ",")} €{" "}
                    {outOfStock && <em className="adm-soldout-badge">Išparduota</em>}
                    {item.inStock && item.stockCount !== null && item.stockCount > 0 && <em className="adm-stockcount">· liko {item.stockCount}</em>}
                    {item.description ? ` · ${item.description.slice(0, 60)}` : ""}
                  </span>
                </div>
                <div className="adm-rowbtns">
                  <button title="Aukštyn" onClick={() => moveItem(cat, item, -1)} disabled={ii === 0}>↑</button>
                  <button title="Žemyn" onClick={() => moveItem(cat, item, 1)} disabled={ii === cat.items.length - 1}>↓</button>
                  <button
                    className={outOfStock ? "" : "warn"}
                    title={outOfStock ? "Grąžinti į pardavimą" : "Pažymėti kaip išparduotą (86)"}
                    onClick={() => toggleStock(item)}
                  >
                    {outOfStock ? "Paduoti" : "86"}
                  </button>
                  <button onClick={() => action({ action: "updateItem", id: item.id, active: !item.active })}>{item.active ? "Paslėpti" : "Rodyti"}</button>
                  <button onClick={()=>setDietaryOpen(dietaryOpen===item.id?null:item.id)} aria-expanded={dietaryOpen===item.id}>Mitybos informacija</button>
                  <button className="primary" onClick={() => setEditing(item)}>Keisti</button>
                  <button className="danger" onClick={() => del("item", item.id, item.name)}>×</button>
                </div>
              </div>
              {dietaryOpen===item.id&&<DietaryRow id={item.id} name={item.name} />}
              </div>
              );
            })}
          </div>
          <button className="ghost" onClick={() => addItem(cat)}>＋ Pridėti patiekalą</button>
        </div>
      ))}

      {editing && <ItemDialog item={editing} onClose={() => setEditing(null)} onSaved={load} />}
      {editingCat && (
        <div className="adm-dialog-backdrop" onClick={() => setEditingCat(null)}>
          <div className="adm-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="adm-dialog-head">
              <h4>Kategorijos pavadinimas</h4>
              <button onClick={() => setEditingCat(null)}>×</button>
            </div>
            <Field label="Pavadinimas">
              <input
                defaultValue={editingCat.name}
                onChange={(e) => setEditingCat({ ...editingCat, name: e.target.value })}
              />
            </Field>
            <button
              className="primary"
              onClick={async () => {
                await action({ action: "updateCategory", id: editingCat.id, name: editingCat.name });
                setEditingCat(null);
              }}
            >
              Išsaugoti
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ItemDialog({item,onClose,onSaved}:{item:Item;onClose:()=>void;onSaved:()=>void}){
 const s=useCmsDocument(`menu:${item.id}`);const v=s.value;
 const set=(key:string,value:any)=>s.edit({...v,[key]:value});
 return <div className="adm-dialog-backdrop"><div className="adm-dialog" role="dialog" aria-modal="true" aria-label="Patiekalo redagavimas"><div className="adm-dialog-head"><h4>{item.name}</h4><button onClick={()=>{if(!s.dirty||confirm('Yra neišsaugotų pakeitimų. Uždaryti?')){onSaved();onClose();}}}>Uždaryti</button></div>{v?<>
 <Field label="Pavadinimas"><input value={v.name} onChange={e=>set('name',e.target.value)} /></Field>
 <Field label="Kaina (€)"><input type="number" min="0" max="10000" step="0.01" value={v.price} onChange={e=>set('price',Number(e.target.value))} /></Field>
 <Field label="Aprašymas"><textarea value={v.description} onChange={e=>set('description',e.target.value)} /></Field>
 <ImagePicker label="Patiekalo nuotrauka" value={v.image} onChange={value=>set('image',value)} />
 <label><input type="checkbox" checked={v.active} onChange={e=>set('active',e.target.checked)} /> Rodyti patiekalą meniu</label>
 <p className="adm-hint">Mitybos informaciją galite tvarkyti tiesiai prie patiekalo meniu sąraše.</p><DraftToolbar state={s} />
 </>:<p>{s.error||'Kraunama…'}</p>}</div></div>;
}
