"use client";

import { api } from "./ui";

// Browser-side Web Push helper: request permission, subscribe this device,
// store the subscription server-side. Used by the admin notification setup.

function urlB64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

export interface PushStatus {
  supported: boolean;
  permission: NotificationPermission | "unknown";
  subscribed: boolean;
  deviceCount?: number;
}

export async function getPushStatus(): Promise<PushStatus> {
  const supported =
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    "Notification" in window;
  if (!supported) return { supported: false, permission: "unknown", subscribed: false };
  const permission = Notification.permission;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = reg ? await reg.pushManager.getSubscription() : null;
    let deviceCount: number | undefined;
    if (sub) {
      try {
        const r = await api<{ count: number }>("/api/admin/push");
        deviceCount = r.count;
      } catch {
        /* not critical */
      }
    }
    return { supported: true, permission, subscribed: !!sub, deviceCount };
  } catch {
    return { supported: true, permission, subscribed: false };
  }
}

export async function enablePush(): Promise<{ ok: boolean; error?: string }> {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
    return { ok: false, error: "Ši naršyklė nepalaiko push pranešimų. Naudokite Chrome, Edge arba Safari (iOS 16.4+)." };
  }
  const perm = await Notification.requestPermission();
  if (perm !== "granted") {
    return { ok: false, error: "Leidimas nesuteiktas. Leiskite pranešimus per naršyklės adreso juostos piktogramą ir bandykite dar kartą." };
  }
  // Wait until the service worker is active (AdminApp registers it on mount)
  const reg = await navigator.serviceWorker.ready;
  const { publicKey } = await api<{ publicKey: string }>("/api/admin/push");
  let sub = await reg.pushManager.getSubscription();
  if (!sub) {
    sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlB64ToUint8Array(publicKey),
    });
  }
  await api("/api/admin/push", { method: "POST", body: JSON.stringify({ subscription: sub.toJSON() }) });
  return { ok: true };
}

export async function testPush(): Promise<void> {
  await api("/api/admin/push/test", { method: "POST" });
}

export async function disablePush(): Promise<void> {
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = reg ? await reg.pushManager.getSubscription() : null;
    if (sub) {
      await api("/api/admin/push", { method: "DELETE", body: JSON.stringify({ endpoint: sub.endpoint }) });
      await sub.unsubscribe();
    }
  } catch {
    /* best effort */
  }
}

/* ------------------------------------------------------------------ */
/* Customer (marketing / loyalty) push — /mano page, /api/me/push       */
/* ------------------------------------------------------------------ */

async function ensureServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!("serviceWorker" in navigator)) return null;
  try {
    let reg = await navigator.serviceWorker.getRegistration();
    if (!reg) reg = await navigator.serviceWorker.register("/sw.js");
    await navigator.serviceWorker.ready;
    return reg || null;
  } catch {
    return null;
  }
}

export async function getCustomerPushStatus(endpoint?: string): Promise<PushStatus> {
  const supported =
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    "Notification" in window;
  if (!supported) return { supported: false, permission: "unknown", subscribed: false };
  const permission = Notification.permission;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = reg ? await reg.pushManager.getSubscription() : null;
    if (!sub) return { supported: true, permission, subscribed: false };
    // Confirm the server still knows this device for THIS account.
    const r = await fetch(`/api/me/push?endpoint=${encodeURIComponent(sub.endpoint)}`, { cache: "no-store" });
    if (!r.ok) return { supported: true, permission, subscribed: false };
    const j = (await r.json()) as { subscribed?: boolean };
    return { supported: true, permission, subscribed: Boolean(j.subscribed) };
  } catch {
    return { supported: true, permission, subscribed: false };
  }
}

export async function enableCustomerPush(): Promise<{ ok: boolean; error?: string }> {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
    return { ok: false, error: "Ši naršyklė nepalaiko push pranešimų. Naudokite Chrome, Edge arba Safari (iOS 16.4+)." };
  }
  const perm = await Notification.requestPermission();
  if (perm !== "granted") {
    return { ok: false, error: "Leidimas nesuteiktas. Leiskite pranešimus per naršyklės adreso juostos piktogramą." };
  }
  const reg = await ensureServiceWorker();
  if (!reg) return { ok: false, error: "Nepavyko paruošti pranešimų serviso." };
  const keyRes = await fetch("/api/me/push", { cache: "no-store" });
  if (!keyRes.ok) return { ok: false, error: "Prisijunkite, kad įjungtumėte pranešimus." };
  const { publicKey } = (await keyRes.json()) as { publicKey: string };
  let sub = await reg.pushManager.getSubscription();
  if (!sub) {
    sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlB64ToUint8Array(publicKey),
    });
  }
  const saveRes = await fetch("/api/me/push", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ subscription: sub.toJSON() }),
  });
  if (!saveRes.ok) return { ok: false, error: "Nepavyko išsaugoti prenumeratos — bandykite dar kartą." };
  return { ok: true };
}

export async function disableCustomerPush(): Promise<void> {
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = reg ? await reg.pushManager.getSubscription() : null;
    if (sub) {
      await fetch("/api/me/push", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: sub.endpoint }),
      }).catch(() => {});
      await sub.unsubscribe().catch(() => {});
    }
  } catch {
    /* best effort */
  }
}
