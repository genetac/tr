"use client";
import {SettingDocument} from "./BusinessTab";

import { useCallback, useEffect, useState } from "react";
import { api, Field, Card, Switch } from "./ui";
import {
  DEFAULT_TEMPLATES,
  EMAIL_TEMPLATE_KEYS,
  EMAIL_TEMPLATE_LABELS,
  TEMPLATE_PLACEHOLDERS,
  mergeTemplate,
  type EmailTemplate,
  type EmailTemplateKey,
} from "@/lib/email-templates";
import { enablePush, testPush, disablePush, getPushStatus, type PushStatus } from "./push-client";
import { LocationsTab, LoyaltyTab, CrmTab } from "./EnterpriseTabs";
import { useLoadEffect, useClientValue } from "@/hooks/use-load-effect";

 

const DAYS = [
  { key: "mon", label: "Pirmadienis" },
  { key: "tue", label: "Antradienis" },
  { key: "wed", label: "Trečiadienis" },
  { key: "thu", label: "Ketvirtadienis" },
  { key: "fri", label: "Penktadienis" },
  { key: "sat", label: "Šeštadienis" },
  { key: "sun", label: "Sekmadienis" },
];

export function SettingsTab() {
  const [settings, setSettings] = useState<any>(null);
  const [tab, setTab] = useState("site");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [msg, setMsg] = useState("");
  const [loadErr, setLoadErr] = useState("");

  const load = useCallback(() => {
    setLoadErr("");
    api<{ settings: any }>("/api/admin/settings")
      .then((r) => setSettings(r.settings))
      .catch((e) => setLoadErr(e instanceof Error ? e.message : "Klaida"));
  }, []);
  useLoadEffect(load);

  if (!settings) {
    return loadErr ? (
      <div className="adm-tab">
        <div className="adm-note">Nepavyko įkelti nustatymų: {loadErr}</div>
        <button className="primary" onClick={load}>
          Bandyti dar kartą
        </button>
      </div>
    ) : (
      <p className="adm-hint">Kraunama...</p>
    );
  }

  function updFn(key: string) {
    return (path: string, value: any) => {
      setSettings((s: any) => {
        const copy = { ...s };
        const keys = path.split(".");
        let cur = copy[key];
        for (let i = 0; i < keys.length - 1; i++) cur = cur[keys[i]] = { ...cur[keys[i]] };
        cur[keys[keys.length - 1]] = value;
        return copy;
      });
      setSaved(false);
    };
  }

  async function saveKey(key: string, value?: any) {
    setSaving(true);
    setMsg("");
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key, value: value ?? settings[key] }) });
      setSaved(true);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  const upSite = updFn("site");
  const upRating = updFn("rating");
  const upEmail = updFn("email");
  const upOrders = updFn("orders");
  const upPickup = updFn("pickup");

  async function changePassword() {
    const current = (document.getElementById("pw-current") as HTMLInputElement)?.value || "";
    const next = (document.getElementById("pw-next") as HTMLInputElement)?.value || "";
    setSaving(true);
    setMsg("");
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key: "password", current, next }) });
      setMsg("✓ Slaptažodis pakeistas");
      const c = document.getElementById("pw-current") as HTMLInputElement;
      const n = document.getElementById("pw-next") as HTMLInputElement;
      if (c) c.value = "";
      if (n) n.value = "";
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  const hours = settings.hours as Record<string, [number, number] | null>;

  return (
    <div className="adm-tab">
      <div className="adm-chiprow" style={{ marginBottom: 14 }}>
        {[
          { v: "site", l: "Restorano informacija" },
          { v: "hours", l: "Darbo laikas" },
          { v: "orders", l: "Užsakymai" },
          { v: "payments", l: "Mokėjimai ir parduotuvė" },
          { v: "locations", l: "Filialai" },
          { v: "loyalty", l: "Lojalumo programa" },
          { v: "crm", l: "CRM kampanijos" },
          { v: "social", l: "Socialiniai prisijungimai" },
          { v: "rating", l: "Google įvertinimas" },
          { v: "email", l: "El. paštas" },
          { v: "push", l: "Pranešimai" },
          { v: "security", l: "Saugumas" },
        ].map((t) => (
          <button key={t.v} className={`chip ${tab === t.v ? "active" : ""}`} onClick={() => setTab(t.v)}>
            {t.l}
          </button>
        ))}
      </div>

      {msg && <div className="adm-note">{msg}</div>}

      {tab === "site" && <SettingDocument key="site" settingKey="site" />}

      {tab === "hours" && <SettingDocument key="hours" settingKey="hours" />}

      {tab === "payments" && <PaymentsStoreTab store={settings.store} onSaved={(store: unknown) => setSettings((s: any) => ({ ...s, store }))} />}

      {tab === "locations" && <LocationsTab />}

      {tab === "loyalty" && <LoyaltyTab />}

      {tab === "crm" && <CrmTab />}

      {tab === "social" && <SocialAuthTab store={settings.store} onSaved={(store: unknown) => setSettings((s: any) => ({ ...s, store }))} />}

      {tab === "rating" && (
        <Card title="Google įvertinimas">
          <p className="adm-hint">
            „Rankinis“ režimas rodo žemiau įvestus duomenis. „Automatinis“ režimas traukia realų įvertinimą iš Google Places API (reikia API rakto ir
            Place ID). „Paslėptas“ — pašalina įvertinimo blokus iš svetainės.
          </p>
          <Field label="Režimas">
            <select value={settings.rating.mode} onChange={(e) => upRating("mode", e.target.value)}>
              <option value="manual">Rankinis</option>
              <option value="auto">Automatinis (Google Places API)</option>
              <option value="hidden">Paslėptas</option>
            </select>
          </Field>
          <Field label="Įvertinimas (0–5)">
            <input type="number" step="0.1" min="0" max="5" value={settings.rating.score} onChange={(e) => upRating("score", Number(e.target.value))} />
          </Field>
          <Field label="Atsiliepimų skaičius">
            <input type="number" min="0" value={settings.rating.count} onChange={(e) => upRating("count", Number(e.target.value))} />
          </Field>
          <Field label="Pastaba po įvertinimu">
            <input value={settings.rating.note} onChange={(e) => upRating("note", e.target.value)} />
          </Field>
          {settings.rating.mode === "auto" && (
            <>
              <Field label="Google Places API raktas">
                <input value={settings.rating.placesApiKey} onChange={(e) => upRating("placesApiKey", e.target.value)} />
              </Field>
              <Field label="Google Place ID" hint="Pvz. ChIJ... — gaunamas iš Google Place IDFinder">
                <input value={settings.rating.placesPlaceId} onChange={(e) => upRating("placesPlaceId", e.target.value)} />
              </Field>
            </>
          )}
          <button className="primary" disabled={saving} onClick={() => saveKey("rating")}>
            Išsaugoti
          </button>
        </Card>
      )}

      {tab === "email" && <EmailSection settings={settings} setSettings={setSettings} saving={saving} setMsg={setMsg} />}

      {tab === "orders" && (
        <Card title="Užsakymų nustatymai">
          <Field label="Numerio prefiksas" hint="Pvz. AC → AC-1042">
            <input value={settings.orders.prefix} onChange={(e) => upOrders("prefix", e.target.value)} />
          </Field>
          <Field label="Kitas užsakymo numeris">
            <input type="number" value={settings.orders.nextNumber} onChange={(e) => upOrders("nextNumber", Number(e.target.value))} />
          </Field>
          <Card title="Atsiėmimas">
            <Switch checked={settings.pickup.enabled} onChange={(v) => upPickup("enabled", v)} label="Rodyti „Atsiėmimui“ scenarijų svetainėje" />
            <Field label="Minimalus laikas iki atsiėmimo (min.)">
              <input type="number" value={settings.pickup.leadMinutes} onChange={(e) => upPickup("leadMinutes", Number(e.target.value))} />
            </Field>
            <Field label="Laiko žingsnis (min.)">
              <input type="number" value={settings.pickup.slotMinutes} onChange={(e) => upPickup("slotMinutes", Number(e.target.value))} />
            </Field>
            <Field label="Kiek dienų pirmyn galima užsakyti">
              <input type="number" value={settings.pickup.maxDaysAhead} onChange={(e) => upPickup("maxDaysAhead", Number(e.target.value))} />
            </Field>
          </Card>
          <button className="primary" disabled={saving} onClick={() => saveKey("orders").then(() => saveKey("pickup"))}>
            Išsaugoti
          </button>
        </Card>
      )}

      {tab === "push" && <NotificationSection />}

      {tab === "security" && (
        <>
          <Card title="Administratoriaus slaptažodis">
            <Field label="Dabartinis slaptažodis">
              <input id="pw-current" type="password" autoComplete="current-password" />
            </Field>
            <Field label="Naujas slaptažodis (min. 12 simbolių)">
              <input id="pw-next" type="password" autoComplete="new-password" />
            </Field>
            <button className="primary" disabled={saving} onClick={changePassword}>
              Keisti slaptažodį
            </button>
          </Card>
          <TurnstileCard store={settings.store} onSaved={(store: unknown) => setSettings((s: any) => ({ ...s, store }))} />
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Pranešimų skiltis: Web Push į šio įrenginio app'ą (nauji užsakymai) */
/* ------------------------------------------------------------------ */

function NotificationSection() {
  const [status, setStatus] = useState<PushStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  function refresh() {
    getPushStatus().then((s) => setStatus(s)).catch(() => setStatus({ supported: false, permission: "unknown", subscribed: false }));
  }
  useEffect(refresh, []);

  async function onEnable() {
    setBusy(true);
    setMsg("");
    const r = await enablePush();
    setMsg(r.ok ? "✓ Pranešimai įjungti šiame įrenginyje — dabar išbandykite bandomąjį pranešimą." : r.error || "Klaida");
    setBusy(false);
    refresh();
  }

  async function onTest() {
    setBusy(true);
    setMsg("");
    try {
      await testPush();
      setMsg("✓ Bandomasis pranešimas išsiųstas — turėtumėte jį matyti ekrane (patikrinkite ir užrakintą sistemą). \u2713");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy(false);
      refresh();
    }
  }

  async function onDisable() {
    setBusy(true);
    await disablePush();
    setMsg("Pranešimai šiame įrenginyje išjungti.");
    setBusy(false);
    refresh();
  }

  return (
    <>
      <Card title="Naujų užsakymų pranešimai (kaip skambutis)">
        <p className="adm-hint">
          Kai klientas pateiks užsakymą ar rezervaciją, šiame įrenginyje iškart pasirodys sisteminis pranešimas su mygtukais
          <b> „Priimti“</b> ir <b>„Atidaryti“</b> — net jei admin langas uždarytas (kol programėlė įdiegta arba naršyklė paleista).
        </p>
        <div className="adm-chiprow" style={{ marginBottom: 14 }}>
          <span className={`chip ${status?.subscribed ? "active" : ""}`}>
            {status === null ? "Tikrinama..." : status.subscribed ? "Šis įrenginys: įjungta ✓" : "Šis įrenginys: išjungta"}
          </span>
          {typeof status?.deviceCount === "number" && <span className="chip">Įrenginių iš viso: {status.deviceCount}</span>}
          {status?.permission === "denied" && <span className="chip">Leidimas užblokuotas naršyklėje ⚠</span>}
        </div>
        {!status?.supported ? (
          <p className="adm-hint">Ši naršyklė nepalaiko push pranešimų — naudokite Chrome/Edge (kompiuteris, Android) arba Safari naudojant įdiegtą app'ą (iPhone, iOS 16.4+).</p>
        ) : (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {!status.subscribed && (
              <button className="primary" disabled={busy} onClick={onEnable}>
                🔔 Įjungti pranešimus šiame įrenginyje
              </button>
            )}
            {status.subscribed && (
              <>
                <button className="primary" disabled={busy} onClick={onTest}>
                  Išbandyti pranešimą
                </button>
                <button className="danger" disabled={busy} onClick={onDisable}>
                  Išjungti šiame įrenginyje
                </button>
              </>
            )}
          </div>
        )}
        {msg && <div className="adm-note" style={{ marginTop: 12 }}>{msg}</div>}
      </Card>

      <Card title="Kaip įdiegti programėlę ir gauti pranešimus">
        <p className="adm-hint">
          <b>Telefonas (Android):</b> Chrome → meniu ⋮ → „Įdiegti programėlę“ → atidarykite iš pradžios ekrano → įjunkite pranešimus čia.
          <br />
          <b>iPhone (iOS 16.4+):</b> Safari → mygtukas „Šaudyklė“ (Share) → „Į pradžios ekraną“ → programėlę atidarykite iš pagrindo ekrano ikonos →
          įjunkite pranešimus čia (be įdiegimo iOS pranešimų nerodo).
          <br />
          <b>Kompiuteris:</b> Chrome/Edge adreso juostoje spauskite instaliacijos ikoną (⊕) arba meniu → „Įdiegti Alma Chaab“.
        </p>
        <p className="adm-hint">
          Jei pranešimai neatsiranda: patikrinkite, ar naršyklės adreso juostoje pranešimų leidimas „Leisti“, ir ar sistemoje (telefonas: Nustatymai →
          Programos → Alma Chaab → Pranešimai) jie aktyvūs.
        </p>
      </Card>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* El. pašto skiltis: paprasta sąranka (Getspace / Gmail) + išplėsta  */
/* ------------------------------------------------------------------ */

type PresetId = "getspace" | "gmail" | "other";

const PRESETS: Record<PresetId, { label: string; host: string; port: number; secure: boolean; hint: string }> = {
  getspace: {
    label: "Getspace",
    host: "mail.almachaab.lt",
    port: 465,
    secure: true,
    hint:
      "Getspace pašto dėžutei: serveris paprastai būna mail.almachaab.lt (prievadas 465, SSL). Slaptažodį rasite Getspace valdymo pulte (cPanel → „El. pašto paskyros“) arba tas pats, kuriuo prisijungiate prie webmail. Vartotojo vardas — pilnas el. pašto adresas.",
  },
  gmail: {
    label: "Gmail",
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    hint:
      "Gmail dėžutei: įjunkite dviejų žingsnių patvirtinimą ir sukurkite „App Password“ (Google paskyros → Sauga → Programos slaptažodžiai). Į slaptažodžio lauką įrašykite būtent App Password — ne įprastą Gmail slaptažodį.",
  },
  other: {
    label: "Kita",
    host: "",
    port: 587,
    secure: false,
    hint: "Įveskite savo pašto tiekėjo pateiktus SMTP duomenis (serveris, prievadas, SSL). Dažniausiai vartotojo vardas — pilnas el. pašto adresas.",
  },
};

function detectPreset(email: { host: string }): PresetId {
  const h = (email.host || "").toLowerCase();
  if (h.includes("gmail")) return "gmail";
  if (h.startsWith("mail.") || h.includes("getspace") || h === "") return "getspace";
  return "other";
}

function domainOf(addr: string): string {
  const at = (addr || "").indexOf("@");
  return at >= 0 ? addr.slice(at + 1).trim() : "";
}

function EmailSection({
  settings,
  setSettings,
  saving,
  setMsg,
}: {
  settings: any;
  setSettings: (fn: (s: any) => any) => void;
  saving: boolean;
  setMsg: (m: string) => void;
}) {
  const [preset, setPreset] = useState<PresetId>(() => detectPreset(settings.email));
  const [quickUser, setQuickUser] = useState<string>(settings.email.user || "");
  const [quickPass, setQuickPass] = useState<string>(settings.email.pass || "");
  const [quickHost, setQuickHost] = useState<string>(settings.email.host || PRESETS.getspace.host);
  const [testing, setTesting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const up = (path: string, value: any) => {
    setSettings((s: any) => {
      const copy = { ...s, email: { ...s.email } };
       
      (copy.email as any)[path] = value;
      return copy;
    });
  };

  function choosePreset(p: PresetId) {
    setPreset(p);
    const pr = PRESETS[p];
    // Derive the mail host from the mailbox domain for Getspace-style hosting
    const dom = domainOf(quickUser) || domainOf(settings.email.user) || "almachaab.lt";
    const host = p === "getspace" ? `mail.${dom}` : pr.host;
    setQuickHost(host);
    up("host", host);
    up("port", pr.port);
    up("secure", pr.secure);
  }

  async function quickSave() {
    setMsg("");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(quickUser.trim())) {
      setMsg("Įveskite pilną el. pašto adresą, pvz. system@almachaab.lt");
      return;
    }
    if (!quickPass) {
      setMsg("Įveskite pašto dėžutės slaptažodį.");
      return;
    }
    const next = {
      ...settings.email,
      enabled: true,
      user: quickUser.trim(),
      pass: quickPass,
      from: settings.email.from || quickUser.trim(),
      host: quickHost || PRESETS[preset].host,
      port: Number(settings.email.port) || PRESETS[preset].port,
      secure: settings.email.secure,
    };
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key: "email", value: next }) });
      setSettings((s: any) => ({ ...s, email: next }));
      setMsg("✓ El. paštas sujungtas — automatiniai pranešimai įjungti. Išbandykite bandomąjį laišką žemiau.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    }
  }

  async function testEmail() {
    const to = (document.getElementById("test-email") as HTMLInputElement)?.value || "";
    setMsg("");
    setTesting(true);
    try {
      await api("/api/admin/email-test", { method: "POST", body: JSON.stringify({ to }) });
      setMsg("✓ Bandomasis laiškas išsiųstas — patikrinkite gautąjį (jei nerandate, pažiūrėkite šlamšte).");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setTesting(false);
    }
  }

  return (
    <>
      <Card title="El. pašto jungimas — paprastai">
        <p className="adm-hint">
          Pasirinkite, kurio tiekėjo pašto dėžutę naudosite automatiniams laiškams klientams — <b>užsakymas gautas</b> ·{" "}
          <b>patvirtintas</b> · <b>apmokėjimo kvitas</b> (mokėjimo būdas ir operacijos nr.) · <b>paruoštas</b> ·{" "}
          <b>atšauktas</b> — ir jums (naujų užsakymų kopijos). Pakanka vienos dėžutės — rekomenduojame atskirą techninę, pvz.{" "}
          <b>system@almachaab.lt</b>.
        </p>
        <div className="adm-chiprow" style={{ marginBottom: 14 }}>
          {(Object.keys(PRESETS) as PresetId[]).map((p) => (
            <button key={p} className={`chip ${preset === p ? "active" : ""}`} onClick={() => choosePreset(p)}>
              {PRESETS[p].label}
            </button>
          ))}
        </div>

        <Field label="El. pašto adresas (dėžutė, iš kurios siųsti)" hint="Pvz. system@almachaab.lt — gali būti ir info@almachaab.lt">
          <input
            value={quickUser}
            onChange={(e) => {
              setQuickUser(e.target.value);
              if (preset === "getspace" && domainOf(e.target.value)) setQuickHost(`mail.${domainOf(e.target.value)}`);
            }}
            placeholder="system@almachaab.lt"
          />
        </Field>
        {preset === "getspace" && (
          <Field label="Pašto serveris" hint="Getspace (cPanel) standartiškai: mail.jūsųdomenas.lt, prievadas 465 su SSL">
            <input value={quickHost} onChange={(e) => setQuickHost(e.target.value)} />
          </Field>
        )}
        <Field label="Slaptažodis">
          <input type="password" value={quickPass} onChange={(e) => setQuickPass(e.target.value)} />
        </Field>
        <p className="adm-hint">{PRESETS[preset].hint}</p>
        <button className="primary" disabled={saving} onClick={quickSave}>
          Sujungti ir įjungti pranešimus
        </button>
      </Card>

      <Card title="Bandomasis laiškas">
        <div className="adm-field">
          <span>Gavėjas</span>
          <div style={{ display: "flex", gap: 8 }}>
            <input id="test-email" placeholder="vardas@pavyzdys.lt" />
            <button disabled={testing} onClick={testEmail}>
              {testing ? "Siunčiama..." : "Siųsti"}
            </button>
          </div>
        </div>
      </Card>

      <EmailTemplatesSection settings={settings} setSettings={setSettings} setMsg={setMsg} />

      <Card
        title="Išplėstiniai nustatymai"
        actions={
          <button onClick={() => setShowAdvanced(!showAdvanced)}>{showAdvanced ? "Slėpti" : "Rodyti"}</button>
        }
      >
        {!showAdvanced ? (
          <p className="adm-hint">Čia galite pakeisti serverio duomenis rankiniu būdu, siuntėjo vardą ir restorano pranešimų dėžutę.</p>
        ) : (
          <>
            <Switch checked={settings.email.enabled} onChange={(v) => up("enabled", v)} label="Siųsti automatinius pranešimus" />
            <Field label="SMTP serveris">
              <input value={settings.email.host} onChange={(e) => up("host", e.target.value)} />
            </Field>
            <Field label="Prievadas">
              <input type="number" value={settings.email.port} onChange={(e) => up("port", Number(e.target.value))} />
            </Field>
            <Switch checked={settings.email.secure} onChange={(v) => up("secure", v)} label="SSL (465 prievadui)" />
            <Field label="El. paštas (siuntėjas)">
              <input value={settings.email.user} onChange={(e) => up("user", e.target.value)} placeholder="system@almachaab.lt" />
            </Field>
            <Field label="App Password / slaptažodis">
              <input type="password" value={settings.email.pass} onChange={(e) => up("pass", e.target.value)} />
            </Field>
            <Field label="Siuntėjo vardas">
              <input value={settings.email.fromName} onChange={(e) => up("fromName", e.target.value)} />
            </Field>
            <Field label="Restorano pranešimų dėžutė" hint="Čia bus dubliuojami nauji užsakymai ir rezervacijos (pvz. info@almachaab.lt)">
              <input value={settings.email.notifyEmail} onChange={(e) => up("notifyEmail", e.target.value)} />
            </Field>
            <button className="primary" disabled={saving} onClick={() => api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key: "email", value: settings.email }) }).then(() => setMsg("✓ Išsaugota")).catch((e) => setMsg(e instanceof Error ? e.message : "Klaida"))}>
              Išsaugoti
            </button>
          </>
        )}
      </Card>
    </>
  );
}

/* ---------- Laiškų šablonų redaktorius (tekstai ir struktūra) ---------- */

function EmailTemplatesSection({
  settings,
  setSettings,
  setMsg,
}: {
  settings: any;
  setSettings: (fn: (s: any) => any) => void;
  setMsg: (m: string) => void;
}) {
  const [key, setKey] = useState<EmailTemplateKey>("order.paid");
  const [draft, setDraft] = useState<EmailTemplate>(() => mergeTemplate("order.paid", settings.email?.templates));
  const [preview, setPreview] = useState<{ subject: string; html: string } | null>(null);
  const [busy, setBusy] = useState<"" | "preview" | "send" | "save" | "reset">("");
  const [testTo, setTestTo] = useState("");

  const saved = mergeTemplate(key, settings.email?.templates);
  const dirty = JSON.stringify(draft) !== JSON.stringify(saved);

  function pick(k: EmailTemplateKey) {
    setKey(k);
    setDraft(mergeTemplate(k, settings.email?.templates));
    setPreview(null);
  }

  function set<K extends keyof EmailTemplate>(field: K, value: EmailTemplate[K]) {
    setDraft((d) => ({ ...d, [field]: value }));
  }

  function insertToken(token: string) {
    setDraft((d) => ({ ...d, body: (d.body ? d.body + " " : "") + token }));
  }

  async function doPreview(send?: boolean) {
    const to = testTo.trim();
    if (send && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) {
      setMsg("Įveskite tikrą gavėjo adresą bandomajam laiškui.");
      return;
    }
    setMsg("");
    setBusy(send ? "send" : "preview");
    try {
      const r = await api<{ subject: string; html: string; sent: { ok: boolean; error?: string } | null }>(
        "/api/admin/email-preview",
        { method: "POST", body: JSON.stringify({ key, template: draft, send: !!send, to }) }
      );
      if (!send) setPreview({ subject: r.subject, html: r.html });
      if (send)
        setMsg(
          r.sent?.ok
            ? `✓ Bandomasis laiškas išsiųstas — patikrinkite ${to} (žiūrėkite ir šlamštą).`
            : `Nepavyko išsiųsti: ${r.sent?.error || "klaida"}`
        );
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy("");
    }
  }

  async function saveTemplate() {
    setMsg("");
    setBusy("save");
    const templates = { ...(settings.email.templates || {}), [key]: draft };
    const next = { ...settings.email, templates };
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key: "email", value: next }) });
      setSettings((s: any) => ({ ...s, email: next }));
      setMsg("✓ Šablonas išsaugotas — nauji laiškai naudos šį tekstą.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy("");
    }
  }

  async function resetTemplate() {
    setMsg("");
    setBusy("reset");
    const templates: Record<string, EmailTemplate> = { ...(settings.email.templates || {}) };
    delete templates[key];
    const next = { ...settings.email, templates };
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify({ key: "email", value: next }) });
      setSettings((s: any) => ({ ...s, email: next }));
      setDraft(DEFAULT_TEMPLATES[key]);
      setPreview(null);
      setMsg("✓ Grąžintas numatytasis tekstas.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy("");
    }
  }

  const orderKeys = EMAIL_TEMPLATE_KEYS.filter((k) => k.startsWith("order."));
  const resKeys = EMAIL_TEMPLATE_KEYS.filter((k) => k.startsWith("reservation."));

  return (
    <Card title="Laiškų tekstai — šablonai ir struktūra">
      <p className="adm-hint">
        Kiekvieno automatinio laiško <b>temą</b>, <b>antraštę</b> ir <b>tekstą</b> redaguokite čia, o struktūrinius blokus
        (informacija, patiekalų sąrašas, apmokėjimo kvitas, sekimo nuoroda) įjunkite arba išjunkite. Neišsaugoti laukai
        naudoja numatytąjį lietuvišką tekstą. Vietos žymos, pvz. <b>{"{{numeris}}"}</b> ar <b>{"{{suma}}"}</b>, siuntimo
        metu pakeičiamos tikrais duomenimis.
      </p>

      <Field label="Užsakymų laiškai">
        <div className="adm-chiprow">
          {orderKeys.map((k) => (
            <button key={k} type="button" className={`chip ${key === k ? "active" : ""}`} onClick={() => pick(k)}>
              {EMAIL_TEMPLATE_LABELS[k]}
            </button>
          ))}
        </div>
      </Field>
      <Field label="Rezervacijų laiškai">
        <div className="adm-chiprow">
          {resKeys.map((k) => (
            <button key={k} type="button" className={`chip ${key === k ? "active" : ""}`} onClick={() => pick(k)}>
              {EMAIL_TEMPLATE_LABELS[k]}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Laiško tema (Subject)" hint="Rodoma gavėjo laiškų sąraše">
        <input value={draft.subject} onChange={(e) => set("subject", e.target.value)} />
      </Field>
      <Field label="Antraštė laiške" hint="Didelė eilutė po logotipu">
        <input value={draft.title} onChange={(e) => set("title", e.target.value)} />
      </Field>
      <Field label="Laiško tekstas" hint="Nauja eilutė = naujas paragrafas">
        <textarea value={draft.body} rows={4} onChange={(e) => set("body", e.target.value)} />
      </Field>

      <Field label="Vietos žymos — spauskite, kad įterpti į tekstą">
        <div className="adm-chiprow">
          {TEMPLATE_PLACEHOLDERS.map((p) => (
            <button key={p.token} type="button" className="chip" title={p.label} onClick={() => insertToken(p.token)}>
              {p.token}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Struktūriniai blokai">
        <div style={{ display: "grid", gap: 8 }}>
          <Switch checked={draft.showDetails} onChange={(v) => set("showDetails", v)} label="Rodyti informacijos bloką (laikas, numeris, suma, pastaba)" />
          <Switch checked={draft.showItems} onChange={(v) => set("showItems", v)} label="Rodyti patiekalų sąrašą" />
          <Switch checked={draft.showPayment} onChange={(v) => set("showPayment", v)} label="Rodyti apmokėjimo kvitą (būdas, operacijos nr., suma)" />
          <Switch checked={draft.showTrack} onChange={(v) => set("showTrack", v)} label="Rodyti būsenos stebėjimo nuorodą" />
        </div>
      </Field>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "14px 0" }}>
        <button type="button" disabled={busy !== ""} onClick={() => doPreview(false)}>
          {busy === "preview" ? "Rodoma..." : "Peržiūrėti su pavyzdiniais duomenimis"}
        </button>
        <button type="button" className="primary" disabled={busy !== "" || !dirty} onClick={saveTemplate}>
          Išsaugoti šabloną
        </button>
        <button type="button" disabled={busy !== ""} onClick={resetTemplate}>
          Atstatyti numatytąjį
        </button>
      </div>

      {preview && (
        <div style={{ marginBottom: 14 }}>
          <Field label="Temos peržiūra">
            <input value={preview.subject} readOnly />
          </Field>
          <iframe
            title="Laiško peržiūra"
            srcDoc={preview.html}
            style={{ width: "100%", height: 440, border: "1px solid #ded0bd", borderRadius: 12, background: "#fffdf8" }}
          />
        </div>
      )}

      <Field label="Bandomasis šio šablono laiškas" hint="Išbandykite ir neįsaugotus pakeitimus — gavėjas gaus laišką su jūsų redaguotu tekstu">
        <div style={{ display: "flex", gap: 8 }}>
          <input value={testTo} placeholder="vardas@pavyzdys.lt" onChange={(e) => setTestTo(e.target.value)} />
          <button type="button" disabled={busy !== ""} onClick={() => doPreview(true)}>
            {busy === "send" ? "Siunčiama..." : "Siųsti"}
          </button>
        </div>
      </Field>
    </Card>
  );
}

/* ---------- Mokėjimai ir parduotuvė (Settings singleton) ---------- */

interface StoreSettingsView {
  restaurantName: string;
  isOpen: boolean;
  stripePublicKey: string;
  stripeSecretKey: string | null; // masked string from server; null = user asked to clear
  stripeWebhookSecret: string | null;
  paypalClientId: string;
  paypalSecret: string | null;
  paypalSandbox: boolean;
  googleEnabled: boolean;
  googleClientId: string;
  googleClientSecret: string | null;
  facebookEnabled: boolean;
  facebookClientId: string;
  facebookClientSecret: string | null;
  telegramEnabled: boolean;
  telegramBotToken: string | null;
  telegramBotUsername: string;
  turnstileEnabled: boolean;
  turnstileSiteKey: string;
  turnstileSecretKey: string | null;
  currency: string;
  taxRate: number;
  deliveryFee: number;
}

function SecretField({ label, value, onChange, hint }: { label: string; value: string | null; onChange: (v: string | null) => void; hint?: string }) {
  const [show, setShow] = useState(false);
  const stored = typeof value === "string" && value.length > 0;
  return (
    <Field label={label} hint={hint}>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          type={show ? "text" : "password"}
          value={value ?? ""}
          autoComplete="new-password"
          placeholder={value === null ? "— bus pašalintas po išsaugojimo —" : "••••"}
          onChange={(e) => onChange(e.target.value)}
        />
        <button type="button" onClick={() => setShow(!show)}>
          {show ? "Slėpti" : "Rodyti"}
        </button>
        {stored && value!.includes("•") && (
          <button type="button" className="danger" title="Pašalinti išsaugotą raktą" onClick={() => onChange(null)}>
            Šalinti
          </button>
        )}
      </div>
    </Field>
  );
}

/* ---------- Cloudflare Turnstile (anti-bot) ---------- */

function TurnstileCard({ store, onSaved }: { store: StoreSettingsView; onSaved: (store: StoreSettingsView) => void }) {
  const [local, setLocal] = useState<StoreSettingsView>(store);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  const [prevStore, setPrevStore] = useState(store);
  if (store !== prevStore) {
    setPrevStore(store);
    setLocal(store);
  }

  function set<K extends keyof StoreSettingsView>(key: K, value: StoreSettingsView[K]) {
    setLocal((s) => ({ ...s, [key]: value }));
    setMsg("");
  }

  async function save() {
    setSaving(true);
    setMsg("");
    try {
      const r = await api<{ store: StoreSettingsView }>("/api/admin/settings", {
        method: "PUT",
        body: JSON.stringify({ key: "store", value: local }),
      });
      onSaved(r.store);
      setMsg("✓ Išsaugota");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card title="Cloudflare Turnstile — apsauga nuo robotų">
      <p className="adm-hint">
        Įjungus, prisijungimo / registracijos / Telegram formose atsiras Cloudflare patikros valdiklis — botai nebeįmanės
        kurti paskyrų ar bruteforcinti slaptažodžių. Raktus sukurkite dash.cloudflare.com → Turnstile → Add site (Hostnames:
        jūsų domenas). Google / Facebook jau turi savo apsaugą — ši patikra jų nereglamentuoja.
      </p>
      <Switch
        checked={local.turnstileEnabled}
        onChange={(v) => set("turnstileEnabled", v)}
        label="Įjungti Cloudflare patikrą prisijungimo formose"
      />
      <Field label="Site key (viešas)" hint="Formatas 0x4AAAAAAA...">
        <input value={local.turnstileSiteKey} placeholder="0x4AAAAAAA..." onChange={(e) => set("turnstileSiteKey", e.target.value)} />
      </Field>
      <SecretField
        label="Secret key (slaptas)"
        value={local.turnstileSecretKey}
        onChange={(v) => set("turnstileSecretKey", v ?? "")}
        hint="Palikite su taškais, jei norite išsaugoti esamą. Formatas 0x4AAAAAAA..."
      />
      <button className="primary" disabled={saving} onClick={save}>
        Išsaugoti
      </button>
      {msg && <p className="adm-hint">{msg}</p>}
    </Card>
  );
}

function PaymentsStoreTab({ store, onSaved }: { store: StoreSettingsView; onSaved: (store: StoreSettingsView) => void }) {
  const [local, setLocal] = useState<StoreSettingsView>(store);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const origin = useClientValue(() => window.location.origin, "");

  const [prevStore, setPrevStore] = useState(store);
  if (store !== prevStore) {
    setPrevStore(store);
    setLocal(store);
  }

  function set<K extends keyof StoreSettingsView>(key: K, value: StoreSettingsView[K]) {
    setLocal((s) => ({ ...s, [key]: value }));
    setMsg("");
  }

  async function save() {
    setSaving(true);
    setMsg("");
    try {
      const r = await api<{ ok: boolean; store: StoreSettingsView }>("/api/admin/settings", {
        method: "PUT",
        body: JSON.stringify({ key: "store", value: local }),
      });
      onSaved(r.store);
      setMsg("✓ Išsaugota — keitimai veikia iš karto.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  const stripeReady = Boolean(store.stripePublicKey || store.stripeSecretKey);
  const paypalReady = Boolean(store.paypalClientId);

  return (
    <>
      <Card title="Parduotuvės būsena ir mokesčiai">
        <Switch
          checked={local.isOpen}
          onChange={(v) => set("isOpen", v)}
          label={local.isOpen ? "Priimame užsakymus (atidaryta)" : "Uždaryta — nauji užsakymai nepriimami"}
        />
        <p className="adm-hint">
          Skubus jungiklis: išjungus svetainės svečiai negali pateikti nei atsiėmimo užsakymų, nei rezervacijų — matys pranešimą skambinti telefonu.
        </p>
        <Field label="Pavadinimas (mokėjimų kvitams)">
          <input value={local.restaurantName} onChange={(e) => set("restaurantName", e.target.value)} />
        </Field>
        <Field label="Valiuta" hint="ISO kodas, pvz. EUR. Stripe / PayPal mokesčiai skaičiuojami šia valiuta.">
          <select value={local.currency} onChange={(e) => set("currency", e.target.value)}>
            <option value="EUR">EUR — euras</option>
            <option value="USD">USD — JAV doleris</option>
            <option value="GBP">GBP — svaras</option>
          </select>
        </Field>
        <Field label="PVM tarifas (%)" hint="0 = be PVM eilutės. PVM pridedamas prie krepšelio sumos ir rodomas klientui.">
          <input
            type="number"
            step="0.1"
            min="0"
            max="100"
            value={local.taxRate}
            onChange={(e) => set("taxRate", Number(e.target.value))}
          />
        </Field>
        <Field label="Pristatymo mokestis (€)" hint="Pristatymo paslaugai (pritaikoma automatiškai, kai bus įjungtas pristatymas).">
          <input
            type="number"
            step="0.5"
            min="0"
            value={local.deliveryFee}
            onChange={(e) => set("deliveryFee", Number(e.target.value))}
          />
        </Field>
        <button className="primary" disabled={saving} onClick={save}>
          {saving ? "Išsaugoma..." : "Išsaugoti"}
        </button>
      </Card>

      <Card
        title="Stripe — mokėjimai kortelėmis"
        actions={<span className={`badge ${stripeReady ? "st-confirmed" : "st-cancelled"}`}>{stripeReady ? "Suvesta" : "Nesukonfigūruota"}</span>}
      >
        <p className="adm-hint">
          Raktus suvesta čia naudoja atsiskaitymas internetu (Stripe Checkout). Slaptojo rakto niekas nemato — jis saugomas serveryje ir rodomas tik
          užmaskuotas. Gaukite raktus iš <b>dashboard.stripe.com → Developers → API keys</b>.
        </p>
        <Field label="Publishable key (viešas)">
          <input
            value={local.stripePublicKey}
            onChange={(e) => set("stripePublicKey", e.target.value)}
            placeholder="pk_live_..."
          />
        </Field>
        <SecretField
          label="Secret key (slaptas)"
          value={local.stripeSecretKey}
          onChange={(v) => set("stripeSecretKey", v)}
          hint="Palikite su taškais, jei norite išsaugoti esamą. Formatas sk_live_... arba sk_test_..."
        />
        <SecretField
          label="Webhook signing secret"
          value={local.stripeWebhookSecret}
          onChange={(v) => set("stripeWebhookSecret", v)}
          hint="whsec_... — sukuriama pridėjus webhook endpoint žemiau."
        />
        <p className="adm-hint">
          Webhook adresas Stripe valdymo skyde: <code>{origin}/api/webhooks/stripe</code> (įvykis <b>checkout.session.completed</b>).
        </p>
        <button className="primary" disabled={saving} onClick={save}>
          {saving ? "Išsaugoma..." : "Išsaugoti"}
        </button>
      </Card>

      <Card
        title="PayPal"
        actions={<span className={`badge ${paypalReady ? "st-confirmed" : "st-cancelled"}`}>{paypalReady ? "Suvesta" : "Nesukonfigūruota"}</span>}
      >
        <p className="adm-hint">
          Kredencialus gaukite iš <b>developer.paypal.com → Apps &amp; Credentials</b> (Live arba Sandbox — pagal žemiau esantį jungiklį).
        </p>
        <Field label="Client ID">
          <input
            value={local.paypalClientId}
            onChange={(e) => set("paypalClientId", e.target.value)}
            placeholder="AeA1QIZX..."
          />
        </Field>
        <SecretField label="Secret" value={local.paypalSecret} onChange={(v) => set("paypalSecret", v)} hint="Palikite su taškais, jei norite išsaugoti esamą." />
        <Switch checked={local.paypalSandbox} onChange={(v) => set("paypalSandbox", v)} label="Sandbox (testinis režimas)" />
        <p className="adm-hint">Išjunkite Sandbox tik patikrinę, kad Live kredencialai suvesti teisingi.</p>
        <button className="primary" disabled={saving} onClick={save}>
          {saving ? "Išsaugoma..." : "Išsaugoti"}
        </button>
      </Card>
    </>
  );
}

/* ---------- Socialiniai prisijungimai (Google / Facebook / Telegram) ---------- */

function SocialAuthTab({ store, onSaved }: { store: StoreSettingsView; onSaved: (store: StoreSettingsView) => void }) {
  const [local, setLocal] = useState<StoreSettingsView>(store);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const origin = useClientValue(() => window.location.origin, "");

  const [prevStore, setPrevStore] = useState(store);
  if (store !== prevStore) {
    setPrevStore(store);
    setLocal(store);
  }

  function set<K extends keyof StoreSettingsView>(key: K, value: StoreSettingsView[K]) {
    setLocal((s) => ({ ...s, [key]: value }));
    setMsg("");
  }

  async function save() {
    setSaving(true);
    setMsg("");
    try {
      const r = await api<{ ok: boolean; store: StoreSettingsView }>("/api/admin/settings", {
        method: "PUT",
        body: JSON.stringify({ key: "social", value: local }),
      });
      onSaved(r.store);
      setMsg("✓ Išsaugota — mygtukai atsiranda klientams iš karto.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  const googleReady = Boolean(local.googleClientId || (local.googleClientSecret && local.googleClientSecret.includes("•")));
  const facebookReady = Boolean(local.facebookClientId || (local.facebookClientSecret && local.facebookClientSecret.includes("•")));
  const telegramReady = Boolean(local.telegramBotUsername || (local.telegramBotToken && local.telegramBotToken.includes("•")));

  return (
    <>
      <p className="adm-hint">
        Socialiniai mygtukai rodomi klientams tik tuomet, kai paslauga įjungta ir suvesti abu raktai. Esamos paskyros susiejamos pagal el. paštą —
        kliento užsakymai ir lojalumo taškai lieka nepakitę.
      </p>

      <Card
        title="Google"
        actions={<span className={`badge ${googleReady && local.googleEnabled ? "st-confirmed" : "st-cancelled"}`}>{googleReady && local.googleEnabled ? "Įjungta" : "Išjungta"}</span>}
      >
        <p className="adm-hint">
          Kredencialus sukurkite <b>console.cloud.google.com → APIs &amp; Services → Credentials → OAuth client ID</b> (Web application). Į
          „Authorized redirect URIs“ įrašykite: <code>{origin}/api/auth/callback/google</code>
        </p>
        <Switch checked={local.googleEnabled} onChange={(v) => set("googleEnabled", v)} label="Rodyti „Prisijungti su Google“ mygtuką" />
        <Field label="Client ID (viešas)">
          <input value={local.googleClientId} onChange={(e) => set("googleClientId", e.target.value)} placeholder="1234567890-xxxx.apps.googleusercontent.com" />
        </Field>
        <SecretField
          label="Client secret (slaptas)"
          value={local.googleClientSecret}
          onChange={(v) => set("googleClientSecret", v)}
          hint="Palikite su taškais, jei norite išsaugoti esamą. Formatas GOCSPX-..."
        />
      </Card>

      <Card
        title="Facebook"
        actions={<span className={`badge ${facebookReady && local.facebookEnabled ? "st-confirmed" : "st-cancelled"}`}>{facebookReady && local.facebookEnabled ? "Įjungta" : "Išjungta"}</span>}
      >
        <p className="adm-hint">
          Kredencialus sukurkite <b>developers.facebook.com → Create App → Facebook Login</b>. Nustatymuose į „Valid OAuth Redirect URIs“ įrašykite:{" "}
          <code>{origin}/api/auth/callback/facebook</code>
        </p>
        <Switch checked={local.facebookEnabled} onChange={(v) => set("facebookEnabled", v)} label="Rodyti „Prisijungti su Facebook“ mygtuką" />
        <Field label="App ID (viešas)">
          <input value={local.facebookClientId} onChange={(e) => set("facebookClientId", e.target.value)} placeholder="123456789012345" />
        </Field>
        <SecretField
          label="App secret (slaptas)"
          value={local.facebookClientSecret}
          onChange={(v) => set("facebookClientSecret", v)}
          hint="Palikite su taškais, jei norite išsaugoti esamą."
        />
      </Card>

      <Card
        title="Telegram"
        actions={<span className={`badge ${telegramReady && local.telegramEnabled ? "st-confirmed" : "st-cancelled"}`}>{telegramReady && local.telegramEnabled ? "Įjungta" : "Išjungta"}</span>}
      >
        <p className="adm-hint">
          Sukurkite botą per <b>@BotFather</b> (/newbot), nukopijuokite token čia, o komandoje /setdomain susiekite domeną{" "}
          <b>{origin.replace(/^https?:\/\//, "")}</b> — be to Telegram mygtukas neveiks. Bot token: <b>BotFather → /mybots → API Token</b>.
        </p>
        <Switch checked={local.telegramEnabled} onChange={(v) => set("telegramEnabled", v)} label="Rodyti Telegram prisijungimą" />
        <Field label="Boto vartotojo vardas" hint="Be @ — pvz. almachaab_bot. Tiksliai toks, kokį sukūrė BotFather.">
          <input value={local.telegramBotUsername} onChange={(e) => set("telegramBotUsername", e.target.value)} placeholder="almachaab_bot" />
        </Field>
        <SecretField
          label="Bot token (slaptas)"
          value={local.telegramBotToken}
          onChange={(v) => set("telegramBotToken", v)}
          hint="Palikite su taškais, jei norite išsaugoti esamą. Formatas 123456789:AA..."
        />
      </Card>

      {msg && <div className="adm-note">{msg}</div>}
      <button className="primary" disabled={saving} onClick={save}>
        {saving ? "Išsaugoma..." : "Išsaugoti"}
      </button>
    </>
  );
}
