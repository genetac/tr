"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, getToken } from "./ui";
import { useLoadEffect, useClientValue } from "@/hooks/use-load-effect";
import "./kitchen.css";

/* ---------- types ---------- */

export interface KitchenOrder {
  id: string;
  number: string;
  type: string; // pickup | reservation
  status: string;
  statusLabel: string;
  customerName: string;
  phone: string;
  items: { name: string; qty: number }[];
  total: number;
  pickupTime: string;
  resDate: string;
  resTime: string;
  guests: number;
  note: string;
  prepMinutes: number | null;
  prepSetAt: string | null;
  readyAt: string | null;
  createdAt: string;
  isRead: boolean;
  paymentStatus: string; // unpaid | paid
  paymentMethod: string; // "" = mokės vietoje, stripe/paypal = online
}

interface KitchenData {
  incoming: KitchenOrder[];
  active: KitchenOrder[];
  today: { count: number; done: number; revenue: number };
  unread: number;
}

const PREP_CHIPS = [15, 20, 30, 45, 60];

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleTimeString("lt-LT", { hour: "2-digit", minute: "2-digit" });
}

function elapsedMin(iso: string): number {
  return Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60_000));
}

/* ---------- ringtone (WebAudio, no assets) ---------- */

function useRingtone(muted: boolean) {
  const ctxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const playingRef = useRef(false);

  const beep = useCallback(() => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    const t = ctx.currentTime;
    // two-tone chime ×2
    for (const [freq, start] of [[880, 0], [660, 0.18], [880, 0.45], [660, 0.63]] as const) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, t + start);
      gain.gain.exponentialRampToValueAtTime(0.35, t + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + start + 0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t + start);
      osc.stop(t + start + 0.18);
    }
  }, []);

  const start = useCallback(() => {
    if (muted || playingRef.current) return;
    playingRef.current = true;
    try {
      ctxRef.current = ctxRef.current || new AudioContext();
      void ctxRef.current.resume();
    } catch {
      return;
    }
    beep();
    timerRef.current = setInterval(beep, 2400);
  }, [beep, muted]);

  const stop = useCallback(() => {
    playingRef.current = false;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  }, []);

  useEffect(() => () => stop(), [stop]);
  return { start, stop, playing: playingRef };
}

/* ---------- component ---------- */

export default function KitchenApp({ embedded = false }: { embedded?: boolean }) {
  const [data, setData] = useState<KitchenData | null>(null);
  // Mute is persisted per device: read from localStorage, overridden once toggled.
  const storedMuted = useClientValue(() => localStorage.getItem("alma_kitchen_muted") === "1", false);
  const [mutedOverride, setMutedOverride] = useState<boolean | null>(null);
  const muted = mutedOverride ?? storedMuted;
  const [customPrep, setCustomPrep] = useState<Record<string, string>>({});
  const [now, setNow] = useState(Date.now());
  const [live, setLive] = useState<"connecting" | "live" | "polling">("connecting");
  const ring = useRingtone(muted);
  const hasIncoming = !!data && data.incoming.length > 0;

  const toggleMute = () => {
    const v = !muted;
    setMutedOverride(v);
    try {
      localStorage.setItem("alma_kitchen_muted", v ? "1" : "0");
    } catch {
      /* storage blocked — the toggle still works for this session */
    }
    if (v) ring.stop();
  };

  /* polling — fallback while SSE is down; slower when live */
  const load = useCallback(async () => {
    try {
      const d = await api<KitchenData>("/api/admin/kitchen");
      setData(d);
    } catch {
      /* keep last known state */
    }
  }, []);
  useLoadEffect(load, live === "live" ? 20000 : 9000);

  /* real-time updates via SSE — instant tickets on checkout & status changes */
  useEffect(() => {
    const token = getToken();
    let es: EventSource | null = null;
    let debounce: ReturnType<typeof setTimeout> | null = null;
    try {
      es = new EventSource(`/api/orders/stream${token ? `?token=${encodeURIComponent(token)}` : ""}`);
      es.addEventListener("ready", () => setLive("live"));
      es.addEventListener("order", () => {
        // collapse bursts of events into one refresh
        if (debounce) clearTimeout(debounce);
        debounce = setTimeout(() => void load(), 250);
      });
      es.onerror = () => {
        // EventSource retries automatically; meanwhile polling covers us
        setLive((s) => (s === "live" ? "polling" : s));
      };
    } catch {
      /* no EventSource — the 9 s polling above (live !== "live") covers us */
    }
    return () => {
      if (debounce) clearTimeout(debounce);
      es?.close();
    };
  }, [load]);

  /* tick every 15s for timers */
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 15_000);
    return () => clearInterval(t);
  }, []);

  /* ringtone + blinking title + app badge on incoming */
  useEffect(() => {
    if (hasIncoming) {
      ring.start();
      if ("vibrate" in navigator) navigator.vibrate?.([300, 150, 300, 150, 300, 150, 300]);
      document.title = "🔔 NAUJAS UŽSAKYMAS — Alma Chaab";
      navigator.setAppBadge?.(data?.unread ?? 1).catch(() => {});
    } else {
      ring.stop();
      document.title = "Virtuvė — Alma Chaab";
      navigator.clearAppBadge?.().catch(() => {});
    }
  }, [hasIncoming, data?.unread, ring]);

  /* wake lock — keep the kitchen screen on */
  useEffect(() => {
    let lock: { release: () => Promise<void> } | null = null;
    const acquire = async () => {
      try {
         
        lock = (await (navigator as any).wakeLock?.request("screen")) || null;
      } catch {
        /* unsupported */
      }
    };
    const onVis = () => {
      if (document.visibilityState === "visible") void acquire();
    };
    void acquire();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      void lock?.release().catch(() => {});
    };
  }, []);

  /* actions */
  const patch = async (id: string, body: Record<string, unknown>) => {
    await api(`/api/admin/orders/${id}`, { method: "PATCH", body: JSON.stringify(body) });
    await load();
  };

  const accept = (o: KitchenOrder) => patch(o.id, { status: "confirmed", isRead: true });
  const decline = (o: KitchenOrder) => {
    if (confirm(`Atmesti užsakymą ${o.number}?`)) patch(o.id, { status: "cancelled", isRead: true });
  };
  const setPrep = (o: KitchenOrder, mins: number) => {
    ring.stop();
    patch(o.id, { prepMinutes: mins, status: o.status === "confirmed" ? "preparing" : o.status, isRead: true });
  };
  const nextStatus = (o: KitchenOrder) => {
    const walk: Record<string, string> = { confirmed: "preparing", preparing: "ready", ready: "completed" };
    patch(o.id, { status: walk[o.status] || o.status, isRead: true });
  };

  /* ---------- render helpers ---------- */

  /** Paid / not-paid chip — the kitchen sees at a glance whether to collect.
   *  Pure table reservations (no pre-ordered dishes, nothing to settle) get
   *  NO payment chip at all — a simple booking is not a payment object. */
  const PayChip = ({ o }: { o: KitchenOrder }) => {
    const paid = o.paymentStatus === "paid";
    if (!paid && o.total <= 0) return null;
    const cls = paid ? "k-pay-paid" : o.paymentMethod ? "k-pay-online" : "k-pay-venue";
    const label = paid ? "✓ Apmokėta" : o.paymentMethod ? "Laukia apmokėjimo" : o.type === "pickup" ? "Mokės atsiimdamas" : "Mokės restorane";
    return <span className={`k-pay ${cls}`}>{label}</span>;
  };

  const OrderLines = ({ o }: { o: KitchenOrder }) =>
    o.type === "pickup" ? (
      <ul className="k-lines">
        {o.items.map((it, i) => (
          <li key={i}>
            <b>{it.qty}×</b> {it.name}
          </li>
        ))}
      </ul>
    ) : (
      <div className="k-resinfo">
        <span>📅 {o.resDate} · {o.resTime}</span>
        <span>👥 {o.guests} svečiai</span>
      </div>
    );

  const PrepRow = ({ o }: { o: KitchenOrder }) => (
    <div className="k-prep-row">
      <span className="k-prep-label">Paruošimo laikas:</span>
      {PREP_CHIPS.map((m) => (
        <button key={m} className={`k-chip ${o.prepMinutes === m ? "k-chip-on" : ""}`} onClick={() => setPrep(o, m)}>
          {m} min
        </button>
      ))}
      <span className="k-custom">
        <input
          inputMode="numeric"
          placeholder="×"
          value={customPrep[o.id] ?? ""}
          onChange={(e) => setCustomPrep((p) => ({ ...p, [o.id]: e.target.value.replace(/\D/g, "").slice(0, 3) }))}
        />
        <button
          className="k-chip"
          disabled={!customPrep[o.id]}
          onClick={() => setPrep(o, Number(customPrep[o.id]))}
        >
          ✓
        </button>
      </span>
    </div>
  );

  const incomingCard = (o: KitchenOrder) => (
    <div className="k-card k-incoming-card" key={o.id}>
      <div className="k-card-head">
        <span className="k-num">{o.number}</span>
        <span className="k-tag k-tag-new">{o.type === "pickup" ? "ATSIEMIMUI" : "REZERVACIJA"}</span>
        <PayChip o={o} />
        <span className="k-elapsed">{elapsedMin(o.createdAt)} min</span>
      </div>
      <div className="k-customer">{o.customerName} · {o.phone}</div>
      <OrderLines o={o} />
      {o.note && <p className="k-note">„{o.note}"</p>}
      <div className="k-actions">
        <button className="k-btn k-btn-accept" onClick={() => accept(o)}>✓ Priimti</button>
        <button className="k-btn k-btn-decline" onClick={() => decline(o)}>✕ Atmesti</button>
      </div>
    </div>
  );

  const activeCard = (o: KitchenOrder) => {
    const late = o.readyAt ? Date.now() > new Date(o.readyAt).getTime() && o.status !== "ready" : false;
    const minsLeft = o.readyAt ? Math.ceil((new Date(o.readyAt).getTime() - now) / 60_000) : null;
    const nextLabel = { confirmed: "Pradėti ruošti", preparing: "Paruošta", ready: "Išduota" }[o.status];
    return (
      <div className={`k-card ${late ? "k-late" : ""}`} key={o.id}>
        <div className="k-card-head">
          <span className="k-num">{o.number}</span>
          <span className={`k-tag k-tag-${o.status}`}>{o.statusLabel}</span>
          <PayChip o={o} />
          {o.type === "pickup" ? (
            <span className={`k-eta ${late ? "k-eta-late" : ""}`}>
              {o.readyAt
                ? minsLeft !== null && minsLeft > 0
                  ? `Paruošta per ~${minsLeft} min (${fmtTime(o.readyAt)})`
                  : `Vėluoja — buvo ${fmtTime(o.readyAt)}`
                : "Nenustatytas laikas"}
            </span>
          ) : (
            <span className="k-eta">📅 {o.resDate} · {o.resTime}</span>
          )}
        </div>
        <div className="k-customer">{o.customerName}</div>
        <OrderLines o={o} />
        {o.type === "pickup" && <PrepRow o={o} />}
        <div className="k-actions">
          {nextLabel && <button className="k-btn k-btn-next" onClick={() => nextStatus(o)}>{nextLabel} →</button>}
          {o.status === "confirmed" && <button className="k-btn k-btn-decline" onClick={() => decline(o)}>✕ Atmesti</button>}
        </div>
      </div>
    );
  };

  /* ---------- layouts ---------- */

  return (
    <div className={`kitchen-root ${embedded ? "k-embedded" : ""}`}>
      <header className="k-topbar">
        <div className="k-brand">🔥 Virtuvės skydelis</div>
        <span className={`k-live k-live-${live}`} title={live === "live" ? "Realiojo laiko ryšys (SSE)" : "Atnaujinama kas 9 sek."}>
          <span className="k-live-dot" />
          {live === "live" ? "LIVE" : live === "connecting" ? "…" : "9s"}
        </span>
        <div className="k-stats">
          <span>Šiandien: <b>{data?.today.count ?? 0}</b></span>
          <span>Baigta: <b>{data?.today.done ?? 0}</b></span>
          <span className="k-rev">⚙ {data?.today.revenue?.toFixed(2) ?? "0.00"} €</span>
        </div>
        <button className={`k-mute ${muted ? "k-muted" : ""}`} onClick={toggleMute} title="Garso jungiklis">
          {muted ? "🔇" : "🔔"}
        </button>
      </header>

      {hasIncoming && !embedded && (
        <section className="k-takeover" role="alert">
          <div className="k-takeover-head">
            <span className="k-pulse" /> NAUJI UŽSAKYMAI — PRIIMKITE
          </div>
          <div className="k-grid">{data!.incoming.map(incomingCard)}</div>
        </section>
      )}

      {hasIncoming && embedded && <div className="k-grid k-grid-embedded">{data!.incoming.map(incomingCard)}</div>}

      <section className="k-section">
        <h2 className="k-h2">Aktyvūs ({data?.active.length ?? 0})</h2>
        {data?.active.length ? (
          <div className="k-grid">{data.active.map(activeCard)}</div>
        ) : (
          <p className="k-empty">Nėra aktyvių užsakymų — laukiame naujų 🍽</p>
        )}
      </section>
    </div>
  );
}
