'use client';
import { Card, Field, ImagePicker } from './ui';

type Props = { content: any; update: (path: string, value: any) => void; area?:string };
export function ManagedContentEditor({ content, update, area }: Props) {
  function setRow(key: string, index: number, patch: Record<string, unknown>) {
    update(key, (content[key] || []).map((row: any, i: number) => i === index ? { ...row, ...patch } : row));
  }
  function actions(key: string, index: number) {
    const rows = content[key] || [];
    return <div className="adm-rowbtns">
      <button disabled={!index} onClick={() => { const next = [...rows]; [next[index-1], next[index]] = [next[index], next[index-1]]; update(key,next); }}>↑</button>
      <button disabled={index === rows.length-1} onClick={() => { const next=[...rows]; [next[index],next[index+1]]=[next[index+1],next[index]]; update(key,next); }}>↓</button>
      <button className="danger" onClick={() => { if (confirm('Pašalinti įrašą? Navigacijos nuorodos pašalinimas neištrina puslapio.')) update(key,rows.filter((_: any,i: number) => i !== index)); }}>Šalinti</button>
    </div>;
  }
  function text(key: string, index: number, field: string, label: string, type='text', multi=false) {
    const row=content[key][index];
    return <Field label={label}>{multi ? <textarea rows={4} value={row[field] || ''} onChange={e => setRow(key,index,{ [field]: e.target.value })} /> : <input type={type} value={row[field] || ''} onChange={e => setRow(key,index,{ [field]:e.target.value })} />}</Field>;
  }
  function visible(key: string, index: number, field: string, label: string) {
    return <label style={{ display: 'block', padding: '12px 0' }}><input type="checkbox" checked={content[key][index][field] === true} onChange={e => setRow(key,index,{ [field]:e.target.checked })} /> {label}</label>;
  }
  return <>
    {(!area || area === 'visibility') && (<Card title="Esamų skyrių matomumas">
      {Object.entries({ hero:'Pagrindinė antraštė',proof:'Praktiniai akcentai',about:'Apie restoraną',social:'Atsiliepimai',hub:'Papildomų skilčių kortelės',wolt:'Pristatymas',visitor:'Informacija lankytojams' }).map(([key,label]) => <label key={key}><input type="checkbox" checked={content.visibility?.[key] !== false} onChange={e => update(`visibility.${key}`,e.target.checked)} /> {label}</label>)}
    </Card>)}
    {(!area || area === 'navigation') && (<Card title="Navigacija">
      <p className="adm-hint">Eilės tvarka taikoma kompiuterio ir telefono meniu. Tėvinis įrašas gali būti tik aukščiausio lygio. Pašalinus nuorodą, puslapis lieka.</p>
      {(content.navigation || []).map((row: any,i: number) => <fieldset key={row.id} style={{ marginBottom:16 }}><legend>{row.label || 'Nuoroda'}</legend>
        {text('navigation',i,'label','Pavadinimas')}{text('navigation',i,'href','Adresas (pvz., /apie-mus arba #pries-atvykstant)')}
        <Field label="Tėvinis įrašas"><select value={row.parentId || ''} onChange={e => setRow('navigation',i,{ parentId:e.target.value })}><option value="">Aukščiausias lygis</option>{content.navigation.filter((p: any) => p.id !== row.id && !p.parentId).map((p: any) => <option key={p.id} value={p.id}>{p.label}</option>)}</select></Field>
        {visible('navigation',i,'visible','Rodyti navigacijoje')}{actions('navigation',i)}
      </fieldset>)}
      <button onClick={() => update('navigation',[...(content.navigation || []),{ id:`nav-${crypto.randomUUID()}`,label:'Nauja nuoroda',href:'/',parentId:'',visible:true }])}>＋ Nuoroda</button>
    </Card>)}
    {(!area || area === 'events') && (<Card title="Renginiai">
      <p className="adm-hint">Skelbkite tik patvirtinę metus, datą, laiką ir aprašymą. Neišsamūs įrašai lieka juodraščiai. Kiekvienas renginys turi atskirą datą; jie nesikartoja automatiškai.</p>
      {(content.liveEvents || []).map((row: any,i: number) => <fieldset key={row.id} style={{ marginBottom:16 }}><legend>{row.title}</legend>
        {text('liveEvents',i,'title','Pavadinimas')}{text('liveEvents',i,'date','Data su metais','date')}{text('liveEvents',i,'time','Pradžia (Lietuvos laiku)','time')}
        {text('liveEvents',i,'description','Aprašymas','text',true)}{text('liveEvents',i,'draftNote','Vidinė pastaba – viešai nerodoma','text',true)}
        <ImagePicker label="Nuotrauka" value={row.image} onChange={image => setRow('liveEvents',i,{ image })} />
        {text('liveEvents',i,'bookingUrl','Rezervacijos nuoroda')}{visible('liveEvents',i,'published','Skelbti renginį kartu su turiniu')}{actions('liveEvents',i)}
      </fieldset>)}
      <button onClick={() => update('liveEvents',[...(content.liveEvents || []),{ id:`event-${crypto.randomUUID()}`,title:'Naujas renginys',date:'',time:'',description:'',draftNote:'',image:'',bookingUrl:'',published:false }])}>＋ Renginys</button>
    </Card>)}
    {(!area || area === 'pages') && (<Card title="Papildomi puslapio skyriai">
      <p className="adm-hint">Skyriai atsiranda pagrindiniame puslapyje. Nuorodą #identifikatorius galite pridėti navigacijoje. Paslėpimas neištrina turinio.</p>
      {(content.pages || []).map((row: any,i: number) => <fieldset key={row.id} style={{ marginBottom:16 }}><legend>{row.title} · #{row.id}</legend>
        {text('pages',i,'title','Antraštė')}{text('pages',i,'text','Tekstas','text',true)}
        <ImagePicker label="Nuotrauka" value={row.image} onChange={image => setRow('pages',i,{ image })} />
        {text('pages',i,'alt','Alternatyvus nuotraukos tekstas')}{text('pages',i,'ctaLabel','Mygtuko tekstas')}{text('pages',i,'ctaHref','Mygtuko nuoroda')}
        {visible('pages',i,'visible','Rodyti skyrių')}{actions('pages',i)}
      </fieldset>)}
      <button onClick={() => update('pages',[...(content.pages || []),{ id:`page-${crypto.randomUUID()}`,title:'Naujas skyrius',text:'',image:'',alt:'',ctaLabel:'',ctaHref:'',visible:false }])}>＋ Skyrius</button>
    </Card>)}
  </>;
}
