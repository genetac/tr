"use client";

import { cloneElement, isValidElement, useId, useEffect, useState, type ReactElement } from "react";

const TOKEN_KEY = "alma_admin_token";

export function getToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function setToken(t: string) {
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    // storage blocked — cookie auth still works in normal contexts
  }
}

export async function api<T = unknown>(url: string, options?: RequestInit): Promise<T> {
  const token = getToken();
  const base: Record<string, string> =
    options?.body instanceof FormData ? {} : { "Content-Type": "application/json" };
  if (token) base["x-admin-token"] = token;
  const res = await fetch(url, { ...options, headers: { ...base, ...(options?.headers || {}) } });
  if (res.status === 401 && typeof window !== "undefined") {
    setToken("");
    window.location.reload();
    throw new Error("unauthorized");
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json as { error?: string }).error || "Įvyko klaida");
  return json as T;
}

export function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  const generatedId=useId();
  const child=isValidElement(children) ? children as ReactElement<{ id?: string; 'aria-describedby'?: string }> : null;
  const id=child?.props.id || generatedId;
  return (
    <div className="adm-field">
      <label htmlFor={id}>{label}</label>
      {child ? cloneElement(child, { id, ...(hint ? { 'aria-describedby': `${id}-hint` } : {}) }) : children}
      {hint && <small id={`${id}-hint`}>{hint}</small>}
    </div>
  );
}

export function Card({ title, children, actions }: { title?: string; children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="adm-card">
      {(title || actions) && (
        <div className="adm-card-head">
          <h3>{title}</h3>
          {actions}
        </div>
      )}
      {children}
    </div>
  );
}

export function ImagePicker({ value, onChange, label, autoOpen=false }: { value: string; onChange: (url: string) => void; label?: string; autoOpen?:boolean }) {
  const [open, setOpen] = useState(autoOpen);
  const [tab, setTab] = useState<"upload" | "library">("upload");
  const [media, setMedia] = useState<{ id: string; url: string; title: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [urlInput, setUrlInput] = useState("");

  useEffect(() => {
    if (open && tab === "library") {
      api<{ media: typeof media }>("/api/admin/media").then((r) => setMedia(r.media)).catch(() => {});
    }
  }, [open, tab]);

  async function upload(files: FileList | null) {
    if (!files || !files.length) return;
    setBusy(true);
    try {
      const fd = new FormData();
      Array.from(files).forEach((f) => fd.append("files", f));
      const r = await api<{ files: { url: string }[] }>("/api/admin/upload", { method: "POST", body: fd });
      if (r.files[0]) {
        onChange(r.files[0].url);
        setOpen(false);
      }
    } catch (e) {
      alert(e instanceof Error ? e.message : "Nepavyko įkelti");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="adm-imagepicker">
      {label && <span className="adm-imagepicker-label">{label}</span>}
      <div className="adm-imagepicker-row">
        <div className="adm-imagepicker-thumb">
          {value ? (
             
            <img src={value} alt="" />
          ) : (
            <span>Nėra</span>
          )}
        </div>
        <div className="adm-imagepicker-actions">
          <button type="button" onClick={() => setOpen(true)}>Keisti nuotrauką</button>
          {value && (
            <button type="button" className="danger" onClick={() => onChange("")}>
              Šalinti
            </button>
          )}
        </div>
      </div>
      {open && (
        <div className="adm-dialog-backdrop" onClick={() => setOpen(false)}>
          <div className="adm-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="adm-dialog-head">
              <h4>Nuotraukos pasirinkimas</h4>
              <button type="button" onClick={() => setOpen(false)}>×</button>
            </div>
            <div className="adm-tabs" style={{ marginBottom: 12 }}>
              <button type="button" className={tab === "upload" ? "active" : ""} onClick={() => setTab("upload")}>Įkelti naują</button>
              <button type="button" className={tab === "library" ? "active" : ""} onClick={() => setTab("library")}>Biblioteka</button>
            </div>
            {tab === "upload" && (
              <div>
                <input type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/avif" multiple onChange={(e) => upload(e.target.files)} disabled={busy} />
                {busy && <p>Įkeliama...</p>}
                <p className="adm-hint">PNG, JPG, WEBP, GIF arba AVIF · iki 8 MB. Nuotraukos išsaugomos svetainės bibliotekoje.</p>
                <div className="adm-field" style={{ marginTop: 14 }}>
                  <span>Arba įklijuokite nuorodą</span>
                  <div style={{ display: "flex", gap: 8 }}>
                    <input value={urlInput} onChange={(e) => setUrlInput(e.target.value)} placeholder="https://..." />
                    <button
                      type="button"
                      onClick={() => {
                        if (urlInput.trim()) {
                          onChange(urlInput.trim());
                          setOpen(false);
                        }
                      }}
                    >
                      Naudoti
                    </button>
                  </div>
                </div>
              </div>
            )}
            {tab === "library" && (
              <div className="adm-media-grid">
                {media.length === 0 && <p className="adm-hint">Biblioteka tuščia — pirmiausia įkelkite nuotrauką.</p>}
                {media.map((m) => (
                  <button
                    type="button"
                    key={m.id} aria-label={`Pasirinkti nuotrauką: ${m.title || m.id}`}
                    className={m.url === value ? "active" : ""}
                    onClick={() => {
                      onChange(m.url);
                      setOpen(false);
                    }}
                  >
                    { }
                    <img src={m.url} alt={m.title} />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" className={`adm-switch ${checked ? "on" : ""}`} onClick={() => onChange(!checked)} role="switch" aria-checked={checked}>
      <span className="adm-switch-track">
        <span className="adm-switch-knob" />
      </span>
      <span>{label}</span>
    </button>
  );
}
