"use client";

import { useState } from "react";
import { setToken } from "./ui";

export function AdminLogin() {
  const [pw, setPw] = useState("");
  const [username,setUsername]=useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw, username }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Klaida");
        return;
      }
      // Keep a fallback token for browser contexts that block cookies
      // (preview frames, strict privacy modes). Cookie still set server-side.
      if (json.token) setToken(String(json.token));
      window.location.reload();
    } catch {
      setError("Serverio klaida");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="adm-login-wrap">
      <form className="adm-login" onSubmit={submit}>
        <div className="adm-login-brand">
          <span>✦</span>
          <strong>Alma Chaab</strong>
          <small>Valdymo sistema</small>
        </div>
        <label><span>Darbuotojo prisijungimas (savininkui palikti tuščią)</span><input autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} /></label>
        <label>
          <span>Slaptažodis</span>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoFocus autoComplete="current-password" />
        </label>
        {error && <div className="adm-login-error">{error}</div>}
        <button type="submit" disabled={busy || !pw}>
          {busy ? "Jungiamasi..." : "Prisijungti"}
        </button>
      </form>
    </div>
  );
}
