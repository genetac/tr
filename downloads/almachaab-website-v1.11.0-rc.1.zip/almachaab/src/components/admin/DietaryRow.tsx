'use client';
import {useCmsDocument} from './use-cms-document';import {DraftToolbar} from './DraftToolbar';import {Field} from './ui';
export function DietaryRow({id,name}:{id:string;name:string}){
 const s=useCmsDocument(`menu:${id}`);const v=s.value;
 if(!v)return <p role="status">{s.error||'Kraunama mitybos informacija…'}</p>;
 const set=(key:string,value:any)=>s.edit({...v,[key]:value});
 return <section className="dietary-row" aria-label={`Mitybos informacija: ${name}`}><h4>{name} — mitybos informacija</h4>
  <label><input type="checkbox" checked={v.dietaryVisible===true} onChange={e=>set('dietaryVisible',e.target.checked)} /> Rodyti mitybos informaciją prie šio patiekalo</label>
  <label><input type="checkbox" checked={v.dietaryReviewed===true} onChange={e=>set('dietaryReviewed',e.target.checked)} /> Informacija patikrinta su virtuve</label>
  <p className="adm-hint">Viešai rodoma tik patikrinta ir paskelbta informacija. Išjungimas neištrina teksto ar žymų. Nepriskirta žyma reiškia „nenurodyta“.</p>
  <div className="adm-toolbar">{([['vegetarian','Vegetariškas'],['vegan','Veganiškas'],['halal','Halal']]as const).map(([key,label])=><label key={key}><input type="checkbox" checked={v[key]===true} onChange={e=>set(key,e.target.checked)} /> {label}</label>)}</div>
  <Field label="Viešas mitybos aprašymas"><textarea maxLength={1000} value={v.dietaryNotes||''} onChange={e=>set('dietaryNotes',e.target.value)} /></Field>
  <label><input type="checkbox" checked={v.dietaryNotesVisible===true} onChange={e=>set('dietaryNotesVisible',e.target.checked)} /> Rodyti šį aprašymą</label>
  <Field label="Vidinė pastaba patikslinimui (viešai nerodoma)"><textarea maxLength={2000} value={v.dietaryInternalNote||''} onChange={e=>set('dietaryInternalNote',e.target.value)} /></Field>
  <div className="adm-card"><strong>Viešo rodymo peržiūra</strong><span>{v.name}</span>{v.dietaryVisible&&v.dietaryReviewed?<><div>{v.vegetarian&&'V · Vegetariškas '}{v.vegan&&'Veganiškas '}{v.halal&&'Halal'}</div>{v.dietaryNotesVisible&&<p>{v.dietaryNotes}</p>}</>:<p>Mitybos informacija paslėpta arba dar nepatikrinta.</p>}</div>
  <DraftToolbar state={s} />
 </section>;
}
export function DietaryDisplaySettings(){const s=useCmsDocument('dietaryDisplay');if(!s.value)return <p>{s.error||'Kraunama…'}</p>;return <details className="adm-card"><summary>Mitybos informacijos rodymas visame meniu</summary><p>Šie nustatymai taikomi patiekalams, kurių informacija patikrinta ir paskelbta.</p>{([['labels','Rodyti mitybos žymas'],['notes','Rodyti patiekalų mitybos aprašymus'],['filters','Rodyti mitybos filtrą']]as const).map(([key,label])=><label key={key}><input type="checkbox" checked={s.value[key]} onChange={e=>s.edit({...s.value,[key]:e.target.checked})}/>{label}</label>)}<DraftToolbar state={s}/></details>;}
