"use client";

import { useEffect, useState } from "react";
import {useCmsDocument} from "./use-cms-document";
import {DraftToolbar} from "./DraftToolbar";
import { api, Field, Card } from "./ui";

interface Theme {
  gold: string;
  gold2: string;
  cream: string;
  cream2: string;
  paper: string;
  ink: string;
  muted: string;
  line: string;
  dark: string;
  radius: number;
  fontHead: string;
  fontBody: string;
}

const FONT_OPTIONS = [
  { label: "Georgia (klasikinis serifas)", value: 'Georgia,"Times New Roman",serif' },
  { label: "Times New Roman", value: '"Times New Roman",Times,serif' },
  { label: "Palatino / knyginis", value: '"Palatino Linotype",Palatino,"Book Antiqua",serif' },
  { label: "System sans (švarus)", value: 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif' },
  { label: "Verdana (aiškus mobiliam)", value: 'Verdana,Geneva,sans-serif' },
  { label: "Trebuchet (draugiškas)", value: '"Trebuchet MS",Tahoma,sans-serif' },
];

const BODY_FONT_OPTIONS = [
  { label: "Inter / system (rekomenduojama)", value: 'Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif' },
  { label: "Helvetica / Arial", value: 'Helvetica,Arial,sans-serif' },
  { label: "Verdana", value: 'Verdana,Geneva,sans-serif' },
  { label: "Georgia (knyginis)", value: 'Georgia,serif' },
];

const COLOR_FIELDS: { key: keyof Theme; label: string; hint: string }[] = [
  { key: "gold", label: "Auksinė (akcentai, mygtukai)", hint: "Naudojama CTA mygtukams, akcentams" },
  { key: "gold2", label: "Šviesi auksinė", hint: "Antriniai akcentai" },
  { key: "cream", label: "Kremo fonas", hint: "Pagrindinis puslapio fonas" },
  { key: "cream2", label: "Šviesus kremas", hint: "Antrinis fonas" },
  { key: "paper", label: "Popierius", hint: "Kortelių fonas" },
  { key: "ink", label: "Tekstas (tamsus)", hint: "Pagrindinio teksto spalva" },
  { key: "muted", label: "Pastabų tekstas", hint: "Antrinio teksto spalva" },
  { key: "line", label: "Linijos / rėmeliai", hint: "Apvadų spalva" },
  { key: "dark", label: "Tamsus fonas", hint: "Tamsios sekcijos" },
];

export function ThemeTab() {
  const state=useCmsDocument('theme');
  const theme=state.value as Theme|null;
  const saving=state.busy;const saved=!state.dirty;
  if(!theme)return <p>{state.error||'Kraunama…'}</p>;
  function upd<K extends keyof Theme>(key:K,value:Theme[K]){state.edit({...theme!,[key]:value});}
  const save=()=>state.save('draft');

  return (
    <div className="adm-tab"><DraftToolbar state={state}/>
      <div className="adm-savebar">
        <span>{saved ? "✓ Juodraštis išsaugotas — viešai keičiasi tik paskelbus" : "Spalvos ir šriftai taikomi visai svetainei"}</span>
        <button className="primary" onClick={save} disabled={saving}>
          {saving ? "Išsaugoma..." : "Išsaugoti juodraštį"}
        </button>
      </div>

      <Card title="Spalvos">
        <div className="adm-colorgrid">
          {COLOR_FIELDS.map((f) => (
            <div key={f.key} className="adm-colorrow">
              <input type="color" value={String(theme[f.key])} onChange={(e) => upd(f.key, e.target.value as never)} />
              <div>
                <span>{f.label}</span>
                <small>
                  {f.hint} · {String(theme[f.key])}
                </small>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Šriftai">
        <Field label="Antraščių šriftas">
          <select value={theme.fontHead} onChange={(e) => upd("fontHead", e.target.value)}>
            {FONT_OPTIONS.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Pagrindinis tekstas">
          <select value={theme.fontBody} onChange={(e) => upd("fontBody", e.target.value)}>
            {BODY_FONT_OPTIONS.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </Field>
      </Card>

      <Card title="Kampų suapvalinimas">
        <Field label={`Radius: ${theme.radius}px`}>
          <input type="range" min="0" max="32" value={theme.radius} onChange={(e) => upd("radius", Number(e.target.value))} />
        </Field>
      </Card>

      <div className="adm-savebar">
        <span>{saved ? "✓ Išsaugota" : ""}</span>
        <button className="primary" onClick={save} disabled={saving}>
          {saving ? "Išsaugoma..." : "Išsaugoti juodraštį"}
        </button>
      </div>
    </div>
  );
}
