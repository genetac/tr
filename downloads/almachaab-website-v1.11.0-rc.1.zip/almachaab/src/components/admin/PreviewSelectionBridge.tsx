'use client';import {useEffect} from 'react';
export function PreviewSelectionBridge(){useEffect(()=>{
 const click=(event:MouseEvent)=>{event.preventDefault();event.stopPropagation();const element=event.target as HTMLElement;const image=element.closest('[data-cms-image]')as HTMLElement|null;const text=element.closest('[data-cms-path]')as HTMLElement|null;const path=image?.dataset.cmsImage||text?.dataset.cmsPath;const block=element.closest('[data-block-id]')as HTMLElement|null;if(block)window.parent.postMessage({type:'alma-preview-block',id:block.dataset.blockId},window.location.origin);if(path)window.parent.postMessage({type:'alma-preview-select',path,image:!!image},window.location.origin);};
 const submit=(event:Event)=>{event.preventDefault();event.stopPropagation();};
 document.addEventListener('click',click,true);document.addEventListener('submit',submit,true);return()=>{document.removeEventListener('click',click,true);document.removeEventListener('submit',submit,true);};
},[]);return <style>{"figure::after,figure::before,.hero::before,.hero::after{pointer-events:none!important}"}</style>;}
