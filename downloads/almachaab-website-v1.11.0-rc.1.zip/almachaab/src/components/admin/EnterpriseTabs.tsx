"use client";

import { useCallback, useEffect, useState } from "react";
import { api, Field, Card, Switch } from "./ui";
import { useLoadEffect, useClientValue } from "@/hooks/use-load-effect";

/* ------------------------------------------------------------------ */
/* Filialai — multi-branch locations                                   */
/* ------------------------------------------------------------------ */

interface LocationRow {
  id: string;
  name: string;
  address: string;
  phone: string;
  isActive: boolean;
  isDefault: boolean;
  taxRate: number | null;
  deliveryFee: number | null;
  sortOrder: number;
  _count?: { orders: number };
}

export function LocationsTab() {
  const [locations, setLocations] = useState<LocationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Partial<LocationRow> | null>(null);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api<{ locations: LocationRow[] }>("/api/admin/locations");
      setLocations(r.locations);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    } finally {
      setLoading(false);
    }
  }, []);

  useLoadEffect(load);

  async function toggleActive(loc: LocationRow) {
    await api("/api/admin/locations", { method: "PUT", body: JSON.stringify({ ...loc, isActive: !loc.isActive }) });
    load();
  }

  async function makeDefault(loc: LocationRow) {
    await api("/api/admin/locations", { method: "PUT", body: JSON.stringify({ ...loc, isDefault: true }) });
    load();
  }

  async function remove(loc: LocationRow) {
    if (!confirm(`Ištrinti filialą „${loc.name}“? Užsakymų istorija liks išsaugota.`)) return;
    await api(`/api/admin/locations?id=${loc.id}`, { method: "DELETE" });
    load();
  }

  return (
    <>
      <Card title="Filialai (adresai)">
        <p className="adm-hint">
          Kiekvienas filialas gali turėti savo PVM tarifą ir pristatymo mokestį (tuščia — naudojami bendri „Mokėjimai ir parduotuvė“ nustatymai).
          Pažymėtas <b>Pagrindinis</b> filialas aptarnauja naujus užsakymus ir rodomas svečiams.
        </p>
        <div className="adm-toolbar">
          <button className="primary" onClick={() => setEditing({ name: "", isActive: true })}>
            ＋ Naujas filialas
          </button>
        </div>
        {loading ? (
          <p className="adm-hint">Kraunama...</p>
        ) : locations.length === 0 ? (
          <p className="adm-hint">Kol kas nėra filialų.</p>
        ) : (
          <div className="adm-list">
            {locations.map((loc) => (
              <div key={loc.id} className={`adm-menuitem ${loc.isActive ? "" : "inactive"}`}>
                <div className="adm-menuitem-info">
                  <strong>
                    {loc.name} {loc.isDefault && <em className="adm-stockcount">· pagrindinis</em>}{" "}
                    {!loc.isActive && <em className="adm-soldout-badge">neaktyvus</em>}
                  </strong>
                  <span>
                    {loc.address || "be adreso"}
                    {loc.taxRate !== null ? ` · PVM ${loc.taxRate}%` : " · PVM pagal bendrus"}
                    {loc.deliveryFee !== null ? ` · pristatymas ${loc.deliveryFee.toFixed(2)} €` : ""}
                    {loc._count?.orders ? ` · ${loc._count.orders} užsakymų` : ""}
                  </span>
                </div>
                <div className="adm-rowbtns">
                  {!loc.isDefault && (
                    <button title="Padaryti pagrindiniu" onClick={() => makeDefault(loc)}>
                      Pagrindinis
                    </button>
                  )}
                  <button onClick={() => toggleActive(loc)}>{loc.isActive ? "Sustabdyti" : "Aktyvuoti"}</button>
                  <button className="primary" onClick={() => setEditing(loc)}>
                    Keisti
                  </button>
                  <button className="danger" onClick={() => remove(loc)}>
                    ×
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        {msg && <div className="adm-note">{msg}</div>}
      </Card>
      {editing && <LocationDialog loc={editing} onClose={() => setEditing(null)} onSaved={load} />}
    </>
  );
}

function LocationDialog({ loc, onClose, onSaved }: { loc: Partial<LocationRow>; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(loc.name || "");
  const [address, setAddress] = useState(loc.address || "");
  const [phone, setPhone] = useState(loc.phone || "");
  const [taxRate, setTaxRate] = useState(loc.taxRate === null || loc.taxRate === undefined ? "" : String(loc.taxRate));
  const [deliveryFee, setDeliveryFee] = useState(loc.deliveryFee === null || loc.deliveryFee === undefined ? "" : String(loc.deliveryFee));
  const [isActive, setIsActive] = useState(loc.isActive ?? true);
  const [isDefault, setIsDefault] = useState(loc.isDefault ?? false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  async function save() {
    setSaving(true);
    setErr("");
    try {
      const body = {
        id: loc.id || "",
        name,
        address,
        phone,
        taxRate: taxRate === "" ? null : Number(taxRate),
        deliveryFee: deliveryFee === "" ? null : Number(deliveryFee),
        isActive,
        isDefault,
      };
      if (loc.id) {
        await api("/api/admin/locations", { method: "PUT", body: JSON.stringify(body) });
      } else {
        await api("/api/admin/locations", { method: "POST", body: JSON.stringify(body) });
      }
      onSaved();
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Klaida");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="adm-dialog-backdrop" onClick={onClose}>
      <div className="adm-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="adm-dialog-head">
          <h4>{loc.id ? "Filialo redagavimas" : "Naujas filialas"}</h4>
          <button onClick={onClose}>×</button>
        </div>
        <Field label="Pavadinimas">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Alma Chaab — Kėdainiai" />
        </Field>
        <Field label="Adresas">
          <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Didžioji g. 25, Kėdainiai" />
        </Field>
        <Field label="Telefonas">
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+370..." />
        </Field>
        <Field label="PVM tarifas (%)" hint="Palikite tuščią, jei taikomas bendras tarifas iš Mokėjimų nustatymų.">
          <input type="number" step="0.1" min="0" max="100" value={taxRate} placeholder="Pagal bendrus" onChange={(e) => setTaxRate(e.target.value)} />
        </Field>
        <Field label="Pristatymo mokestis (€)" hint="Palikite tuščią, jei taikomas bendras mokestis.">
          <input
            type="number"
            step="0.5"
            min="0"
            value={deliveryFee}
            placeholder="Pagal bendrus"
            onChange={(e) => setDeliveryFee(e.target.value)}
          />
        </Field>
        <Switch checked={isActive} onChange={setIsActive} label={isActive ? "Aktyvus" : "Sustabdytas"} />
        <Switch checked={isDefault} onChange={setIsDefault} label="Pagrindinis filialas (naujiems užsakymams)" />
        {err && <div className="adm-note">{err}</div>}
        <button className="primary" disabled={saving || name.trim().length < 2} onClick={save}>
          {saving ? "Išsaugoma..." : "Išsaugoti"}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Lojaluma — points program + rewards catalog                         */
/* ------------------------------------------------------------------ */

interface LoyaltyConfigView {
  enabled: boolean;
  pointsPerEuro: number;
  stampGoal: number;
  welcomeBonus: number;
}
interface RewardRow {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  active: boolean;
}
interface RecentTx {
  id: string;
  type: string;
  points: number;
  note: string;
  createdAt: string;
  profile: { user: { name: string; email: string } };
}

export function LoyaltyTab() {
  const [cfg, setCfg] = useState<LoyaltyConfigView | null>(null);
  const [rewards, setRewards] = useState<RewardRow[]>([]);
  const [stats, setStats] = useState<{ profileCount: number; openVouchers: number }>({ profileCount: 0, openVouchers: 0 });
  const [recent, setRecent] = useState<RecentTx[]>([]);
  const [editing, setEditing] = useState<Partial<RewardRow> | null>(null);
  const [voucher, setVoucher] = useState("");
  const [voucherMsg, setVoucherMsg] = useState("");
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    api<{ config: LoyaltyConfigView; rewards: RewardRow[]; stats: { profileCount: number; openVouchers: number }; recent: RecentTx[] }>(
      "/api/admin/loyalty"
    )
      .then((r) => {
        setCfg(r.config);
        setRewards(r.rewards);
        setStats(r.stats);
        setRecent(r.recent);
      })
      .catch((e) => setMsg(e instanceof Error ? e.message : "Klaida"));
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function saveConfig(patch: Partial<LoyaltyConfigView>) {
    if (!cfg) return;
    try {
      const r = await api<{ config: LoyaltyConfigView }>("/api/admin/loyalty", {
        method: "PUT",
        body: JSON.stringify({ value: { ...cfg, ...patch } }),
      });
      setCfg(r.config);
      setMsg("✓ Išsaugota");
      setTimeout(() => setMsg(""), 2500);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Klaida");
    }
  }

  async function checkVoucher() {
    setVoucherMsg("");
    if (!voucher.trim()) return;
    try {
      await api("/api/admin/loyalty", { method: "POST", body: JSON.stringify({ action: "useVoucher", code: voucher.trim() }) });
      setVoucherMsg("✓ Kuponas panaudotas — prizas išduotas.");
      setVoucher("");
    } catch (e) {
      setVoucherMsg(e instanceof Error ? e.message : "Klaida");
    }
  }

  if (!cfg) return <p className="adm-hint">Kraunama...</p>;

  return (
    <>
      <Card title="Lojalumo programa" actions={msg ? <span className="adm-hint">{msg}</span> : undefined}>
        <Switch
          checked={cfg.enabled}
          onChange={(v) => saveConfig({ enabled: v })}
          label={cfg.enabled ? "Įjungta — klientai renka taškus ir stampus" : "Išjungta — taškai neskiriami"}
        />
        <Field label="Taškai už 1 €" hint="Kiek taškų uždirba klientas už kiekvieną visą eurą.">
          <input
            type="number"
            step="0.5"
            min="0"
            max="100"
            value={cfg.pointsPerEuro}
            onChange={(e) => setCfg({ ...cfg, pointsPerEuro: Number(e.target.value) })}
            onBlur={() => saveConfig({ pointsPerEuro: cfg.pointsPerEuro })}
          />
        </Field>
        <Field label="Stampų kortelės tikslas" hint="Kiek stampų iki nemokamo stampinio prizo. Pilna kortelė persikelia į naują.">
          <input
            type="number"
            min="1"
            max="100"
            value={cfg.stampGoal}
            onChange={(e) => setCfg({ ...cfg, stampGoal: Number(e.target.value) })}
            onBlur={() => saveConfig({ stampGoal: cfg.stampGoal })}
          />
        </Field>
        <Field label="Sveikinimo dovana (taškai)" hint="Pradiniai taškai už paskyros sukūrimą. 0 = išjungta.">
          <input
            type="number"
            min="0"
            max="10000"
            value={cfg.welcomeBonus}
            onChange={(e) => setCfg({ ...cfg, welcomeBonus: Number(e.target.value) })}
            onBlur={() => saveConfig({ welcomeBonus: cfg.welcomeBonus })}
          />
        </Field>
        <p className="adm-hint">
          Statistika: <b>{stats.profileCount}</b> lojalumo profilių · <b>{stats.openVouchers}</b> nepanaudotų kuponų.
        </p>
      </Card>

      <Card title="Prizų katalogas">
        <div className="adm-toolbar">
          <button className="primary" onClick={() => setEditing({ name: "", pointsCost: 50, active: true })}>
            ＋ Naujas prizas
          </button>
        </div>
        <div className="adm-list">
          {rewards.length === 0 && <p className="adm-hint">Kol kas nėra prizų — pridėkite pirmąjį.</p>}
          {rewards.map((r) => (
            <div key={r.id} className={`adm-menuitem ${r.active ? "" : "inactive"}`}>
              <div className="adm-menuitem-info">
                <strong>{r.name}</strong>
                <span>
                  {r.pointsCost} taškų {r.description ? `· ${r.description}` : ""}
                  {!r.active && " · neaktyvus"}
                </span>
              </div>
              <div className="adm-rowbtns">
                <button className="primary" onClick={() => setEditing(r)}>
                  Keisti
                </button>
                <button
                  className="danger"
                  onClick={async () => {
                    if (!confirm(`Ištrinti prizą „${r.name}“?`)) return;
                    await api("/api/admin/loyalty", { method: "POST", body: JSON.stringify({ action: "deleteReward", id: r.id }) });
                    load();
                  }}
                >
                  ×
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Kupono patikrinimas">
        <p className="adm-hint">Klientas atsiėmimo metu parodo kodą — suveskite jį čia, kad prizas būtų pažymėtas kaip išduotas.</p>
        <div style={{ display: "flex", gap: 8 }}>
          <input value={voucher} onChange={(e) => setVoucher(e.target.value.toUpperCase())} placeholder="ALMA-XXXX-XXXX" />
          <button className="primary" onClick={checkVoucher}>
            Panaudoti
          </button>
        </div>
        {voucherMsg && <div className="adm-note">{voucherMsg}</div>}
      </Card>

      <Card title="Paskutinės taškų operacijos">
        {recent.length === 0 ? (
          <p className="adm-hint">Kol kas nėra operacijų.</p>
        ) : (
          <div className="adm-list">
            {recent.map((t) => (
              <div key={t.id} className="adm-menuitem">
                <div className="adm-menuitem-info">
                  <strong>
                    {t.profile?.user?.name || t.profile?.user?.email || "Klientas"} · {t.points > 0 ? `+${t.points}` : t.points} taškų
                  </strong>
                  <span>
                    {t.note} · {new Date(t.createdAt).toLocaleString("lt-LT", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {editing && <RewardDialog reward={editing} onClose={() => setEditing(null)} onSaved={load} />}
    </>
  );
}

function RewardDialog({ reward, onClose, onSaved }: { reward: Partial<RewardRow>; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(reward.name || "");
  const [description, setDescription] = useState(reward.description || "");
  const [pointsCost, setPointsCost] = useState(String(reward.pointsCost ?? 50));
  const [active, setActive] = useState(reward.active ?? true);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  return (
    <div className="adm-dialog-backdrop" onClick={onClose}>
      <div className="adm-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="adm-dialog-head">
          <h4>{reward.id ? "Prizo redagavimas" : "Naujas prizas"}</h4>
          <button onClick={onClose}>×</button>
        </div>
        <Field label="Pavadinimas">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nemokamas gėrimas" />
        </Field>
        <Field label="Aprašymas">
          <textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Trumpas aprašymas klientui" />
        </Field>
        <Field label="Kaina (taškais)">
          <input type="number" min="0" value={pointsCost} onChange={(e) => setPointsCost(e.target.value.replace(/\D/g, ""))} />
        </Field>
        <Switch checked={active} onChange={setActive} label={active ? "Aktyvus — rodomas klientams" : "Neaktyvus"} />
        {err && <div className="adm-note">{err}</div>}
        <button
          className="primary"
          disabled={saving || name.trim().length < 2}
          onClick={async () => {
            setSaving(true);
            setErr("");
            try {
              await api("/api/admin/loyalty", {
                method: "POST",
                body: JSON.stringify({
                  action: "saveReward",
                  id: reward.id || "",
                  name,
                  description,
                  pointsCost: Number(pointsCost) || 0,
                  active,
                }),
              });
              onSaved();
              onClose();
            } catch (e) {
              setErr(e instanceof Error ? e.message : "Klaida");
            } finally {
              setSaving(false);
            }
          }}
        >
          {saving ? "Išsaugoma..." : "Išsaugoti"}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* CRM — dormant-customer win-back campaigns                           */
/* ------------------------------------------------------------------ */

interface DormantRow {
  userId: string;
  name: string;
  email: string;
  lastOrderAt: string | null;
  daysSilent: number;
  hasPush: boolean;
  points: number;
}
interface LastRun {
  at: string;
  days: number;
  targeted: number;
  pushSent: number;
  emailsSent: number;
}

export function CrmTab() {
  const [days, setDays] = useState("14");
  const [message, setMessage] = useState("");
  const [sendEmail, setSendEmail] = useState(true);
  const [preview, setPreview] = useState<{ count: number; pushCount: number; customers: DormantRow[]; lastRun: LastRun | null } | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState("");

  async function loadPreview() {
    setBusy(true);
    setResult("");
    try {
      const r = await api<{ count: number; pushCount: number; customers: DormantRow[]; lastRun: LastRun | null }>(
        `/api/admin/crm/winback?days=${encodeURIComponent(days)}`
      );
      setPreview(r);
    } catch (e) {
      setResult(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy(false);
    }
  }

  async function runCampaign() {
    if (!confirm(`Siųsti grįžimo kampaniją ${preview?.count ?? 0} klientui(-ams)?`)) return;
    setBusy(true);
    setResult("");
    try {
      const r = await api<{ targeted: number; pushSent: number; emailsSent: number }>("/api/admin/crm/winback", {
        method: "POST",
        body: JSON.stringify({ days: Number(days) || 14, message: message.trim() || undefined, sendEmail }),
      });
      setResult(`✓ Kampanija įvykdyta: ${r.targeted} tikslinėms paskyroms, ${r.pushSent} push, ${r.emailsSent} laiškų.`);
      loadPreview();
    } catch (e) {
      setResult(e instanceof Error ? e.message : "Klaida");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Card title="Grįžimo kampanija (CRM)">
        <p className="adm-hint">
          Automatinis priminimas klientams, kurie nebuvo užsakę nustatytą dienų skaičių. Push pranešimai siunčiami tik tiems, kas /mano puslapyje
          įjungė pasiūlymų pranešimus; laiškai — visiems su el. paštu (jei įjungta SMTP).
        </p>
        <Field label="Dienos be užsakymų" hint="14 dienų — standartinis grįžimo ciklas.">
          <input type="number" min="1" max="365" value={days} onChange={(e) => setDays(e.target.value.replace(/\D/g, ""))} />
        </Field>
        <Field label="Žinutė (neprivaloma)" hint="Tuščia — naudojamas numatytas tekstas.">
          <textarea
            rows={3}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ilgai nesimatėm! Jūsų mėgstami skoniai laukia — grįžkite paragauti."
          />
        </Field>
        <Switch checked={sendEmail} onChange={setSendEmail} label={sendEmail ? "Siųsti ir el. laiškus" : "Tik push pranešimai"} />
        <div className="adm-rowbtns" style={{ marginTop: 10 }}>
          <button className="primary" disabled={busy} onClick={loadPreview}>
            {busy ? "Kraunama..." : "Peržiūrėti, kam siųsti"}
          </button>
          <button className="primary" disabled={busy || !preview || preview.count === 0} onClick={runCampaign}>
            Siųsti kampaniją
          </button>
        </div>
        {result && <div className="adm-note">{result}</div>}
        {preview?.lastRun && (
          <p className="adm-hint">
            Paskutinė kampanija: {new Date(preview.lastRun.at).toLocaleString("lt-LT")} · {preview.lastRun.targeted} paskyrų ·{" "}
            {preview.lastRun.pushSent} push · {preview.lastRun.emailsSent} laiškų.
          </p>
        )}
      </Card>

      {preview && (
        <Card title={`Nebesimatantys klientai (${preview.count})`}>
          {preview.count === 0 ? (
            <p className="adm-hint">Visi klientai aktyvūs — kampanijai siųsti nėra kam.</p>
          ) : (
            <div className="adm-list">
              {preview.customers.map((c) => (
                <div key={c.userId} className="adm-menuitem">
                  <div className="adm-menuitem-info">
                    <strong>{c.name || c.email}</strong>
                    <span>
                      {c.email} · tylioji {c.daysSilent} d. {c.lastOrderAt ? `· pask. užsakymas ${new Date(c.lastOrderAt).toLocaleDateString("lt-LT")}` : "· dar be užsakymų"}
                      {c.points > 0 ? ` · ${c.points} taškų` : ""}
                      {c.hasPush ? " · ✓ push" : ""}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </>
  );
}
