"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "./ui";
import { useLoadEffect, useClientValue } from "@/hooks/use-load-effect";

export interface OrderRow {
  id: string;
  number: string;
  type: string;
  status: string;
  statusLabel: string;
  customerName: string;
  phone: string;
  email: string;
  items: { name: string; qty: number; price: number }[];
  total: number;
  pickupTime: string;
  resDate: string;
  resTime: string;
  guests: number;
  experiences: string;
  note: string;
  isRead: boolean;
  paymentStatus: string; // unpaid | paid
  paymentMethod: string; // "" | stripe | paypal | venue
  locationName?: string;
  history: { status: string; at: string; emailSent?: { ok: boolean }; email?: { ok: boolean } }[];
  createdAt: string;
}

const STATUS_FLOW: Record<string, { to: string; label: string; cls: string }[]> = {
  pickup: [
    { to: "confirmed", label: "Patvirtinti", cls: "green" },
    { to: "preparing", label: "Ruošti", cls: "violet" },
    { to: "ready", label: "Paruošta", cls: "green" },
    { to: "completed", label: "Užbaigti", cls: "gray" },
    { to: "cancelled", label: "Atšaukti", cls: "red" },
  ],
  reservation: [
    { to: "confirmed", label: "Patvirtinti", cls: "green" },
    { to: "completed", label: "Užbaigti", cls: "gray" },
    { to: "cancelled", label: "Atšaukti", cls: "red" },
  ],
};

const STATUS_FILTERS = [
  { v: "all", label: "Visi" },
  { v: "new", label: "Nauji" },
  { v: "awaiting", label: "Laukiama patv." },
  { v: "confirmed", label: "Patvirtinti" },
  { v: "preparing", label: "Ruošiami" },
  { v: "ready", label: "Paruošti" },
  { v: "completed", label: "Užbaigti" },
  { v: "cancelled", label: "Atšaukti" },
];

function eur(v: number) {
  return v.toFixed(2).replace(".", ",") + " €";
}
function fmtDate(iso: string) {
  return new Date(iso).toLocaleString("lt-LT", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export function OrdersTab({ type }: { type: "pickup" | "reservation" }) {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [status, setStatus] = useState("all");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<OrderRow | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api<{ orders: OrderRow[] }>(`/api/admin/orders?type=${type}&status=${status}`);
      setOrders(r.orders);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [type, status]);

  useLoadEffect(load, 20000);

  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        const qq = q.trim().toLowerCase();
        if (!qq) return true;
        return o.number.toLowerCase().includes(qq) || o.customerName.toLowerCase().includes(qq) || o.phone.toLowerCase().includes(qq);
      }),
    [orders, q]
  );

  async function changeStatus(o: OrderRow, to: string) {
    try {
      await api(`/api/admin/orders/${o.id}`, { method: "PATCH", body: JSON.stringify({ status: to }) });
      setSelected(null);
      load();
    } catch (e) {
      alert(e instanceof Error ? e.message : "Klaida");
    }
  }

  /** Money collected in person (cash / card terminal) → same funnel as online payments. */
  async function markPaid(o: OrderRow) {
    try {
      await api(`/api/admin/orders/${o.id}`, { method: "PATCH", body: JSON.stringify({ paid: true }) });
      setSelected(null);
      load();
    } catch (e) {
      alert(e instanceof Error ? e.message : "Klaida");
    }
  }

  return (
    <div className="adm-tab">
      <div className="adm-toolbar">
        <div className="adm-chiprow">
          {STATUS_FILTERS.map((f) => (
            <button key={f.v} className={`chip ${status === f.v ? "active" : ""}`} onClick={() => setStatus(f.v)}>
              {f.label}
            </button>
          ))}
        </div>
        <input className="adm-search" placeholder="Paieška: numeris, vardas, telefonas..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {loading && orders.length === 0 ? (
        <p className="adm-hint">Kraunama...</p>
      ) : filtered.length === 0 ? (
        <p className="adm-hint">Įrašų nėra.</p>
      ) : (
        <div className="adm-list">
          {filtered.map((o) => {
            const next = (STATUS_FLOW[o.type] || []).filter((s) => {
              const order1 = ["new", "awaiting", "confirmed", "preparing", "ready", "completed"];
              return order1.indexOf(s.to) > order1.indexOf(o.status);
            });
            return (
              <button key={o.id} className={`adm-row ${o.isRead ? "" : "unread"}`} onClick={() => setSelected(o)}>
                <div className="adm-row-top">
                  <strong>#{o.number}</strong>
                  <span className={`badge st-${o.status}`}>{o.statusLabel}</span>
                  {o.paymentStatus === "paid" ? (
                    <span className="badge st-paid">Apmokėta</span>
                  ) : o.total > 0 && o.status !== "cancelled" ? (
                    <span className="badge st-unpaid">Neapmokėta</span>
                  ) : null}
                </div>
                <div className="adm-row-mid">
                  <span>{o.customerName} · {o.phone}</span>
                  <b>{o.total > 0 ? eur(o.total) : ""}</b>
                </div>
                <div className="adm-row-sub">
                  {o.type === "pickup" ? `Atsiėmimas: ${o.pickupTime || "—"}` : `${o.resDate} ${o.resTime} · ${o.guests} svečiai`} · {fmtDate(o.createdAt)}
                  {o.type === "reservation" && o.experiences ? ` · ${o.experiences}` : ""}
                  {o.locationName ? ` · 📍 ${o.locationName}` : ""}
                </div>
                {o.isRead === false && (
                  <div className="adm-row-actions" onClick={(e) => e.stopPropagation()}>
                    {(next || []).slice(0, 2).map((s) => (
                      <button key={s.to} className={`mini ${s.cls}`} onClick={() => changeStatus(o, s.to)}>
                        {s.label}
                      </button>
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <div className="adm-dialog-backdrop" onClick={() => setSelected(null)}>
          <div className="adm-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="adm-dialog-head">
              <h4>
                #{selected.number} — {selected.type === "pickup" ? "Atsiėmimas" : "Rezervacija"}
              </h4>
              <button onClick={() => setSelected(null)}>×</button>
            </div>
            <div className="adm-detail">
              <div className="adm-detail-grid">
                <div>
                  <span>Klientas</span>
                  <strong>{selected.customerName}</strong>
                </div>
                <div>
                  <span>Telefonas</span>
                  <a href={`tel:${selected.phone}`}>
                    <strong>{selected.phone}</strong>
                  </a>
                </div>
                <div>
                  <span>El. paštas</span>
                  <strong>{selected.email || "—"}</strong>
                </div>
                {selected.type === "pickup" ? (
                  <div>
                    <span>Atsiėmimo laikas</span>
                    <strong>{selected.pickupTime || "—"}</strong>
                  </div>
                ) : (
                  <>
                    <div>
                      <span>Data ir laikas</span>
                      <strong>
                        {selected.resDate} {selected.resTime}
                      </strong>
                    </div>
                    <div>
                      <span>Svečiai</span>
                      <strong>{selected.guests}</strong>
                    </div>
                  </>
                )}
              </div>
              {selected.experiences && (
                <p>
                  <b>Patirtys:</b> {selected.experiences}
                </p>
              )}
              {selected.items.length > 0 && (
                <div className="adm-detail-items">
                  {selected.items.map((i, idx) => (
                    <div key={idx}>
                      <span>
                        {i.name} × {i.qty}
                      </span>
                      <b>{eur(i.price * i.qty)}</b>
                    </div>
                  ))}
                  <div className="adm-detail-total">
                    <span>Suma</span>
                    <b>{eur(selected.total)}</b>
                  </div>
                </div>
              )}
              {selected.note && (
                <p>
                  <b>Pastaba:</b> {selected.note}
                </p>
              )}
              <div className="adm-status-actions">
                {(STATUS_FLOW[selected.type] || []).map((s) => (
                  <button key={s.to} className={`mini ${s.cls} ${selected.status === s.to ? "current" : ""}`} onClick={() => changeStatus(selected, s.to)} disabled={selected.status === s.to}>
                    {selected.status === s.to ? `Dabartinė: ${s.label}` : s.label}
                  </button>
                ))}
              </div>
              {selected.paymentStatus !== "paid" && selected.total > 0 && selected.status !== "cancelled" && (
                <div className="adm-status-actions">
                  <button className="mini green" onClick={() => markPaid(selected)}>
                    ✓ Apmokėta (grynieji / vietoje)
                  </button>
                </div>
              )}
              <div className="adm-history">
                <b>Istorija</b>
                {selected.history.map((h, i) => (
                  <div key={i} className="adm-history-line">
                    <span>{fmtDate(h.at)}</span>
                    <span>{h.status}</span>
                    {h.emailSent?.ok || h.email?.ok ? <em>✓ laiškas išsiųstas</em> : null}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
