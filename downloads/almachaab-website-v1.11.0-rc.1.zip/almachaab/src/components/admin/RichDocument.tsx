'use client';
import {MDXEditor,headingsPlugin,listsPlugin,quotePlugin,linkPlugin,linkDialogPlugin,imagePlugin,thematicBreakPlugin,markdownShortcutPlugin,toolbarPlugin,UndoRedo,BoldItalicUnderlineToggles,BlockTypeSelect,ListsToggle,CreateLink,InsertImage,InsertThematicBreak} from '@mdxeditor/editor';
import '@mdxeditor/editor/style.css';import {api} from './ui';import {useEffect,useRef} from 'react';import type {MDXEditorMethods} from '@mdxeditor/editor';
export default function RichDocument({markdown,onChange}:{markdown:string;onChange:(value:string)=>void}){
 const editor=useRef<MDXEditorMethods>(null);
 useEffect(()=>{if(editor.current&&editor.current.getMarkdown()!==markdown)editor.current.setMarkdown(markdown);},[markdown]);
 return <MDXEditor translation={(_key,value)=>({
 'Undo':'Atšaukti','Redo':'Pakartoti','Bold':'Paryškintas','Italic':'Kursyvas','Underline':'Pabrauktas','Paragraph':'Pastraipa','Heading 1':'Antraštė 1','Heading 2':'Antraštė 2','Heading 3':'Antraštė 3','Bulleted list':'Sąrašas su ženkleliais','Numbered list':'Numeruotas sąrašas','Insert image':'Įterpti nuotrauką','Insert Image':'Įterpti nuotrauką','Image URL':'Nuotraukos nuoroda','Alt text':'Alternatyvus tekstas','Title':'Pavadinimas','Save':'Išsaugoti','Cancel':'Atšaukti','Delete':'Šalinti','Link':'Nuoroda','Create link':'Įterpti nuorodą','URL':'Adresas','Insert thematic break':'Įterpti skirtuką'
 }as Record<string,string>)[value]||value} ref={editor} markdown={markdown} onChange={onChange} contentEditableClassName="cms-writing-surface" plugins={[
 headingsPlugin(),listsPlugin(),quotePlugin(),linkPlugin(),linkDialogPlugin(),imagePlugin({imageUploadHandler:async file=>{const body=new FormData();body.append('files',file);const r=await api<any>('/api/admin/upload',{method:'POST',body});return r.files[0].url;}}),thematicBreakPlugin(),markdownShortcutPlugin(),toolbarPlugin({toolbarContents:()=> <><UndoRedo/><BoldItalicUnderlineToggles/><BlockTypeSelect/><ListsToggle/><CreateLink/><InsertImage/><InsertThematicBreak/></>})
 ]}/>;
}
