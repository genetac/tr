"use client";
import {DocumentList} from './DocumentEditor';
export function ArticlesTab(){return <DocumentList kind="article"/>;}
