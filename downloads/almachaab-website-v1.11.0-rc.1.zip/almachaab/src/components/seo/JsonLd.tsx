/**
 * Centralized JSON-LD structured data renderer (server component).
 *
 * Single source of truth for <script type="application/ld+json"> tags so the
 * site can never accidentally emit duplicates with different escaping rules.
 * Usage:
 *   <JsonLd data={restaurantJsonLd(site, rating, hours)} />
 *   <JsonLd data={[restaurantJsonLd(...), faqJsonLd(faq)]} />  // multiple docs
 */
export function JsonLd({ data }: { data: Record<string, unknown> | Record<string, unknown>[] }) {
  // "<" is escaped so a "</script>" sequence inside DB-driven strings
  // can never terminate the tag early (JSON-LD spec + XSS hardening).
  const json = JSON.stringify(data).replace(/</g, "\\u003c");
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json }} />;
}
