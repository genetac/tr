import { NextRequest, NextResponse } from "next/server";

/**
 * CSRF origin check (review fix #6): browser cross-site POSTs carry an Origin
 * header from another host — reject those. Non-browser requests (Stripe /
 * PayPal webhooks, server-to-server, curl) send no Origin and pass.
 * Combined with SameSite=Lax session cookies this closes cross-site form CSRF.
 *
 * Next 16: the file convention is proxy.ts with a named `proxy` export
 * (the old middleware.ts name prints a deprecation warning).
 */
export function proxy(req: NextRequest) {
  if (req.method === "POST" || req.method === "PUT" || req.method === "PATCH" || req.method === "DELETE") {
    const origin = req.headers.get("origin");
    if (origin) {
      const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "";
      try {
        if (new URL(origin).host !== host) {
          return new NextResponse(JSON.stringify({ error: "bad-origin" }), {
            status: 403,
            headers: { "content-type": "application/json" },
          });
        }
      } catch {
        return new NextResponse(JSON.stringify({ error: "bad-origin" }), {
          status: 403,
          headers: { "content-type": "application/json" },
        });
      }
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/api/:path*"],
};
