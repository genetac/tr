import webpush from "web-push";
import { db } from "./db";
import { getSetting, setSetting } from "./settings";
import { decryptSecret } from "./vault";

// VAPID keys identify our server to push services. Generated once, stored in the
// Setting table so they survive restarts and are included in DB backups.
let cachedKeys: { publicKey: string; privateKey: string } | null = null;

export async function ensureVapid(): Promise<{ publicKey: string; privateKey: string }> {
  if (cachedKeys) return cachedKeys;
  let keys = await getSetting<{ publicKey: string; privateKey: string }>("vapid");
  // SEC-008: the private key is stored encrypted (setSetting) — decrypt it;
  // an unreadable key (new APP_SECRET_KEY) means a fresh pair is generated.
  if (keys?.privateKey) keys = { ...keys, privateKey: decryptSecret(keys.privateKey) };
  if (!keys?.publicKey || !keys?.privateKey) {
    keys = webpush.generateVAPIDKeys();
    await setSetting("vapid", keys);
  }
  webpush.setVapidDetails("mailto:info@almachaab.lt", keys.publicKey, keys.privateKey);
  cachedKeys = keys;
  return keys;
}

export interface PushPayload {
  title: string;
  body: string;
  tag?: string;
  url?: string;
  orderId?: string;
}

export interface PushResult {
  sent: number;
  removed: number;
}

// Send a push to every subscribed owner device. Stale subscriptions (device
// uninstalled the app, browser cleared data) return 404/410 and are pruned.
export async function sendPushToAll(payload: PushPayload): Promise<PushResult> {
  await ensureVapid();
  const subs = await db.pushSubscription.findMany({ where: { audience: "owner" } });
  let sent = 0;
  let removed = 0;
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload),
          { TTL: 3600 }
        );
        sent++;
      } catch (err: unknown) {
        const code = (err as { statusCode?: number })?.statusCode;
        if (code === 404 || code === 410) {
          await db.pushSubscription.delete({ where: { id: s.id } }).catch(() => {});
          removed++;
        }
      }
    })
  );
  return { sent, removed };
}

/** Push to one customer's opted-in devices (loyalty award, win-back). */
export async function sendPushToUser(userId: string, payload: PushPayload): Promise<PushResult> {
  await ensureVapid();
  const subs = await db.pushSubscription.findMany({ where: { userId, audience: "customer" } });
  let sent = 0;
  let removed = 0;
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload),
          { TTL: 3600 * 24 }
        );
        sent++;
      } catch (err: unknown) {
        const code = (err as { statusCode?: number })?.statusCode;
        if (code === 404 || code === 410) {
          await db.pushSubscription.delete({ where: { id: s.id } }).catch(() => {});
          removed++;
        }
      }
    })
  );
  return { sent, removed };
}
