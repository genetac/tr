import { createHmac, timingSafeEqual, randomBytes, scryptSync } from "crypto";
import { cookies, headers } from "next/headers";
import { db } from "./db";
import { getSettings } from "./settings";

/**
 * Customer (guest) account sessions — separate from the admin session.
 * HMAC-signed token cookie `alma_user`, salted scrypt password hashes.
 */

const COOKIE = "alma_user";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 days

export interface SafeUser {
  id: string;
  email: string;
  name: string;
  phone: string;
}

export function hashUserPassword(pw: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(pw, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyUserPassword(pw: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(pw, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return timingSafeEqual(candidate, expected);
}

async function sign(payload: string): Promise<string> {
  const s = await getSettings();
  // SEC-001: never sign with an empty / short key (getSettings rotates it).
  if (!s.admin.secret || s.admin.secret.length < 32) throw new Error("customer session secret unavailable");
  return createHmac("sha256", `${s.admin.secret}|customer`).update(payload).digest("hex");
}

export async function createUserToken(userId: string): Promise<string> {
  const payload = `user.${userId}.${Date.now()}`;
  return `${payload}.${await sign(payload)}`;
}

/** Returns the userId encoded in a valid, unexpired token — else null. */
export async function verifyUserToken(token: string | undefined | null): Promise<string | null> {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 4) return null;
  const [role, userId, ts, sig] = parts;
  if (role !== "user" || !userId) return null;
  const expected = await sign(`${role}.${userId}.${ts}`);
  try {
    if (!timingSafeEqual(Buffer.from(sig, "hex"), Buffer.from(expected, "hex"))) return null;
  } catch {
    return null;
  }
  const age = Date.now() - Number(ts);
  if (!Number.isFinite(age) || age < 0 || age > MAX_AGE * 1000) return null;
  return userId;
}

export async function setUserCookie(userId: string) {
  const token = await createUserToken(userId);
  const jar = await cookies();
  const h = await headers();
  const proto = (h.get("x-forwarded-proto") || "").split(",")[0].trim();
  const isHttps = proto === "https";
  jar.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax", // SEC-013: Lax on every origin (OAuth bridge is a top-level GET, which Lax allows)
    secure: isHttps,
    path: "/",
    maxAge: MAX_AGE,
  });
}

/**
 * Same cookie as setUserCookie, but returned as a raw Set-Cookie header value —
 * used by the social sign-in bridge, which redirects with its own NextResponse
 * (the next/headers cookie store is not guaranteed to merge into custom responses).
 */
export async function userCookieHeaderValue(userId: string, isHttps: boolean): Promise<string> {
  const token = await createUserToken(userId);
  const attrs = [
    `${COOKIE}=${token}`,
    "Path=/",
    "HttpOnly",
    `Max-Age=${MAX_AGE}`,
    isHttps ? "Secure" : "",
    "SameSite=Lax", // SEC-013
  ].filter(Boolean);
  return attrs.join("; ");
}

export async function clearUserCookie() {
  const jar = await cookies();
  jar.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/** Current customer (or null). Reads the cookie only — no header fallback needed. */
export async function getCurrentUser(): Promise<SafeUser | null> {
  const jar = await cookies();
  const userId = await verifyUserToken(jar.get(COOKIE)?.value);
  if (!userId) return null;
  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) return null;
  return { id: user.id, email: user.email, name: user.name, phone: user.phone };
}
