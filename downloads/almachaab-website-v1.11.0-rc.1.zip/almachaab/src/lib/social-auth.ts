import { createHash, createHmac, timingSafeEqual } from "crypto";
import { db } from "./db";
import { getStoreSettings, isPlaceholderCredential } from "./settings";
import { ensureProfile, grantWelcomeBonus, getLoyaltyConfig } from "./loyalty";

/**
 * Social sign-in plumbing shared by the NextAuth providers (Google / Facebook)
 * and the custom Telegram Login Widget endpoint.
 *
 * Provisioning rule: the email address is the account identity. A social
 * sign-in links to the existing User row (keeping orders, loyalty points,
 * push subscriptions and stamps intact) or creates a new one — passwordless.
 */

export interface SocialProviderConfig {
  google: { enabled: boolean; clientId: string; clientSecret: string };
  facebook: { enabled: boolean; clientId: string; clientSecret: string };
  telegram: { enabled: boolean; botToken: string; botUsername: string };
}

/** Merged config: DB (admin-managed) wins over .env fallbacks. */
export async function getSocialConfig(): Promise<SocialProviderConfig> {
  const s = await getStoreSettings();
  // A provider is ON only when enabled AND the credentials are real —
  // placeholders (000000…, demo ids) never render a live button (v1.4 §C).
  const googleId = s.googleClientId || process.env.GOOGLE_CLIENT_ID || "";
  const googleSecret = s.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET || "";
  const facebookId = s.facebookClientId || process.env.FACEBOOK_CLIENT_ID || "";
  const facebookSecret = s.facebookClientSecret || process.env.FACEBOOK_CLIENT_SECRET || "";
  const telegramToken = s.telegramBotToken || process.env.TELEGRAM_BOT_TOKEN || "";
  const telegramUser = s.telegramBotUsername || process.env.TELEGRAM_BOT_USERNAME || "";
  return {
    google: {
      enabled: s.googleEnabled && !isPlaceholderCredential(googleId) && !isPlaceholderCredential(googleSecret),
      clientId: isPlaceholderCredential(googleId) ? "" : googleId,
      clientSecret: isPlaceholderCredential(googleSecret) ? "" : googleSecret,
    },
    facebook: {
      enabled: s.facebookEnabled && !isPlaceholderCredential(facebookId) && !isPlaceholderCredential(facebookSecret),
      clientId: isPlaceholderCredential(facebookId) ? "" : facebookId,
      clientSecret: isPlaceholderCredential(facebookSecret) ? "" : facebookSecret,
    },
    telegram: {
      enabled: s.telegramEnabled && !isPlaceholderCredential(telegramToken) && !isPlaceholderCredential(telegramUser),
      botToken: isPlaceholderCredential(telegramToken) ? "" : telegramToken,
      botUsername: isPlaceholderCredential(telegramUser) ? "" : telegramUser,
    },
  };
}

export interface PublicSocialConfig {
  google: boolean;
  facebook: boolean;
  telegram: boolean;
  telegramBot: string;
  /** Set by the caller (social-config route) after the cached getMe check. */
  telegramBotActive?: boolean;
}

/** Public-safe projection — flags + bot username only, never secrets. */
export function publicSocialConfig(cfg: SocialProviderConfig): PublicSocialConfig {
  return {
    google: cfg.google.enabled && Boolean(cfg.google.clientId && cfg.google.clientSecret),
    facebook: cfg.facebook.enabled && Boolean(cfg.facebook.clientId && cfg.facebook.clientSecret),
    telegram: cfg.telegram.enabled && Boolean(cfg.telegram.botToken && cfg.telegram.botUsername),
    telegramBot: cfg.telegram.botUsername,
  };
}

/* ---------------- Telegram bot liveness (cached) ---------------- */

interface TgBotCheck {
  key: string;
  active: boolean;
  checkedAt: number;
}
let tgBotCheck: TgBotCheck | null = null;
const TG_BOT_CHECK_TTL = 10 * 60 * 1000; // 10 min — admins flip creds rarely, page loads often

/**
 * True only when the bot token is real AND its Telegram username matches the
 * configured one (getMe). Drives the /mano placeholder: an unregistered or
 * mismatched bot shows "dar neaktyvuota" instead of Telegram's own widget error.
 * Result is cached per token+username pair, so page loads stay fast.
 */
export async function telegramBotActive(botToken: string, botUsername: string): Promise<boolean> {
  if (!botToken || !botUsername) return false;
  const key = `${botToken}:${botUsername.toLowerCase()}`;
  if (tgBotCheck && tgBotCheck.key === key && Date.now() - tgBotCheck.checkedAt < TG_BOT_CHECK_TTL) {
    return tgBotCheck.active;
  }
  let active = false;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000);
    const res = await fetch(`https://api.telegram.org/bot${botToken}/getMe`, {
      signal: ctrl.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (res.ok) {
      const j = (await res.json()) as { ok?: boolean; result?: { username?: string } };
      active = Boolean(j?.ok && j.result?.username && j.result.username.toLowerCase() === botUsername.toLowerCase());
    }
  } catch {
    active = false; // unreachable network / bad token / timeout → treat as inactive
  }
  tgBotCheck = { key, active, checkedAt: Date.now() };
  return active;
}

export interface SocialProfile {
  provider: "google" | "facebook" | "telegram";
  providerAccountId: string;
  email: string;
  name?: string;
  image?: string;
}

/**
 * Find-or-create the User for a social profile and record the provider link.
 * Existing customers keep everything: orders, loyalty points, stamps, push.
 */
export async function upsertSocialUser(p: SocialProfile) {
  const email = p.email.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    throw new Error("invalid-email");
  }

  let user = await db.user.findUnique({ where: { email } });

  if (!user) {
    user = await db.user.create({
      data: {
        email,
        name: (p.name || "").slice(0, 80),
        image: (p.image || "").slice(0, 500),
        // passwordHash stays null — social-only account
      },
    });
  } else if (p.name && !user.name && p.name !== user.name) {
    // Backfill the name for accounts created without one (e.g. password first).
    await db.user.update({ where: { id: user.id }, data: { name: p.name.slice(0, 80) } });
  }

  // Record / refresh the provider link (unique per provider + account id).
  await linkProviderAccount(user.id, p.provider, p.providerAccountId);

  // Loyalty: profile + optional welcome bonus, same as email registration.
  // grantWelcomeBonus is idempotent (dedupes on the "welcome" ledger type).
  const cfg = await getLoyaltyConfig().catch(() => null);
  if (cfg?.enabled) {
    await ensureProfile(user.id).catch(() => null);
    await grantWelcomeBonus(user.id).catch(() => null);
  }

  return user;
}

/**
 * Attach (or move) a provider link to an existing user row. The unique
 * [provider, providerAccountId] constraint means a provider identity belongs
 * to at most one user — linking it to a new owner moves the row (used when a
 * signed-in customer connects an additional sign-in method to their profile).
 */
export async function linkProviderAccount(
  userId: string,
  provider: "google" | "facebook" | "telegram",
  providerAccountId: string,
) {
  await db.account.upsert({
    where: { provider_providerAccountId: { provider, providerAccountId } },
    update: { userId },
    create: { userId, type: "oauth", provider, providerAccountId },
  });
}

/* ---------------- Telegram Login Widget verification ---------------- */

export interface TelegramAuthPayload {
  id: number | string;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  auth_date: number | string;
  hash: string;
}

/**
 * Verify a Telegram Login Widget payload per the official algorithm:
 * secret = SHA256(bot_token); data_check_string = sorted "key=value" lines
 * joined with \n; valid = hex(HMAC_SHA256(secret, dcs)) === hash.
 */
export function verifyTelegramAuth(payload: TelegramAuthPayload, botToken: string): boolean {
  if (!botToken || !payload?.hash) return false;
  const { hash, ...rest } = payload;
  const dcs = Object.keys(rest)
    .sort()
    .map((k) => `${k}=${rest[k as keyof typeof rest]}`)
    .join("\n");
  const secret = createHash("sha256").update(botToken).digest();
  const expected = createHmac("sha256", secret).update(dcs).digest("hex");
  try {
    return timingSafeEqual(Buffer.from(expected, "hex"), Buffer.from(hash, "hex"));
  } catch {
    return false;
  }
}

/** Reject payloads older than 24 h (replay protection). */
export function telegramAuthDateFresh(payload: TelegramAuthPayload): boolean {
  const ts = Number(payload.auth_date) * 1000;
  if (!Number.isFinite(ts)) return false;
  const age = Date.now() - ts;
  return age >= 0 && age <= 24 * 60 * 60 * 1000;
}
