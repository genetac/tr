export const PEOPLE_DEFAULTS=[{id:'irina',name:'Irina Eid',role:'„AlmaChaab“ vadovė',bio:'Moters įkurtas ir valdomas verslas',image:'/images/irina-eid-alma-chaab.webp'},{id:'elie',name:'Elie',role:'Virtuvės šefas',bio:'',image:''}];
export function peopleInfo(content:any):typeof PEOPLE_DEFAULTS{return content?.people||PEOPLE_DEFAULTS;}

export function resolveBusinessContent(content:any){const people=peopleInfo(content);const irina=people.find(p=>p.id==='irina');const articles={...content?.articles};if(irina&&articles.authorName==='Irina Eid'){articles.authorName=irina.name;if(['„AlmaChaab“ vadovė','Alma Chaab vadovė'].includes(articles.authorRole))articles.authorRole=irina.role;}return {...content,people,articles};}
