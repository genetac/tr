import Stripe from "stripe";
import { getStoreSettings, isPlaceholderCredential, type StoreSettings } from "./settings";

/**
 * Payment gateway helpers — Stripe SDK + PayPal REST v2.
 * Credentials are read live from the admin-managed Settings singleton
 * (never from environment variables), so the owner can configure or swap
 * gateways from /admin → Nustatymai → Mokėjimai without a redeploy.
 * Placeholder/demo credentials count as NOT configured (v1.4 §C).
 */

export function stripeEnabled(store: StoreSettings): boolean {
  return Boolean(store.stripeSecretKey) && !isPlaceholderCredential(store.stripeSecretKey);
}

export function paypalEnabled(store: StoreSettings): boolean {
  return (
    Boolean(store.paypalClientId && store.paypalSecret) &&
    !isPlaceholderCredential(store.paypalClientId) &&
    !isPlaceholderCredential(store.paypalSecret)
  );
}

/** Stripe client bound to the admin-configured secret key (or null if unset). */
export async function getStripeClient(): Promise<{ stripe: Stripe; store: StoreSettings } | null> {
  const store = await getStoreSettings();
  if (!store.stripeSecretKey) return null;
  // apiVersion intentionally omitted → account default version.
  return { stripe: new Stripe(store.stripeSecretKey), store };
}

/* ---------------- PayPal REST v2 (no deprecated SDK) ---------------- */

function paypalBase(store: StoreSettings): string {
  return store.paypalSandbox ? "https://api-m.sandbox.paypal.com" : "https://api-m.paypal.com";
}

async function paypalAccessToken(store: StoreSettings): Promise<string> {
  const basic = Buffer.from(`${store.paypalClientId}:${store.paypalSecret}`).toString("base64");
  const res = await fetch(`${paypalBase(store)}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });
  if (!res.ok) throw new Error("PayPal autentifikacija nepavyko.");
  const json = (await res.json()) as { access_token?: string };
  if (!json.access_token) throw new Error("PayPal atsakė be prieigos rakto.");
  return json.access_token;
}

export interface PaypalCreateInput {
  orderId: string;
  orderNumber: string;
  items: { name: string; price: number; qty: number }[];
  currency: string;
  subtotal: number;
  tax: number;
  deliveryFee: number;
  total: number;
  baseUrl: string;
}

/** Creates a PayPal order; amount breakdown always matches our server-side math. */
export async function paypalCreateOrder(store: StoreSettings, input: PaypalCreateInput): Promise<string> {
  const token = await paypalAccessToken(store);
  const reference = `${input.orderNumber}-${Date.now()}`;
  const res = await fetch(`${paypalBase(store)}/v2/checkout/orders`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: reference,
          custom_id: input.orderId, // lets the capture step find our Order row
          description: `${store.restaurantName} užsakymas #${input.orderNumber}`.slice(0, 127),
          amount: {
            currency_code: input.currency,
            value: input.total.toFixed(2),
            breakdown: {
              item_total: { currency_code: input.currency, value: input.subtotal.toFixed(2) },
              ...(input.tax > 0 ? { tax_total: { currency_code: input.currency, value: input.tax.toFixed(2) } } : {}),
              ...(input.deliveryFee > 0 ? { shipping: { currency_code: input.currency, value: input.deliveryFee.toFixed(2) } } : {}),
            },
          },
          items: input.items.map((i) => ({
            name: i.name.slice(0, 127),
            quantity: String(i.qty),
            unit_amount: { currency_code: input.currency, value: i.price.toFixed(2) },
          })),
        },
      ],
    }),
  });
  const json = (await res.json()) as { id?: string; message?: string };
  if (!res.ok || !json.id) throw new Error(json.message || "PayPal užsakymo sukurti nepavyko.");
  return json.id;
}

export interface PaypalCaptureResult {
  status: string;
  captureId: string;
  orderId: string; // our internal order id (custom_id)
}

/**
 * Pulls OUR internal order id out of a PayPal capture response. PayPal is
 * inconsistent about where custom_id lands (unit level vs capture level —
 * some responses omit it entirely), so every known location is checked and
 * a DB-derived fallback is accepted last.
 */
export function extractInternalOrderId(json: unknown, fallbackOrderId = ""): string {
  const j = json as {
    purchase_units?: {
      custom_id?: string;
      payments?: { captures?: { custom_id?: string }[] };
    }[];
  };
  const unit = j?.purchase_units?.[0];
  const fromUnit = unit?.custom_id?.trim();
  if (fromUnit) return fromUnit;
  const fromCapture = unit?.payments?.captures?.[0]?.custom_id?.trim();
  if (fromCapture) return fromCapture;
  return fallbackOrderId;
}

export async function paypalCaptureOrder(
  store: StoreSettings,
  paypalOrderId: string,
  fallbackOrderId = ""
): Promise<PaypalCaptureResult> {
  const token = await paypalAccessToken(store);
  const res = await fetch(`${paypalBase(store)}/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    cache: "no-store",
    body: "{}",
  });

  const json = (await res.json()) as any;
  if (!res.ok) {
    const msg = json?.details?.[0]?.description || json?.message || "PayPal apmokėjimo patvirtinti nepavyko.";
    throw new Error(msg);
  }
  const unit = json?.purchase_units?.[0];
  const capture = unit?.payments?.captures?.[0];
  if (!capture || capture.status !== "COMPLETED") throw new Error("PayPal apmokėjimas nepatvirtintas.");
  return {
    status: capture.status,
    captureId: String(capture.id || ""),
    // custom_id is occasionally missing from the capture payload — the
    // caller passes our DB-derived id (Order.paymentRef lookup) as fallback.
    orderId: extractInternalOrderId(json, fallbackOrderId),
  };
}

/* ---------------- masking ---------------- */

/** "sk_live_51H8…abcd" → "••••abcd" for safe display in the admin UI. */
export function maskSecret(value: string | null | undefined): string {
  if (!value) return "";
  const tail = value.slice(-4);
  return `••••${tail}`;
}

export function isMasked(value: string): boolean {
  return value.includes("•");
}
