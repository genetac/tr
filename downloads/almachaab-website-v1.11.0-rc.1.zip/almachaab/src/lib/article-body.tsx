import {DocumentBlocks} from "@/components/cms/DocumentBlocks";
import {DEFAULTS} from "./settings";
/**
 * Article body rendering helpers (server-safe, no client JS).
 *
 * Body blocks (Article.bodyJson):
 *   { t: "p",   text }            paragraph
 *   { t: "h",   text }            H2 heading
 *   { t: "q",   text }            blockquote
 *   { t: "ul",  items: string[] } bullet list
 *   { t: "img", url, alt }        image
 *
 * Inline markup inside text / items:
 *   **bold**            → <strong>
 *   [label](/path)      → internal <Link> (must start with "/")
 *   [label](https://…)  → external <a rel="noopener">
 * Anything else stays plain text (React escapes it), so no HTML injection.
 */
import Link from "next/link";
import type { ReactNode } from "react";

const TOKEN = /\*\*([^*]+)\*\*|\[([^\]]+)\]\(([^)\s]+)\)/g;

export function renderInline(text: string, keyPrefix = "i"): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0;
  let n = 0;
  for (const m of text.matchAll(TOKEN)) {
    const idx = m.index ?? 0;
    if (idx > last) out.push(text.slice(last, idx));
    const key = `${keyPrefix}-${n++}`;
    if (m[1] !== undefined) {
      out.push(<strong key={key}>{m[1]}</strong>);
    } else {
      const label = m[2];
      const href = m[3];
      if (href.startsWith("/")) out.push(<Link key={key} href={href}>{label}</Link>);
      else if (href.startsWith("https://")) out.push(<a key={key} href={href} rel="noopener" target="_blank">{label}</a>);
      else out.push(label); // unknown scheme → plain text
    }
    last = idx + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

/** Plain text (markup stripped) — for JSON-LD and meta. */
export function plainText(text: string): string {
  return text.replace(/\*\*([^*]+)\*\*/g, "$1").replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, "$1");
}

export type Block = import("./document-blocks").DocumentBlock;

export function renderBlock(b: Block, i: number): ReactNode {
  if(b.visible===false)return null;
  if(b.t==='md')return <DocumentBlocks key={i} blocks={[b]} settings={DEFAULTS}/>;
  const text = String(b.text || "");
  if (b.t === "h") return <h2 key={i}>{plainText(text)}</h2>;
  if (b.t === "q") return <blockquote key={i}>{renderInline(text, `q${i}`)}</blockquote>;
  if (b.t === "ul" && Array.isArray(b.items))
    return (
      <ul key={i}>
        {b.items.map((it, j) => (
          <li key={j}>{renderInline(String(it), `l${i}-${j}`)}</li>
        ))}
      </ul>
    );
  if (b.t === "img")
    return <img key={i} src={String(b.url || "")} alt={String(b.alt || "")} loading="lazy" decoding="async" />;
  return <p key={i}>{renderInline(text, `p${i}`)}</p>;
}

/**
 * FAQ pairs from a "Dažni klausimai" section: paragraphs shaped
 * "**Question?** Answer" that follow an H block with that title.
 */
export function extractFaq(body: Block[]): { q: string; a: string }[] {
  const start = body.findIndex((b) => b.t === "h" && /^dažni klausimai$/i.test(String(b.text || "").trim()));
  if (start < 0) return [];
  const out: { q: string; a: string }[] = [];
  for (const b of body.slice(start + 1)) {
    if (b.t === "h") break;
    if (b.t !== "p") continue;
    const m = String(b.text || "").match(/^\*\*([\s\S]+?)\*\*\s*([\s\S]+)$/);
    if (m) out.push({ q: plainText(m[1]).trim(), a: plainText(m[2]).trim() });
  }
  return out;
}
