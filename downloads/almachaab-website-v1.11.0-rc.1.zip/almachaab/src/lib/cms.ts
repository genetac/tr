import { db } from './db';
import type { Prisma } from '@prisma/client';
import { randomUUID } from 'crypto';
export type CmsRecord = { revision:number; draft:any; published:any; pending:boolean; updatedAt:string; actor:string; redirects?:string[] };
export class CmsError extends Error { constructor(message:string, public status=400){super(message);} }
const keyPattern=/^(content|theme|site|hours|dietaryDisplay|menu-layout|article:[a-zA-Z0-9_-]+|menu:[a-zA-Z0-9_-]+|page:[a-zA-Z0-9_-]+)$/;
export function assertCmsKey(key:string){if(!keyPattern.test(key))throw new CmsError('Netinkamas dokumentas.');}
export async function initialDocument(key:string, tx:any=db):Promise<any> {
  if(['content','theme','site','hours','dietaryDisplay'].includes(key)){
    const row=await tx.setting.findUnique({where:{key}});
    if(row)return JSON.parse(row.value);
    const {DEFAULTS}=await import('./settings');return (DEFAULTS as any)[key];
  }
  if(key==='menu-layout'){const categories=await tx.category.findMany({orderBy:{sortOrder:'asc'},include:{items:{orderBy:{sortOrder:'asc'}}}});return categories.map((c:any)=>({id:c.id,name:c.name,active:c.active,itemOrder:c.items.map((i:any)=>i.id)}));}
  const [kind,id]=key.split(':');
  if(kind==='article') {const a=await tx.article.findUnique({where:{id}});if(!a)throw new CmsError('Straipsnis nerastas.',404);return {...a,body:JSON.parse(a.bodyJson).map((b:any,i:number)=>({...b,id:b.id||`legacy-${i}`})),bodyJson:undefined};}
  if(kind==='menu') {const a=await tx.menuItem.findUnique({where:{id}});if(!a)throw new CmsError('Patiekalas nerastas.',404);return a;}
  return null;
}
export async function getDocument(key:string, tx:any=db):Promise<CmsRecord>{
  assertCmsKey(key);
  const row=await tx.setting.findUnique({where:{key:`cms:${key}`}});
  if(row)return JSON.parse(row.value);
  const initial=await initialDocument(key,tx);
  let draft=initial;let revision=0;let pending=false;
  if(key==='content'){
    const old=await tx.setting.findUnique({where:{key:'contentDraft'}});
    if(old){const parsed=JSON.parse(old.value);draft=parsed.content;revision=parsed.revision||0;pending=parsed.pending===true;}
  }
  return {revision,draft,published:initial,pending,updatedAt:'',actor:''};
}
export async function saveDocument(key:string,data:any,expected:number,mode:'draft'|'publish',actor:string,apply?:(tx:Prisma.TransactionClient,data:any)=>Promise<void>){
  assertCmsKey(key);
  return db.$transaction(async tx=>{
    const current=await getDocument(key,tx);
    if(current.revision!==expected)throw new CmsError('Pakeista kitame lange. Perkraukite ir palyginkite pakeitimus.',409);
    const time=new Date().toISOString();
    // Keep the previous snapshot, including the initial published version.
    await tx.setting.create({data:{key:`cms-history:${key}:${randomUUID()}`,value:JSON.stringify({...current,at:time})}});
    const record:CmsRecord={...current,revision:expected+1,draft:data,pending:mode!=='publish',updatedAt:time,actor};
    if(mode==='publish'){
      if((key.startsWith('page:')||key.startsWith('article:'))&&current.published?.slug&&current.published.slug!==data.slug)record.redirects=[...new Set([...(current.redirects||[]),current.published.slug])];
      if(apply)await apply(tx,data);
      record.published=data;
    }
    const value=JSON.stringify(record);
    await tx.setting.upsert({where:{key:`cms:${key}`},update:{value},create:{key:`cms:${key}`,value}});
    // Synchronize the existing content editor without a second publishing state.
    if(key==='content'){
      const old=JSON.stringify({revision:record.revision,content:data,pending:record.pending});
      await tx.setting.upsert({where:{key:'contentDraft'},update:{value:old},create:{key:'contentDraft',value:old}});
    }
    const history=await tx.setting.findMany({where:{key:{startsWith:`cms-history:${key}:`}},orderBy:{updatedAt:'desc'},skip:50,select:{key:true}});
    if(history.length)await tx.setting.deleteMany({where:{key:{in:history.map(x=>x.key)}}});
    return record;
  });
}
export async function documentHistory(key:string){assertCmsKey(key);return (await db.setting.findMany({where:{key:{startsWith:`cms-history:${key}:`}},orderBy:{updatedAt:'desc'},take:50})).map(r=>({id:r.key,...JSON.parse(r.value)})).filter(r=>r.draft!==null);}
export async function pageRecords(){return (await db.setting.findMany({where:{key:{startsWith:'cms:page:'}},orderBy:{updatedAt:'desc'}})).map(row=>({id:row.key.slice('cms:page:'.length),...JSON.parse(row.value) as CmsRecord}));}
export async function publishedPage(slug:string){return (await pageRecords()).find(p=>p.published?.slug===slug&&p.published?.visible!==false);}
