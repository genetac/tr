import { db } from "./db";
import { computeTotals, nextOrderNumber, priceCart, pushHistory, type Totals } from "./orders";
import { getStoreSettings, type StoreSettings } from "./settings";
import { getCurrentUser } from "./userauth";
import { resolvePricing } from "./locations";
import { newTrackToken } from "./track-auth";
import type { Order } from "@prisma/client";

/**
 * Shared server-side preparation for paid online orders (Stripe/PayPal).
 * Supports BOTH order types:
 *  - "pickup"      → validated pickup slot + items
 *  - "reservation" → validated date/time/guests + optional pre-ordered items
 * Re-validates everything on the server: store open, contact fields,
 * item availability (86'd items rejected) and prices — the client can
 * never dictate amounts.
 */
export interface OnlineCheckoutInput {
  type?: "pickup" | "reservation";
  customerName?: string;
  phone?: string;
  email?: string;
  note?: string;
  pickupTime?: string;
  resDate?: string;
  resTime?: string;
  guests?: number;
  experiences?: string;
  items?: { id: string; qty: number }[];
}

export type PreparedOrder =
  | { error: string; status: number }
  | { order: Order; totals: Totals; store: StoreSettings; clean: { name: string; price: number; qty: number }[] };

export async function prepareOnlineOrder(p: OnlineCheckoutInput): Promise<PreparedOrder> {
  const store = await getStoreSettings();
  if (!store.isOpen) {
    return { error: "Šiuo metu nepriimame užsakymų — susisiekite telefonu.", status: 503 };
  }

  const type = p.type === "reservation" ? "reservation" : "pickup";
  const name = String(p.customerName || "").trim().slice(0, 80); // SEC-015: bounded lengths
  const phone = String(p.phone || "").trim().slice(0, 30);
  const email = String(p.email || "").trim().slice(0, 120);

  if (name.length < 2) return { error: "Įveskite vardą.", status: 400 };
  if (phone.replace(/\D/g, "").length < 8) return { error: "Įveskite tikrą telefono numerį.", status: 400 };
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { error: "Netinkamas el. pašto adresas.", status: 400 };

  // Type-specific validation (mirrors /api/orders rules)
  let pickupTime = "";
  let resDate = "";
  let resTime = "";
  let guests = 0;
  let experiences = "";
  if (type === "pickup") {
    pickupTime = (p.pickupTime || "").trim();
    if (!/^\d{2}:\d{2}$/.test(pickupTime)) return { error: "Pasirinkite atsiėmimo laiką.", status: 400 };
  } else {
    resDate = (p.resDate || "").trim();
    resTime = (p.resTime || "").trim();
    guests = Math.max(1, Math.min(80, Math.floor(Number(p.guests) || 0)));
    experiences = (p.experiences || "").trim().slice(0, 300);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(resDate)) return { error: "Pasirinkite rezervacijos datą.", status: 400 };
    if (!/^\d{2}:\d{2}$/.test(resTime)) return { error: "Pasirinkite rezervacijos laiką.", status: 400 };
    if (!guests) return { error: "Pasirinkite svečių skaičių.", status: 400 };
  }

  const priced = await priceCart(Array.isArray(p.items) ? p.items.slice(0, 100) : []); // SEC-015
  if (priced.soldOut.length > 0) {
    return { error: `Šie patiekalai jau išparduoti: ${priced.soldOut.join(", ")}.`, status: 409 };
  }
  // Reservations may be paid without any pre-ordered dishes (table-only);
  // pickups always need at least one item.
  if (type === "pickup" && priced.clean.length === 0) return { error: "Krepšelis tuščias.", status: 400 };

  // Branch-aware pricing: default Location overrides PVM/delivery when set.
  const pricing = await resolvePricing();
  const totals = computeTotals(priced.total, { taxRate: pricing.taxRate, deliveryFee: pricing.deliveryFee });
  const user = await getCurrentUser();
  const number = await nextOrderNumber();

  const order = await db.order.create({
    data: {
      number,
      trackToken: newTrackToken(),
      type,
      status: "awaiting",
      customerName: name,
      phone,
      email,
      itemsJson: JSON.stringify(priced.clean),
      total: totals.total,
      taxAmount: totals.tax,
      pickupTime,
      resDate,
      resTime,
      guests,
      experiences,
      note: (p.note || "").slice(0, 1000),
      historyJson: JSON.stringify([
        { status: "awaiting", at: new Date().toISOString(), label: "Laukiama apmokėjimo online" },
      ]),
      paymentStatus: "unpaid",
      paymentMethod: "", // set by the gateway route
      userId: user?.id || null,
      locationId: pricing.locationId,
    },
  });

  return { order, totals, store, clean: priced.clean };
}

/**
 * Loads an existing UNPAID order for pay-later (from /mano or the tracking
 * card). The order number acts as the capability token — the same secret the
 * customer already uses to track the order.
 */
export async function getUnpaidOrderByNumber(rawNumber: string): Promise<
  { error: string; status: number } | { order: Order; store: StoreSettings }
> {
  const clean = rawNumber.trim().toUpperCase().replace(/^#/, "");
  if (!clean) return { error: "Trūksta užsakymo numerio.", status: 400 };

  const store = await getStoreSettings();
  const order = await db.order.findFirst({
    where: { OR: [{ number: clean }, { number: clean.replace(/^[A-Z]+-?/, "") }] },
  });
  if (!order) return { error: "Tokio užsakymo nerasta.", status: 404 };
  if (order.paymentStatus === "paid") return { error: "Šis užsakymas jau apmokėtas.", status: 409 };
  if (order.status === "cancelled") return { error: "Šis užsakymas atšauktas.", status: 409 };
  if (order.total <= 0) return { error: "Šis užsakymas be sumos — apmokėkite vietoje.", status: 400 };
  return { order, store };
}

export { pushHistory };
