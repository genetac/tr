import { randomBytes } from "crypto";
import { db } from "./db";
import { getSetting, setSetting } from "./settings";
import type { Order } from "@prisma/client";

/**
 * Loyalty engine — points + stamp card.
 *
 * Config lives in the Setting key-value store ("loyalty") so the owner can
 * tune it from /admin without a migration. Every mutation is written to the
 * LoyaltyTransaction ledger; earning is idempotent per order (unique
 * [profileId, orderId, type] constraint), so webhook retries can never
 * double-credit a customer.
 */

export interface LoyaltyConfig {
  enabled: boolean;
  pointsPerEuro: number; // 1 point per whole €1 by default
  stampGoal: number; // stamps needed for a free reward stamp
  welcomeBonus: number; // one-time points for creating an account
}

export const LOYALTY_DEFAULTS: LoyaltyConfig = {
  enabled: false,
  pointsPerEuro: 1,
  stampGoal: 8,
  welcomeBonus: 0,
};

export async function getLoyaltyConfig(): Promise<LoyaltyConfig> {
  const saved = await getSetting<Partial<LoyaltyConfig>>("loyalty");
  return { ...LOYALTY_DEFAULTS, ...(saved || {}) };
}

export async function setLoyaltyConfig(patch: Partial<LoyaltyConfig>): Promise<LoyaltyConfig> {
  const merged = { ...(await getLoyaltyConfig()), ...patch };
  merged.pointsPerEuro = Math.max(0, Math.min(100, Math.round(merged.pointsPerEuro * 100) / 100));
  merged.stampGoal = Math.max(1, Math.min(100, Math.floor(merged.stampGoal) || LOYALTY_DEFAULTS.stampGoal));
  merged.welcomeBonus = Math.max(0, Math.min(10000, Math.floor(merged.welcomeBonus) || 0));
  await setSetting("loyalty", merged);
  return merged;
}

export async function ensureProfile(userId: string) {
  const existing = await db.loyaltyProfile.findUnique({ where: { userId } });
  if (existing) return existing;
  try {
    return await db.loyaltyProfile.create({ data: { userId } });
  } catch {
    // concurrent creation — re-read
    const p = await db.loyaltyProfile.findUnique({ where: { userId } });
    if (!p) throw new Error("Lojalumo profilis nerastas.");
    return p;
  }
}

/** One-time welcome bonus on account creation (configurable, default off). */
export async function grantWelcomeBonus(userId: string) {
  const cfg = await getLoyaltyConfig();
  if (!cfg.enabled || cfg.welcomeBonus <= 0) return null;
  const profile = await ensureProfile(userId);
  const dup = await db.loyaltyTransaction.findFirst({ where: { profileId: profile.id, type: "welcome" } });
  if (dup) return null;
  await applyPoints(profile.id, cfg.welcomeBonus, "welcome", null, "Sveiki atvykę į Alma Chaab lojalumą!");
  return cfg.welcomeBonus;
}

/**
 * Award points + a stamp for a successfully completed / paid order.
 * Safe to call multiple times for the same order (ledger-unique).
 * Returns the awarded amount or null when nothing was granted.
 */
export async function awardForOrder(
  order: Pick<Order, "id" | "userId" | "total" | "number">
): Promise<{ points: number; stamps: number } | null> {
  if (!order.userId) return null;
  const cfg = await getLoyaltyConfig();
  if (!cfg.enabled) return null;

  const profile = await ensureProfile(order.userId);
  const points = Math.max(0, Math.floor(order.total * cfg.pointsPerEuro));
  const stamps = 1;
  if (points <= 0 && stamps <= 0) return null;

  try {
    // Ledger write is the source of truth — unique constraint blocks dupes.
    await db.loyaltyTransaction.create({
      data: {
        profileId: profile.id,
        type: "earn",
        points,
        orderId: order.id,
        note: `Užsakymas #${order.number}`,
      },
    });
    await db.loyaltyTransaction.create({
      data: {
        profileId: profile.id,
        type: "stamp",
        points: 0,
        orderId: order.id,
        note: `Stampas už #${order.number}`,
      },
    });
  } catch {
    return null; // already awarded for this order
  }

  const stampsAfter = profile.stamps + stamps;
  const carry = cfg.stampGoal > 0 ? Math.floor(stampsAfter / cfg.stampGoal) * cfg.stampGoal : 0;
  await db.loyaltyProfile.update({
    where: { id: profile.id },
    data: {
      points: { increment: points },
      lifetimePoints: { increment: points },
      stamps: stampsAfter - carry, // full card → restart
      totalStamps: { increment: stamps },
    },
  });
  return { points, stamps };
}

/** Internal: adjust balance + write ledger row. */
async function applyPoints(profileId: string, points: number, type: string, orderId: string | null, note: string) {
  await db.loyaltyTransaction.create({
    data: { profileId, type, points, orderId, note },
  });
  await db.loyaltyProfile.update({
    where: { id: profileId },
    data: {
      points: { increment: points },
      lifetimePoints: { increment: Math.max(0, points) },
    },
  });
}

function voucherCode(): string {
  const raw = randomBytes(4).toString("hex").toUpperCase();
  return `ALMA-${raw.slice(0, 4)}-${raw.slice(4, 8)}`;
}

/** Spend points on a reward → unique voucher code. Throws with LT message on failure. */
export async function redeemReward(userId: string, rewardId: string) {
  const cfg = await getLoyaltyConfig();
  if (!cfg.enabled) throw new Error("Lojalumo programa šiuo metu neaktyvi.");
  const reward = await db.reward.findUnique({ where: { id: rewardId } });
  if (!reward || !reward.active) throw new Error("Šis prizas nebegalioja.");
  const profile = await ensureProfile(userId);
  if (profile.points < reward.pointsCost) {
    throw new Error(`Trūksta taškų — reikia ${reward.pointsCost}, turite ${profile.points}.`);
  }

  const code = voucherCode();
  const [, redemption] = await db.$transaction([
    db.loyaltyProfile.update({
      where: { id: profile.id },
      data: { points: { decrement: reward.pointsCost } },
    }),
    db.rewardRedemption.create({
      data: { profileId: profile.id, rewardId, pointsSpent: reward.pointsCost, code },
    }),
    db.loyaltyTransaction.create({
      data: { profileId: profile.id, type: "redeem", points: -reward.pointsCost, note: `Prizas: ${reward.name}` },
    }),
  ]);
  return redemption;
}

/** Staff marks a printed/shown voucher as used. */
export async function markRedemptionUsed(code: string) {
  const r = await db.rewardRedemption.findUnique({ where: { code } });
  if (!r) throw new Error("Kuponas nerastas.");
  if (r.status !== "issued") throw new Error("Kuponas jau panaudotas.");
  return db.rewardRedemption.update({ where: { code }, data: { status: "used", usedAt: new Date() } });
}
