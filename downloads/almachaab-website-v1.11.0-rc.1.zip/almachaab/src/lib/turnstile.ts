import { getStoreSettings, isPlaceholderCredential } from "./settings";

/**
 * Cloudflare Turnstile anti-bot protection for the auth endpoints.
 *
 * - Enabled state, site key and secret live in the Settings singleton
 *   (/admin → Nustatymai → Saugumas), same pattern as payment/social keys.
 * - The /mano form renders the official widget (challenges.cloudflare.com)
 *   when enabled and sends the token with login / register / Telegram POSTs.
 * - Verification is fail-closed: if the check cannot be completed, the
 *   request is rejected. Google/Facebook OAuth stays out of scope — those
 *   providers already run their own bot risk engines.
 */

export interface TurnstileConfig {
  enabled: boolean;
  siteKey: string;
  secretKey: string;
}

export async function getTurnstileConfig(): Promise<TurnstileConfig> {
  const s = await getStoreSettings();
  // Placeholder demo keys ("1x0000…" always passes) count as OFF (v1.4 §C).
  const realKeys =
    Boolean(s.turnstileSiteKey && s.turnstileSecretKey) &&
    !isPlaceholderCredential(s.turnstileSiteKey) &&
    !isPlaceholderCredential(s.turnstileSecretKey);
  return {
    enabled: s.turnstileEnabled && realKeys,
    siteKey: realKeys ? s.turnstileSiteKey : "",
    secretKey: realKeys ? s.turnstileSecretKey : "",
  };
}

/** Client-facing projection — the site key is public by design. */
export function publicTurnstileConfig(cfg: TurnstileConfig) {
  return { enabled: cfg.enabled, siteKey: cfg.siteKey };
}

export async function verifyTurnstile(token: string, ip?: string): Promise<boolean> {
  const cfg = await getTurnstileConfig();
  if (!cfg.enabled) return true; // feature off → no gate
  if (!token) return false;

  try {
    const body = new URLSearchParams({ secret: cfg.secretKey, response: token });
    if (ip) body.set("remoteip", ip);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body,
      signal: ctrl.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return false;
    const j = (await res.json()) as { success?: boolean };
    return Boolean(j.success);
  } catch {
    return false; // timeout / network error → fail closed
  }
}

/** Extract the caller IP from proxy headers (best effort, for siteverify logging). */
export function clientIp(header: string | null): string | undefined {
  const first = (header || "").split(",")[0].trim();
  return first || undefined;
}
