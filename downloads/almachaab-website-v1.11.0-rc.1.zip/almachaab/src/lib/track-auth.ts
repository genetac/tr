import { randomBytes, timingSafeEqual } from "crypto";

/**
 * Public order-tracking authorization (review fix #3).
 * Bare order numbers are sequential and guessable, so a lookup is allowed
 * only with the order's random track token (from emailed / returned links)
 * or the last 4 digits of the customer's phone.
 *
 * A2: the 4-digit check has only 10 000 combinations, so failed p4 attempts
 * are rate-limited — 5 failures per order number per IP within 15 minutes,
 * then 429 for that order+IP pair. Token auth is never limited.
 */

export interface TrackOrderRef {
  number: string;
  trackToken: string;
  phone: string;
}

function safeEq(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

// ---------- p4 failed-attempt limiter (in-memory, one server) ----------

const P4_WINDOW_MS = 15 * 60_000;
const P4_MAX_FAILS = 5;
const p4Fails = new Map<string, { count: number; resetAt: number }>();

// SEC-006: per-order cap across ALL IPs — even with many addresses an attacker
// gets at most 20 phone guesses per order per hour (0.2% of the 10 000 space).
const P4_ORDER_WINDOW_MS = 60 * 60_000;
const P4_ORDER_MAX_FAILS = 20;
function orderKey(number: string): string {
  return `${number.toUpperCase()}|*`;
}

function p4Key(number: string, ip: string): string {
  return `${number.toUpperCase()}|${ip}`;
}

export function trackFailStatus(number: string, ip: string): { blocked: boolean; retryAfterSec: number } {
  const all = p4Fails.get(orderKey(number));
  if (all && all.resetAt >= Date.now() && all.count >= P4_ORDER_MAX_FAILS) {
    return { blocked: true, retryAfterSec: Math.ceil((all.resetAt - Date.now()) / 1000) };
  }
  const rec = p4Fails.get(p4Key(number, ip));
  if (!rec || rec.resetAt < Date.now()) return { blocked: false, retryAfterSec: 0 };
  return { blocked: rec.count >= P4_MAX_FAILS, retryAfterSec: Math.ceil((rec.resetAt - Date.now()) / 1000) };
}

/** Count one failed phone-last-4 attempt for this order+IP. */
export function trackFail(number: string, ip: string): void {
  const now = Date.now();
  const bump = (key: string, windowMs: number) => {
    const rec = p4Fails.get(key);
    if (!rec || rec.resetAt < now) p4Fails.set(key, { count: 1, resetAt: now + windowMs });
    else rec.count += 1;
  };
  bump(p4Key(number, ip), P4_WINDOW_MS);
  bump(orderKey(number), P4_ORDER_WINDOW_MS);
}

/** Success clears the counter (a correct guess is a legit customer). */
export function trackFailReset(number: string, ip: string): void {
  p4Fails.delete(p4Key(number, ip));
}

/** Periodic sweep so expired windows don't pin memory (called by the routes). */
export function trackFailSweep(): void {
  const now = Date.now();
  for (const [key, rec] of p4Fails) if (rec.resetAt < now) p4Fails.delete(key);
}

export const TRACK_RATE_MESSAGE =
  "Per daug bandymų. Bandykite po 15 min. arba naudokite nuorodą iš laiško.";

/** Random tracking token for new orders (A3: crypto-grade, URL-safe). */
export function newTrackToken(): string {
  return randomBytes(16).toString("base64url");
}

/** Deep link to the tracking card on /mano (used by confirmation emails). */
export function trackLink(baseUrl: string, number: string, trackToken: string): string {
  return `${baseUrl}/mano?nr=${encodeURIComponent(number)}&t=${encodeURIComponent(trackToken)}`;
}

/**
 * Combined gate used by /api/track/[number] and its /stream route.
 * Returns "ok" | "forbidden" (403 — wrong/missing credentials) | "limited"
 * (429 — too many failed p4 attempts for this order+IP).
 * `ip` comes from clientIp() in src/lib/auth.ts (cf-connecting-ip first).
 */
export function authorizeTrackLimited(
  order: TrackOrderRef,
  t: string | null,
  p4: string | null,
  ip: string
): "ok" | "forbidden" | "limited" {
  // Token auth is never rate-limited.
  if (t && order.trackToken && safeEq(t.trim(), order.trackToken)) {
    trackFailReset(order.number, ip);
    return "ok";
  }
  const given = (p4 || "").replace(/\D/g, "");
  const digits = (order.phone || "").replace(/\D/g, "");
  if (given.length === 4) {
    if (trackFailStatus(order.number, ip).blocked) return "limited";
    if (digits.length >= 4 && safeEq(given, digits.slice(-4))) {
      trackFailReset(order.number, ip);
      return "ok";
    }
    // Wrong p4 guess — consumes one of the 5 attempts.
    trackFail(order.number, ip);
  }
  return "forbidden";
}
