import nodemailer from "nodemailer";
import { getSettings, type EmailSettings } from "./settings";
import { DEFAULT_TEMPLATES, mergeTemplate, renderTpl, type EmailTemplate, type EmailTemplateKey, type EmailTemplatesSetting } from "./email-templates";
import { trackLink } from "./track-auth";
import type { Order } from "@prisma/client";

export const STATUS_LT: Record<string, string> = {
  new: "Naujas",
  awaiting: "Laukiama patvirtinimo",
  confirmed: "Patvirtintas",
  preparing: "Ruošiamas",
  ready: "Paruoštas",
  completed: "Užbaigtas",
  cancelled: "Atšauktas",
};

/** Payment method labels shown on receipts. */
export const METHOD_LT: Record<string, string> = {
  stripe: "Banko kortelė (Stripe)",
  paypal: "PayPal",
  venue: "Apmokėta vietoje (grynieji / kortelė)",
};

/** SEC-004: HTML-escape every customer-supplied value before it goes into an email. */
export function escapeHtml(v: unknown): string {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * SEC-004: one central place — a copy of the order whose text fields (and
 * cart item names) are HTML-escaped. Every HTML email body is built from this
 * copy; subjects (plain text) use the raw order.
 */
function htmlSafeOrder(order: Order): Order {
  const items = (() => {
    try {
      return (JSON.parse(order.itemsJson || "[]") as CartItem[]).map((i) => ({ ...i, name: escapeHtml(i.name) }));
    } catch {
      return [];
    }
  })();
  const o = { ...order } as Record<string, unknown>;
  for (const k of ["number", "customerName", "phone", "email", "note", "experiences", "pickupTime", "resDate", "resTime", "paymentRef", "paymentMethod"]) {
    if (typeof o[k] === "string") o[k] = escapeHtml(o[k]);
  }
  o.itemsJson = JSON.stringify(items);
  return o as unknown as Order;
}

function fmtEur(v: number) {
  return v.toFixed(2).replace(".", ",") + " €";
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  qty: number;
}

function orderRows(items: CartItem[]) {
  if (!items.length) return "";
  return `<table style="width:100%;border-collapse:collapse;margin:12px 0">${items
    .map(
      (i) =>
        `<tr><td style="padding:6px 0;border-bottom:1px solid #eee">${i.name} × ${i.qty}</td><td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;white-space:nowrap">${fmtEur(i.price * i.qty)}</td></tr>`
    )
    .join("")}</table>`;
}

function layout(title: string, body: string) {
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:auto;padding:24px;color:#241a13">
  <div style="border-bottom:3px solid #b47b2d;padding-bottom:12px;margin-bottom:18px">
    <span style="font-family:Georgia,serif;font-size:24px;color:#6d4822">Alma Chaab</span>
    <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:#74665b;margin-top:4px">Kėdainių senamiestis</div>
  </div>
  <h2 style="font-family:Georgia,serif;font-weight:400;color:#241a13">${title}</h2>
  ${body}
  <div style="margin-top:24px;padding-top:12px;border-top:1px solid #ded0bd;font-size:12px;color:#74665b">
    Alma Chaab · Didžioji g. 25, Kėdainiai · +370 666 13 055
  </div>
</div>`;
}

async function transport(cfg: EmailSettings) {
  return nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure,
    auth: { user: cfg.user, pass: cfg.pass },
  });
}

export async function sendMail(to: string, subject: string, html: string): Promise<{ ok: boolean; error?: string }> {
  const s = await getSettings();
  const cfg = s.email;
  if (!cfg.enabled || !cfg.user || !cfg.pass) return { ok: false, error: "email-disabled" };
  try {
    const tr = await transport(cfg);
    const from = cfg.from || cfg.user;
    await tr.sendMail({ from: `"${cfg.fromName}" <${from}>`, to, subject, html });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "send-failed" };
  }
}

function trackLinkFor(baseUrl: string, order: Order) {
  // /sekti merged into /mano — link straight to the tracking card, with the
  // tracking token so only this customer can open the order.
  return trackLink(baseUrl, order.number, order.trackToken);
}

/** Receipt (kvitas) block appended to the "paid" event email. */
function paymentBlock(order: Order) {
  const method = METHOD_LT[order.paymentMethod] || order.paymentMethod || "—";
  return `<div style="margin:14px 0;padding:12px 16px;background:#f8f2e9;border:1px solid #ded0bd;border-radius:12px;font-size:14px;line-height:1.8">
    Mokėjimo būdas: <strong>${method}</strong><br/>
    ${order.paymentRef ? `Mokėjimo operacijos nr.: <span style="color:#74665b;font-size:12px">${order.paymentRef}</span><br/>` : ""}
    Apmokėta suma: <strong>${fmtEur(order.total)}</strong>
  </div>`;
}

/** Win-back / re-engagement email for dormant customers (CRM campaign). */
export async function emailWinBack(
  to: string,
  name: string,
  message: string,
  baseUrl: string
): Promise<{ ok: boolean; error?: string }> {
  const first = escapeHtml((name || "").split(" ")[0] || "");
  const html = layout(
    first ? `${first}, seniai nebuvote pas mus!` : "Seniai nebuvote pas mus!",
    `<p style="line-height:1.6">${message}</p>
     <p style="margin:22px 0">
       <a href="${baseUrl}/#meniu" style="background:#b47b2d;color:#fff;padding:12px 26px;border-radius:24px;text-decoration:none;font-weight:bold">Užsisakyti dabar</a>
     </p>
     <p style="font-size:13px;color:#74665b;line-height:1.6">Jūsų lojalumo taškai laukia — prisijunkite prie <a href="${baseUrl}/mano" style="color:#b47b2d">mano paskyros</a> ir pamatysite, ką už juos galite gauti.</p>`
  );
  return sendMail(to, "Seniai matėmės — jūsų mėgstami skoniai laukia ✦", html);
}

// ---------------- Customer emails (template-driven) ----------------

/** Multi-line body text -> <p> paragraphs. */
function paragraphs(text: string) {
  return String(text || "")
    .split(/\n+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => `<p style="line-height:1.6">${s}</p>`)
    .join("");
}

/** Base info block — when / number / total summary (+ customer note). */
function baseInfoBlock(order: Order, kind: "order" | "reservation") {
  if (kind === "reservation") {
    return `<p>Rezervacijos numeris: <strong>#${order.number}</strong><br/>
Data ir laikas: <strong>${order.resDate} ${order.resTime}</strong><br/>
Svečių skaičius: <strong>${order.guests}</strong><br/>
${order.experiences ? `Patirtys: ${order.experiences}<br/>` : ""}
${order.total > 0 ? `Numatoma patiekalų suma: <strong>${fmtEur(order.total)}</strong><br/>` : ""}</p>${order.note ? `<p>Pastaba: ${order.note}</p>` : ""}`;
  }
  return `<p>Atsiėmimo laikas: <strong>${order.pickupTime || "patvirtinsime"}</strong><br/>Užsakymo numeris: <strong>#${order.number}</strong><br/>Suma: <strong>${fmtEur(order.total)}</strong></p>${order.note ? `<p>Pastaba: ${order.note}</p>` : ""}`;
}

function orderItemsHtml(items: CartItem[]) {
  if (!items.length) return "";
  return orderRows(items);
}

/** All placeholders available in templates, resolved from the order + settings. */
function orderVars(order: Order, kind: "order" | "reservation", s: Awaited<ReturnType<typeof getSettings>>, link: string): Record<string, string> {
  return {
    vardas: order.customerName || "",
    numeris: order.number,
    suma: fmtEur(order.total),
    laikas:
      kind === "order" ? order.pickupTime || "patvirtinsime" : `${order.resDate} ${order.resTime}`.trim(),
    sveciai: order.guests ? String(order.guests) : "",
    mokejimas: METHOD_LT[order.paymentMethod] || order.paymentMethod || "",
    ref: order.paymentRef || "",
    telefonas: s.site.phoneDisplay || s.site.phone,
    nuoroda: link,
    restoranas: s.site.name,
  };
}

/**
 * Composes the final { subject, html } from a merged template + order.
 * Block order: body text → base info → items → payment → tracking link,
 * each block toggleable per template. Shared by real sends and admin preview.
 */
function composeOrderEmail(
  order: Order,
  tpl: EmailTemplate,
  kind: "order" | "reservation",
  s: Awaited<ReturnType<typeof getSettings>>,
  baseUrl: string
): { subject: string; html: string } {
  const link = trackLinkFor(baseUrl, order);
  const safe = htmlSafeOrder(order); // SEC-004
  const vars = orderVars(safe, kind, s, escapeHtml(link));
  const rawVars = orderVars(order, kind, s, link); // plain-text subject only
  const items: CartItem[] = JSON.parse(safe.itemsJson || "[]");

  const parts: string[] = [];
  const bodyHtml = paragraphs(renderTpl(tpl.body, vars));
  if (bodyHtml) parts.push(bodyHtml);
  if (tpl.showDetails) parts.push(baseInfoBlock(safe, kind));
  if (tpl.showItems) parts.push(orderItemsHtml(items));
  if (tpl.showPayment && order.paymentMethod) parts.push(paymentBlock(safe));
  if (tpl.showTrack) parts.push(`<p>Būseną galite stebėti čia:<br/><a href="${escapeHtml(link)}">${escapeHtml(link)}</a></p>`);

  const subject = renderTpl(tpl.subject, rawVars);
  const html = layout(renderTpl(tpl.title, vars), parts.join(""));
  return { subject, html };
}

/**
 * Renders a customer email from the editable template (settings.email.templates
 * merged over DEFAULT_TEMPLATES) and sends it.
 */
async function renderOrderEmail(
  order: Order,
  event: string,
  baseUrl: string,
  kindOverride?: "order" | "reservation"
): Promise<{ ok: boolean; error?: string }> {
  const kind = kindOverride || (order.type === "pickup" ? "order" : "reservation");
  const key = `${kind}.${event}` as EmailTemplateKey;
  if (!DEFAULT_TEMPLATES[key] || !order.email) return { ok: false, error: "no-recipient" };

  const s = await getSettings();
  const tpl = mergeTemplate(key, s.email.templates);
  const { subject, html } = composeOrderEmail(order, tpl, kind, s, baseUrl);
  return sendMail(order.email, subject, html);
}

// ---------------- Admin template preview (sample data) ----------------

/** Realistic sample order so the admin sees the template as a customer would. */
function sampleOrder(kind: "order" | "reservation"): Order {
  const items = [
    { id: "s1", name: "Obuolių pyragas", price: 4.5, qty: 2 },
    { id: "s2", name: "Kava „Alma“", price: 3.2, qty: 1 },
  ];
  const base = {
    id: "preview",
    number: "AC-1042",
    status: "confirmed",
    customerName: "Eglė Petraitienė",
    phone: "+370 600 00000",
    email: "klientas@pavyzdys.lt",
    itemsJson: JSON.stringify(items),
    total: items.reduce((t, i) => t + i.price * i.qty, 0),
    note: kind === "reservation" ? "Staliukas prie lango, jei įmanoma." : "Be riešutų, prašau.",
    historyJson: "[]",
    isRead: false,
    prepMinutes: null,
    prepSetAt: null,
    paymentStatus: "paid",
    paymentMethod: "stripe",
    paymentRef: "pi_3PxYzDemo123456",
    paidAt: new Date(),
    taxAmount: 0,
    userId: null,
    locationId: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  return kind === "reservation"
    ? ({ ...base, type: "reservation", resDate: "2026-05-15", resTime: "18:30", guests: 4, experiences: "Degustacija", pickupTime: "" } as unknown as Order)
    : ({ ...base, type: "pickup", resDate: "", resTime: "", guests: 0, experiences: "", pickupTime: "Šiandien 17:30" } as unknown as Order);
}

/**
 * Admin-side preview: renders any template key (optionally with unsaved edits
 * in `draft`) against sample data — no email is sent from here.
 */
export async function renderTemplatePreview(
  key: EmailTemplateKey,
  draft?: Partial<EmailTemplate>,
  baseUrl = "http://localhost:3000"
): Promise<{ subject: string; html: string } | null> {
  if (!DEFAULT_TEMPLATES[key]) return null;
  const kind = key.split(".")[0] as "order" | "reservation";
  const s = await getSettings();
  const tpl = mergeTemplate(key, { [key]: draft } as EmailTemplatesSetting);
  return composeOrderEmail(sampleOrder(kind), tpl, kind, s, baseUrl);
}

export async function emailOrderEvent(order: Order, event: string, baseUrl: string) {
  return renderOrderEmail(order, event, baseUrl);
}

export async function emailReservationEvent(order: Order, event: string, baseUrl: string) {
  return renderOrderEmail(order, event, baseUrl, "reservation");
}

// ---------------- Internal restaurant notification ----------------
export async function notifyRestaurant(rawOrder: Order, baseUrl: string) {
  const order = htmlSafeOrder(rawOrder); // SEC-004: body built from escaped copy
  const s = await getSettings();
  const to = s.email.notifyEmail || s.site.email;
  if (!to) return { ok: false, error: "no-notify-email" };
  const items: CartItem[] = JSON.parse(order.itemsJson || "[]");
  const isPickup = order.type === "pickup";
  const link = `${baseUrl}/admin`;
  const body = `
    <p><strong>${isPickup ? "Naujas atsiėmimo užsakymas" : "Nauja rezervacijos užklausa"}</strong> #${order.number}</p>
    <p>Klientas: ${order.customerName}, tel. ${order.phone}${order.email ? `, ${order.email}` : ""}<br/>
    ${isPickup ? `Atsiėmimas: ${order.pickupTime || "—"}` : `Data: ${order.resDate} ${order.resTime}, svečių: ${order.guests}`}</p>
    ${orderItemsHtml(items)}
    ${order.total > 0 ? `<p>Suma: <strong>${fmtEur(order.total)}</strong></p>` : ""}
    ${order.note ? `<p>Pastaba: ${order.note}</p>` : ""}
    <p><a href="${link}">Atidaryti /admin →</a></p>`;
  return sendMail(to, `${isPickup ? "Naujas užsakymas" : "Nauja rezervacija"} #${rawOrder.number}`, layout("Naujas įrašas sistemoje", body));
}

export async function sendTestEmail(to: string) {
  return sendMail(to, "Alma Chaab – bandomasis laiškas", layout("Sistema veikia!", "<p>Šis bandomasis laiškas patvirtina, kad el. pašto nustatymai teisingi.</p>"));
}
