import { z } from 'zod';

export function safeContentUrl(value: string): boolean {
  if (!value) return true;
  if (/[\s\\\u0000-\u001f]/.test(value)) return false;
  if (value.startsWith('#')) return /^#[a-zA-Z0-9_-]+$/.test(value);
  if (value.startsWith('/')) return !value.startsWith('//');
  try { return ['http:', 'https:'].includes(new URL(value).protocol); } catch { return false; }
}
const url = z.string().max(2000).refine(safeContentUrl, 'Įveskite saugią http(s) arba svetainės nuorodą.');
const identifier = z.string().regex(/^[a-z][a-z0-9-]{0,60}$/);
export const navigationSchema = z.array(z.object({ id: identifier, label: z.string().trim().min(1).max(100), href: url.refine(Boolean), parentId: z.string().max(61).default(''), visible: z.boolean() })).max(30).superRefine((items, ctx) => {
  const ids = new Set(items.map(x => x.id));
  if (ids.size !== items.length) ctx.addIssue({ code: 'custom', message: 'Navigacijos identifikatoriai turi būti unikalūs.' });
  for (const item of items) if (item.parentId && (!items.some(p => p.id === item.parentId && !p.parentId) || item.parentId === item.id)) ctx.addIssue({ code: 'custom', message: 'Navigacijos tėvinis įrašas turi būti aukščiausiame lygyje.' });
});
export const eventSchema = z.array(z.object({
  id: identifier, title: z.string().trim().min(1).max(200), date: z.string().max(10), time: z.string().max(5), description: z.string().max(5000), image: url, bookingUrl: url, published: z.boolean(), draftNote: z.string().max(1000),
})).max(100).superRefine((events, ctx) => {
  if (new Set(events.map(e => e.id)).size !== events.length) ctx.addIssue({ code: 'custom', message: 'Renginių identifikatoriai turi būti unikalūs.' });
  for (const e of events) {
    const validDate = /^\d{4}-\d{2}-\d{2}$/.test(e.date) && !Number.isNaN(Date.parse(e.date)) && new Date(e.date).toISOString().slice(0,10) === e.date;
    if ((e.date && !validDate) || (e.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(e.time)) || (e.published && (!validDate || !e.time || !e.description.trim()))) ctx.addIssue({ code: 'custom', message: 'Skelbiamam renginiui reikia tikros datos su metais, laiko ir aprašymo.' });
  }
});
export const pagesSchema = z.array(z.object({ id: identifier, title: z.string().trim().min(1).max(200), text: z.string().max(10000), image: url, alt: z.string().max(300), ctaLabel: z.string().max(100), ctaHref: url, visible: z.boolean() })).max(30).superRefine((pages, ctx) => {
  const reserved = new Set(['pradzia','meniu','apie','atsiliepimai','kontaktai','pries-atvykstant','renginiai','galerija','degustacijos','skoniai','wolt']);
  if (new Set(pages.map(p => p.id)).size !== pages.length || pages.some(p => reserved.has(p.id))) ctx.addIssue({ code: 'custom', message: 'Puslapio identifikatorius turi būti unikalus ir nenaudojamas kitur.' });
});
export const DEFAULT_NAVIGATION = [
  { id: 'menu', label: 'Meniu ir rezervacija', href: '#meniu', parentId: '', visible: true },
  { id: 'about', label: 'Apie mus', href: '/apie-mus', parentId: '', visible: true },
  { id: 'visitor', label: 'Prieš atvykstant', href: '#pries-atvykstant', parentId: '', visible: true },
  { id: 'contact', label: 'Kontaktai', href: '#kontaktai', parentId: '', visible: true },
];
export function validateManagedContent(content: any): string | null {
  if (!content || typeof content !== 'object' || Array.isArray(content)) return 'Netinkamas turinys.';
  for (const [key,schema] of [['navigation',navigationSchema],['liveEvents',eventSchema],['pages',pagesSchema]] as const) {
    if (content[key] !== undefined) { const result = schema.safeParse(content[key]); if (!result.success) return result.error.issues[0]?.message || 'Netinkamas turinys.'; }
  }
  if (content.visibility && (typeof content.visibility !== 'object' || Object.values(content.visibility).some(v => typeof v !== 'boolean'))) return 'Netinkamas skyrių matomumas.';
  if (content.gallery?.images !== undefined) {
    const images=z.array(z.object({ src:url.refine(Boolean), caption:z.string().max(1000), alt:z.string().max(500).optional() })).max(100).safeParse(content.gallery.images);
    if (!images.success) return 'Patikrinkite galerijos nuorodas, antraštes ir alternatyvų tekstą.';
  }
  if(content.people!==undefined){const result=z.array(z.object({id:z.string().min(1).max(80),name:z.string().trim().min(1).max(200),role:z.string().max(200),bio:z.string().max(5000),image:url})).max(30).safeParse(content.people);if(!result.success)return 'Patikrinkite žmonių vardus, pareigas ir nuotraukas.';}
  if(content.sectionOrder!==undefined&&(!Array.isArray(content.sectionOrder)||content.sectionOrder.some((k:any)=>!['hero','proof','about','ribbon','social','menu','hub','wolt','contacts','custom','visitor','seo'].includes(k))))return 'Netinkama skyrių tvarka.';
  if(content.visualStyles){for(const style of Object.values(content.visualStyles) as any[]){if(!style||typeof style!=='object'||Object.keys(style).some(k=>!['color','textAlign'].includes(k))||(style.color&&!/^#[a-f0-9]{6}$/i.test(style.color))||(style.textAlign&&!['left','center','right'].includes(style.textAlign)))return 'Netinkamas teksto stilius.';}}
  const b=content.events?.billiards;
  if (b) {
    for (const field of ['studentPrice','adultPrice']) if (b[field] !== undefined && (typeof b[field] !== 'number' || !Number.isFinite(b[field]) || b[field]<0 || b[field]>10000)) return 'Netinkama biliardo kaina.';
    if (b.cutoff !== undefined && !/^([01]\d|2[0-3]):[0-5]\d$/.test(b.cutoff)) return 'Netinkamas biliardo laikas.';
  }
  if (content.visitor && (typeof content.visitor !== 'object' || Object.values(content.visitor).some(v => typeof v !== 'string' || v.length>3000))) return 'Netinkama informacija lankytojams.';
  return null;
}
export function publicContent(content: any) {
  const { liveEvents = [], ...rest } = content || {};
  return { ...rest, pages: (rest.pages || []).filter((p: any) => p.visible), liveEvents: liveEvents.filter((e: any) => e.published && eventSchema.safeParse([e]).success).map(({ draftNote: _note, ...e }: any) => e) };
}
