/** Only explicitly visible and reviewed dietary information leaves the server. */
export function publicMenuItem<T extends Record<string,any>>(item:T, options:{labels?:boolean;notes?:boolean}={}){
 const {dietaryInternalNote:_private,dietaryReviewed,dietaryVisible,dietaryNotesVisible,...safe}=item;
 const visible=dietaryVisible===true&&dietaryReviewed===true;
 return {...safe,vegetarian:visible&&options.labels!==false&&item.vegetarian===true,vegan:visible&&options.labels!==false&&item.vegan===true,halal:visible&&options.labels!==false&&item.halal===true,dietaryNotes:visible&&options.notes!==false&&dietaryNotesVisible===true?item.dietaryNotes:''};
}
