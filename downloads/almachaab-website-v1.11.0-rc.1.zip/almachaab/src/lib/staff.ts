import {db} from './db';
import {randomUUID, scryptSync, randomBytes, timingSafeEqual} from 'crypto';
export type StaffRole='owner'|'editor'|'kitchen';
export type Permission='content'|'publish'|'media'|'menu'|'orders'|'help'|'users'|'settings';
export type StaffAccount={id:string;username:string;name:string;role:'editor'|'kitchen';canPublish:boolean;active:boolean;passwordHash:string;sessionVersion:number};
export const staffHash=(value:string)=>{const salt=randomBytes(16).toString('hex');return `scrypt:${salt}:${scryptSync(value,salt,64).toString('hex')}`;};
export function verifyStaffPassword(value:string,hash:string){try{const [,salt,hex]=hash.split(':');const expected=Buffer.from(hex,'hex');const actual=scryptSync(value,salt,64);return actual.length===expected.length&&timingSafeEqual(actual,expected);}catch{return false;}}
export async function staffAccounts():Promise<StaffAccount[]>{return(await db.setting.findMany({where:{key:{startsWith:'staff:'}}})).map(row=>JSON.parse(row.value));}
export async function staffById(id:string):Promise<StaffAccount|null>{const row=await db.setting.findUnique({where:{key:`staff:${id}`}});return row?JSON.parse(row.value):null;}
export async function saveStaff(account:StaffAccount){const key=`staff:${account.id}`;const value=JSON.stringify(account);await db.setting.upsert({where:{key},update:{value},create:{key,value}});}
export function permissionFor(role:StaffRole,permission:Permission,publish=false){if(role==='owner')return true;if(role==='kitchen')return ['orders','help'].includes(permission);return ['content','media','menu','help'].includes(permission)||(permission==='publish'&&publish);}
export async function revokeStaff(id:string){const staff=await staffById(id);if(staff)await saveStaff({...staff,sessionVersion:staff.sessionVersion+1});}
export function newStaffId(){return randomUUID().replaceAll('-','');}
