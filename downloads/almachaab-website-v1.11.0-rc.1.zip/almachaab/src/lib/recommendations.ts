import { db } from "./db";

/**
 * Smart upsell engine — "Frequently Bought Together".
 *
 * Strategy (best signal first):
 *  1. Co-purchase mining — scan recent orders that contain a cart item and
 *     rank the other items that rode along most often. Real behavioural data
 *     from this restaurant, so it surfaces actual pairings (drink with a
 *     main, sauce with a starter).
 *  2. Margin heuristics — when there is not enough history, fill remaining
 *     slots with high-attach categories (drinks, desserts, sauces) that are
 *     not already in the cart.
 *
 * Only active, in-stock items are ever recommended, and quantities are
 * aggregated by menu item id, so renames keep history useful.
 */

export interface Recommendation {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  reason: string; // shown on the card
  score: number;
}

const UPSell_CATEGORIES = ["gerimai", "desertai", "padazai", "uzkandziai"];

export async function recommendForCart(
  cartItemIds: string[],
  opts: { limit?: number; categoryByItem?: Map<string, string>; onlyCategories?: string[] } = {}
): Promise<Recommendation[]> {
  const limit = Math.max(1, Math.min(6, opts.limit ?? 3));
  const ids = cartItemIds.filter(Boolean);
  if (ids.length === 0) return [];

  // Candidate pool: everything active + in stock, excluding cart items.
  // onlyCategories (e.g. drinks-only upsell) narrows the pool first, so the
  // whole ranking — mining and heuristics alike — can never leave that scope.
  const pool = await db.menuItem.findMany({
    where: {
      active: true,
      inStock: true,
      OR: [{ stockCount: null }, { stockCount: { gt: 0 } }],
      ...(opts.onlyCategories?.length ? { categoryId: { in: opts.onlyCategories } } : {}),
    },
    include: { category: true },
  });
  const cartSet = new Set(ids);
  const candidates = pool.filter((i) => !cartSet.has(i.id));
  if (candidates.length === 0) return [];

  const scores = new Map<string, number>();
  const reasons = new Map<string, string>();
  const bump = (id: string, pts: number, reason: string) => {
    scores.set(id, (scores.get(id) || 0) + pts);
    if (!reasons.has(id)) reasons.set(id, reason);
  };

  // 1) Co-purchase mining over the latest 300 orders.
  const recent = await db.order.findMany({
    where: { itemsJson: { not: "[]" }, status: { not: "cancelled" } },
    orderBy: { createdAt: "desc" },
    take: 300,
    select: { itemsJson: true },
  });
  let mined = 0;
  for (const o of recent) {
    let items: { id: string; qty?: number }[] = [];
    try {
      const parsed = JSON.parse(o.itemsJson);
      if (Array.isArray(parsed)) items = parsed;
    } catch {
      continue;
    }
    const itemIds = items.map((i) => String(i.id || "")).filter(Boolean);
    if (!itemIds.some((id) => cartSet.has(id))) continue;
    mined++;
    for (const id of itemIds) {
      if (cartSet.has(id)) continue;
      // More recent orders matter a little more (front of the list).
      bump(id, 10, "Dažniausiai kartu perkama");
    }
  }

  // 2) Category-affinity fill for items the mining did not surface.
  const catOf = new Map(pool.map((i) => [i.id, i.categoryId]));
  const cartCats = new Set(ids.map((id) => catOf.get(id)).filter(Boolean) as string[]);
  for (const cand of candidates) {
    if (scores.has(cand.id)) continue;
    if (UPSell_CATEGORIES.includes(cand.categoryId)) {
      bump(cand.id, 4, "Puikus priedas prie jūsų pasirinkimo");
    } else if (cartCats.has(cand.categoryId)) {
      bump(cand.id, 2, "Panašaus skonio pasirinkimų");
    }
  }
  if (mined === 0) {
    // No history at all → prefer the classic margin-makers.
    for (const cand of candidates) {
      if (UPSell_CATEGORIES.includes(cand.categoryId)) bump(cand.id, 3, "Mėgstamiausi priedai");
    }
  }

  return candidates
    .map((cand) => ({ cand, score: scores.get(cand.id) || 0 }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || a.cand.sortOrder - b.cand.sortOrder)
    .slice(0, limit)
    .map(({ cand, score }) => ({
      id: cand.id,
      name: cand.name,
      price: cand.price,
      image: cand.image,
      description: cand.description,
      reason: reasons.get(cand.id) || "Rekomenduojame",
      score,
    }));
}
