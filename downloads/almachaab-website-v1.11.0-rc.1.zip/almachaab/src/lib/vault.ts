import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";

/**
 * Secrets-at-rest vault — AES-256-GCM.
 *
 * Payment gateway keys, the SMTP mailbox password, the VAPID private key and
 * the admin session secret are stored in SQLite only in encrypted form. The
 * encryption key is kept OUT of the database: env var APP_SECRET_KEY.
 *
 * Ciphertext format: "enc:v1:<iv b64>:<auth tag b64>:<ciphertext b64>".
 * Values without the prefix are treated as legacy plaintext and returned
 * as-is (a one-time migration script re-saves them encrypted).
 *
 * SEC-001/002: there is NO built-in fallback key in production. A missing
 * APP_SECRET_KEY makes every secret operation throw, so the app fails loudly
 * instead of encrypting with a key that is published in the source code.
 * Development keeps a local-only key so `next dev` works without setup.
 */

const PREFIX = "enc:v1:";

let warned = false;

export class VaultKeyMissingError extends Error {
  constructor() {
    super("APP_SECRET_KEY is not set — refusing to read or write secrets. Set it in the server environment (see DEPLOY.md §0).");
    this.name = "VaultKeyMissingError";
  }
}

function key(): Buffer {
  const raw = (process.env.APP_SECRET_KEY || "").trim();
  if (raw) {
    if (raw.length < 32) throw new Error("APP_SECRET_KEY is too short — use 64 hex characters (32 random bytes).");
    return createHash("sha256").update(raw).digest();
  }
  if (process.env.NODE_ENV === "production") throw new VaultKeyMissingError();
  if (!warned) {
    console.warn("[vault] APP_SECRET_KEY is not set — using a development-only key. Production refuses to start secret operations without it.");
    warned = true;
  }
  return createHash("sha256").update("alma-chaab-dev-only-key").digest();
}

export function isEncrypted(value: string | null | undefined): boolean {
  return typeof value === "string" && value.startsWith(PREFIX);
}

/** Encrypts a secret. Throws (never stores plaintext) when no key is available. */
export function encryptSecret(plain: string): string {
  if (!plain || isEncrypted(plain)) return plain;
  const k = key();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", k, iv);
  const ct = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + [iv.toString("base64"), tag.toString("base64"), ct.toString("base64")].join(":");
}

/**
 * Decrypts a secret. A record encrypted with a different key (or corrupted)
 * comes back as "" — callers that need a value must treat "" as "missing"
 * and never as a usable key (see getSettings → admin.secret).
 */
export function decryptSecret(value: string): string {
  if (!value || !isEncrypted(value)) return value;
  const k = key();
  try {
    const [ivB64, tagB64, ctB64] = value.slice(PREFIX.length).split(":");
    const decipher = createDecipheriv("aes-256-gcm", k, Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(ctB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}
