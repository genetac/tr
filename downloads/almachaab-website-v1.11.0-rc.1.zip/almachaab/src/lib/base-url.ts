/**
 * SEC-016: canonical absolute base URL for links in emails, payment return
 * URLs and redirects. Built from NEXTAUTH_URL — never from request headers
 * (Host / X-Forwarded-Host), which a client can influence when the app is
 * reached without the Caddy proxy in front.
 * Development without NEXTAUTH_URL falls back to the local dev host.
 */
export function siteBaseUrl(req?: { headers: Headers }): string {
  const env = (process.env.NEXTAUTH_URL || "").trim().replace(/\/+$/, "");
  if (/^https?:\/\/[A-Za-z0-9.-]+(:\d+)?$/.test(env)) return env;
  if (process.env.NODE_ENV === "production") return "https://almachaab.lt";
  const host = req?.headers.get("host") || "";
  return /^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host) ? `http://${host}` : "http://localhost:3000";
}
