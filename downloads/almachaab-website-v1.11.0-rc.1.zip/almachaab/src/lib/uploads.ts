import path from "path";

/**
 * Where uploaded images live on disk. Set UPLOAD_DIR in .env on the server
 * (e.g. /var/www/almachaab/uploads). Defaults to ./uploads next to the app.
 * Keep it OUTSIDE public/ and outside the build output so deploys never wipe it.
 */
export const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), "uploads");
