import {z} from 'zod';
import {safeContentUrl,validateManagedContent} from './content-management';
export const safeUrl=z.string().max(2000).refine(safeContentUrl,'Netinkama nuoroda.');
const color=z.string().regex(/^#[0-9a-f]{6}$/i);
export const blockSchema=z.object({id:z.string().min(1).max(100),t:z.enum(['p','h','q','ul','md','img','button','visitor','people','business']),text:z.string().max(30000).optional(),html:z.string().max(40000).optional(),items:z.array(z.string().max(5000)).max(100).optional(),url:safeUrl.optional(),alt:z.string().max(500).optional(),caption:z.string().max(1000).optional(),visible:z.boolean().default(true),color:color.optional(),background:color.optional(),align:z.enum(['left','center','right']).optional(),width:z.enum(['normal','wide']).optional()});
export const bodySchema=z.array(blockSchema).max(200).refine(blocks=>new Set(blocks.map(b=>b.id)).size===blocks.length,'Blokų identifikatoriai kartojasi.');
export const pageSchema=z.object({title:z.string().trim().min(1).max(200),slug:z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(150),description:z.string().max(500).default(''),visible:z.boolean().default(true),blocks:bodySchema,coverImage:safeUrl.default(''),author:z.string().max(200).default('')});
export const articleSchema=z.object({title:z.string().trim().min(1).max(200),slug:z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(150),excerpt:z.string().max(2000).default(''),keywords:z.string().max(2000).default(''),coverImage:safeUrl.default(''),body:bodySchema,published:z.boolean().default(true)});
export const menuSchema=z.object({name:z.string().trim().min(1).max(200),description:z.string().max(3000),price:z.number().finite().min(0).max(10000),image:safeUrl,active:z.boolean(),vegetarian:z.boolean(),vegan:z.boolean(),halal:z.boolean(),dietaryNotes:z.string().max(1000),dietaryVisible:z.boolean().default(false),dietaryNotesVisible:z.boolean().default(false),dietaryReviewed:z.boolean().default(false),dietaryInternalNote:z.string().max(2000).default('')});
export function validateDocument(key:string,value:any):any{
 const walk=(v:any,depth=0)=>{if(depth>35)throw new Error('Per sudėtingas dokumentas.');if(v&&typeof v==='object')for(const [key,child] of Object.entries(v)){if(['__proto__','prototype','constructor'].includes(key))throw new Error('Netinkamas dokumento laukas.');walk(child,depth+1);}};walk(value);
 if(key==='dietaryDisplay')return z.object({labels:z.boolean(),notes:z.boolean(),filters:z.boolean()}).parse(value);
 if(key==='menu-layout')return z.array(z.object({id:z.string().min(1).max(100),name:z.string().trim().min(1).max(200),active:z.boolean(),itemOrder:z.array(z.string().min(1).max(100)).max(500)})).max(100).refine(a=>new Set(a.map(c=>c.id)).size===a.length,'Kategorijos kartojasi.').parse(value);
 if(key==='content'){const error=validateManagedContent(value);if(error)throw new Error(error);return value;}
 if(key.startsWith('page:'))return pageSchema.parse(value);
 if(key.startsWith('article:'))return articleSchema.parse(value);
 if(key.startsWith('menu:'))return menuSchema.parse(value);
 if(key==='theme'){
  const fields=['gold','gold2','cream','cream2','paper','ink','muted','line','dark'];
  for(const field of fields)color.parse(value[field]);
  if(typeof value.fontHead!=='string'||typeof value.fontBody!=='string'||/[{};<>@\\]/.test(value.fontHead+value.fontBody))throw new Error('Netinkamas šriftas.');
  if(!Number.isFinite(value.radius)||value.radius<0||value.radius>40)throw new Error('Netinkamas kampų dydis.');return value;
 }
 if(key==='site'){
  if(!value||typeof value.name!=='string'||!value.name.trim())throw new Error('Įrašykite pavadinimą.');
  for(const [field,text]of Object.entries(value)){if(typeof text!=='string'||text.length>2000)throw new Error('Netinkamas nustatymas.');if(/Url$/.test(field))safeUrl.parse(text);}return value;
 }
 if(key==='hours'){
  if(!value||Object.keys(value).some(k=>!['mon','tue','wed','thu','fri','sat','sun'].includes(k)))throw new Error('Netinkama savaitės diena.');
  for(const h of Object.values(value))if(h!==null&&(!Array.isArray(h)||h.length!==2||h.some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0||x>24)||h[0]>=h[1]))throw new Error('Patikrinkite darbo valandas.');return value;
 }
 throw new Error('Netinkamas dokumentas.');
}
