import { db } from "./db";
import { getStoreSettings, type StoreSettings } from "./settings";

/**
 * Multi-branch helpers.
 *
 * A Location row can override the global tax rate and delivery fee
 * (null = inherit from the Settings singleton). New orders are attached
 * to the default active branch so reporting per-branch stays possible
 * without any extra guest friction for the single-location case.
 */

export interface ResolvedPricing {
  locationId: string | null;
  locationName: string | null;
  taxRate: number;
  deliveryFee: number;
}

export async function listLocations(onlyActive = false) {
  return db.location.findMany({
    where: onlyActive ? { isActive: true } : undefined,
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });
}

export async function getDefaultLocation() {
  const def = await db.location.findFirst({
    where: { isActive: true, isDefault: true },
    orderBy: { sortOrder: "asc" },
  });
  if (def) return def;
  // fall back to the first active branch
  return db.location.findFirst({ where: { isActive: true }, orderBy: { sortOrder: "asc" } });
}

/**
 * Global store settings merged with the default branch's overrides.
 * This is the single source of truth for order pricing.
 */
export async function resolvePricing(): Promise<ResolvedPricing & { store: StoreSettings }> {
  const store = await getStoreSettings();
  const loc = await getDefaultLocation();
  return {
    store,
    locationId: loc?.id || null,
    locationName: loc?.name || null,
    taxRate: loc?.taxRate ?? store.taxRate,
    deliveryFee: loc?.deliveryFee ?? store.deliveryFee,
  };
}

/** Validation shared by the admin CRUD route. */
export function sanitizeLocationInput(v: Record<string, unknown>) {
  const out: Record<string, unknown> = {};
  if (typeof v.name === "string") out.name = v.name.trim().slice(0, 120);
  if (typeof v.address === "string") out.address = v.address.trim().slice(0, 200);
  if (typeof v.phone === "string") out.phone = v.phone.trim().slice(0, 40);
  if (typeof v.isActive === "boolean") out.isActive = v.isActive;
  if (typeof v.isDefault === "boolean") out.isDefault = v.isDefault;
  if (typeof v.sortOrder === "number" && Number.isFinite(v.sortOrder)) {
    out.sortOrder = Math.max(0, Math.floor(v.sortOrder));
  }
  for (const key of ["taxRate", "deliveryFee"] as const) {
    const raw = v[key];
    if (raw === null || raw === "") {
      out[key] = null; // inherit global
    } else if (raw !== undefined) {
      const n = Number(raw);
      out[key] = Number.isFinite(n) ? Math.max(0, key === "taxRate" ? Math.min(100, n) : Math.min(1000, n)) : null;
    }
  }
  return out;
}
