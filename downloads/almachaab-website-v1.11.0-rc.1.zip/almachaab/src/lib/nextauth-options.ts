import type { NextAuthOptions } from "next-auth";
import GoogleProvider, { type GoogleProfile } from "next-auth/providers/google";
import FacebookProvider, { type FacebookProfile } from "next-auth/providers/facebook";
import { getSocialConfig, upsertSocialUser } from "./social-auth";
import { getSettings } from "./settings";
import { createHmac } from "crypto";

/**
 * NextAuth options are built per-request because the provider credentials
 * live in the database (admin panel → Nustatymai → Socialiniai prisijungimai)
 * and can change at runtime, with .env values as a fallback.
 *
 * Session strategy is "jwt" — NextAuth's own cookie only carries the provisioned
 * user id through the OAuth callback. The app's source of truth stays the
 * existing `alma_user` HMAC cookie, which the /api/auth/social/bridge route
 * issues right after the callback. That keeps every existing flow (orders,
 * loyalty, /mano, push opt-in) working without any changes.
 */

export const NEXTAUTH_COOKIE_NAME = "authjs.state.session";

export async function nextAuthSecret(): Promise<string> {
  const env = (process.env.NEXTAUTH_SECRET || "").trim();
  if (env.length >= 32) return env;
  // SEC-002: no hard-coded fallback. Without NEXTAUTH_SECRET, derive a
  // per-install key from the random admin HMAC secret (getSettings guarantees
  // it exists and is ≥ 32 chars), domain-separated so it is never the same key.
  const s = await getSettings();
  return createHmac("sha256", s.admin.secret).update("nextauth-v1").digest("hex");
}

export async function buildAuthOptions(): Promise<NextAuthOptions> {
  const cfg = await getSocialConfig();
  const secret = await nextAuthSecret();

  const providers: NextAuthOptions["providers"] = [];

  if (cfg.google.enabled && cfg.google.clientId && cfg.google.clientSecret) {
    providers.push(
      GoogleProvider({
        clientId: cfg.google.clientId,
        clientSecret: cfg.google.clientSecret,
        authorization: {
          params: { prompt: "select_account" },
        },
        profile(profile: GoogleProfile) {
          return {
            id: profile.sub,
            name: profile.name || "",
            email: profile.email,
            image: profile.picture || "",
          };
        },
      })
    );
  }

  if (cfg.facebook.enabled && cfg.facebook.clientId && cfg.facebook.clientSecret) {
    providers.push(
      FacebookProvider({
        clientId: cfg.facebook.clientId,
        clientSecret: cfg.facebook.clientSecret,
        profile(profile: FacebookProfile) {
          return {
            id: profile.id,
            name: profile.name || "",
            email: profile.email ?? "",
            image: profile.picture?.data?.url || "",
          };
        },
      })
    );
  }

  return {
    providers,
    secret,
    session: { strategy: "jwt", maxAge: 10 * 60 }, // short-lived bridge token
    jwt: {
      maxAge: 10 * 60,
    },
    pages: {
      signIn: "/mano",
      error: "/mano",
    },
    callbacks: {
      async signIn({ user, account }) {
        // Provision/link the customer row immediately on successful OAuth.
        try {
          if (!account || !user?.email) return false;
          await upsertSocialUser({
            provider: account.provider as "google" | "facebook" | "telegram",
            providerAccountId: account.providerAccountId,
            email: user.email,
            name: user.name || "",
            image: user.image || "",
          });
          // Carry the internal user id through the JWT to the bridge route.
          return true;
        } catch (err) {
          console.error("[nextauth] signIn provisioning failed:", err);
          return false;
        }
      },
      async jwt({ token, user, account }) {
        if (user?.email && account) {
          try {
            const { db } = await import("./db");
            const u = await db.user.findUnique({ where: { email: user.email } });
            if (u) {
              token.uid = u.id;
              token.bridge = "alma-social-v1"; // set only after a real OAuth sign-in
            }
          } catch {
            /* no uid → the bridge refuses the token */
          }
        }
        return token;
      },
      async redirect({ baseUrl }) {
        // After the OAuth callback ALWAYS land through the bridge, which
        // exchanges the NextAuth JWT for the native alma_user cookie and
        // continues to /mano.
        return `${baseUrl}/api/auth/social/bridge`;
      },
    },
  };
}
