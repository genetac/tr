import { db } from "./db";
import { getSettings, getStoreSettings, type StoreSettings } from "./settings";
import type { Order } from "@prisma/client";

export const ORDER_STATUSES = ["new", "awaiting", "confirmed", "preparing", "ready", "completed", "cancelled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const STATUS_LT: Record<string, string> = {
  new: "Naujas",
  awaiting: "Laukiama patvirtinimo",
  confirmed: "Patvirtintas",
  preparing: "Ruošiamas",
  ready: "Paruoštas",
  completed: "Užbaigtas",
  cancelled: "Atšauktas",
};

export const RESERVATION_STATUSES = ["new", "confirmed", "completed", "cancelled"] as const;

export async function nextOrderNumber(): Promise<string> {
  const s = await getSettings();
  const num = s.orders.nextNumber;
  await db.setting.update({
    where: { key: "orders" },
    data: { value: JSON.stringify({ ...s.orders, nextNumber: num + 1 }) },
  });
  return `${s.orders.prefix}-${num}`;
}

export function pushHistory(order: Order, status: string, extra?: Record<string, unknown>) {
  const hist = JSON.parse(order.historyJson || "[]");
  hist.push({ status, at: new Date().toISOString(), ...(extra || {}) });
  return JSON.stringify(hist);
}

export function parseItems(itemsJson: string) {
  try {
    const arr = JSON.parse(itemsJson || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

// Validate that submitted item ids exist and recompute total server-side.
// Out-of-stock items (86'd by the admin) are rejected and reported by name.
export async function priceCart(items: { id: string; qty: number }[]) {
  const ids = items.map((i) => i.id);
  const dbItems = await db.menuItem.findMany({ where: { id: { in: ids }, active: true } });
  const byId = new Map(dbItems.map((d) => [d.id, d]));
  const clean: { id: string; name: string; price: number; qty: number }[] = [];
  const soldOut: string[] = [];
  let total = 0;
  for (const it of items) {
    const d = byId.get(it.id);
    if (!d) continue;
    if (!d.inStock || (d.stockCount !== null && d.stockCount <= 0)) {
      soldOut.push(d.name);
      continue;
    }
    const qty = Math.max(0, Math.min(50, Math.floor(Number(it.qty) || 0)));
    if (qty === 0) continue;
    clean.push({ id: d.id, name: d.name, price: d.price, qty });
    total += d.price * qty;
  }
  return { clean, total: Math.round(total * 100) / 100, soldOut };
}

// Money math: subtotal → + tax (PVM %) → + delivery fee → total.
// Amounts are rounded to cents at every step so Stripe/PayPal amounts,
// the order row and the checkout UI always agree.
export interface Totals {
  subtotal: number;
  tax: number;
  deliveryFee: number;
  total: number;
}

export function computeTotals(subtotal: number, store: Pick<StoreSettings, "taxRate" | "deliveryFee">): Totals {
  const round = (v: number) => Math.round(v * 100) / 100;
  const sub = round(subtotal);
  const tax = round(sub * (store.taxRate / 100));
  const deliveryFee = store.deliveryFee > 0 ? round(store.deliveryFee) : 0;
  return { subtotal: sub, tax, deliveryFee, total: round(sub + tax + deliveryFee) };
}

/** Store settings with only the fields pricing needs (avoids an extra read when already loaded). */
export async function getStoreForPricing(): Promise<Pick<StoreSettings, "taxRate" | "deliveryFee">> {
  const s = await getStoreSettings();
  return { taxRate: s.taxRate, deliveryFee: s.deliveryFee };
}

// Opening hours in Europe/Vilnius
export function todayHours(hours: Record<string, [number, number] | null>, dayIdx: number) {
  const keys = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  return hours[keys[dayIdx]] || null;
}

export function vilniusNow() {
  const fmt = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Vilnius", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false });
  const parts = fmt.formatToParts(new Date());
  const wd = parts.find((p) => p.type === "weekday")?.value || "Mon";
  const h = Number(parts.find((p) => p.type === "hour")?.value || 0);
  const m = Number(parts.find((p) => p.type === "minute")?.value || 0);
  const map: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return { dayIdx: map[wd], minutes: h * 60 + m };
}
