/** Confirmed owner information. Defaults are editable through the existing CMS. */
export const VISITOR_DEFAULTS = {
  accessibility: 'Pagrindinis įėjimas pritaikytas patekti su vežimėliu. Pirmame aukšte yra staliukų, prie kurių patogu sėdėti su vežimėliu. Tualetas turi platesnes duris, tačiau jame nėra atraminio turėklo.',
  families: 'Laukiame šeimų su vaikais. Turime dvi vaikiškas maitinimo kėdutes, vaikišką meniu ir vaikų kampelį.',
  dietary: 'Dėl vegetariškų, veganiškų ir halal patiekalų teiraukitės mūsų komandos prieš atvykdami arba restorane.',
  brunch: 'Vėlyvieji pusryčiai grupėms ruošiami tik iš anksto susitarus.',
  kitchen: 'Virtuvė užsakymus įprastai priima iki 21 val. Dėl galimybės užsisakyti vėliau teiraukitės komandos. Kai restoranas užsidaro anksčiau, užsakymai priimami ne ilgiau nei iki uždarymo.',
  drinks: 'Siūlome alų, vyną, kokteilius ir stipriuosius gėrimus. Įprastai aptarnaujame prie staliukų.',
  sports: 'Svarbių rungtynių metu galimos sporto transliacijos. Dėl konkrečių rungtynių teiraukitės mūsų komandos.',
  outdoor: 'Šiltuoju metų laiku svečių laukiame ir kiemelyje.',
  privateRoom: 'Antrame aukšte esančioje salėje telpa iki 30 žmonių. Ją galima rezervuoti ir mažesnei kompanijai. Sąlygos derinamos individualiai. Į ją patenkama tik laiptais.',
  catering: 'Dėl išvažiuojamojo maitinimo galimybių, meniu ir užsakymo sąlygų susisiekite su mumis – viską deriname individualiai.',
  delivery: 'Maistą galite užsisakyti per „Wolt“ ir „Bolt Food“. Dėl didesnio užsakymo pristatymo galima susitarti individualiai.',
  reservations: 'Staliuką galima rezervuoti, tačiau laukiame ir atvykstant be rezervacijos.',
  parking: 'Turime privačią automobilių stovėjimo aikštelę su ribotu vietų skaičiumi. Netoliese yra ir kitų automobilių stovėjimo aikštelių. Specialiai pažymėtos vietos žmonėms su negalia nėra.',
  payments: 'Priimame grynuosius, „Visa“, „Mastercard“ ir bekontakčius mokėjimus telefonu, įskaitant „Apple Pay“ bei „Google Pay“.',
  dogs: 'Šunys laukiami restorano viduje ir kiemelyje.',
  toilets: 'Tualetai bendri visiems lankytojams.',
  ownership: 'Moters įkurtas ir valdomas verslas',
};
export const VISITOR_LABELS: Record<keyof typeof VISITOR_DEFAULTS, string> = {
  accessibility: 'Prieinamumas', families: 'Šeimoms su vaikais', dietary: 'Mitybos pasirinkimai',
  brunch: 'Vėlyvieji pusryčiai', kitchen: 'Virtuvės darbo laikas', drinks: 'Gėrimai ir aptarnavimas',
  sports: 'Sporto transliacijos', outdoor: 'Kiemelis', privateRoom: 'Privati salė ir šventės',
  catering: 'Išvažiuojamasis maitinimas', delivery: 'Pristatymas', reservations: 'Rezervacijos',
  parking: 'Automobilių stovėjimas', payments: 'Atsiskaitymas', dogs: 'Augintiniai', toilets: 'Tualetai', ownership: 'Apie verslą',
};
export function visitorInfo(content: { visitor?: Partial<typeof VISITOR_DEFAULTS> } | null | undefined) {
  return { ...VISITOR_DEFAULTS, ...content?.visitor };
}
export function billiardsInfo(content: any) {
  const b = content?.events?.billiards || {};
  return { studentPrice: 5, adultPrice: 10, cutoff: '20:00', ...b };
}
export function billiardsPriceLine(content: any) {
  const b = billiardsInfo(content);
  return `Moksleiviams ir studentams – ${b.studentPrice} €/val., suaugusiesiems – ${b.adultPrice} €/val.`;
}
export function billiardsSummary(content: any) {
  return `Veikia du biliardo stalai. ${billiardsPriceLine(content)} Žaisti galima iki ${billiardsInfo(content).cutoff}.`;
}
