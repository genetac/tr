// Lithuanian-friendly slug generator for article URLs
const LT_MAP: Record<string, string> = {
  ą: "a", č: "c", ę: "e", ė: "e", į: "i", š: "s", ų: "u", ū: "u", ž: "z",
};

export function slugify(input: string): string {
  return (input || "")
    .toLowerCase()
    .replace(/[ąčęėįšųūž]/g, (ch) => LT_MAP[ch] || ch)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80)
    .replace(/-+$/g, "");
}
