import type { FullSettings } from "./settings";
import { cssValue } from "./sanitize";

// Shared theme CSS: injects the admin-editable palette/fonts into pages that
// render outside the home page's .alma-root but still reuse those variables.
// SEC-017: every value passes cssValue() so it can't close the declaration,
// the rule or the <style> tag. A missing value emits no declaration at all,
// so the page's own stylesheet default applies (never "inherit"/"undefined").
export function themeCss(t: FullSettings["theme"]): string {
  const vars: [string, unknown][] = [
    ["--gold", t.gold], ["--gold2", t.gold2], ["--cream", t.cream], ["--cream2", t.cream2], ["--paper", t.paper],
    ["--ink", t.ink], ["--muted", t.muted], ["--line", t.line], ["--dark", t.dark],
  ];
  const decl = vars
    .map(([k, v]) => [k, cssValue(v)] as const)
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}:${v};`)
    .join("");
  const r = Number(t.radius);
  const radius = Number.isFinite(r) && t.radius !== undefined && t.radius !== null ? `--radius:${Math.max(0, Math.min(64, r))}px;` : "";
  const body = cssValue(t.fontBody);
  const head = cssValue(t.fontHead);
  return `
.alma-root{${decl}${radius}${body ? `font-family:${body};` : ""}}
${head ? `.alma-root .serif,.alma-root h1,.alma-root h2,.alma-root h3{font-family:${head};}` : ""}
`.trim();
}
