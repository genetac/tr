import type { NextRequest } from "next/server";
import { authorizeTrackLimited, trackFailSweep } from "./track-auth";
import { clientIp } from "./auth";
import { getCurrentUser } from "./userauth";

/**
 * SEC-010: one gate for every public route that reads or acts on an order by
 * its (sequential, guessable) number: /api/track, its stream, and the
 * pay-later / payment-verify routes. Allowed with the order's tracking token,
 * the phone last 4 (rate-limited), or as the signed-in owner.
 * Credentials come from the query string (?t=, ?p4=) or a JSON body ({ t, p4 }).
 */
export async function authorizeOrderAccess(
  req: NextRequest,
  order: { number: string; trackToken: string; phone: string; userId: string | null },
  creds?: { t?: unknown; p4?: unknown }
): Promise<"ok" | "forbidden" | "limited"> {
  const user = await getCurrentUser();
  if (user && order.userId && order.userId === user.id) return "ok";
  const t = typeof creds?.t === "string" ? creds.t : req.nextUrl.searchParams.get("t");
  const p4 = typeof creds?.p4 === "string" ? creds.p4 : req.nextUrl.searchParams.get("p4");
  trackFailSweep();
  return authorizeTrackLimited(order, t, p4, clientIp(req.headers));
}

export const ORDER_ACCESS_DENIED = "Neteisingas patvirtinimas — naudokite laiške gautą nuorodą arba įveskite paskutinius 4 telefono skaitmenis.";
