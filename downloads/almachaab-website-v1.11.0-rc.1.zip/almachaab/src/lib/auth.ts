import { staffById, permissionFor, revokeStaff, type Permission, type StaffRole, type StaffAccount } from "./staff";
import { createHmac, timingSafeEqual, createHash, randomBytes, scryptSync } from "crypto";
import { cookies, headers } from "next/headers";
import { getSettings } from "./settings";

const COOKIE = "alma_admin";
const MAX_AGE = 60 * 60 * 24 * 7; // 7 days (SEC-011)

function sign(payload: string, secret: string) {
  // SEC-001: an empty or short key would make tokens forgeable by anyone.
  if (!secret || secret.length < 32) throw new Error("admin session secret unavailable");
  return createHmac("sha256", secret).update(payload).digest("hex");
}

// ---------- Password hashing (scrypt, salted) ----------
// Format: "scrypt:<salt hex>:<hash hex>" — same scheme as customer accounts.
// Legacy SHA-256 hashes ("alma:"+pw) still verify and are re-hashed on next
// successful login / password change.

function hashScrypt(pw: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(pw, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

function verifyScrypt(pw: string, stored: string): boolean {
  const [, salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  try {
    const candidate = scryptSync(pw, salt, 64);
    const expected = Buffer.from(hash, "hex");
    if (candidate.length !== expected.length) return false;
    return timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

/** Legacy hash (kept only to verify + migrate old stored hashes). */
function hashLegacy(pw: string): string {
  return createHash("sha256").update("alma:" + pw).digest("hex");
}

function safeEqualHex(a: string, b: string): boolean {
  try {
    return a.length === b.length && timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
  } catch {
    return false;
  }
}

/** New passwords are always stored salted-scrypt. */
export function hashPassword(pw: string): string {
  return hashScrypt(pw);
}

function storedHashIsLegacy(stored: string): boolean {
  return !stored.startsWith("scrypt:");
}

export async function checkPassword(pw: string): Promise<boolean> {
  const s = await getSettings();
  const stored = s.admin.passwordHash;
  if (!stored) return false;
  if (stored.startsWith("scrypt:")) return verifyScrypt(pw, stored);
  return safeEqualHex(stored, hashLegacy(pw));
}

/** True while the admin still uses the factory default password. */
export async function isDefaultPasswordInUse(): Promise<boolean> {
  return checkPassword("alma2026");
}

/** Re-hash a legacy SHA-256 password as salted scrypt (transparent upgrade). */
export async function migratePasswordHash(pw: string): Promise<void> {
  const s = await getSettings();
  if (s.admin.passwordHash && storedHashIsLegacy(s.admin.passwordHash)) {
    const { setSetting } = await import("./settings");
    await setSetting("admin", { ...s.admin, passwordHash: hashPassword(pw) });
  }
}

// ---------- Login rate limiting (in-memory; per IP + global cap) ----------
// 5 failed attempts per IP per 15 minutes + a global cap of 50 failed
// attempts per 15 minutes across ALL IPs (distributed-slowdown defense —
// once the global cap trips, everyone gets 429 until the window clears).
// On a multi-instance deployment move this to shared storage; behind
// Cloudflare additionally add a WAF rate-limit rule on /api/admin/login
// (see DEPLOY.md).

const RATE_WINDOW_MS = 15 * 60_000;
const RATE_MAX = 5;
const RATE_GLOBAL_MAX = 50;
const GLOBAL_KEY = "__global__";
const attempts = new Map<string, { count: number; resetAt: number }>();

function rateKey(ip: string) {
  return ip;
}

export function loginRateStatus(ip: string): { blocked: boolean; retryAfterSec: number } {
  const now = Date.now();
  // Global cap first — it 429s everyone when tripped.
  const g = attempts.get(GLOBAL_KEY);
  if (g && g.resetAt >= now && g.count >= RATE_GLOBAL_MAX) {
    return { blocked: true, retryAfterSec: Math.ceil((g.resetAt - now) / 1000) };
  }
  const rec = attempts.get(rateKey(ip));
  if (!rec || rec.resetAt < now) return { blocked: false, retryAfterSec: 0 };
  return { blocked: rec.count >= RATE_MAX, retryAfterSec: Math.ceil((rec.resetAt - now) / 1000) };
}

export function loginRateFail(ip: string): void {
  const bump = (key: string): void => {
    const rec = attempts.get(key);
    const now = Date.now();
    if (!rec || rec.resetAt < now) {
      attempts.set(key, { count: 1, resetAt: now + RATE_WINDOW_MS });
      return;
    }
    rec.count += 1;
  };
  bump(rateKey(ip));
  bump(GLOBAL_KEY);
}

export function loginRateReset(ip: string): void {
  // A successful login clears only the per-IP counter — the global cap
  // intentionally keeps counting the window's total failed attempts.
  attempts.delete(rateKey(ip));
}

/**
 * Best-effort client IP, ordered from hardest to spoof:
 * 1. cf-connecting-ip — set by Cloudflare at the edge, cannot be spoofed
 *    through Cloudflare (attacker-supplied values are overwritten).
 * 2. x-real-ip — set by our own Caddy reverse proxy.
 * 3. LAST entry of x-forwarded-for — the rightmost value is the one appended
 *    by the closest trusted proxy; trusting the first would let a client
 *    rotate its own fake values and reset per-IP counters.
 * 4. "local" — direct dev access with no proxy headers.
 */
export function clientIp(h: Headers): string {
  const cf = (h.get("cf-connecting-ip") || "").trim();
  if (cf) return cf;
  const real = (h.get("x-real-ip") || "").trim();
  if (real) return real;
  const xff = (h.get("x-forwarded-for") || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (xff.length) return xff[xff.length - 1];
  return "local";
}

// ---------- Admin session (HMAC-signed token) ----------
// Payload role "admin" = normal session; "adminc" = session created while the
// default password is still in use. Such sessions may ONLY change the
// password (see isAdmin vs isAdminAllowUnchanged).
// Token: "<role>.<issuedAt>.<sessionVersion>.<hmac>". SEC-011: bumping
// admin.sessionVersion (logout, password change) revokes every older token.

/**
 * SEC-011: the localStorage / header / ?token= fallback exists only for
 * development preview iframes. In production the httpOnly cookie is the only
 * accepted carrier, so a token copied out of the browser is useless.
 */
export const ADMIN_TOKEN_FALLBACK = process.env.NODE_ENV !== "production";

export async function createSessionToken(mustChangePassword = false): Promise<string> {
  const s = await getSettings();
  const ver = Number(s.admin.sessionVersion || 0);
  const payload = `${mustChangePassword ? "adminc" : "admin"}.${Date.now()}.${ver}`;
  return `${payload}.${sign(payload, s.admin.secret)}`;
}

type SessionState = { ok:boolean; mustChangePassword:boolean; role?:StaffRole; staffId?:string; name?:string; canPublish?:boolean };
async function verifySessionToken(token: string | undefined | null): Promise<SessionState> {
  const no = { ok: false, mustChangePassword: false };
  if (!token) return no;
  const parts = token.split(".");
  if (parts.length !== 4) return no;
  const [role, ts, ver, sig] = parts;
  if (role !== "admin" && role !== "adminc" && !/^staff_[a-f0-9]{32}$/.test(role)) return no;
  const s = await getSettings();
  let staff:StaffAccount|null = null;
  if (role.startsWith('staff_')) {
    staff=await staffById(role.slice(6));
    if(!staff?.active || ver !== `${Number(s.admin.sessionVersion||0)}-${staff.sessionVersion}`)return no;
  } else if (Number(ver) !== Number(s.admin.sessionVersion || 0)) return no;
  const expected = sign(`${role}.${ts}.${ver}`, s.admin.secret);
  try {
    if (!timingSafeEqual(Buffer.from(sig, "hex"), Buffer.from(expected, "hex"))) return no;
  } catch {
    return no;
  }
  const age = Date.now() - Number(ts);
  const ok = Number.isFinite(age) && age >= 0 && age < MAX_AGE * 1000;
  return { ok, mustChangePassword: ok && role === "adminc", role: staff?.role || "owner", staffId:staff?.id, name:staff?.name || "Administratorius", canPublish:staff?.canPublish || !staff };
}

/** SEC-011: invalidate every issued admin token (all devices). */
export async function revokeAllAdminSessions(): Promise<void> {
  const s = await getSettings();
  const { setSetting } = await import("./settings");
  await setSetting("admin", { ...s.admin, sessionVersion: Number(s.admin.sessionVersion || 0) + 1 });
}

export async function setSessionCookie(token?: string) {
  const t = token || (await createSessionToken());
  const jar = await cookies();
  const h = await headers();
  const proto = (h.get("x-forwarded-proto") || "").split(",")[0].trim();
  jar.set(COOKIE, t, {
    httpOnly: true,
    sameSite: "lax", // cross-site POSTs are blocked by Origin check instead
    secure: proto === "https",
    path: "/",
    maxAge: MAX_AGE,
  });
  return t;
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/** Valid admin session — may or may not still owe a password change. */
export async function getSessionState(): Promise<SessionState> {
  const jar = await cookies();
  const viaCookie = await verifySessionToken(jar.get(COOKIE)?.value);
  if (viaCookie.ok) return viaCookie;
  // Fallback (development only): preview iframes may block the cookie —
  // accept the token the client keeps in localStorage and sends as a header.
  if (!ADMIN_TOKEN_FALLBACK) return { ok: false, mustChangePassword: false };
  const h = await headers();
  const tok = h.get("x-admin-token");
  return tok ? verifySessionToken(tok) : { ok: false, mustChangePassword: false };
}

/** Full admin access — requires a session that is NOT in must-change state. */
export async function isAdmin(): Promise<boolean> {
  const st = await getSessionState();
  return st.ok && !st.mustChangePassword && st.role === "owner";
}

/** Partial access — only routes that let the admin set a new password. */
export async function isAdminAllowUnchanged(): Promise<boolean> {
  const st=await getSessionState(); return st.ok && st.role === "owner";
}

/** Validate a raw admin token string (EventSource ?token= fallback, development only). */
export async function verifyAdminToken(token: string | undefined | null): Promise<boolean> {
  if (!ADMIN_TOKEN_FALLBACK) return false;
  const st = await verifySessionToken(token);
  return st.ok && !st.mustChangePassword && (st.role === "owner" || st.role === "kitchen");
}

export async function createStaffSession(id:string){
  const staff=await staffById(id);if(!staff?.active)throw new Error('Paskyra neaktyvi.');
  const s=await getSettings();const payload=`staff_${id}.${Date.now()}.${Number(s.admin.sessionVersion||0)}-${staff.sessionVersion}`;
  return `${payload}.${sign(payload,s.admin.secret)}`;
}
export async function can(permission:Permission){const st=await getSessionState();return Boolean(st.ok&&!st.mustChangePassword&&st.role&&permissionFor(st.role,permission,st.canPublish));}
export async function cmsActor(){const st=await getSessionState();return st.staffId || (st.ok?'owner':'anonymous');}
export async function revokeCurrentSession(){const st=await getSessionState();if(st.staffId)await revokeStaff(st.staffId);else if(st.ok)await revokeAllAdminSessions();}
