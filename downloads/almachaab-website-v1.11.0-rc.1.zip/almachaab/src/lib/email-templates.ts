/**
 * Editable email templates — shared by the server (mail.ts) and the admin UI
 * (SettingsTab). Pure module: no server-only imports, safe for client bundles.
 *
 * Each email = subject + heading (title) + body text, with placeholders like
 * {{numeris}} replaced at send time, plus structure toggles that show/hide the
 * fixed blocks (base info, items table, payment block, tracking link).
 */

export interface EmailTemplate {
  subject: string;
  title: string;
  body: string;
  showDetails: boolean; // base info: laikas, numeris, suma (+ kliento pastaba)
  showItems: boolean; // patiekalų sąrašas
  showPayment: boolean; // apmokėjimo blokas (būdas, operacijos nr., suma)
  showTrack: boolean; // būsenos stebėjimo nuoroda
}

export type EmailTemplateKey =
  | "order.received"
  | "order.confirmed"
  | "order.paid"
  | "order.ready"
  | "order.cancelled"
  | "reservation.received"
  | "reservation.confirmed"
  | "reservation.paid"
  | "reservation.cancelled";

export const EMAIL_TEMPLATE_KEYS: EmailTemplateKey[] = [
  "order.received",
  "order.confirmed",
  "order.paid",
  "order.ready",
  "order.cancelled",
  "reservation.received",
  "reservation.confirmed",
  "reservation.paid",
  "reservation.cancelled",
];

export const EMAIL_TEMPLATE_LABELS: Record<EmailTemplateKey, string> = {
  "order.received": "Užsakymas gautas",
  "order.confirmed": "Užsakymas patvirtintas",
  "order.paid": "Kvitas — užsakymas apmokėtas",
  "order.ready": "Užsakymas paruoštas",
  "order.cancelled": "Užsakymas atšauktas",
  "reservation.received": "Rezervacijos užklausa gauta",
  "reservation.confirmed": "Rezervacija patvirtinta",
  "reservation.paid": "Kvitas — rezervacija apmokėta",
  "reservation.cancelled": "Rezervacija atšaukta",
};

/** What the admin can save — any subset of templates with any subset of fields. */
export type EmailTemplatesSetting = Partial<Record<EmailTemplateKey, Partial<EmailTemplate>>>;

export const DEFAULT_TEMPLATES: Record<EmailTemplateKey, EmailTemplate> = {
  "order.received": {
    subject: "Užsakymas #{{numeris}} gautas – laukiame patvirtinimo",
    title: "Užsakymas gautas. Laukiama patvirtinimo.",
    body: "",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: true,
  },
  "order.confirmed": {
    subject: "Jūsų užsakymas #{{numeris}} patvirtintas",
    title: "Jūsų užsakymas patvirtintas.",
    body: "Netrukus pradėsime ruošti jūsų užsakymą.",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: false,
  },
  "order.paid": {
    subject: "Kvitas – užsakymas #{{numeris}} apmokėtas ({{suma}})",
    title: "Mokėjimas gautas — ačiū!",
    body: "Užsakymas patvirtintas — netrukus pradėsime jį ruošti.",
    showDetails: true,
    showItems: true,
    showPayment: true,
    showTrack: true,
  },
  "order.ready": {
    subject: "Užsakymas #{{numeris}} paruoštas",
    title: "Jūsų užsakymas paruoštas – galite atsiimti.",
    body: "Iki pasimatymo Alma Chaab!",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: false,
  },
  "order.cancelled": {
    subject: "Užsakymas #{{numeris}} atšauktas",
    title: "Užsakymas atšauktas.",
    body: "Klausimų atveju skambinkite {{telefonas}}.",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: false,
  },
  "reservation.received": {
    subject: "Rezervacijos užklausa #{{numeris}} gauta",
    title: "Jūsų rezervacijos užklausa gauta.",
    body: "Susisieksime su Jumis patvirtinti rezervaciją.",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: true,
  },
  "reservation.confirmed": {
    subject: "Jūsų rezervacija #{{numeris}} patvirtinta",
    title: "Jūsų rezervacija patvirtinta.",
    body: "Iki pasimatymo Alma Chaab!",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: false,
  },
  "reservation.paid": {
    subject: "Kvitas – rezervacija #{{numeris}} apmokėta ({{suma}})",
    title: "Mokėjimas gautas — ačiū!",
    body: "Rezervacija patvirtinta — iki pasimatymo Alma Chaab!",
    showDetails: true,
    showItems: true,
    showPayment: true,
    showTrack: true,
  },
  "reservation.cancelled": {
    subject: "Rezervacija #{{numeris}} atšaukta",
    title: "Rezervacija atšaukta.",
    body: "Tikimės matyti kitą kartą. Klausimų atveju skambinkite {{telefonas}}.",
    showDetails: true,
    showItems: true,
    showPayment: false,
    showTrack: false,
  },
};

/** Merge a saved (partial) template over the defaults — field by field. */
export function mergeTemplate(key: EmailTemplateKey, saved?: EmailTemplatesSetting): EmailTemplate {
  const def = DEFAULT_TEMPLATES[key];
  const s = saved?.[key] || {};
  return {
    subject: typeof s.subject === "string" ? s.subject : def.subject,
    title: typeof s.title === "string" ? s.title : def.title,
    body: typeof s.body === "string" ? s.body : def.body,
    showDetails: typeof s.showDetails === "boolean" ? s.showDetails : def.showDetails,
    showItems: typeof s.showItems === "boolean" ? s.showItems : def.showItems,
    showPayment: typeof s.showPayment === "boolean" ? s.showPayment : def.showPayment,
    showTrack: typeof s.showTrack === "boolean" ? s.showTrack : def.showTrack,
  };
}

/** Replace {{token}} placeholders; unknown tokens become "". */
export function renderTpl(str: string, vars: Record<string, string>): string {
  return String(str || "").replace(/\{\{\s*([a-zA-Z_]+)\s*\}\}/g, (_, name) => vars[name] ?? "");
}

/** Placeholders offered in the admin editor. */
export const TEMPLATE_PLACEHOLDERS: { token: string; label: string }[] = [
  { token: "{{vardas}}", label: "Kliento vardas" },
  { token: "{{numeris}}", label: "Užsakymo numeris" },
  { token: "{{suma}}", label: "Suma" },
  { token: "{{laikas}}", label: "Atsiėmimo / rezervacijos laikas" },
  { token: "{{sveciai}}", label: "Svečių skaičius (rezervacijoms)" },
  { token: "{{mokejimas}}", label: "Mokėjimo būdas" },
  { token: "{{ref}}", label: "Mokėjimo operacijos numeris" },
  { token: "{{telefonas}}", label: "Restorano telefonas" },
  { token: "{{nuoroda}}", label: "Būsenos stebėjimo nuoroda" },
  { token: "{{restoranas}}", label: "Restorano pavadinimas" },
];
