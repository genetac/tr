/**
 * SEC-017: admin-authored rich text and theme values are rendered raw
 * (dangerouslySetInnerHTML / <style>). Keep them to a tiny allow-list so a
 * stolen admin session or a future staff role can't plant scripts.
 */

const ALLOWED = new Set(["b", "strong", "i", "em", "br", "a"]);

function escText(s: string): string {
  return s.replace(/&(?!(?:[a-z]+|#\d+|#x[0-9a-f]+);)/gi, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function escAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/** Inline HTML allow-list: <b> <strong> <i> <em> <br> and <a href="http(s)|mailto|tel">. */
export function sanitizeInlineHtml(input: string): string {
  const src = String(input ?? "");
  let out = "";
  let last = 0;
  const re = /<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9]*)([^>]*)>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    out += escText(src.slice(last, m.index));
    last = re.lastIndex;
    const closing = m[1] === "/";
    const tag = m[2].toLowerCase();
    if (!ALLOWED.has(tag)) continue; // drop the tag, keep surrounding text
    if (tag === "br") {
      out += closing ? "" : "<br/>";
      continue;
    }
    if (closing) {
      out += `</${tag}>`;
      continue;
    }
    if (tag === "a") {
      const href = /href\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(m[3]);
      const url = (href?.[2] ?? href?.[3] ?? href?.[4] ?? "").trim();
      if (/^(https?:\/\/|mailto:|tel:|\/(?!\/)|#)/i.test(url)) {
        const ext = /^https?:\/\//i.test(url);
        out += `<a href="${escAttr(url)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ""}>`;
      } else out += "<a>";
      continue;
    }
    out += `<${tag}>`;
  }
  out += escText(src.slice(last));
  return out;
}

/** Theme values (colours, font stacks, radius) — no characters that can leave the CSS declaration. */
export function cssValue(v: unknown, fallback = ""): string {
  const s = String(v ?? "").replace(/[<>{};\\@]/g, "").replace(/\/\*|\*\//g, "").trim().slice(0, 120);
  return s || fallback;
}
