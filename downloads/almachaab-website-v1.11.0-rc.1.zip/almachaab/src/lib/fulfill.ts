import { db } from "./db";
import { pushHistory, STATUS_LT } from "./orders";
import { publishOrderEvent } from "./events";
import { emailOrderEvent } from "./mail";
import { sendPushToAll, sendPushToUser } from "./push";
import { awardForOrder, getLoyaltyConfig } from "./loyalty";

/**
 * Marks an order as paid — the single funnel used by the Stripe webhook,
 * the Stripe return-page verification and the PayPal capture step.
 * Idempotent: a second call for the same order is a no-op.
 */
export async function markOrderPaid(
  orderId: string,
  opts: { method: "stripe" | "paypal" | "venue"; ref: string; baseUrl?: string }
): Promise<{ ok: boolean; number?: string; trackToken?: string; status?: string; alreadyPaid?: boolean }> {
  const order = await db.order.findUnique({ where: { id: orderId } });
  if (!order) return { ok: false };

  if (order.paymentStatus === "paid") {
    return { ok: true, number: order.number, trackToken: order.trackToken, status: order.status, alreadyPaid: true };
  }

  const nextStatus = order.status === "new" || order.status === "awaiting" ? "confirmed" : order.status;

  const updated = await db.order.update({
    where: { id: orderId },
    data: {
      paymentStatus: "paid",
      paymentMethod: opts.method,
      paymentRef: opts.ref.slice(0, 200),
      paidAt: new Date(),
      status: nextStatus,
      isRead: true,
      historyJson: pushHistory(order, nextStatus, {
        by: opts.method === "venue" ? "admin" : "payment",
        label: `Apmokėta (${opts.method === "stripe" ? "Stripe" : opts.method === "paypal" ? "PayPal" : "grynieji vietoje"})`,
        ref: opts.ref.slice(0, 120),
      }),
    },
  });

  publishOrderEvent({
    type: "paid",
    orderId: updated.id,
    number: updated.number,
    status: updated.status,
    paymentStatus: "paid",
  });

  // Fire-and-forget side effects — never block the payment response.
  const baseUrl = opts.baseUrl || "https://almachaab.lt";
  if (updated.email) {
    // Dedicated payment receipt (kvitas): method, transaction ref, total.
    // Result is logged into order history so the owner can verify delivery.
    emailOrderEvent(updated, "paid", baseUrl)
      .then((res) =>
        db.order
          .update({
            where: { id: updated.id },
            data: { historyJson: pushHistory(updated, updated.status, { emailSent: res }) },
          })
          .catch(() => {})
      )
      .catch(() => {});
  }
  sendPushToAll({
    title: `💰 Apmokėta #${updated.number}`,
    body: `${updated.customerName} · ${updated.total.toFixed(2).replace(".", ",")} € · ${STATUS_LT[updated.status] || updated.status}`,
    tag: "alma-paid",
    url: "/admin",
    orderId: updated.id,
  }).catch(() => {});

  // Loyalty: a paid order always earns points/stamps for account holders.
  void awardLoyaltyFor(updated.id);

  return { ok: true, number: updated.number, trackToken: updated.trackToken, status: updated.status };
}

/**
 * Award loyalty points for an order (idempotent). Called after payment and
 * after an admin marks a pay-on-pickup order completed. Notifies the
 * customer's opted-in devices with a short confirmation push.
 */
export async function awardLoyaltyFor(orderId: string) {
  try {
    const order = await db.order.findUnique({ where: { id: orderId } });
    if (!order?.userId) return null;
    const cfg = await getLoyaltyConfig();
    if (!cfg.enabled) return null;
    const award = await awardForOrder(order);
    if (award && award.points > 0) {
      sendPushToUser(order.userId, {
        title: `＋ ${award.points} lojalumo taškų ✓`,
        body: `Užsakymas #${order.number} — jau turite taškų prizams /mano puslapyje.`,
        tag: "alma-loyalty",
        url: "/mano",
      }).catch(() => {});
    }
    return award;
  } catch {
    return null; // loyalty must never break order flow
  }
}
