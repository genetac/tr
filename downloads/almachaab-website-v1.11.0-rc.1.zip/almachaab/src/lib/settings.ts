import {resolveBusinessContent} from "./business-content";
import { publicContent } from "./content-management";
import { db } from "./db";
import type { Settings } from "@prisma/client";
import type { EmailTemplatesSetting } from "./email-templates";
import { randomBytes } from "crypto";
import { encryptSecret, decryptSecret } from "./vault";

// ---------- Types ----------
export interface SiteSettings {
  name: string;
  tagline: string;
  phone: string;
  phoneDisplay: string;
  email: string;
  address: string;
  woltUrl: string;
  boltFoodUrl?: string;
  mapsUrl: string;
  facebookUrl: string;
  /** Legal entity shown in the footer, /privatumas, /apie-mus and JSON-LD. */
  legalName?: string;
  companyCode?: string;
}
export interface HoursSettings {
  // Index signature lets hours objects flow into Record<string, [h, m] | null> helpers.
  [key: string]: [number, number] | null;
  mon: [number, number] | null;
  tue: [number, number] | null;
  wed: [number, number] | null;
  thu: [number, number] | null;
  fri: [number, number] | null;
  sat: [number, number] | null;
  sun: [number, number] | null;
}
export interface ThemeSettings {
  gold: string;
  gold2: string;
  cream: string;
  cream2: string;
  paper: string;
  ink: string;
  muted: string;
  line: string;
  dark: string;
  radius: number;
  fontHead: string;
  fontBody: string;
}
export interface RatingSettings {
  mode: "manual" | "hidden" | "auto";
  score: number;
  count: number;
  placesApiKey: string;
  placesPlaceId: string;
  note: string;
}
export interface EmailSettings {
  enabled: boolean;
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  from: string;
  fromName: string;
  notifyEmail: string;
  /** Editable per-event templates — missing entries fall back to DEFAULT_TEMPLATES. */
  templates?: EmailTemplatesSetting;
}
export interface OrdersSettings {
  prefix: string;
  nextNumber: number;
}
export interface PickupSettings {
  enabled: boolean;
  leadMinutes: number;
  slotMinutes: number;
  maxDaysAhead: number;
}
export interface AdminSettings {
  passwordHash: string;
  secret: string;
  /** SEC-011: bumped on logout / password change — older tokens stop working. */
  sessionVersion?: number;
}

/** Store-level configuration — mirrored from the Settings singleton (payments, open/closed, fees). */
export interface StoreSettings {
  restaurantName: string;
  isOpen: boolean;
  stripePublicKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  paypalClientId: string;
  paypalSecret: string;
  paypalSandbox: boolean;
  // Social sign-in providers (Google / Facebook / Telegram)
  googleEnabled: boolean;
  googleClientId: string;
  googleClientSecret: string;
  facebookEnabled: boolean;
  facebookClientId: string;
  facebookClientSecret: string;
  telegramEnabled: boolean;
  telegramBotToken: string;
  telegramBotUsername: string;
  // Cloudflare Turnstile anti-bot
  turnstileEnabled: boolean;
  turnstileSiteKey: string;
  turnstileSecretKey: string;
  currency: string;
  taxRate: number;
  deliveryFee: number;
}
 
export type Content = any; // content JSON is free-form, edited via admin

export interface FullSettings {
  site: SiteSettings;
  dietaryDisplay: {labels:boolean;notes:boolean;filters:boolean};
  hours: HoursSettings;
  theme: ThemeSettings;
  rating: RatingSettings;
  email: EmailSettings;
  orders: OrdersSettings;
  pickup: PickupSettings;
  admin: AdminSettings;
  store: StoreSettings;
  content: Content;
  /** Web analytics — the cookie banner renders only while this is on. */
  analytics: { enabled: boolean };
}

// ---------- Defaults ----------
const STORE_DEFAULTS: StoreSettings = {
  restaurantName: "Alma Chaab",
  isOpen: true,
  stripePublicKey: "",
  stripeSecretKey: "",
  stripeWebhookSecret: "",
  paypalClientId: "",
  paypalSecret: "",
  paypalSandbox: true,
  googleEnabled: false,
  googleClientId: "",
  googleClientSecret: "",
  facebookEnabled: false,
  facebookClientId: "",
  facebookClientSecret: "",
  telegramEnabled: false,
  telegramBotToken: "",
  telegramBotUsername: "",
  turnstileEnabled: false,
  turnstileSiteKey: "",
  turnstileSecretKey: "",
  currency: "EUR",
  taxRate: 0,
  deliveryFee: 0,
};

export const DEFAULTS: Omit<FullSettings, "admin"> = {
  dietaryDisplay: {labels:true,notes:true,filters:true},
  site: {
    name: "Alma Chaab",
    tagline: "Kėdainių senamiestis",
    phone: "+37066613055",
    phoneDisplay: "+370 666 13 055",
    email: "info@almachaab.lt",
    address: "Didžioji g. 25, Kėdainiai",
    woltUrl: "https://wolt.com/lt/ltu/kedainiai/restaurant/alma-chaab",
    // Google Business Profile (reviews link + JSON-LD sameAs). Directions use the address.
    boltFoodUrl: "",
    mapsUrl: "https://share.google/yxkPJvWAh18FvUBOt",
    facebookUrl: "https://www.facebook.com/restoranas.almachaab",
    legalName: "UAB „Chaab“",
    companyCode: "307075624",
  },
  hours: { mon: null, tue: [12, 22], wed: [12, 22], thu: [12, 22], fri: [12, 22], sat: [11, 22], sun: [11, 20] },
  theme: {
    gold: "#b47b2d", gold2: "#d0a15f", cream: "#f8f2e9", cream2: "#fffaf2", paper: "#fffdf8",
    ink: "#241a13", muted: "#74665b", line: "#ded0bd", dark: "#35241a", radius: 24,
    fontHead: 'Georgia,"Times New Roman",serif',
    fontBody: 'Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
  },
  rating: { mode: "manual", score: 4.4, count: 161, placesApiKey: "", placesPlaceId: "", note: "" },
  email: { enabled: false, host: "smtp.gmail.com", port: 465, secure: true, user: "", pass: "", from: "", fromName: "Alma Chaab", notifyEmail: "" },
  orders: { prefix: "AC", nextNumber: 1042 },
  pickup: { enabled: true, leadMinutes: 30, slotMinutes: 30, maxDaysAhead: 7 },
  store: { ...STORE_DEFAULTS },
  content: {},
  analytics: { enabled: false },
};

// ---------- Reader ----------
 
export async function getSetting<T = any>(key: string): Promise<T | null> {
  const row = await db.setting.findUnique({ where: { key } });
  return row ? (JSON.parse(row.value) as T) : null;
}

export async function getSettings(): Promise<FullSettings> {
  const rows = await db.setting.findMany();
   
  const map: Record<string, any> = {};
  for (const r of rows) map[r.key] = JSON.parse(r.value);
  const out = { ...DEFAULTS } as FullSettings;
  for (const k of Object.keys(DEFAULTS) as (keyof typeof DEFAULTS)[]) {
     
    out[k] = { ...(DEFAULTS[k] as any), ...(map[k] || {}) } as any;
  }
  out.content = resolveBusinessContent(map.content || {});
  out.admin = { passwordHash: "", secret: "", ...(map.admin || {}) };
  // Secrets are stored encrypted (vault.ts) — decrypt for in-app use.
  out.admin.secret = out.admin.secret ? decryptSecret(out.admin.secret) : "";
  // SEC-001: never sign sessions with an empty / short / undecryptable key.
  // A missing secret, or one encrypted under a different APP_SECRET_KEY
  // (fresh server key, shipped DB), is replaced by a new random one.
  // Side effect by design: existing admin + customer sessions are logged out.
  if (!out.admin.secret || out.admin.secret.length < 32) {
    out.admin.secret = await rotateAdminSecret({ ...out.admin });
  }
  if (out.email?.pass) out.email.pass = decryptSecret(out.email.pass);
  out.store = await getStoreSettings();
  return out;
}

/** Generate, persist (encrypted) and return a fresh admin HMAC secret. */
let rotating: Promise<string> | null = null;
async function rotateAdminSecret(admin: AdminSettings): Promise<string> {
  // One rotation per process even when several requests race on first boot.
  if (!rotating) {
    rotating = (async () => {
      const fresh = randomBytes(32).toString("hex");
      console.warn("[settings] admin session secret was missing or unreadable — generated a new one (all sessions logged out).");
      await setSetting("admin", { ...admin, secret: fresh });
      return fresh;
    })().finally(() => {
      setTimeout(() => (rotating = null), 5_000);
    });
  }
  return rotating;
}

/** Persist a settings JSON blob, encrypting known secret fields at rest. */
export async function setSetting(key: string, value: unknown): Promise<void> {
  let v = value;
  if (key === "email" && v && typeof v === "object" && "pass" in (v as Record<string, unknown>)) {
    v = { ...(v as Record<string, unknown>), pass: encryptSecret(String((v as Record<string, unknown>).pass || "")) };
  }
  if (key === "vapid" && v && typeof v === "object" && "privateKey" in (v as Record<string, unknown>)) {
    // SEC-008: VAPID private key encrypted at rest like every other secret.
    v = { ...(v as Record<string, unknown>), privateKey: encryptSecret(String((v as Record<string, unknown>).privateKey || "")) };
  }
  if (key === "admin" && v && typeof v === "object" && "secret" in (v as Record<string, unknown>)) {
    v = { ...(v as Record<string, unknown>), secret: encryptSecret(String((v as Record<string, unknown>).secret || "")) };
  }
  const data = JSON.stringify(v);
  await db.setting.upsert({
    where: { key },
    update: { value: data },
    create: { key, value: data },
  });
}

// ---------- Store singleton (Settings model) ----------

function normalizeStore(row: Settings | null): StoreSettings {
  const raw = {
    restaurantName: row?.restaurantName || STORE_DEFAULTS.restaurantName,
    isOpen: row ? row.isOpen : STORE_DEFAULTS.isOpen,
    stripePublicKey: row?.stripePublicKey || "",
    stripeSecretKey: row?.stripeSecretKey || "",
    stripeWebhookSecret: row?.stripeWebhookSecret || "",
    paypalClientId: row?.paypalClientId || "",
    paypalSecret: row?.paypalSecret || "",
    paypalSandbox: row ? row.paypalSandbox : STORE_DEFAULTS.paypalSandbox,
    googleEnabled: row ? row.googleEnabled : STORE_DEFAULTS.googleEnabled,
    googleClientId: row?.googleClientId || "",
    googleClientSecret: row?.googleClientSecret || "",
    facebookEnabled: row ? row.facebookEnabled : STORE_DEFAULTS.facebookEnabled,
    facebookClientId: row?.facebookClientId || "",
    facebookClientSecret: row?.facebookClientSecret || "",
    telegramEnabled: row ? row.telegramEnabled : STORE_DEFAULTS.telegramEnabled,
    telegramBotToken: row?.telegramBotToken || "",
    telegramBotUsername: row?.telegramBotUsername || "",
    turnstileEnabled: row ? row.turnstileEnabled : STORE_DEFAULTS.turnstileEnabled,
    turnstileSiteKey: row?.turnstileSiteKey || "",
    turnstileSecretKey: row?.turnstileSecretKey || "",
    currency: row?.currency || STORE_DEFAULTS.currency,
    taxRate: typeof row?.taxRate === "number" ? row.taxRate : STORE_DEFAULTS.taxRate,
    deliveryFee: typeof row?.deliveryFee === "number" ? row.deliveryFee : STORE_DEFAULTS.deliveryFee,
  };
  // Secrets live encrypted in the DB — decrypt for in-app use.
  const rawRec = raw as unknown as Record<string, string>;
  for (const k of ["stripeSecretKey", "stripeWebhookSecret", "paypalSecret", "googleClientSecret", "facebookClientSecret", "telegramBotToken", "turnstileSecretKey"] as const) {
    rawRec[k] = decryptSecret(rawRec[k]);
  }
  return raw;
}

export async function getStoreSettings(): Promise<StoreSettings> {
  const row = await db.settings.findUnique({ where: { id: "global" } });
  return normalizeStore(row);
}

/** Patch-merge store settings and return the updated record. */
export async function setStoreSettings(patch: Partial<StoreSettings>): Promise<StoreSettings> {
  const current = await getStoreSettings();
  const merged = { ...current, ...patch };
  // Encrypt secrets before they touch the database.
  const atRest = { ...merged } as unknown as Record<string, unknown>;
  for (const k of ["stripeSecretKey", "stripeWebhookSecret", "paypalSecret", "googleClientSecret", "facebookClientSecret", "telegramBotToken", "turnstileSecretKey"] as const) {
    atRest[k] = encryptSecret(atRest[k] as string);
  }
  await db.settings.upsert({
    where: { id: "global" },
    update: { ...atRest },
    create: { id: "global", ...atRest },
  });
  return merged;
}

// Public-safe settings (no admin/email/payment secrets)
export function publicSettings(s: FullSettings) {
  return {
    site: s.site,
    dietaryDisplay: s.dietaryDisplay,
    hours: s.hours,
    theme: s.theme,
    rating: { mode: s.rating.mode, score: s.rating.score, count: s.rating.count, note: s.rating.note },
    pickup: s.pickup,
    orders: { prefix: s.orders.prefix },
    store: {
      restaurantName: s.store.restaurantName,
      isOpen: s.store.isOpen,
      currency: s.store.currency,
      taxRate: s.store.taxRate,
      deliveryFee: s.store.deliveryFee,
    },
    analyticsEnabled: s.analytics?.enabled === true,
    content: publicContent(s.content),
  };
}

export type PublicSettings = ReturnType<typeof publicSettings>;

// ---------- Placeholder-credential safety net (v1.4 §C) ----------

/**
 * True when a provider key is empty or still a placeholder/demo value
 * ("000000…", "pk_test_PLACEHOLDER…", Cloudflare's always-pass "1x0000…").
 * Every feature gate (payments, social sign-in, Turnstile) treats such a
 * credential as OFF — a placeholder can never render a live button again,
 * even if the enabled flag is accidentally left on.
 */
export function isPlaceholderCredential(v: string | null | undefined): boolean {
  const s = (v || "").trim();
  if (!s) return true;
  if (/^0+$/.test(s)) return true; // "000000…"
  if (/placeholder/i.test(s)) return true; // "pk_test_PLACEHOLDER…"
  if (/^[123]x0000/.test(s)) return true; // Cloudflare Turnstile demo keys (always-pass / always-block)
  if (/^(changeme|xxx|test|demo|dummy|\*+)$/i.test(s)) return true;
  return false;
}
