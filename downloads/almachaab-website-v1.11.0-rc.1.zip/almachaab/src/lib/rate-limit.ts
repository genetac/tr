/**
 * Generic in-memory sliding-window rate limiter (v1.4 §F).
 * Fine for a single Node server; move to shared storage if the app ever
 * scales beyond one instance. Used by /api/orders (per-IP order cap).
 */

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

/** Consume one unit for `key`. Returns retry-after seconds when over the cap. */
export function rateLimit(key: string, max: number, windowMs: number): { limited: boolean; retryAfterSec: number } {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { limited: false, retryAfterSec: 0 };
  }
  b.count += 1;
  if (b.count > max) return { limited: true, retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
  return { limited: false, retryAfterSec: 0 };
}

/** Periodic sweep so expired windows don't pin memory. */
export function rateLimitSweep(): void {
  const now = Date.now();
  for (const [key, b] of buckets) if (b.resetAt < now) buckets.delete(key);
}

// ---------- Failure counters (count only failed attempts) ----------
// SEC-005: used by customer login — check before verifying, record on failure,
// clear on success. Same in-memory, single-server caveat as above.

const fails = new Map<string, Bucket>();

/** True (with retry-after) once `key` has `max` failures inside its window. */
export function failBlocked(key: string, max: number): { blocked: boolean; retryAfterSec: number } {
  const now = Date.now();
  const b = fails.get(key);
  if (!b || b.resetAt < now) return { blocked: false, retryAfterSec: 0 };
  return { blocked: b.count >= max, retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
}

export function failRecord(key: string, windowMs: number): void {
  const now = Date.now();
  const b = fails.get(key);
  if (!b || b.resetAt < now) fails.set(key, { count: 1, resetAt: now + windowMs });
  else b.count += 1;
  if (fails.size > 10_000) for (const [k, v] of fails) if (v.resetAt < now) fails.delete(k);
}

export function failClear(key: string): void {
  fails.delete(key);
}
