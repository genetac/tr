import { db } from "./db";
import { getSetting, setSetting } from "./settings";
import { sendPushToUser } from "./push";
import { emailWinBack } from "./mail";

/**
 * Retention CRM — automated win-back for dormant customers.
 *
 * A customer is "dormant" when their most recent order (any type) is older
 * than N days, or they registered N+ days ago and never ordered. Campaigns
 * target only customers who opted in to marketing push (PushSubscription
 * audience="customer") for the push leg; the email leg uses the account
 * address and respects the SMTP master switch inside sendMail().
 */

export interface DormantCustomer {
  userId: string;
  name: string;
  email: string;
  lastOrderAt: string | null;
  daysSilent: number;
  hasPush: boolean;
  points: number;
}

export async function findDormantCustomers(days: number): Promise<DormantCustomer[]> {
  const cutoff = new Date(Date.now() - Math.max(1, days) * 24 * 3600 * 1000);

  // Last order date per user (single grouped query — no N+1).
  const lastOrders = await db.order.groupBy({
    by: ["userId"],
    where: { userId: { not: null } },
    _max: { createdAt: true },
  });
  const lastByUser = new Map<string, Date | null>();
  for (const row of lastOrders) {
    if (row.userId) lastByUser.set(row.userId, row._max.createdAt || null);
  }

  // Users with opted-in marketing push.
  const pushUsers = new Set(
    (await db.pushSubscription.findMany({ where: { audience: "customer", userId: { not: null } }, select: { userId: true } })).map(
      (s) => s.userId as string
    )
  );

  // Loyalty balances.
  const profiles = await db.loyaltyProfile.findMany({ select: { userId: true, points: true } });
  const pointsByUser = new Map(profiles.map((p) => [p.userId, p.points]));

  const users = await db.user.findMany({
    where: { OR: [{ orders: { none: {} } }, { orders: { every: { createdAt: { lt: cutoff } } } }] },
    select: { id: true, name: true, email: true, createdAt: true },
  });

  const out: DormantCustomer[] = [];
  for (const u of users) {
    // Registered users must have had at least `days` days of exposure before
    // a brand-new account counts as dormant (never nudge a day-old signup).
    const last = lastByUser.get(u.id) || null;
    const anchor = last || u.createdAt;
    if (anchor && anchor > cutoff) continue;

    const daysSilent = Math.floor((Date.now() - anchor.getTime()) / 86400000);
    out.push({
      userId: u.id,
      name: u.name,
      email: u.email,
      lastOrderAt: last ? last.toISOString() : null,
      daysSilent,
      hasPush: pushUsers.has(u.id),
      points: pointsByUser.get(u.id) || 0,
    });
  }
  return out.sort((a, b) => b.daysSilent - a.daysSilent);
}

export interface WinBackOptions {
  days?: number; // dormancy threshold, default 14
  message?: string; // custom copy; default LT copy used when empty
  sendPush?: boolean;
  sendEmail?: boolean;
  baseUrl?: string;
}

export interface WinBackResult {
  targeted: number;
  pushSent: number;
  emailsSent: number;
  recipients: { name: string; email: string; push: boolean; emailed: boolean }[];
}

const DEFAULT_MESSAGE =
  "Jau kurį laiką nesimatėm — jūsų mėgstami Libano skoniai vis dar kvepia Alma Chaab virtuvėje. Užsisakykite atsiėmimui internetu ir grįžkite paragauti!";

export async function runWinBackCampaign(opts: WinBackOptions = {}): Promise<WinBackResult> {
  const loyalty=await getSetting<{enabled?:boolean}>('loyalty');
  if(!loyalty?.enabled)throw new Error('Lojalumo / CRM pilotas dar neįjungtas. Pirmiausia suderinkite taisykles ir sutikimus.');
  if(opts.sendEmail!==false)throw new Error('Reklaminiai laiškai išjungti, kol neįgyvendintas ir nepatikrintas atskiras el. pašto sutikimų bei atsisakymo procesas.');

  const days = Math.max(1, Math.min(365, Math.floor(opts.days ?? 14)));
  const message = (opts.message || DEFAULT_MESSAGE).slice(0, 600);
  const baseUrl = (opts.baseUrl || "https://almachaab.lt").replace(/\/$/, "");
  const dormant = await findDormantCustomers(days);

  let pushSent = 0;
  let emailsSent = 0;
  const recipients: WinBackResult["recipients"] = [];

  for (const c of dormant) {
    let didPush = false;
    let didEmail = false;
    // Fire-and-forget per recipient — one slow mailbox must not stall the run.
    const jobs: Promise<void>[] = [];
    if (opts.sendPush !== false && c.hasPush) {
      jobs.push(
        sendPushToUser(c.userId, {
          title: "Seniai matėmės Alma Chaab? ✦",
          body: message.slice(0, 140),
          tag: "alma-winback",
          url: "/mano",
        })
          .then((r) => {
            if (r.sent > 0) {
              pushSent++;
              didPush = true;
            }
          })
          .catch(() => {})
      );
    }
    if (opts.sendEmail !== false && c.email) {
      jobs.push(
        emailWinBack(c.email, c.name, message, baseUrl)
          .then((r) => {
            if (r.ok) {
              emailsSent++;
              didEmail = true;
            }
          })
          .catch(() => {})
      );
    }
    await Promise.all(jobs);
    if (didPush || didEmail) recipients.push({ name: c.name, email: c.email, push: didPush, emailed: didEmail });
  }

  const result: WinBackResult = { targeted: dormant.length, pushSent, emailsSent, recipients };
  await setSetting("crmLastRun", { at: new Date().toISOString(), days, ...result, recipients: undefined });
  return result;
}

export async function getLastRun() {
  return getSetting<{ at: string; days: number; targeted: number; pushSent: number; emailsSent: number } | null>("crmLastRun");
}
