import {peopleInfo} from "./business-content";
/**
 * Reusable JSON-LD (schema.org) builders — server-side only.
 * Used by the home page (Restaurant + FAQPage) and article pages (Article).
 */

export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXTAUTH_URL || "https://almachaab.lt";

type SiteInfo = {
  name: string;
  phone: string;
  address?: string;
  woltUrl: string;
  mapsUrl: string;
  facebookUrl?: string;
  legalName?: string;
  companyCode?: string;
};

/** Owners — public business roles (press: Kėdainių mugė, 2025-07-16). */
export const OWNERS = [
  { "@type": "Person", name: "Irina Eid", jobTitle: "Vadovė", url: `${SITE_URL}/apie-mus` },
  { "@type": "Person", name: "Elie Eid", jobTitle: "Virtuvės šefas", url: `${SITE_URL}/apie-mus` },
];

/** Independent press coverage, linked as subjectOf. */
export const PRESS = [
  {
    "@type": "NewsArticle",
    headline: "Restoranas „Alma Chaab“: rytietiški skoniai Kėdainių senamiestyje",
    url: "https://muge.eu/restoranas-alma-chaab-rytietiski-skoniai-kedainiu-senamiestyje/",
    datePublished: "2025-07-16",
    author: { "@type": "Person", name: "Asta Raicevičienė" },
    publisher: { "@type": "Organization", name: "Kėdainių mugė", url: "https://muge.eu" },
  },
];

type Rating = { mode: string; score: number; count: number };

type Hours = Record<string, [number, number] | null>;

const DAY_MAP: Record<string, string> = {
  mon: "Monday",
  tue: "Tuesday",
  wed: "Wednesday",
  thu: "Thursday",
  fri: "Friday",
  sat: "Saturday",
  sun: "Sunday",
};

function fmtHour(n: number): string {
  return `${String(Math.floor(n)).padStart(2, "0")}:${n % 1 ? "30" : "00"}`;
}

/** Group DB-driven hours into canonical OpeningHoursSpecification entries. */
export function openingHoursSpec(hours: Hours) {
  const grouped: Record<string, string[]> = {};
  for (const [k, v] of Object.entries(hours)) {
    if (!v) continue; // closed days are omitted
    const key = `${v[0]}-${v[1]}`;
    (grouped[key] ||= []).push(DAY_MAP[k]);
  }
  return Object.entries(grouped).map(([key, days]) => {
    const [o, c] = key.split("-").map(Number);
    return {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: days,
      opens: fmtHour(o),
      closes: fmtHour(c),
    };
  });
}

/** Restaurant / LocalBusiness schema for the home page. */
type MenuCat = { name: string; items: { name: string; price: number; description?: string | null }[] };

/** Strip emoji markers (🌶️ etc.) from menu names for structured data. */
function cleanName(s: string): string {
  return s.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, "").replace(/\s+/g, " ").trim();
}

/** schema.org Menu built from the live (active) menu categories. */
export function menuJsonLd(categories: MenuCat[]) {
  return {
    "@type": "Menu",
    "@id": `${SITE_URL}/#meniu`,
    name: "Alma Chaab meniu",
    inLanguage: "lt",
    url: `${SITE_URL}/#meniu`,
    hasMenuSection: categories
      .filter((c) => c.items.length)
      .map((c) => ({
        "@type": "MenuSection",
        name: c.name,
        hasMenuItem: c.items.map((i) => ({
          "@type": "MenuItem",
          name: cleanName(i.name),
          ...(i.description ? { description: i.description } : {}),
          offers: { "@type": "Offer", price: i.price.toFixed(2), priceCurrency: "EUR" },
        })),
      })),
  };
}

// `rating` is kept in the signature for compatibility but no longer emitted:
// Google does not allow review markup copied from third-party sites (Google Maps),
// and self-serving LocalBusiness ratings never earn stars anyway.
export function restaurantJsonLd(site: SiteInfo, _rating: Rating, hours: Hours, menu?: MenuCat[], content?:any) {
  const spec = openingHoursSpec(hours);
  return {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    "@id": SITE_URL,
    name: site.name,
    url: SITE_URL,
    image: [`${SITE_URL}/images/og-cover.jpg`],
    logo: `${SITE_URL}/icon-512.png`,
    description:
      "Libaniškos ir Artimųjų Rytų virtuvės restoranas Kėdainių senamiestyje. Pietūs, vakarienės, banketai, maistas išsinešimui ir staliuko rezervacija internetu.",
    telephone: site.phone,
    priceRange: "€€",
    servesCuisine: ["Libanietiška virtuvė", "Artimųjų Rytų virtuvė", "Europietiška virtuvė"],
    currenciesAccepted: "EUR",
    paymentAccepted: "Grynieji, kortelė",
    acceptsReservations: "True",
    hasMenu: menu && menu.length ? menuJsonLd(menu) : `${SITE_URL}/#meniu`,
    address: site.address || "Didžioji g. 25, Kėdainiai",
    contactPoint: {
      "@type": "ContactPoint",
      telephone: site.phone,
      contactType: "reservations",
      areaServed: "LT",
      availableLanguage: ["lt", "en", "ru"],
    },
    ...(spec.length ? { openingHoursSpecification: spec } : {}),
    sameAs: [site.facebookUrl, site.woltUrl, site.mapsUrl].filter(Boolean),
    ...(site.legalName ? { legalName: site.legalName } : {}),
    ...(site.companyCode
      ? { identifier: { "@type": "PropertyValue", propertyID: "Juridinio asmens kodas", value: site.companyCode } }
      : {}),
    founder: peopleInfo(content).filter(p=>p.id==='irina').map(p=>({"@type":"Person",name:p.name,jobTitle:p.role})),
    employee: peopleInfo(content).map(p=>({"@type":"Person",name:p.name,jobTitle:p.role})),
    subjectOf: PRESS,
  };
}

/** FAQPage schema — mirrors the visible FAQ accordion. */
export function faqJsonLd(faq: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faq.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

/** Article / BlogPosting schema for /straipsniai/[slug]. */
export function articleJsonLd(
  a: {
    title: string;
    excerpt: string | null;
    coverImage: string | null;
    keywords: string | null;
    publishedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
    slug: string;
  },
  siteName: string,
  author?: { name: string; role?: string } | null
) {
  const cover = a.coverImage
    ? a.coverImage.startsWith("http")
      ? a.coverImage
      : `${SITE_URL}${a.coverImage}`
    : `${SITE_URL}/images/og-cover.jpg`;
  return {
    "@context": "https://schema.org",
    // BlogPosting (subtype of Article) — recognized by Google's Article rich result.
    "@type": "BlogPosting",
    headline: a.title,
    description: a.excerpt || undefined,
    image: [cover],
    datePublished: (a.publishedAt ?? a.createdAt).toISOString(),
    dateModified: a.updatedAt.toISOString(),
    keywords: a.keywords || undefined,
    inLanguage: "lt-LT",
    author: author?.name
      ? { "@type": "Person", name: author.name, ...(author.role ? { jobTitle: author.role } : {}), url: `${SITE_URL}/apie-mus` }
      : { "@type": "Organization", name: siteName, url: SITE_URL },
    publisher: {
      "@type": "Organization",
      name: siteName,
      logo: { "@type": "ImageObject", url: `${SITE_URL}/icon-512.png` },
    },
    mainEntityOfPage: { "@type": "WebPage", "@id": `${SITE_URL}/straipsniai/${a.slug}` },
  };
}
