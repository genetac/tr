import { EventEmitter } from "events";

/**
 * Lightweight in-process event bus used by the Server-Sent-Events (SSE) routes.
 * Every order mutation (customer checkout, kitchen status change, payment
 * webhook) publishes here; /api/orders/stream and /api/track/[number]/stream
 * subscribe and push updates to connected browsers instantly.
 *
 * Singleton lives on globalThis so dev-server HMR or route isolation never
 * splits the bus in two.
 */

export interface OrderEvent {
  type: "created" | "updated" | "paid" | "deleted";
  orderId: string;
  number: string;
  status?: string;
  paymentStatus?: string;
  at: string;
}

const g = globalThis as unknown as { __almaOrderBus?: EventEmitter };

export function orderBus(): EventEmitter {
  if (!g.__almaOrderBus) {
    const emitter = new EventEmitter();
    emitter.setMaxListeners(200);
    g.__almaOrderBus = emitter;
  }
  return g.__almaOrderBus;
}

export function publishOrderEvent(ev: Omit<OrderEvent, "at">) {
  try {
    orderBus().emit("order", { ...ev, at: new Date().toISOString() } satisfies OrderEvent);
  } catch {
    // publishing must never break the request that triggered it
  }
}
