"use client";

import { useEffect, useSyncExternalStore } from "react";

/**
 * Data loading on mount (and optionally on an interval) — the one place where
 * admin and account screens kick off their fetches. Loaders may set state
 * (loading flags, results); that happens in response to the fetch, not as a
 * render cascade from the effect body itself.
 */
export function useLoadEffect(load: () => unknown, intervalMs = 0): void {
  useEffect(() => {
    void load();
    if (!intervalMs) return;
    const t = setInterval(() => void load(), intervalMs);
    return () => clearInterval(t);
  }, [load, intervalMs]);
}

const noSubscribe = () => () => {};

/** A browser-only value (window.location, localStorage…) without a setState-in-effect round trip. */
export function useClientValue<T>(getClient: () => T, serverValue: T): T {
  return useSyncExternalStore(noSubscribe, getClient, () => serverValue);
}
