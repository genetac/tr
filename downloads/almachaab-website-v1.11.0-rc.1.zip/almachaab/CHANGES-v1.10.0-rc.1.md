# v1.10.0-rc.1 — unified scope and deployment candidate

- Unified the client letter, agreed work, optional €50 loyalty pilot, hosting decision and launch gates.
- Added owner-confirmed visitor information, shared billiards prices/cutoff and corrected Irina/Elie roles. Removed the outdated September offer and changing-team feature.
- Added independent vegetarian/vegan/halal fields, notes, accessible labels and menu filters. Existing dishes remain unclassified.
- Added server-side content drafts, authenticated preview, publication and stale-write protection. Hidden sections and incomplete events are omitted from public data.
- Added shared two-level desktop/mobile navigation, additional content sections and visibility controls.
- Retained four music dates as internal draft notes, moved ten existing articles to review drafts, and added authenticated article preview.
- Hid sample gallery photographs, added gallery alternative text and retained secure image uploads/replacement.
- Added an editable optional Bolt Food listing URL without inventing a destination. Removed inactive loyalty promises and made loyalty off by default.
- Added additive/idempotent data migration, portable frozen dependency installation, offline initial-admin password setup, safer packaging and Lithuanian admin/deployment guides.

This is a release candidate. External hosting/domain, mail/push, business content approvals and optional provider integrations remain launch gates. See docs/RELEASE-STATUS.md for actual executed checks and remaining limitations. No public deployment was performed.
