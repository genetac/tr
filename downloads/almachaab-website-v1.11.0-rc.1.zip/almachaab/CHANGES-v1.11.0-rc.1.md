# v1.11.0-rc.1 — restaurant content management

- Existing-dish dietary controls: per-dish visibility, kitchen review, independent classifications, optional public description, private notes, global display/filter switches.
- Shared CMS drafts, optimistic revisions, autosave, persistent history (50 previous snapshots), draft restore and session undo/redo for public content, pages/articles, menu documents and theme/business settings.
- Homepage click-to-edit text/photos, constrained colour/alignment, section visibility/order and real responsive preview frames.
- Standalone About/privacy/custom pages, visual blocks, document-style article writing, protected previews, public metadata, sitemap and old-address redirects.
- Shared people/visitor/business blocks; Lithuanian navigation, dedicated events/navigation screens, media metadata and upload handling.
- Individually revocable staff accounts, editor publication permission, kitchen access, private internal support threads/attachments.
- Additive dietary migration and idempotent visual-page migration; safe staged package sanitation. Loyalty remains disabled and legacy marketing-email sends are blocked pending a complete consent/unsubscribe workflow.

See docs/RELEASE-STATUS.md for tested scope and production launch requirements. No public deployment, paid hosting order or real provider/device verification is included.
